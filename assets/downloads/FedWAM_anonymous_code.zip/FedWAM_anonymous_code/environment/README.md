# Environment Versions

- `lawam_observed`: LaWAM main-experiment environment, including MuJoCo 2.3.7.
- `imagewam_observed`: ImageWAM model and visualization environment.
- `lawam_qualitative_observed`: LaWAM native qualitative capture environment,
  including MuJoCo 3.3.2, used for the supplied H8 task video.

Each record lists the installed Python and distribution versions. Use separate
model environments and install the platform-specific native dependencies
specified by the pinned upstream projects.
