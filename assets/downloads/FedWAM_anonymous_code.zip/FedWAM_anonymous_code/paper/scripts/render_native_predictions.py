"""Lay out verified native predictions; never run a model or synthesize pixels.

Run with the project .venv-imagewam/bin/python. Inputs remain in the media
bundle; the manifest records every input used and its SHA256 digest.
"""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
from PIL import Image

PAPER = Path(__file__).resolve().parents[1]
SOURCE = PAPER.parent / 'reports/paper_prediction_media_20260926'
OUTPUT = PAPER / 'figures/native_predictions'
OUTPUT.mkdir(parents=True, exist_ok=True)
INPUTS = {}
FIGURES = {}
plt.rcParams.update({'font.size': 8.5, 'axes.titlesize': 8.5,
                     'font.family': 'DejaVu Sans', 'pdf.fonttype': 42})


def record(path):
    INPUTS[str(path.relative_to(SOURCE))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return path


def metadata(model):
    return json.loads(record(SOURCE / model / 'result.json').read_text())


def rgb(path):
    return np.asarray(Image.open(record(path)).convert('RGB'))


def save(fig, name, rows):
    for ax in fig.axes:
        if ax.get_label() != 'colorbar':
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
    # Fixed 5.5-inch canvas matches the manuscript's actual text width.
    for suffix in ('pdf', 'png'):
        fig.savefig(OUTPUT / f'{name}.{suffix}', dpi=300, facecolor='white', **({'metadata': {'Creator': 'Anonymous artifact', 'CreationDate': None, 'ModDate': None}} if suffix == 'pdf' else {}))
    plt.close(fig)
    FIGURES[name] = {'starts': [x['start'] for x in rows],
                     'ends': [x['end'] for x in rows]}


def lawam(rows, name, complete=False):
    nrows = 4 if complete else 3
    compact = not complete
    fig, axes = plt.subplots(nrows, len(rows), figsize=(2.65, 2.15) if compact else (5.5, 4.55), squeeze=False)
    for col, row in enumerate(rows):
        folder = SOURCE / 'lawam' / row['folder']
        axes[0, col].imshow(rgb(folder / 'current.png'))
        if row['start'] == 0:
            axes[0, col].add_patch(Rectangle((112, 32), 16, 16, fill=False,
                                           edgecolor='#00ff00', linewidth=1.2))
        axes[0, col].set_title(f"t={row['start']}" if compact else f"{row['start']} → {row['end']}",
                              fontsize=8 if compact else 8.5, pad=3 if compact else 6)
        axes[1, col].imshow(rgb(folder / 'predicted_pca_16x16.png'), interpolation='nearest')
        actual = rgb(folder / 'actual_end.png')
        axes[2, col].imshow(actual)
        values = np.load(record(folder / 'patch_cosine.npy'))
        axes[2, col].imshow(values, cmap='magma', vmin=-1, vmax=1,
                           extent=(-.5, 255.5, 255.5, -.5), interpolation='bilinear', alpha=.5)
        if complete:
            axes[3, col].imshow(actual)
    labels = ['RGB', 'PCA', 'Sim.'] if compact else ['Current RGB', 'Predicted PCA', 'Similarity on\nactual endpoint']
    if complete:
        labels.append('Actual RGB')
    for ax, label in zip(axes[:, 0], labels):
        ax.set_ylabel(label, labelpad=3 if compact else 6, fontsize=8 if compact else 8.5)
    fig.subplots_adjust(left=.14 if compact else .13, right=.99,
                        top=.89 if compact else .925, bottom=.20 if compact else .15,
                        wspace=.05, hspace=.07)
    cb = fig.add_axes([.55, .10 if compact else .095, .35, .017], label='colorbar')
    # Unblended scalar scale, not the alpha-blended RGB overlay.
    fig.colorbar(plt.cm.ScalarMappable(norm=plt.Normalize(-1, 1), cmap='magma'),
                 cax=cb, orientation='horizontal', ticks=[-1, 0, 1])
    if compact:
        cb.tick_params(labelsize=8, length=2, pad=1)
        fig.text(.14, .10, 'Cosine', fontsize=8)
    else:
        cb.set_xlabel('Cosine similarity', fontsize=8.5, labelpad=0)
        fig.text(.13, .083, 'Fixed initial patch;\nfixed PCA mapping', fontsize=8.5)
    save(fig, name, rows)


def imagewam(rows, name):
    fig, axes = plt.subplots(3, len(rows), figsize=(5.5, 4.7 if len(rows) == 3 else 2.8), squeeze=False)
    for col, row in enumerate(rows):
        folder = SOURCE / 'imagewam' / row['folder']
        for line, key in enumerate(('current', 'predicted_future', 'actual_future')):
            axes[line, col].imshow(rgb(folder / f'{key}_front.png'))
        axes[0, col].set_title(f"{row['start']} → {row['end']}")
    for ax, label in zip(axes[:, 0], ('Current RGB', 'Predicted RGB', 'Actual RGB')):
        ax.set_ylabel(label, labelpad=6)
    fig.subplots_adjust(left=.11, right=.99, top=.925 if len(rows) == 3 else .88,
                        bottom=.035, wspace=.04, hspace=.06)
    save(fig, name, rows)


if __name__ == '__main__':
    law = metadata('lawam')['chunks']
    img = metadata('imagewam')['examples']
    record(SOURCE / 'lawam/visualization_protocol.json')
    record(SOURCE / 'lawam/pca_projection.npz')
    lawam([law[i] for i in (0, 3, 6, 9)], 'lawam_main')
    lawam(law[:5], 'lawam_all_1', complete=True)
    lawam(law[5:], 'lawam_all_2', complete=True)
    imagewam([img[i] for i in (0, 2, 5)], 'imagewam_main')
    imagewam(img, 'imagewam_all')
    manifest = {'source': '../../reports/paper_prediction_media_20260926',
                'scope': 'Native pretrained checkpoints; no federated updates',
                'selection': 'Main panels use rounded uniformly spaced indices; appendix retains all recorded predictions',
                'figures': FIGURES, 'source_sha256': INPUTS}
    (OUTPUT / 'provenance.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'Rendered {len(FIGURES)} figures from {len(INPUTS)} recorded inputs.')
