"""Wait for the user's own HF login, then fetch the authorized official AE."""
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
os.environ['HF_HOME'] = str(ROOT / 'cache/imagewam/huggingface')
os.environ['HF_HUB_OFFLINE'] = '0'
os.environ['HF_ENDPOINT'] = 'https://huggingface.co'
os.environ['HF_HUB_DISABLE_XET'] = '1'
from huggingface_hub import hf_hub_download
from huggingface_hub.errors import GatedRepoError


def main():
    report = ROOT / 'reports/imagewam_preparation/ae.json'
    deadline = time.monotonic() + 23 * 3600
    candidates = [Path(os.environ['HF_HOME']) / 'token', Path.home() / '.cache/huggingface/token']
    while time.monotonic() < deadline:
        token = os.environ.get('HF_TOKEN')
        if not token:
            token = next((p.read_text().strip() for p in candidates if p.is_file()), None)
        if token:
            try:
                report.write_text(json.dumps({'state': 'downloading', 'repository': 'black-forest-labs/FLUX.2-dev'}))
                path = hf_hub_download('black-forest-labs/FLUX.2-dev', 'ae.safetensors',
                    revision='26afe3a78bb242c0a8bb181dcc8937bb16e5c66c', token=token,
                    local_dir=ROOT / 'assets/imagewam/flux2_ae')
                digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
                if digest != '868fe7b343cc8f3a19dbcfcafbc3d5f888802be3f89bd81b65b3621a066ce8f3':
                    raise ValueError('Official AE SHA256 mismatch')
                report.write_text(json.dumps({'state':'verified','path':path,'sha256':digest},indent=2))
                print('Official gated AE downloaded and hash verified.', flush=True)
                return
            except GatedRepoError:
                state='waiting_for_authorized_login'
        else:
            state='waiting_for_login'
        report.write_text(json.dumps({'state':state,'token_value_recorded':False}))
        time.sleep(30)
    raise SystemExit('Login wait expired; rerun after logging in. No other assets removed.')


if __name__ == '__main__':
    main()
