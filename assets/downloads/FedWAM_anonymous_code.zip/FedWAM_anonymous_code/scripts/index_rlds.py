"""Index full raw episodes with source and image evidence, without converted-order guesses."""
from pathlib import Path
import io,sys,traceback
from collections import Counter
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,save,load,status,digest,file_hash
from fedwam.rlds import iter_records,parse_episode,feature_payloads,feature_values
from fedwam.data_contracts import source_category
REPORT=ROOT/'reports/data/index'
def main():
    import numpy as np
    import google_crc32c
    from PIL import Image
    raw=ROOT/'data/libero_plus_rlds/libero_mix/1.0.0'
    lengths=list(map(int,load(raw/'dataset_info.json')['splits'][0]['shardLengths']))
    rows=[]
    for idx,n in enumerate(lengths):
        path=raw/f'libero_mix-train.tfrecord-{idx:05d}-of-01024'
        receipt=REPORT/'shards'/f'{idx:05d}.json'
        observed=load(ROOT/'reports/data/recovery/shards'/f'{path.name}.json')
        if receipt.exists():
            report=load(receipt)
            if report['sha256']!=observed['sha256']:raise ValueError('Indexed shard changed')
            group=report['rows']
        else:
            group=[]
            for j,(offset,payload) in enumerate(iter_records(path,crc_function=google_crc32c.value)):
                row=parse_episode(payload);features=feature_payloads(payload)
                image_keys=[k for k in features if k.startswith('steps/observation/') and (k.endswith('/image') or k.endswith('/wrist_image'))]
                if len(image_keys)!=2:raise ValueError(f'Unexpected image keys: {list(features)}')
                image_evidence={}
                for key in image_keys:
                    frames=feature_values(features[key],1)
                    if len(frames)!=row['length']:raise ValueError('Image/action sequence length mismatch')
                    # Validate every encoded frame, not just three pilot thumbnails.
                    formats=set();shapes=set()
                    for frame in frames:
                        with Image.open(io.BytesIO(frame)) as im:
                            formats.add(im.format);shapes.add(im.size);im.load()
                            if im.mode!='RGB':raise ValueError('Expected encoded RGB observation')
                    image_evidence[key]={'count':len(frames),'formats':sorted(formats),'sizes':[list(x) for x in sorted(shapes)]}
                numeric=REPORT/'numeric'/f'{idx:05d}_{j:03d}.npz';numeric.parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(numeric,action=feature_values(features['steps/action'],2).reshape(-1,7),
                    state=feature_values(features['steps/observation/state'],2).reshape(-1,8))
                row.update(record_id=f'{idx:05d}:{j:03d}',shard=str(path),offset=offset,category=source_category(row['source_bucket']),
                    images=image_evidence,legal_chunk_count=max(0,row['length']-8),numeric_path=str(numeric),
                    exact_group=digest([row['action_sha256'],row['state_sha256'],row['length']]))
                group.append(row)
            if len(group)!=n:raise ValueError(f'Shard record count mismatch {idx}: {len(group)} != {n}')
            save(receipt,{'sha256':observed['sha256'],'rows':group,'crc32c_verified':True})
        rows.extend(group)
        status(REPORT,state='running',phase='raw_image_numeric_validation',shards=idx+1,total=1024,records=len(rows))
    buckets=dict(Counter(r['source_bucket'] for r in rows));coverage=dict(Counter(f"{r['suite']}/{r['category']}" for r in rows))
    save(ROOT/'manifests/raw_episodes.json',{'rows':rows,'records':len(rows),'buckets':buckets,'coverage':coverage,
        'status':'raw_index_only_not_training_split','remaining_gates':['near-duplicate source grouping','seven-client source coverage','train variant and initialization audit']})
    status(REPORT,state='completed',phase='raw_index_not_training_acceptance',records=len(rows),buckets=buckets,coverage=coverage)
if __name__=='__main__':
    try:main()
    except Exception as e:status(REPORT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
