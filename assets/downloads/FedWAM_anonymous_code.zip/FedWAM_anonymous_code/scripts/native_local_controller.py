"""Aggregate only four verified native local training runs."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,NATIVE_LOCAL_STORAGE_ROOT,load
from fedwam.round_runtime import atomic_json
from train_native_local import run_identity

CLIENTS=('lighting','camera_pose','sensor_noise','background')
def finalize(mode):
 steps,micro=(2,2) if mode=='engineering' else (25000,32)
 ident=run_identity(mode,steps,micro);refs={}
 for client in CLIENTS:
  root=NATIVE_LOCAL_STORAGE_ROOT/mode/client
  receipt=load(root/'verification.json')
  if receipt.get('passed') is not True or receipt.get('identity')!=ident:raise ValueError('Incomplete native local '+client)
  refs[client]=dict(run=str(root),ref=receipt['ref'],updates=receipt['updates'],draw=receipt['draw'])
 out=ROOT/'reports/native_local_seed42_v3'/mode
 atomic_json(out/'summary.json',dict(passed=True,identity=ident,clients=refs,mode=mode,
          scope='official loss/optimizer local adaptation from released LIBERO SFT on accepted PLUS train data'))
def main():
 p=argparse.ArgumentParser();p.add_argument('--mode',choices=['engineering','formal'],required=True);args=p.parse_args();finalize(args.mode)
if __name__=='__main__':main()
