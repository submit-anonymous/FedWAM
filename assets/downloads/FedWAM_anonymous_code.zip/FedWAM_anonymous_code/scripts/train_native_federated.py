"""One native LaWAM client stage with private VLM/world/action optimizer states."""
import argparse,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,NATIVE_STORAGE_ROOT,load,digest
from fedwam.native_federation import native_config,NativeLaWAMFederation
from fedwam.native_execution import native_identity,native_gate
from fedwam.native_engine import NativeDetachedEngine
from fedwam.detached_engine import DependencyPending
from fedwam.round_runtime import atomic_json
from fedwam.experiment_config import METHODS

def record_resource_retry(root,client,limit=12):
 path=Path(root)/f'resource_retries/{client}.json'
 current=load(path)['count'] if path.exists() else 0
 if current>=limit:raise RuntimeError('Allocated GPU remained occupied after bounded retries')
 count=current+1
 atomic_json(path,dict(count=count,limit=limit,client=client))
 marker=f'resource_retries/{client}-{count:04d}.json'
 atomic_json(Path(root)/marker,dict(retry_ready=True,count=count,client=client))
 return marker

def main():
 p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,required=True)
 p.add_argument('--mode',choices=['engineering','formal'],required=True);p.add_argument('--run',type=Path,required=True)
 p.add_argument('--client',required=True);p.add_argument('--attempt',required=True);p.add_argument('--token',required=True);args=p.parse_args()
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Slurm GPU allocation required')
 cfg=native_config(args.method,args.mode);ident=native_identity(cfg);root=args.run.resolve()
 if not root.is_relative_to(NATIVE_STORAGE_ROOT.resolve()):raise ValueError('Run outside native account storage')
 clients=['pooled'] if args.method=='M9' else cfg['clients']
 if args.client not in clients:raise ValueError('Unknown client')
 if args.mode=='formal':native_gate(cfg,load(ROOT/'reports/native_fedwam_engineering_v6/summary.json'))
 result=root/f'client_job_state/{args.client}.json';transport=None;engine=None
 def status(**kw):atomic_json(result,dict(attempt=args.attempt,token=args.token,job=os.environ['SLURM_JOB_ID'],client=args.client,**kw))
 try:
  status(state='loading_model')
  import torch,acceptance
  from model_probe import frozen_hash
  acceptance.OUT=root/'model_acceptance'/args.client/args.token
  policy,_,transport=acceptance.model()
  if torch.cuda.device_count()!=1:raise ValueError('One visible GPU per client required')
  uuid=str(getattr(torch.cuda.get_device_properties(0),'uuid',''))
  if not uuid:raise ValueError('Missing GPU UUID')
  interface=digest({k:ident[k] for k in ('data_identity','checkpoint_sha256','normalization_sha256','model_config_sha256','native_protocol_sha256')})+':native-deployed-intent:H8:20Hz:'+cfg['representation']
  backend=NativeLaWAMFederation(policy,cfg,root,interface);backend._enable('pre');frozen=frozen_hash(policy)
  engine=NativeDetachedEngine(root,ident,cfg,backend,args.client,args.attempt)
  pending=None;ref=None
  try:ref=engine.run_client()
  except DependencyPending as error:pending=error.name
  backend._enable('pre')
  if frozen_hash(policy)!=frozen:raise ValueError('Frozen foundation changed')
  if pending:status(state='waiting_dependency',wait=pending,gpu_uuid=uuid,gpu_released_on_exit=True)
  else:
   state=engine.store.read_ref(ref)['state']
   changed={k:any(not torch.equal(v,getattr(backend,'base_'+k)[name]) for name,v in state[k].items()) for k in ('world','action','vlm','aux')}
   changed['updates']=state['total_updates']
   if not all(changed[k] for k in ('world','action','vlm','aux')):raise ValueError('Missing native private module update')
   atomic_json(root/f'client_verification/{args.client}.json',dict(passed=True,identity=ident,attempt=args.attempt,ref=ref,module_updates=changed,frozen_sha256=frozen,gpu_uuid=uuid))
   status(state='training_completed',gpu_uuid=uuid)
 except Exception as error:
  if engine is None and isinstance(error,RuntimeError) and str(error).startswith('Allocated GPU already occupied or insufficient memory'):
   try:marker=record_resource_retry(root,args.client)
   except Exception as terminal:
    status(state='failed',error=repr(terminal));raise
   status(state='waiting_dependency',wait=marker,reason='allocated_gpu_occupied',gpu_released_on_exit=True)
   return
  if engine:engine.fail(error)
  status(state='failed',error=repr(error));raise
 finally:
  if transport:transport.close()
if __name__=='__main__':main()
