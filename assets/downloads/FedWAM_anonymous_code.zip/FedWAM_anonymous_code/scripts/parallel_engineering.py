"""Require all ten real process-per-client checks before seed43 formal work."""
import argparse,sys,subprocess,time,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,digest
from fedwam.experiment_config import METHODS,resolved_config
from fedwam.parallel_execution import parallel_identity
from fedwam.round_runtime import atomic_json
from fedwam.retention import compact_completed_run
OUT=ROOT/'reports/parallel_engineering'
def main():
 started=time.perf_counter();ident=parallel_identity(resolved_config('M1',43,'engineering'));tag=digest(ident)[:16];passed=[]
 for method in METHODS:
  expected=parallel_identity(resolved_config(method,43,'engineering'));root=ROOT/'runs/parallel_engineering'/tag/method
  atomic_json(OUT/'status.json',{'state':'running','method':method,'passed':passed,'seed':43})
  if not (root/'verification.json').exists() or load(root/'verification.json').get('identity')!=expected:
   n=1 if method=='M9' else 4
   cmd=['srun','--exclusive','--ntasks='+str(n),'--cpus-per-task=8','--gpus-per-task=staff:1','--gpu-bind=single:1','--kill-on-bad-exit=1',sys.executable,'-u',str(ROOT/'scripts/train_parallel.py'),'--method',method,'--seed','43','--mode','engineering','--run',str(root),'--attempt',uuid.uuid4().hex]
   subprocess.run(cmd,check=True,cwd=ROOT)
  result=load(root/'verification.json')
  if result.get('passed') is not True or result.get('identity')!=expected:raise ValueError('Failed parallel method: '+method)
  compact_completed_run(root,expected)
  passed.append(method)
 if parallel_identity(resolved_config('M1',43,'engineering'))!=ident:raise ValueError('Implementation changed during acceptance')
 summary={k:ident[k] for k in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','execution')}
 summary.update(passed=True,mode='real_parallel_client_engineering',methods_passed=passed,seed=43,seconds=time.perf_counter()-started,runs_root=str(ROOT/'runs/parallel_engineering'/tag),scope='engineering budgets only; not scientific results')
 atomic_json(OUT/'summary.json',summary);atomic_json(OUT/'status.json',{'state':'completed','methods_passed':passed,'seed':43})
if __name__=='__main__':
 try:main()
 except Exception as e:atomic_json(OUT/'status.json',{'state':'failed','error':repr(e)});raise
