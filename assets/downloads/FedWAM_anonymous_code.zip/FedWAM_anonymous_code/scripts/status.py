"""Concise status from actual reports, never from a planned experiment row."""
from pathlib import Path
import json,subprocess
ROOT=Path(__file__).resolve().parents[1]
def read(p):
    try:return json.loads((ROOT/p).read_text())
    except (FileNotFoundError,json.JSONDecodeError):return {}
print('项目:',ROOT)
native_plan=read('manifests/fedwam_seed42_native_v6_work_plan.json')
if not native_plan and read('configs/native_fedwam_protocol_v2.json').get('seed') == 42:
    print('当前方案: LaWAM 主体优先，seed42；ImageWAM 扩展暂停')
    print('新正式计划: 尚未冻结；先确认检查点存储及完成新版真实模型验收')
    print('旧检查点清理: 候选已列出，尚未获准删除；docs/seed42-cleanup-candidates.md')
    print('历史 seed43 工程状态不计作当前训练进度。')
    r=subprocess.run(['squeue','-u','anonymous','-h','-o','%i %j %T %R'],capture_output=True,text=True)
    for line in r.stdout.splitlines():
        if 'fwfull-' in line:print('Slurm:',line)
    raise SystemExit(0)
if native_plan:
    print('当前方案: native LaWAM v6，seed42，四个独立单卡客户端任务')
    local=read('reports/native_local_seed42_v3/engineering/summary.json')
    print('真实模型本地训练验收:', '通过' if local.get('passed') is True else '未通过/待运行')
    prefix='reports/native_fedwam_engineering_v6/'
    status=read(prefix+'status.json');summary=read(prefix+'summary.json')
    print('联邦工程验收:',status.get('state','未启动'),'| 当前',status.get('method',''),
          '| 通过',len(summary.get('methods_passed',status.get('passed',[]))),'/10')
    storage=read(prefix+'startup_storage.json')
    if storage:
        print('存储:',storage.get('state'),'| 可用 %.1f GiB | 要求 %.1f GiB' %
              (storage.get('free_bytes',0)/1024**3,storage.get('required_free_bytes',0)/1024**3))
    error=read(prefix+'pipeline_error.json')
    if error.get('error'):print('控制器错误:',str(error['error'])[:180])
    from collections import Counter
    queue_path=Path(native_plan['root'])/'scheduler/queue.json'
    if queue_path.exists():
        tasks=json.loads(queue_path.read_text()).get('tasks',{})
        planned={t['id']:t for t in native_plan['tasks']}
        rows=[dict(planned[key],**value) for key,value in tasks.items()] if isinstance(tasks,dict) else tasks
        print('正式训练任务:',dict(Counter(t.get('state','unknown') for t in rows if t.get('kind')=='detached_train')))
        print('正式评测任务:',dict(Counter(t.get('state','unknown') for t in rows if t.get('kind')!='detached_train')))
    r=subprocess.run(['squeue','-u','anonymous','-h','-o','%i %j %T %R'],capture_output=True,text=True)
    for line in r.stdout.splitlines():
        if 'fwfull-' in line:print('Slurm:',line)
    print('历史受限训练与 seed43 / v1–v5 验收不计入本轮完成数。')
    raise SystemExit(0)
x=read('reports/environment/ready.json');print('独立环境:', '已安装' if x else '未完成')
x=read('reports/data/recovery/status.json')
raw=ROOT/'data/libero_plus_rlds/libero_mix/1.0.0'
available=sum(p.is_file() for p in raw.glob('libero_mix-train.tfrecord-*-of-01024'))
print('全量数据:',x.get('state','未启动'),'| 已落盘',available,'/1024 |',x.get('phase',''))
if x.get('phase')=='verify_existing':print('分片重新校验:',x.get('shards_checked',0),'/1024 | 已通过',x.get('reused',0),'| 隔离异常',x.get('quarantined',0))
if x.get('error'):print('数据错误:',str(x['error'])[:160])
x=read('reports/data/index/status.json');print('数据索引:',x.get('state','等待全量分片'),'| 已验证记录',x.get('records',0))
x=read('reports/data/source_audit/status.json');print('轨迹来源/重复审计:',x.get('state','未启动'),'|',x.get('phase',''))
x=read('reports/data/originals/status.json');print('原始 HDF5:',x.get('state','未启动'),'|',x.get('done',0),'/40')
x=read('reports/data/provenance/status.json');print('来源组划分:',x.get('state','等待原始 HDF5'),'|',x.get('phase',''))
x=read('reports/data/overlap/status.json');print('环境/初态重叠:',x.get('state','等待来源核验'),'|',x.get('phase',''))
print('自采集: 已按用户要求停止；原检查及初态文件保留，不计作训练演示')
print('当前数据方案: 官方数据；4 类训练客户端 × 7 类评测')
x=read('reports/data/official_four_clients/status.json');print('四客户端数据验收:',x.get('state','未启动'),'|',x.get('phase',''),'| 记录',x.get('accepted_records',x.get('accepted',0)),'| chunks',x.get('chunks','待核验'))
if x.get('error'):print('数据验收错误:',str(x['error'])[:160])
x=read('reports/official_training_smoke/status.json')
if (ROOT/'reports/scheduling/fedwam_official_full_jobs.json').exists():print('原单步优化器检查: 已由十种方法的完整多轮工程验收替代')
else:print('四客户端优化器验收:',x.get('state','未运行'),'|',x.get('phase',''),'| 通过',x.get('clients_passed',x.get('clients_done',0)),'/4')
if x.get('error'):print('优化器验收错误:',str(x['error'])[:160])
x=read('reports/acceptance/status.json');print('模型/仿真:',x.get('state','未启动'),'|',x.get('phase',''), '| 已处理',x.get('done',x.get('passed',0)),'/28')
if x.get('error'):print('验收错误:',str(x['error'])[:150])
x=read('reports/control_probe/result.json');print('world→action 梯度与干预:', '通过' if x.get('passed') else '未通过/待运行')
workers=list((ROOT/'runs/M0_plus_full/workers').glob('*/status.json'))
counts=[json.loads(p.read_text()) for p in workers]
print('全量原模型基线:',sum(x.get('done',0) for x in counts),'/10030（工程 case 单独保存）')
x=read('reports/federation_engineering/status.json')
print('完整多轮工程验收:',x.get('state','等待 Slurm'),'| 当前',x.get('method',''),'| 通过',len(x.get('methods_passed',x.get('passed',[]))),'/10')
if x.get('error'):print('多轮验收错误:',str(x['error'])[:180])
x=read('reports/parallel_engineering/status.json')
print('客户端并行 GPU 验收:',x.get('state','未启动'),'| 当前',x.get('method',''),'| 通过',len(x.get('methods_passed',x.get('passed',[]))),'/10')
if x.get('error'):print('并行验收错误:',str(x['error'])[:180])
x=read('reports/detached_engineering/status.json')
print('独立客户端 GPU 验收:',x.get('state','等待调度'),'| 当前',x.get('method',''),'| 通过',len(x.get('methods_passed',x.get('passed',[]))),'/10')
x=read('reports/detached_engineering/pipeline_error.json')
if x.get('error'):print('独立客户端错误:',str(x['error'])[:180])
print('当前正式范围: 仅 seed42；四个独立单卡任务，可分别启动；依赖等待释放 GPU')
for path in sorted((ROOT/'reports/scheduling').glob('*_jobs.json')):
 x=read(path.relative_to(ROOT));print('完整调度:',x.get('state'),'| GPU上限',x.get('max_total_gpus'),'|',x.get('jobs',{}))
for path in sorted((ROOT/'runs').glob('*/scheduler/queue.json')):
 x=read(path.relative_to(ROOT))
 from collections import Counter
 tasks=x.get('tasks',{})
 values=tasks.values() if isinstance(tasks,dict) else tasks
 print('正式任务:',path.parent.parent.name,'|',dict(Counter(t.get('state','unknown') for t in values)))
for path in sorted((ROOT/'runs').glob('fedwam_official_full/*/seed*/status.json')):
 x=read(path.relative_to(ROOT));print('训练:',str(path.parent.relative_to(ROOT/'runs')),x.get('state'),x.get('phase',''),x.get('round',''),x.get('client',''))
for path in sorted((ROOT/'runs').glob('fedwam_seed43_detached/*/seed43/client_status/*.json')):
 x=read(path.relative_to(ROOT));print('并行客户端:',str(path.relative_to(ROOT/'runs')),x.get('state'),x.get('phase',''),x.get('round',''))
r=subprocess.run(['squeue','-u','anonymous','-h','-o','%i %j %T'],capture_output=True,text=True)
for line in r.stdout.splitlines():
 if 'fwfull-' in line:print('Slurm:',line)
