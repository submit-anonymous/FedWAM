"""Fixed linear projection and patch cosine similarity for scientific figures."""
import numpy as np

def cosine_map(reference,features):
    q=np.asarray(reference,dtype=np.float64);x=np.asarray(features,dtype=np.float64)
    if x.ndim!=2 or q.shape!=(x.shape[1],) or not np.isfinite(x).all() or not np.isfinite(q).all():
        raise ValueError('Invalid feature dimensions or values')
    norms=np.linalg.norm(x,axis=-1);qn=np.linalg.norm(q)
    if qn<1e-12 or np.any(norms<1e-12):raise ValueError('Undefined zero-vector cosine')
    return np.clip(x@q/(norms*qn),-1,1)

def fit_pca(initial_features):
    x=np.asarray(initial_features,dtype=np.float64)
    if x.ndim!=2 or min(x.shape)<3 or not np.isfinite(x).all():raise ValueError('Invalid PCA input')
    mean=x.mean(0);_,singular,vh=np.linalg.svd(x-mean,full_matrices=False)
    basis=vh[:3].copy()
    for row in basis:
        if row[np.argmax(np.abs(row))]<0:row*=-1
    return dict(mean=mean,basis=basis,explained_variance_ratio=singular[:3]**2/max(float((singular**2).sum()),1e-12))

def project_pca(features,pca):
    x=np.asarray(features,dtype=np.float64)
    if x.ndim!=2 or x.shape[1]!=len(pca['mean']) or not np.isfinite(x).all():raise ValueError('Invalid PCA query')
    return (x-pca['mean'])@pca['basis'].T
