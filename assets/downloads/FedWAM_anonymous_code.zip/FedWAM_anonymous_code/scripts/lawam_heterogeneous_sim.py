"""Native LaWAM short rollouts with the heterogeneous chapter's MuJoCo version."""
import json
import os
from pathlib import Path
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from imagewam_model_acceptance import write


def run(output):
    from unittest.mock import patch
    import mujoco
    from fedwam.heterogeneous.adapters import LaWAMAdapter
    from deployment.model_server.server_policy import build_policy_server_metadata
    from examples.LIBERO.eval_files import model2libero_interface as interface
    from acceptance import Transport,rollout
    from libero.libero import benchmark
    status=dict(state='running',phase='load',mujoco=mujoco.__version__,seed=42)
    write(output/'status.json',status)
    if mujoco.__version__!='3.3.2':raise ValueError('Heterogeneous simulator version mismatch')
    adapter=LaWAMAdapter(ROOT)
    checkpoint=str(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt')
    metadata=build_policy_server_metadata(adapter.model,ckpt_path=checkpoint,server_type='local_native_plus',env='libero',supported_eval_envs=['libero'])
    transport=Transport(adapter.model,metadata)
    with patch.object(interface,'WebsocketClientPolicy',lambda *a,**kw:transport):
        client=interface.ModelClient(checkpoint,action_hz=20.,embodiment_id=25,eval_action_chunk_len=8)
    results=[]
    for name in ('libero_spatial','libero_object','libero_goal','libero_10'):
        suite=benchmark.get_benchmark_dict()[name](task_order_index=0)
        row=dict(suite=name,task_index=0,name=suite.get_task(0).name,seed=42,init_state_index=0,
                 max_steps=16,record_video=True,scope='MuJoCo3.3.2 compatibility only; not success-rate evaluation')
        status.update(phase='rollout',suite=name);write(output/'status.json',status)
        results.append(rollout(row,client,transport,output/name))
    write(output/'result.json',dict(passed=True,mujoco=mujoco.__version__,cases=results,scientific_evaluation=False))
    status.update(state='completed',phase='simulator_compatibility',passed=len(results));write(output/'status.json',status)


if __name__=='__main__':
    output=ROOT/'reports/heterogeneous'/('lawam-sim-'+os.environ['SLURM_JOB_ID'])
    try:run(output)
    except Exception as exc:
        write(output/'status.json',dict(state='failed',error=repr(exc)[:2000]));traceback.print_exc();raise SystemExit(1)
