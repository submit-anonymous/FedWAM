"""Inspect native benchmark states and original demonstrations; retain unknown replay provenance."""
import sys,re,hashlib
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,digest
from fedwam.provenance import state_matches
OUT=ROOT/'reports/data/overlap'

def bddl_key(text):
    text=re.sub(r';[^\n]*','',text)
    tokens=re.findall(r'\(|\)|[^\s()]+',text)
    # The problem's filename label has no simulator semantics.
    if len(tokens)>4 and tokens[:4]==['(','define','(','problem']:tokens[4]='PROBLEM_NAME'
    return digest(tokens)

def main():
    import torch
    from libero.libero import benchmark,get_libero_path
    from unittest.mock import patch
    cases=load(ROOT/'manifests/plus_full.json')['cases'];cache={};native=[];loaded_files={}
    original=torch.load
    def cached(path,*args,**kwargs):
        path=str(path)
        if path not in cache:
            # Pinned official repository files only; no untrusted arbitrary pickle paths.
            if not Path(path).resolve().is_relative_to(ROOT/'third_party/LIBERO-plus'):raise ValueError('Unexpected state path')
            cache[path]=original(path,weights_only=False)
        return cache[path]
    for suite in sorted({r['suite'] for r in cases}):
        obj=benchmark.get_benchmark_dict()[suite](task_order_index=0)
        for row in (r for r in cases if r['suite']==suite):
            with patch.object(torch,'load',cached):states=np.asarray(obj.get_task_init_states(row['task_index']))
            if states.ndim!=2 or not np.isfinite(states).all():raise ValueError('Invalid native init state array')
            task=obj.get_task(row['task_index']);path=Path(get_libero_path('bddl_files'))/task.problem_folder/task.bddl_file
            # Native env wrapper strips view/init/noise from a virtual filename before loading BDDL.
            if not path.exists() and '_view_' in path.name:path=path.with_name(path.name.split('_view_')[0]+'.bddl')
            text=path.read_text();key=bddl_key(text)
            native.append({'variant_id':row['variant_id'],'suite':suite,'category':row['category'],'name':row['name'],
                'state':states[row['init_state_index']].tolist(),'bddl_key':key,'bddl_path':str(path),
                'init_state_index':row['init_state_index']})
        status(OUT,state='running',phase='benchmark_init_inventory',native_cases=len(native),total=len(cases))
    save(OUT/'native_initial_states.json',{'rows':native,'scope':'published index 0 before reset settling; all 10030 benchmark variants'})
    reserve=list(native)
    for path,arrays in cache.items():
        path=Path(path);suite=path.parent.name
        if suite not in {r['suite'] for r in native}:continue
        for index,value in enumerate(np.atleast_2d(arrays)):
            reserve.append({'suite':suite,'name':path.name.removesuffix('.pruned_init'),'state':value.tolist(),'init_state_index':index,'source':str(path)})
    save(OUT/'published_init_reserve.json',{'rows':reserve,'scope':'all arrays loaded by benchmark, including indices reserved for original 50-trial evaluation'})
    bysuite=defaultdict(list)
    for r in native:bysuite[r['suite']].append(r)
    original_states=load(ROOT/'reports/data/provenance/original_states.json');comparisons=[]
    for d in original_states:
        a=np.load(d['state_file']);task=d['source_file'].removesuffix('_demo.hdf5')
        candidates=[r for r in bysuite[d['suite']] if r['name'].startswith(task) and len(r['state'])==len(a['init'])]
        if not candidates:continue
        arr=np.array([r['state'] for r in candidates]);hits={}
        for key in ['init','first_state']:
            hits[key]=[candidates[i]['variant_id'] for i in state_matches(a[key],arr)]
        comparisons.append({'source':d['source'],'compared_variants':len(candidates),'matches':hits,
            'minimum_physical_linf':float(np.min(np.max(np.abs(arr[:,1:]-a['init'][None,1:]),axis=1)))})
    benchmark_keys={r['bddl_key'] for r in native};pool=[]
    for p in (ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files/libero_mix').glob('*.bddl'):
        key=bddl_key(p.read_text());pool.append({'path':str(p),'key':key,'same_bddl_as_evaluation':key in benchmark_keys})
    save(OUT/'original_vs_published_states.json',comparisons)
    save(OUT/'mix_bddl_pool.json',pool)
    summary={'native_cases':len(native),'unique_published_state_files':len(cache),
        'original_demonstrations_compared':len(comparisons),
        'originals_with_exact_physical_state_match':sum(any(x['matches'].values()) for x in comparisons),
        'mix_bddl_files':len(pool),'mix_bddl_identical_to_evaluation':sum(p['same_bddl_as_evaluation'] for p in pool),
        'actual_rlds_replay_state_comparison':'unknown: no full simulator state in released episodes',
        'actual_rlds_environment_comparison':'unknown: no per-episode texture/light/camera/reset metadata',
        'settling_caveat':'Original demos begin after simulation settling; published initial arrays are before settling. Nonmatching arrays do not prove independent initial configurations.',
        'task_overlap':'same 40 base tasks by design; not task-disjoint evaluation',
        'training_eligibility':'strict no-overlap training remains blocked until fresh collection metadata pass',
        'scope':'file and exact-state audit, not a proof of absence of semantic or near-state overlap'}
    save(OUT/'summary.json',summary);status(OUT,state='completed',phase='overlap_audit_with_explicit_unknowns',**summary)
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));raise
