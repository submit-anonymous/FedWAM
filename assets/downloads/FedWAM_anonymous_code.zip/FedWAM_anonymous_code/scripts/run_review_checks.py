"""Offline CPU checks for the released algorithmic contracts, not full training."""
from pathlib import Path
import sys, unittest, json, os, argparse

os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('MKL_NUM_THREADS','2')

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts'),str(ROOT/'tests')]

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--with-upstream',action='store_true',help='Also run two tests requiring the full pinned LaWAM source and dependencies')
    args=parser.parse_args()
    import torch
    torch.set_num_threads(2)
    names=[
        'test_parameter_methods','test_packets','test_server_teacher','test_reception',
        'test_function_controls','test_round_runtime','test_resume','test_federation_engine',
        'test_parallel_engine','test_detached_engine','test_native_detached_engine',
        'test_native_federation_gradient','test_native_protocol_v2','test_native_local',
        'test_heterogeneous_interface','test_heterogeneous_teacher','test_heterogeneous_packets',
        'test_heterogeneous_packet_io','test_heterogeneous_calibration',
        'test_heterogeneous_residual_readout','test_heterogeneous_spatial_readout',
        'test_heterogeneous_native_checkpoint','test_subgoal_visual_math',
    ]
    suite=unittest.defaultTestLoader.loadTestsFromNames(names)
    requires_upstream={
      'test_parameter_methods.ParameterMethods.test_actual_decoder_intent_projection_and_attention_forward',
      'test_native_federation_gradient.NativeFederationGradientTests.test_adapter_method_keeps_base_world_frozen_under_official_freeze',
    }
    def mark_external_tests(item):
        if isinstance(item,unittest.TestSuite):
            for child in item:mark_external_tests(child)
        elif item.id() in requires_upstream and not args.with_upstream:
            method=getattr(item,item._testMethodName)
            setattr(item,item._testMethodName,unittest.skip('Requires full external LaWAM source; rerun with --with-upstream after setup')(method))
    mark_external_tests(suite)
    result=unittest.TextTestRunner(verbosity=1).run(suite)
    value=dict(scope='CPU contracts only; not full-model training or benchmark evaluation',
               modules=names,tests=result.testsRun,failures=len(result.failures),
               errors=len(result.errors),skipped=len(result.skipped),passed=result.wasSuccessful(),
               external_tests=sorted(requires_upstream),with_upstream=args.with_upstream)
    out=ROOT/'validation';out.mkdir(exist_ok=True)
    (out/'cpu_checks.json').write_text(json.dumps(value,indent=2)+'\n')
    sys.exit(0 if result.wasSuccessful() else 1)
