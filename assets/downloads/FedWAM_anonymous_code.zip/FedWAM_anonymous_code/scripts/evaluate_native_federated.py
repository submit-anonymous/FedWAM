"""Evaluate native private VLM/world/action checkpoints on the frozen full manifest."""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from fedwam.io import ROOT, NATIVE_STORAGE_ROOT, digest, file_hash, load, save, status
from fedwam.evaluation import partition
from fedwam.federated_reporting import (CLIENTS, attach_base_tasks, evaluate_shard,
                                         load_final_checkpoint, prediction_items,
                                         reusable_result, verify_manifest,
                                         verify_run_identity)
from fedwam.native_local import make_collator, make_native_sample, restore_auxiliary_state
import evaluate_federated as previous


def evaluation_identity(run, final, client, manifest):
    value = previous_evaluation_identity(run, final, client, manifest)
    value['code']['scripts/evaluate_native_federated.py'] = file_hash(
        ROOT/'scripts/evaluate_native_federated.py')
    value['native_private_vlm'] = True
    value['prediction_interface'] = 'native collator and current private VLM'
    return value


previous_evaluation_identity = previous.evaluation_identity


def load_deployed_policy(run, final, client, out):
    import acceptance
    checkpoint = load_final_checkpoint(run, final, client)
    if not {'vlm', 'aux'} <= checkpoint['state'].keys():
        raise ValueError('Native private VLM/auxiliary state missing from final checkpoint')
    acceptance.OUT = out
    policy, native_client, transport = acceptance.model()
    backend = policy.policy_backend
    if final['method'] in ('M3', 'Local-adapter'):
        from fedwam.parameter_methods import install_adapters
        rank = final.get('adapter_rank')
        if not isinstance(rank, int) or rank < 1:
            raise ValueError('Final adapter rank missing')
        install_adapters(backend.lam.decoder, rank=rank, seed=0)
    backend.vlm.load_state_dict(checkpoint['state']['vlm'], strict=True)
    backend.lam.decoder.load_state_dict(checkpoint['state']['world'], strict=True)
    backend.flow.load_state_dict(checkpoint['state']['action'], strict=True)
    restore_auxiliary_state(policy, checkpoint['state']['aux'])
    policy.eval()
    for parameter in policy.parameters():
        parameter.requires_grad_(False)
    del checkpoint
    return policy, native_client, transport


def prediction_test(policy, out, identity, client, seed, index, count, scope):
    import torch
    from fedwam.official_dataset import OfficialDataset
    stats = load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
    collator = make_collator(policy, training=True)
    backend = policy.policy_backend
    worker = out/'prediction_test'/scope/client/'workers'/f'{index:04d}-of-{count:04d}'
    expected = done = errors = 0
    for source_client in CLIENTS if client == 'pooled' else [client]:
        data = OfficialDataset(ROOT, source_client, 'prediction_test', seed,
                               max_cached_episodes=1)
        items = list(prediction_items(data.rows, scope))
        save(out/'prediction_test'/scope/client/f'{source_client}_plan.json',
             {'scope': scope, 'source_client': source_client, 'expected': len(items),
              'source_groups': len({row['source_group'] for row, _ in items}),
              'identity': identity})
        assigned = partition(items, index, count)
        expected += len(assigned)
        for row, t in assigned:
            key = {'evaluation': digest(identity), 'source_client': source_client,
                   'record_id': row['record_id'], 'source_group': row['source_group'],
                   't': t, 'scope': scope}
            path = out/'prediction_test'/scope/client/'cases'/f'{digest(key)}.json'
            if path.exists() and reusable_result(load(path), key):
                done += 1
                continue
            started = time.perf_counter()
            try:
                sample = data.reader.read(row, t)
                raw = make_native_sample(sample, stats)
                batch = {k: v.to(next(policy.parameters()).device)
                         if isinstance(v, torch.Tensor) else v
                         for k, v in collator([raw]).items()}
                with torch.no_grad():
                    shared = backend._run_shared_encoding_train(
                        prepared_batch=batch, source='native_prediction_test',
                        lam_features_with_no_grad=True)
                    mse = (shared.h_t1_pred.float()-shared.h_t1_gt.float()).square().mean()
                    persistence = (shared.h_t.float()-shared.h_t1_gt.float()).square().mean()
                    if not torch.isfinite(mse) or not torch.isfinite(persistence):
                        raise ValueError('Nonfinite native prediction error')
                record = {'future_mse': float(mse),
                          'persistence_mse': float(persistence),
                          'completed': True, 'success': True, 'error': None}
                done += 1
            except Exception as error:
                record = {'completed': False, 'success': False, 'error': repr(error)}
                errors += 1
            record.update(identity=key, client=client, source_client=source_client,
                          seed=seed, suite=row['suite'], task=row['task'],
                          source_group=row['source_group'], record_id=row['record_id'],
                          t=t, elapsed_seconds=time.perf_counter()-started,
                          transition_mse='algebraically equivalent to future MSE at fixed current z')
            save(path, record)
            status(worker, state='running', done=done, errors=errors, assigned=expected)
    status(worker, state='completed' if errors == 0 else 'failed',
           done=done, errors=errors, assigned=expected)
    if errors:
        raise RuntimeError(f'{errors} native prediction cases failed')


def validate_native_run_path(path):
    run = Path(path).resolve()
    if not run.is_relative_to(NATIVE_STORAGE_ROOT.resolve()):
        raise ValueError('Run must be inside native account storage')
    return run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, required=True)
    parser.add_argument('--client', choices=(*CLIENTS, 'pooled'), required=True)
    parser.add_argument('--index', type=int, required=True)
    parser.add_argument('--count', type=int, required=True)
    parser.add_argument('--prediction-test', action='store_true')
    parser.add_argument('--prediction-scope',
                        choices=('representative-per-group', 'all-chunks'),
                        default='representative-per-group')
    args = parser.parse_args()
    partition([], args.index, args.count)
    run = validate_native_run_path(args.run)
    final = load(run/'final.json')
    verify_run_identity(ROOT, final['identity'])
    if final['method'] != final['identity']['method'] or final['seed'] != 42:
        raise ValueError('Native final method or seed mismatch')
    if not final['identity'].get('execution', {}).get('private_vlm'):
        raise ValueError('Final checkpoint is not from native private-VLM execution')
    manifest = load(ROOT/'manifests/plus_full.json')
    verify_manifest(manifest)
    rows = attach_base_tasks(manifest['cases'], load(
        ROOT/'manifests/official_four_clients/lighting/train.json')['rows'])
    out = run/'evaluation'
    identity = evaluation_identity(run, final, args.client, manifest)
    identity_path = out/'identities'/f'{args.client}.json'
    if identity_path.exists() and load(identity_path) != identity:
        raise ValueError('Native evaluation identity changed')
    save(identity_path, identity)
    worker = (out/'prediction_test'/args.prediction_scope/args.client/'workers'
              if args.prediction_test else out/'workers'/args.client)
    worker = worker/f'{args.index:04d}-of-{args.count:04d}'
    status(worker, state='running', phase='load_final_checkpoint')
    transport = None
    try:
        policy, native_client, transport = load_deployed_policy(
            run, final, args.client, worker)
        if args.prediction_test:
            prediction_test(policy, out, identity, args.client, 42,
                            args.index, args.count, args.prediction_scope)
        else:
            import acceptance
            def rollout(row, directory):
                return acceptance.rollout(row, native_client, transport,
                                          directory, save_result=False)
            result = evaluate_shard(out, rows, identity, args.client, 42,
                                    args.index, args.count, rollout)
            if result['errors']:
                raise RuntimeError(f'{result["errors"]} rollout errors retained in denominator')
    except Exception as error:
        status(worker, state='failed', error=repr(error))
        raise
    finally:
        if transport is not None:
            transport.close()


if __name__ == '__main__':
    main()
