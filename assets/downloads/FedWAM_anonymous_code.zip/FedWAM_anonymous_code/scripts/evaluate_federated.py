"""Evaluate a checksum-bound final model on every assigned native PLUS case."""
import argparse
from pathlib import Path
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT, digest, file_hash, load, save, status
from fedwam.evaluation import partition
from fedwam.federated_reporting import (CLIENTS, attach_base_tasks, evaluate_shard,
    load_final_checkpoint, prediction_items, reusable_result, verify_manifest, verify_run_identity)


def evaluation_identity(run, final, client, manifest):
    sources = ['scripts/evaluate_federated.py','scripts/acceptance.py','src/fedwam/federated_reporting.py',
               'src/fedwam/evaluation.py','src/fedwam/training.py','src/fedwam/official_dataset.py',
               'src/fedwam/parameter_methods.py']
    return {'schema':'fedwam.evaluation.v1','training_identity':final['identity'],
            'method':final['method'],'seed':final['seed'],'client':client,
            'final_sha256':file_hash(run/'final.json'),
            'checkpoint_sha256':final['clients'][client]['sha256'],
            'manifest_sha256':manifest['sha256'],
            'code':{p:file_hash(ROOT/p) for p in sources},
            'scope':'all native PLUS cases; no case cap; E_confirm excluded from model selection',
            'video_policy':'only the two smallest (sha256(JSON variant_id), variant_id) cases per suite/category in the full manifest; identical selection across shards and outcomes; all other cases recorded without video; all case results and available action trajectories retained; execution-error videos only when native serialization completed'}


def load_deployed_policy(run, final, client, out):
    import acceptance
    checkpoint = load_final_checkpoint(run,final,client)
    acceptance.OUT = out
    policy, native_client, transport = acceptance.model()
    backend = policy.policy_backend
    if final['method'] in ('M3','Local-adapter'):
        from fedwam.parameter_methods import install_adapters
        rank = final.get('adapter_rank')
        if not isinstance(rank,int) or rank < 1:
            raise ValueError('Final adapter rank missing')
        install_adapters(backend.lam.decoder,rank=rank,seed=0)
    backend.lam.decoder.load_state_dict(checkpoint['state']['world'],strict=True)
    backend.flow.load_state_dict(checkpoint['state']['action'],strict=True)
    policy.eval()
    for parameter in policy.parameters():
        parameter.requires_grad_(False)
    del checkpoint
    return policy,native_client,transport


def prediction_test(policy, out, identity, client, seed, index, count, scope):
    import torch
    from fedwam.official_dataset import OfficialDataset
    from fedwam.training import encode, amp
    stats = load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
    worker = out/'prediction_test'/scope/client/'workers'/f'{index:04d}-of-{count:04d}'
    expected = done = errors = 0
    for source_client in CLIENTS if client=='pooled' else [client]:
        data = OfficialDataset(ROOT,source_client,'prediction_test',seed,max_cached_episodes=1)
        items = list(prediction_items(data.rows,scope))
        save(out/'prediction_test'/scope/client/f'{source_client}_plan.json',
             {'scope':scope,'source_client':source_client,'expected':len(items),
              'source_groups':len({row['source_group'] for row,_ in items}),
              'selection':'lexicographic record_id then earliest verified chunk per source group' if scope=='representative-per-group' else 'every verified chunk in every accepted prediction_test record',
              'identity':identity})
        assigned = partition(items,index,count)
        expected += len(assigned)
        for row,t in assigned:
            key = {'evaluation':digest(identity),'source_client':source_client,
                   'record_id':row['record_id'],'source_group':row['source_group'],'t':t,'scope':scope}
            path = out/'prediction_test'/scope/client/'cases'/f'{digest(key)}.json'
            if path.exists() and reusable_result(load(path),key):
                done += 1
                continue
            started = time.perf_counter()
            try:
                sample = data.reader.read(row,t)
                with torch.no_grad():
                    batch,_ = encode(policy,sample,stats)
                    with amp(batch['h_t'].device):
                        pred = policy.policy_backend._decode_future_tokens_strict_single_query(
                            h_t=batch['h_t'],pred_action_emb=batch['intent'],source='fixed_prediction_test')
                    mse = (pred.float()-batch['future_target'].float()).square().mean()
                    persistence = (batch['h_t'].float()-batch['future_target'].float()).square().mean()
                    if not torch.isfinite(mse) or not torch.isfinite(persistence):
                        raise ValueError('Nonfinite fixed-input prediction error')
                record = {'future_mse':float(mse),'persistence_mse':float(persistence),
                          'completed':True,'success':True,'error':None}
                done += 1
            except Exception as error:
                record = {'completed':False,'success':False,'error':repr(error)}
                errors += 1
            record.update(identity=key,client=client,source_client=source_client,seed=seed,
                          suite=row['suite'],task=row['task'],source_group=row['source_group'],
                          record_id=row['record_id'],t=t,elapsed_seconds=time.perf_counter()-started,
                          pose_contact_metrics='unavailable in accepted image/action record interface',
                          transition_mse='algebraically equivalent to future MSE; not additional evidence')
            save(path,record)
            status(worker,state='running',done=done,errors=errors,assigned=expected)
    status(worker,state='completed' if errors==0 else 'failed',done=done,errors=errors,assigned=expected)
    if errors:
        raise RuntimeError(f'{errors} prediction cases failed; retained as explicit errors')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',type=Path,required=True)
    parser.add_argument('--client',choices=(*CLIENTS,'pooled'),required=True)
    parser.add_argument('--index',type=int,required=True)
    parser.add_argument('--count',type=int,required=True)
    parser.add_argument('--prediction-test',action='store_true',help='Evaluate fixed held-out inputs instead of native rollouts')
    parser.add_argument('--prediction-scope',choices=('representative-per-group','all-chunks'),default='representative-per-group')
    args = parser.parse_args()
    partition([],args.index,args.count)
    run = args.run.resolve()
    if not run.is_relative_to(ROOT):
        raise ValueError('Run must be inside the project')
    final = load(run/'final.json')
    verify_run_identity(ROOT,final['identity'])
    if final['method'] != final['identity']['method'] or final['seed'] != final['identity']['seed']:
        raise ValueError('Final method/seed does not match training identity')
    manifest = load(ROOT/'manifests/plus_full.json')
    verify_manifest(manifest)
    rows = attach_base_tasks(manifest['cases'],load(ROOT/'manifests/official_four_clients/lighting/train.json')['rows'])
    out = run/'evaluation'
    identity = evaluation_identity(run,final,args.client,manifest)
    identity_path = out/'identities'/f'{args.client}.json'
    if identity_path.exists() and load(identity_path) != identity:
        raise ValueError('Evaluation identity changed')
    save(identity_path,identity)
    worker = (out/'prediction_test'/args.prediction_scope/args.client/'workers' if args.prediction_test
              else out/'workers'/args.client)/f'{args.index:04d}-of-{args.count:04d}'
    status(worker,state='running',phase='load_final_checkpoint')
    transport = None
    try:
        policy,native_client,transport = load_deployed_policy(run,final,args.client,worker)
        if args.prediction_test:
            prediction_test(policy,out,identity,args.client,final['seed'],args.index,args.count,args.prediction_scope)
        else:
            import acceptance
            def rollout(row,directory):
                return acceptance.rollout(row,native_client,transport,directory,save_result=False)
            result = evaluate_shard(out,rows,identity,args.client,final['seed'],args.index,args.count,rollout)
            if result['errors']:
                raise RuntimeError(f'{result["errors"]} execution errors retained in denominator; rerun shard to retry')
    except Exception as error:
        status(worker,state='failed',error=repr(error))
        raise
    finally:
        if transport is not None:
            transport.close()


if __name__=='__main__':
    main()
