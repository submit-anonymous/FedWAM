"""Single-GPU full method/seed worker, private clients time-multiplexed within rounds."""
import argparse,sys,os,json,fcntl,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,digest
from fedwam.round_runtime import atomic_json
from fedwam.experiment_config import resolved_config,identity,formal_gate,METHODS

def main():
 p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,required=True);p.add_argument('--seed',type=int,choices=[42,43,44],default=42)
 p.add_argument('--mode',choices=['formal','engineering'],default='formal');p.add_argument('--run',type=Path,required=True)
 p.add_argument('--overrides',type=Path);p.add_argument('--dry-run',action='store_true');p.add_argument('--engineering-receipt',type=Path,default=ROOT/'reports/federation_engineering/summary.json');args=p.parse_args()
 cfg=resolved_config(args.method,args.seed,args.mode,load(args.overrides) if args.overrides else None)
 root=args.run.resolve()
 if not root.is_relative_to(ROOT/'runs'):raise ValueError('Run must stay within project runs directory')
 if args.dry_run:
  print(json.dumps({'method':args.method,'seed':args.seed,'mode':args.mode,'clients':cfg['clients'],'training':cfg['training'],'run':str(root)},indent=2));return
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Training must run inside Slurm')
 root.mkdir(parents=True,exist_ok=True)
 with (root/'worker.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  ident=identity(cfg)
  from fedwam.retention import compact_completed_run
  if (root/'verification.json').exists():
   verified=load(root/'verification.json')
   if verified.get('passed') and verified.get('identity')==ident:
    compact_completed_run(root,ident);print('Verified completed run; no duplicate training');return
  if args.mode=='formal':formal_gate(ident,load(args.engineering_receipt))
  for path,key in [('reports/data/official_four_clients/status.json','state')]:
   if load(ROOT/path).get(key)!='completed':raise ValueError('Official data acceptance is incomplete')
  from fedwam.official_dataset import OfficialDataset
  for client in cfg['clients']:OfficialDataset(ROOT,client,'train',args.seed,max_cached_episodes=1)
  import acceptance
  from fedwam.lawam_federation import LaWAMFederation
  from fedwam.federation_engine import FederationEngine
  from model_probe import frozen_hash
  acceptance.OUT=root/'model_acceptance'
  policy,client,transport=acceptance.model()
  backend=LaWAMFederation(policy,cfg,root,digest({k:ident[k] for k in ('data_identity','checkpoint_sha256','normalization_sha256','model_config_sha256')})+':deployed-intent:H8:20Hz:'+cfg['representation'])
  backend._enable('pre');frozen_before=frozen_hash(policy)
  engine=FederationEngine(root,ident,cfg,backend)
  try:
   final=engine.run();backend._enable('pre')
   if frozen_hash(policy)!=frozen_before:raise ValueError('Frozen foundation/intent changed')
   from fedwam.round_runtime import sha
   import torch
   changed={}
   for name,ref in final['clients'].items():
    state=engine.store.read_ref(ref)['state']
    changed[name]={'world':any(not torch.equal(v,backend.base_world[k]) for k,v in state['world'].items()),
     'action':any(not torch.equal(v,backend.base_action[k]) for k,v in state['action'].items()),'updates':state['total_updates']}
    if not all(changed[name][k] for k in ('world','action')):raise ValueError('Training did not update expected private modules')
   atomic_json(root/'verification.json',{'passed':True,'identity':ident,'frozen_sha256':frozen_before,'module_updates':changed,'scope':args.mode})
   compact_completed_run(root,ident)
  except Exception as e:
   atomic_json(root/'status.json',{'state':'failed','error':repr(e)});raise
  finally:transport.close()
if __name__=='__main__':main()
