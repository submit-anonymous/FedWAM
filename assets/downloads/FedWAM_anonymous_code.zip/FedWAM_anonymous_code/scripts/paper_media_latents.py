"""Reproducible qualitative samples; selection uses GT change, not prediction gain."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
OUT=ROOT/'reports/paper_media_20260926'
DOMAINS=('lighting','camera_pose','sensor_noise','background')

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()

def write(path,x):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(x,indent=2,allow_nan=False))

def imagewam():
    import gc
    import numpy as np
    import torch
    from PIL import Image
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.residual_readout import ResidualFutureReadout
    torch.set_num_threads(4);torch.manual_seed(42)
    selection=json.loads((ROOT/'manifests/heterogeneous_residual_readout_seed42_v1.json').read_text())
    records=[]
    for domain in DOMAINS:
        folder=Path('/workspace/reviewer/fedwam-residual-readout-v1')/domain
        r=json.loads((folder/'residual-result.json').read_text())
        row=next(x for x in selection['clients'] if x['domain']==domain)
        assert sha(row['head'])==row['sha256']==r['head_sha256']
        identity=json.loads((folder/'identity.json').read_text())
        cache=Path('/workspace/reviewer/fedwam-readout-diagnosis-v2')/domain/'features.pt'
        assert sha(cache)==identity['feature_sha256']
        data=torch.load(cache,map_location='cpu',weights_only=True,mmap=True)['data']['development']
        ranked=sorted(range(len(data)),key=lambda i:(r['rows']['development'][i]['copy_mse'],i))
        head=ResidualFutureReadout(3072).cuda().eval().requires_grad_(False)
        head.load_state_dict(torch.load(row['head'],map_location='cpu',weights_only=True)['head'],strict=True)
        ds=HeterogeneousDataset(ROOT,'B',domain,'development')
        for q in (25,50,75):
            idx=ranked[round((len(ranked)-1)*q/100)]
            x=data[idx];metric=r['rows']['development'][idx]
            assert all(x[k]==metric[k] for k in ('record_id','source_group','t','task'))
            source=next(z for z in ds.rows if z['record_id']==x['record_id'])
            sample=ds.reader.read(source,x['t'])
            assert sample['source_group']==x['source_group'] and sample['lang']==x['task']
            with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
                pred=head(x['h'][None].cuda(),x['current'][None].cuda())[0].float().cpu()
            mse=float((pred-x['future']).square().mean())
            if abs(mse-metric['mse'])>1e-5:raise ValueError('Replayed readout metric differs from saved result')
            name=f'{domain}_q{q}'
            p=OUT/'latent_data'/name;p.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(p/'imagewam.npz',current=x['current'].numpy(),future=x['future'].numpy(),prediction=pred.numpy())
            Image.fromarray(sample['primary']).save(p/'current.png')
            Image.fromarray(sample['future']).save(p/'future.png')
            item=dict(name=name,domain=domain,quantile=q,development_index=idx,
                **{k:x[k] for k in ('task','record_id','source_group','t')},future_t=x['t']+8,
                imagewam_mse=mse,copy_mse=metric['copy_mse'],head_sha256=row['sha256'],
                cache_sha256=identity['feature_sha256'],sample_selection='GT change MSE quantile over fixed256development; ties=index')
            write(p/'provenance.json',item);records.append(item)
            print(name,mse,metric['copy_mse'],flush=True)
        del head,data,ds;gc.collect();torch.cuda.empty_cache()
    write(OUT/'latent_samples.json',records)

def lawam():
    import numpy as np
    import torch
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.adapters import LaWAMAdapter
    torch.manual_seed(42);torch.set_num_threads(4)
    model=LaWAMAdapter(ROOT)
    rows=json.loads((OUT/'latent_samples.json').read_text())
    for domain in DOMAINS:
        ds=HeterogeneousDataset(ROOT,'A',domain,'development')
        for row in (r for r in rows if r['domain']==domain):
            p=OUT/'latent_data'/row['name']
            src=next(x for x in ds.rows if x['record_id']==row['record_id'])
            sample=ds.reader.read(src,row['t'])
            assert sample['source_group']==row['source_group']
            with torch.no_grad():
                native=model.prepare(sample);prediction=model.predict(native)[0].cpu().numpy()
            with np.load(p/'imagewam.npz') as original:
                current=original['current'];future=original['future']
            assert prediction.shape==future.shape==(49,768) and np.isfinite(prediction).all()
            np.savez_compressed(p/'lawam.npz',current=current,future=future,prediction=prediction)
            row['lawam_mse']=float(np.mean((prediction-future)**2))
            write(p/'provenance.json',row)
            print(row['name'],row['lawam_mse'],flush=True)
    write(OUT/'latent_samples.json',rows)
    write(OUT/'latent_model_scope.json',dict(lawam='Original LIBERO SFT checkpoint, no new training',
        imagewam='Domain-specific1000native updates plus frozen4000-update residual readout',
        comparison='Different adaptation stages; qualitative examples, NOT a fair model ranking or federation comparison',
        horizon=8,grid=[7,7],reference='Shared DINOv3 reference from frozen10472 cache',
        inference='LaWAM prediction consumes current visual/intent only; future is evaluation target',
        laWAM_checkpoint=str(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt')))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('architecture',choices=['imagewam','lawam']);args=p.parse_args()
    try:
        globals()[args.architecture]()
        write(OUT/f'{args.architecture}_latent_status.json',dict(state='completed',samples=12))
    except Exception as exc:
        write(OUT/f'{args.architecture}_latent_status.json',dict(state='failed',error=repr(exc)))
        traceback.print_exc();raise
