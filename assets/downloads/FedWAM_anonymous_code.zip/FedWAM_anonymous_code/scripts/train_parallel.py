"""One Slurm rank per private client; same losses/budgets as the frozen serial backend."""
import argparse,fcntl,json,os,sys,traceback,resource
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,digest
from fedwam.experiment_config import resolved_config,METHODS,identity,formal_gate
from fedwam.parallel_execution import parallel_identity,check_gate
from fedwam.parallel_engine import ParallelEngine
from fedwam.round_runtime import atomic_json

def main():
 p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,required=True);p.add_argument('--seed',type=int,choices=[43],default=43)
 p.add_argument('--mode',choices=['formal','engineering'],required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--attempt',required=True);args=p.parse_args()
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Slurm GPU allocation required')
 cfg=resolved_config(args.method,args.seed,args.mode);ident=parallel_identity(cfg);root=args.run.resolve()
 if not root.is_relative_to(ROOT/'runs'):raise ValueError('Run must stay in project')
 rank=int(os.environ.get('SLURM_PROCID','-1'));size=int(os.environ.get('SLURM_NTASKS','0'))
 clients=['pooled'] if args.method=='M9' else cfg['clients']
 if size!=len(clients) or not 0<=rank<size:raise ValueError('One Slurm rank per client required')
 name=clients[rank]
 if args.mode=='formal':check_gate(cfg,load(ROOT/'reports/parallel_engineering/summary.json'))
 else:formal_gate(identity(cfg),load(ROOT/'reports/federation_engineering/summary.json'))
 if (root/'verification.json').exists():
  x=load(root/'verification.json')
  if x.get('passed') and x.get('identity')==ident:
   if rank==0:
    from fedwam.retention import compact_completed_run
    compact_completed_run(root,ident)
   return
 root.mkdir(parents=True,exist_ok=True)
 engine=None;transport=None
 try:
  import torch,acceptance
  from fedwam.lawam_federation import LaWAMFederation
  from model_probe import frozen_hash
  acceptance.OUT=root/'model_acceptance'/name
  policy,native,transport=acceptance.model()
  properties=torch.cuda.get_device_properties(0);uuid=str(getattr(properties,'uuid',''))
  if not uuid:raise RuntimeError('Cannot verify physical GPU UUID')
  atomic_json(root/f'devices/{name}.json',{'rank':rank,'client':name,'uuid':uuid,'visible':os.environ.get('CUDA_VISIBLE_DEVICES'),'device_count':torch.cuda.device_count(),'attempt':args.attempt})
  interface=digest({k:ident[k] for k in ('data_identity','checkpoint_sha256','normalization_sha256','model_config_sha256')})+':deployed-intent:H8:20Hz:'+cfg['representation']
  backend=LaWAMFederation(policy,cfg,root,interface);backend._enable('pre');frozen=frozen_hash(policy)
  engine=ParallelEngine(root,ident,cfg,backend,name,args.attempt)
  # The initial device check is only infrastructure acceptance, not a training-stage barrier.
  devices={c:engine.wait(f'devices/{c}.json',lambda v:v.get('attempt')==args.attempt) for c in clients}
  if len({v['uuid'] for v in devices.values()})!=len(clients) or any(v['device_count']!=1 or v['attempt']!=args.attempt for v in devices.values()):raise ValueError('GPU ownership is not unique/current')
  ref=engine.run_client();backend._enable('pre')
  if frozen_hash(policy)!=frozen:raise ValueError('Frozen foundation/intent changed')
  state=engine.store.read_ref(ref)['state']
  changed={'world':any(not torch.equal(v,backend.base_world[k]) for k,v in state['world'].items()),'action':any(not torch.equal(v,backend.base_action[k]) for k,v in state['action'].items()),'updates':state['total_updates']}
  if not changed['world'] or not changed['action']:raise ValueError('Missing expected private parameter update')
  atomic_json(root/f'client_verification/{name}.json',{'passed':True,'identity':ident,'attempt':args.attempt,'ref':ref,'module_updates':changed,'frozen_sha256':frozen,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
  if rank==0:
   final=engine.finalize();proofs={c:load(root/f'client_verification/{c}.json') for c in clients}
   atomic_json(root/'verification.json',{'passed':True,'identity':ident,'scope':args.mode,'module_updates':{c:x['module_updates'] for c,x in proofs.items()},'frozen_sha256_by_client':{c:x['frozen_sha256'] for c,x in proofs.items()},'gpu_uuids':{c:v['uuid'] for c,v in devices.items()}})
   from fedwam.retention import compact_completed_run
   compact_completed_run(root,ident)
 except Exception as error:
  if engine:engine.fail(error)
  atomic_json(root/f'client_status/{name}.json',{'state':'failed','error':repr(error)})
  if rank==0:atomic_json(root/'status.json',{'state':'failed','error':repr(error)})
  raise
 finally:
  if transport:transport.close()
if __name__=='__main__':main()
