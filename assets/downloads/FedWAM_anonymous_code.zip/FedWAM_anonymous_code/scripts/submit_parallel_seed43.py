"""Submit the verified client-parallel workflow; hold complete DAG until persisted."""
import argparse,fcntl,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,file_hash
from fedwam.round_runtime import atomic_json
from fedwam.experiment_config import code_identity
from fedwam.parallel_execution import execution_code

def command(args):return subprocess.check_output(args,text=True).strip()
def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);a=p.parse_args();planpath=a.plan.resolve();plan=load(planpath)
 if plan['seeds']!=[43] or plan['code']!=code_identity() or plan['parallel_code']!=execution_code():raise ValueError('Plan identity changed')
 output=ROOT/'reports/scheduling/seed43_parallel_jobs.json';output.parent.mkdir(parents=True,exist_ok=True)
 with output.with_suffix('.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  if output.exists():
   state=load(output)
   if state['plan_sha256']!=file_hash(planpath):raise ValueError('Already submitted a different plan')
   if state['state']=='submitted':print(json.dumps(state,indent=2));return
  else:
   queue=command(['squeue','-u',str(os.getuid()),'-h','-o','%i|%j|%T'])
   if 'fwfull-' in queue:raise RuntimeError('Inspect active own experiments before new six-GPU allocation')
   state={'state':'submitting','plan':str(planpath),'plan_sha256':file_hash(planpath),'max_total_gpus':6,'seeds':[43],'jobs':{}}
   atomic_json(output,state)
  def submit(key,*options):
   if key in state['jobs']:return state['jobs'][key]
   marker='seed43-parallel:'+state['plan_sha256'][:16]+':'+key
   rows=command(['squeue','-u',str(os.getuid()),'-h','-o','%i|%k']).splitlines()
   matches={r.partition('|')[0].split('_')[0] for r in rows if r.partition('|')[2]==marker}
   if len(matches)>1:raise RuntimeError('Duplicate scheduler marker')
   job=matches.pop() if matches else command(['sbatch','--hold','--parsable','--comment='+marker,*options]).split(';')[0]
   state['jobs'][key]=job;atomic_json(output,state);return job
  engineering=submit('engineering',str(ROOT/'scripts/parallel_engineering.slurm'))
  previous=engineering;order=['M1','M2','M4','M6','M7','M8','M5','M3','Local-adapter','M9']
  for method in order:
   options=['--dependency=afterok:'+previous,'--job-name=fwfull-s43-'+method]
   if method=='M9':options+=['--gres=gpu:staff:1','--ntasks=1','--mem=64G']
   previous=submit(method,*options,str(ROOT/'scripts/parallel_campaign.slurm'),str(planpath),method)
  evaluations=submit('evaluation','--dependency=afterok:'+state['jobs']['M1'],str(ROOT/'scripts/parallel_eval.slurm'),str(planpath))
  submit('report',f'--dependency=afterany:{previous}:{evaluations}',str(ROOT/'scripts/parallel_finalize.slurm'),str(planpath))
  # All dependencies and jobs exist before a GPU task can start.
  for key in [k for k in state['jobs'] if k!='engineering']+['engineering']:
   if key in state.setdefault('released',[]):continue
   job=state['jobs'][key];r=subprocess.run(['scontrol','show','job','-o',job],capture_output=True,text=True)
   if r.returncode==0 and 'Reason=JobHeldUser' in r.stdout:subprocess.run(['scontrol','release',job],check=True)
   elif r.returncode==0 and 'Reason=JobHeldAdmin' in r.stdout:raise RuntimeError('Administrator hold: '+job)
   state['released'].append(key);atomic_json(output,state)
  state['state']='submitted';atomic_json(output,state);print(json.dumps(state,indent=2))
if __name__=='__main__':main()
