"""CPU-only bounded retry for native local acceptance on externally occupied GPUs."""
import fcntl
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parent/'src'))
from fedwam.io import ROOT,NATIVE_LOCAL_STORAGE_ROOT, load
from fedwam.round_runtime import atomic_json
from train_native_local import run_identity
from native_local_controller import finalize

CLIENTS = ('lighting', 'camera_pose', 'sensor_noise', 'background')
OUT = ROOT/'reports/native_local_seed42_v3/retry'


def retry_candidates(states, *, active, done, attempts, limit=12, max_active=2):
    for client, state in states.items():
        if client in done:
            continue
        if state.get('state') == 'failed' and 'Allocated GPU already occupied or insufficient memory' not in state.get('error', ''):
            raise ValueError(f'Non-resource native local failure for {client}: {state.get("error")}')
    slots = max(0, max_active-active)
    candidates = []
    for client in CLIENTS:
        if client in done or states.get(client, {}).get('state') != 'failed':
            continue
        if attempts.get(client, 0) >= limit:
            raise RuntimeError(f'GPU allocation retries exhausted for {client}')
        candidates.append(client)
    return candidates[:slots]


def queue_rows(running_only=False):
    command = ['squeue', '-u', str(os.getuid()), '-h']
    if running_only:
        command += ['-t', 'RUNNING']
    command += ['-o', '%i|%j']
    output = subprocess.check_output(command, text=True)
    return [tuple(row.split('|', 1)) for row in output.splitlines() if '|' in row]


def main():
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('Native local retry coordinator requires CPU Slurm job')
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT/'controller.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state_path = OUT/'scheduler.json'
        state = load(state_path) if state_path.exists() else {'attempts': {}, 'submitted': {}}
        expected = run_identity('engineering', 2, 2)
        while True:
            if shutil.disk_usage(NATIVE_LOCAL_STORAGE_ROOT).free < 80*1024**3:
                raise RuntimeError('Data filesystem below 80-GiB floor')
            states = {}
            done = set()
            for client in CLIENTS:
                root = NATIVE_LOCAL_STORAGE_ROOT/'engineering'/client
                path = root/'status.json'
                states[client] = load(path) if path.exists() else {}
                proof = root/'verification.json'
                if proof.exists():
                    receipt = load(proof)
                    if receipt.get('passed') is not True or receipt.get('identity') != expected:
                        raise ValueError('Native local verification mismatch: '+client)
                    done.add(client)
            if len(done) == len(CLIENTS):
                finalize('engineering')
                atomic_json(OUT/'status.json', {'state': 'completed', 'clients': list(CLIENTS),
                                                'attempts': state['attempts']})
                return
            rows = queue_rows()
            active = sum(name == 'fwfull-native-local' for _, name in queue_rows(True))
            pending_retries = {client for client, job in state['submitted'].items()
                               if any(key == job or key.startswith(job+'_') for key, _ in rows)}
            candidates = retry_candidates(states, active=active+len(pending_retries),
                                          done=done, attempts=state['attempts'])
            for client in candidates:
                if client in pending_retries:
                    continue
                index = CLIENTS.index(client)
                attempt = state['attempts'].get(client, 0)+1
                command = ['sbatch', '--parsable', '--gres=gpu:staff:1',
                           f'--array={index}',
                           f'--comment=fwnat-local-retry:{client}:{attempt}',
                           str(ROOT/'scripts/native_local_client.slurm'), 'engineering']
                job = subprocess.check_output(command, text=True).strip().split(';')[0]
                state['attempts'][client] = attempt
                state['submitted'][client] = job
                atomic_json(state_path, state)
                pending_retries.add(client)
            atomic_json(OUT/'status.json', {'state': 'running', 'done': sorted(done),
                                            'active_gpu_jobs': active,
                                            'pending_retries': sorted(pending_retries),
                                            'attempts': state['attempts']})
            time.sleep(20)


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        atomic_json(OUT/'status.json', {'state': 'failed', 'error': repr(error)})
        raise
