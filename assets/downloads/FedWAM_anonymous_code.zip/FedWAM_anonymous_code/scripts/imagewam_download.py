"""Download only manifest-listed public assets; atomic publication after verification."""
import concurrent.futures
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reports/imagewam_preparation'


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


def fetch(row):
    target = Path(row['destination'])
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        if target.exists():
            if target.stat().st_size != row['size']:
                raise ValueError('Existing published asset size mismatch; refusing overwrite')
            digest = sha256(target)
            if row['sha256'] and digest != row['sha256']:
                raise ValueError('Existing published asset checksum mismatch; refusing overwrite')
            return dict(row, state='verified', reused=True, actual_sha256=digest)
        partial = target.with_name(target.name + '.partial')
        url = f"https://huggingface.co/{row['repo']}/resolve/{row['revision']}/{row['filename']}?download=true"
        print('Downloading:', row['repo'], row['filename'], row['size'], flush=True)
        if row['size'] >= 64 * 1024**2:
            command = ['aria2c', '--continue=true', '--auto-file-renaming=false',
                       '--allow-overwrite=true', '--file-allocation=none',
                       '--max-connection-per-server=16', '--split=16', '--min-split-size=4M',
                       '--max-tries=12', '--retry-wait=5', '--connect-timeout=30',
                       '--timeout=120', '--summary-interval=60', '--console-log-level=warn',
                       '--download-result=hide', '--dir=' + str(partial.parent),
                       '--out=' + partial.name, url]
        else:
            command = ['curl', '--fail', '--location', '--silent', '--show-error',
                       '--retry', '5', '--retry-all-errors', '--retry-delay', '5',
                       '--connect-timeout', '30', '--speed-limit', '1024', '--speed-time', '120',
                       '--continue-at', '-', '--output', str(partial), url]
        subprocess.run(command, check=True)
        if partial.stat().st_size != row['size']:
            raise ValueError('Downloaded size mismatch')
        digest = sha256(partial)
        if row['sha256'] and digest != row['sha256']:
            raise ValueError('Downloaded checksum mismatch; partial preserved')
        partial.rename(target)
        print('Verified:', row['filename'], flush=True)
        return dict(row, state='verified', reused=False, actual_sha256=digest)
    except Exception as error:
        return dict(row, state='failed', error=str(error))


def main():
    manifest = json.loads((ROOT / 'manifests/imagewam_assets.json').read_text())
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        for result in pool.map(fetch, manifest['files']):
            results.append(result)
            temporary = OUT / 'downloads.json.partial'
            temporary.write_text(json.dumps({'files': results, 'blocked': manifest['blocked']}, indent=2))
            temporary.replace(OUT / 'downloads.json')
    if any(r['state'] != 'verified' for r in results):
        raise SystemExit('Some public assets failed; inspect downloads.json')
    print('All public files verified. Gated AE remains separate; this is not model acceptance.', flush=True)


if __name__ == '__main__':
    main()
