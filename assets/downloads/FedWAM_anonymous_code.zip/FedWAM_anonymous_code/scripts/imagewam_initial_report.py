"""Development-only summary after the independent native-adaptation pipelines."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from imagewam_model_acceptance import write
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from fedwam.heterogeneous.development import select_adapted_readout, DOMAINS, KINDS
from fedwam.heterogeneous.reference import REFERENCE_ID


def main(job):
    clients=[];results={kind:{} for kind in KINDS}
    for domain in DOMAINS:
        status_path=Path('/workspace/reviewer/fedwam-heterogeneous-native-v4')/domain/'status.json'
        state=json.loads(status_path.read_text()) if status_path.exists() else {}
        row=dict(domain=domain,native_state=state.get('state','not_started'),step=state.get('step',0),readouts={})
        if state.get('error'):row['native_error']=state['error']
        for kind in KINDS:
            output=ROOT/f'reports/heterogeneous/adapted-readout-{kind}-{domain}-{job}'
            path=output/'result.json'
            if path.exists():
                result=json.loads(path.read_text());metrics=result['curves'][-1]
                with (output/'readout.pt').open('rb') as f:
                    if hashlib.file_digest(f,'sha256').hexdigest()!=result['head_sha256']:
                        raise ValueError('Readout checkpoint differs from its development receipt')
                if result['native_adaptation']['identity']!=json.loads((status_path.parent/'identity.json').read_text()):
                    raise ValueError('Readout native identity differs from client')
                results[kind][domain]=result
                row['readouts'][kind]=dict(completed=True,mse=metrics['mse'],copy_mse=metrics['copy_mse'],
                    beats_copy=result['development_beats_copy'],native_step=result['native_adaptation']['step'])
            else:
                s=json.loads((output/'status.json').read_text()) if (output/'status.json').exists() else {}
                row['readouts'][kind]=dict(completed=False,state=s.get('state','not_started'),error=s.get('error'))
        clients.append(row)
    complete=all(r['native_state']=='completed' and r['step']==1000 and all(v['completed'] for v in r['readouts'].values()) for r in clients)
    report=dict(seed=42,array_job=job,development_complete=complete,clients=clients,
                readout_selection=select_adapted_readout(results,reference_id=REFERENCE_ID),
                formal_federation_started=False,scope='native local adaptation and common readout development; no control-effect claim')
    write(ROOT/'reports/heterogeneous/native_initial_report.json',report)
    for row in clients:
        print(row['domain'],str(row['step'])+'/1000',row['native_state'],
              'readout checks',sum(v['completed'] for v in row['readouts'].values()),'/2')
    print('Formal heterogeneous federation: not started')
    print('Selected common readout:',report['readout_selection']['selected_readout'] or 'none')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--array-job',required=True);args=p.parse_args();main(args.array_job)
