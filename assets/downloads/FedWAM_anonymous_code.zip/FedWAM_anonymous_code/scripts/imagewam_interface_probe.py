"""Real model H8 graph/normalization probe, distinct from scientific training."""
import argparse
import gc
import json
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / 'src'), str(ROOT / 'third_party/ImageWAM'),
                str(ROOT / 'third_party/ImageWAM/experiments/libero')]
from imagewam_model_acceptance import check_keys, write


def run(output, domain):
    import numpy as np
    import torch
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.interface import FutureReadout, pool_spatial
    from fedwam.heterogeneous.reference import ReferenceEncoder, REFERENCE_ID
    from fedwam.heterogeneous.imagewam import make_native_sample, prefix_cache, control_features_from_cache

    torch.manual_seed(42)
    status = dict(state='running', phase='load', seed=42, domain=domain,
                  scope='H8 engineering graph probe; not full training or calibrated prediction acceptance')
    write(output / 'status.json', status)
    cfg = OmegaConf.load(ROOT / 'reports/imagewam_preparation/native_eval_config.yaml')
    model = instantiate(cfg.model, model_dtype=torch.bfloat16, device='cuda')
    hook = model.mot.register_load_state_dict_post_hook(lambda m, k: check_keys(k.missing_keys, k.unexpected_keys))
    try:
        payload = model.load_checkpoint(str(cfg.ckpt))
        if 'proprio_encoder' not in payload:
            raise ValueError('Missing proprio weights')
        del payload
    finally:
        hook.remove()
    gc.collect()
    model.eval().requires_grad_(False)
    processor = instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    sample = HeterogeneousDataset(ROOT, 'B', domain).sample(0)
    native = make_native_sample(sample, processor)
    text, mask = model._encode_flux2_prompts([native['instruction']])
    native['text_hidden_states'], native['text_attention_mask'] = text, mask
    image, proprio = native['current_frame'], native['proprio']
    infer = dict(prompt=None, input_image=image, proprio=proprio, context=text, context_mask=mask,
                 action_horizon=8, num_inference_steps=10, seed=42)
    status['phase'] = 'deployment_prefix_parity'
    write(output / 'status.json', status)
    captured = []
    original = model.mot.prefill_flux2_video_cache
    def capture(**kwargs):
        cache = original(**kwargs)
        captured.append(control_features_from_cache(cache).detach())
        return cache
    model.mot.prefill_flux2_video_cache = capture
    try:
        before_action = model.infer_action_flux2(**infer)['action']
    finally:
        model.mot.prefill_flux2_video_cache = original
    with torch.no_grad():
        own_features = control_features_from_cache(prefix_cache(model, image, text, mask, proprio))
    parity = (captured[0].float() - own_features.float()).abs().max().item()
    if parity > 1e-5:
        raise ValueError(f'Deployment prefix parity failed: {parity}')
    del captured
    # Shared encoder uses its pinned reference preprocessing and excludes registers.
    reference = ROOT / 'assets/dinov3-vitb16-pretrain-lvd1689m'
    encoder = ReferenceEncoder(reference)
    with torch.no_grad():
        z_current, z_future = encoder([sample['primary'], sample['future']]).chunk(2)
    del encoder
    gc.collect()
    torch.cuda.empty_cache()
    # Text cache is now fixed; free the large frozen text encoder for graph tests.
    model.text_encoder.model.to('cpu')
    torch.cuda.empty_cache()
    head = FutureReadout(own_features.shape[-1]).cuda()
    head.requires_grad_(False)
    # Engineering intervention targets one actual world layer; not a full-model recipe.
    world = model.video_expert.single_blocks[-1].linear1
    world.requires_grad_(True)
    action_versions = {n: p._version for n, p in model.action_expert.named_parameters()}
    status['phase'] = 'world_gradient_and_action_intervention'
    write(output / 'status.json', status)
    with torch.autocast('cuda', dtype=torch.bfloat16):
        h = control_features_from_cache(prefix_cache(model, image, text, mask, proprio))
        pred = head(h)
    loss = (pred.float() - z_future.float()).square().mean()
    loss.backward()
    grad = world.weight.grad
    if grad is None or not torch.isfinite(grad).all() or grad.float().abs().sum() == 0:
        raise ValueError('Readout loss does not reach actual world parameters')
    grad_norm = grad.float().norm().item()
    if any(p.grad is not None for p in head.parameters()) or any(p.grad is not None for p in model.action_expert.parameters()):
        raise ValueError('Private action or frozen readout unexpectedly received interface gradients')
    del h, pred, loss
    with torch.no_grad():
        scale = grad.float().square().mean().sqrt().clamp_min(1e-12)
        world.weight.add_((-1e-3 * grad.float() / scale).to(world.weight.dtype))
    world.zero_grad(set_to_none=True)
    world.requires_grad_(False)
    after_action = model.infer_action_flux2(**infer)['action']
    delta = (after_action - before_action).abs().max().item()
    if not torch.isfinite(after_action).all() or delta == 0:
        raise ValueError('World intervention did not change finite action output')
    if any(p._version != action_versions[n] for n, p in model.action_expert.named_parameters()):
        raise ValueError('Action expert changed during world-only intervention')
    # Native joint loss consumes the true H8 future, not a cropped H16 prediction.
    status['phase'] = 'native_h8_loss'
    write(output / 'status.json', status)
    with torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
        native_loss, components = model.training_loss(native)
    if not torch.isfinite(native_loss):
        raise ValueError('Nonfinite native image/action loss')
    physical = processor.normalizer.normalizers['action']['default'].backward(native['action']).numpy()[0]
    physical[:, -1] = -(2 * physical[:, -1] - 1)
    norm_error = float(np.abs(physical - sample['actions']).max())
    if norm_error > 1e-4:
        raise ValueError('PLUS physical action roundtrip failed')
    result = dict(passed=True, seed=42, domain=domain, reference_id=REFERENCE_ID, record_id=sample['record_id'],
                  source_group=sample['source_group'], split=sample['split'],
                  native_h8_action_shape=list(after_action.shape), prefix_parity_max_abs=parity,
                  control_feature_shape=list(own_features.shape), shared_target_shape=list(z_future.shape),
                  world_gradient_norm=grad_norm, world_parameter='single_blocks[-1].linear1.weight',
                  intervention_rms=1e-3, action_change_max_abs=delta, action_parameters_unchanged=True,
                  frozen_head_gradient_none=True, physical_roundtrip_max_error=norm_error,
                  native_loss=float(native_loss), native_components=components,
                  current_copy_mse=float((z_current-z_future).square().mean()),
                  readout_calibrated=False, full_native_backward_validated=False,
                  scientific_training_started=False, peak_gpu_bytes=torch.cuda.max_memory_allocated())
    write(output / 'result.json', result)
    status.update(state='completed', phase='h8_graph_probe')
    write(output / 'status.json', status)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--domain', choices=['lighting', 'camera_pose', 'sensor_noise', 'background'], default='lighting')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        run(args.output, args.domain)
    except Exception as exc:
        path = args.output / 'status.json'
        status = json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed', error=repr(exc)[:2000])
        write(path, status)
        traceback.print_exc()
        raise SystemExit(1)
