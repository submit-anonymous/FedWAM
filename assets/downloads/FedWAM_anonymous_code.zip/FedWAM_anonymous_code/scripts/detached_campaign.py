"""CPU controller: independent one-GPU jobs, never reserve GPUs while waiting."""
import argparse,fcntl,json,os,shutil,subprocess,sys,time,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,digest,file_hash
from fedwam.experiment_config import METHODS,resolved_config,code_identity
from fedwam.detached_execution import detached_identity,detached_code,check_gate
from fedwam.detached_engine import DetachedEngine
from fedwam.parallel_execution import claim_filtered,remaining
from fedwam.round_runtime import atomic_json
from fedwam.retention import compact_completed_run
from fedwam.work_queue import WorkQueue
from plan_federated import make_plan

PLAN=ROOT/'manifests/fedwam_seed43_detached_work_plan.json'
OUT=ROOT/'reports/detached_engineering'
ORDER=['M1','M2','M4','M6','M7','M8','M5','M3','Local-adapter','M9']
def command(args):return subprocess.check_output(args,text=True).strip()
def queue_jobs():
 rows=command(['squeue','-u',str(os.getuid()),'-h','-o','%i|%T|%k|%r']).splitlines()
 return {row.split('|',3)[0]:dict(zip(('state','comment','reason'),row.split('|',3)[1:])) for row in rows}
def ensure_job(state,key,args,path,marker):
 # Persist a stable request before submission; reconcile an interrupted reply by comment.
 entry=state['jobs'].setdefault(key,{'job':None,'token':uuid.uuid4().hex})
 atomic_json(path,state);rows=queue_jobs()
 if entry['job'] is None:
  matches={job.split('_')[0] for job,row in rows.items() if row['comment']==marker}
  if len(matches)>1:raise ValueError('Duplicate job marker')
  entry['job']=matches.pop() if matches else command(['sbatch','--hold','--parsable','--comment='+marker,*args]).split(';')[0]
  atomic_json(path,state);rows=queue_jobs()
 matching=[v for job,v in rows.items() if job==entry['job'] or job.startswith(entry['job']+'_')]
 if any(v['reason']=='JobHeldUser' for v in matching):subprocess.run(['scontrol','release',entry['job']],check=True)
 return entry['job']
def prepare():
 plan=make_plan('fedwam_seed43_detached');plan['runs']=[r for r in plan['runs'] if r.endswith('/seed43')]
 plan['tasks']=[t for t in plan['tasks'] if '-s43-' in t['id']]
 for task in plan['tasks']:
  if task['kind']=='train':task.update(kind='detached_train',method=task['argv'][task['argv'].index('--method')+1])
 plan.update(seeds=[43],deferred_seeds=[42,44],max_gpu_workers=4,training_jobs=10,rollout_cases=371110,
  execution_code=detached_identity(resolved_config('M1',43,'engineering'))['code'],expected_final_models=37,
  expected_prediction_inputs=1584830,scope='four independent one-GPU client jobs; stage waits release GPUs; seed43 only; evaluation follows training')
 if PLAN.exists() and load(PLAN)!=plan:raise ValueError('Frozen detached plan changed')
 atomic_json(PLAN,plan);WorkQueue(Path(plan['root'])/'scheduler',plan['tasks']);print(str(PLAN))
def validated_plan():
 plan=load(PLAN)
 if plan['seeds']!=[43] or plan['code']!=code_identity() or plan['execution_code']!=detached_identity(resolved_config('M1',43,'engineering'))['code']:raise ValueError('Execution plan changed')
 return plan
def launch():
 plan=validated_plan();path=ROOT/'reports/scheduling/seed43_detached_jobs.json';path.parent.mkdir(parents=True,exist_ok=True)
 with path.with_suffix('.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  state=load(path) if path.exists() else dict(state='submitting',plan_sha256=file_hash(PLAN),jobs={},max_total_gpus=4,seeds=[43])
  if state['plan_sha256']!=file_hash(PLAN):raise ValueError('Submission plan differs')
  tag='fwdet:'+state['plan_sha256'][:12]
  controller=ensure_job(state,'controller',[str(ROOT/'scripts/detached_pipeline.slurm')],path,tag+':controller')
  evaluation=ensure_job(state,'evaluation',['--dependency=afterok:'+controller,str(ROOT/'scripts/detached_eval.slurm')],path,tag+':evaluation')
  ensure_job(state,'report',['--dependency=afterany:'+evaluation,str(ROOT/'scripts/parallel_finalize.slurm'),str(PLAN)],path,tag+':report')
  state['state']='submitted';atomic_json(path,state);print(json.dumps(state,indent=2))
def run_method(cfg,root):
 ident=detached_identity(cfg);root.mkdir(parents=True,exist_ok=True)
 proof=root/'verification.json'
 if proof.exists():
  receipt=load(proof)
  if receipt.get('identity')!=ident or receipt.get('passed') is not True:raise ValueError('Stale method proof')
  return compact_completed_run(root,ident)
 clients=['pooled'] if cfg['method']=='M9' else cfg['clients']
 path=root/'detached_scheduler.json'
 state=load(path) if path.exists() else dict(identity=ident,attempt=uuid.uuid4().hex,jobs={},sequence={c:0 for c in clients},current={})
 if state['identity']!=ident:raise ValueError('Method scheduler identity changed')
 atomic_json(path,state)
 # Also initializes and validates the shared store before any GPU is submitted.
 coordinator=DetachedEngine(root,ident,cfg,None,clients[0],state['attempt'])
 while True:
  if detached_identity(cfg)!=ident:raise ValueError('Active execution changed')
  if shutil.disk_usage(ROOT).free<80*1024**3:raise RuntimeError('Disk below80GiB; active checkpoints retained')
  failures=list((root/f"attempts/{state['attempt']}/errors").glob('*.json'))
  if failures:raise RuntimeError(failures[0].read_text()[:1000])
  rows=queue_jobs();done=[];active=[]
  for client in clients:
   key=state['current'].get(client);entry=state['jobs'].get(key) if key else None
   if entry and entry['job'] in rows:
    if rows[entry['job']]['reason']=='JobHeldUser':subprocess.run(['scontrol','release',entry['job']],check=True)
    active.append(client);continue
   completion=root/f'client_verification/{client}.json'
   if completion.exists():
    value=load(completion)
    if value.get('attempt')==state['attempt'] and value.get('identity')==ident and value.get('passed') is True:done.append(client);continue
   result=root/f'client_job_state/{client}.json'
   if entry and entry['job'] is not None:
    value=load(result) if result.exists() else {}
    if value.get('token')!=entry['token'] or value.get('state') not in ('waiting_dependency','training_completed'):
     raise RuntimeError(f'Client job {entry["job"]} ended without a successful stage: {value}')
    if value['state']=='training_completed':raise ValueError('Missing client completion proof')
    waiting=coordinator.store.path(value['wait'])
    if not waiting.exists():continue
   if entry is None or entry['job'] is not None:
    state['sequence'][client]+=1;key=f'{client}-{state["sequence"][client]}'
    state['current'][client]=key;entry={'job':None,'token':uuid.uuid4().hex};state['jobs'][key]=entry;atomic_json(path,state)
   marker=f'fwdet:{digest(ident)[:12]}:{key}'
   ensure_job(state,key,['--job-name=fwfull-'+cfg['mode'][:3]+'-'+cfg['method']+'-'+client,
     str(ROOT/'scripts/detached_client.slurm'),'--method',cfg['method'],'--mode',cfg['mode'],'--run',str(root),
     '--client',client,'--attempt',state['attempt'],'--token',entry['token']],path,marker)
   active.append(client)
  atomic_json(root/'detached_status.json',dict(state='running',method=cfg['method'],mode=cfg['mode'],completed_clients=done,allocated_or_queued=active,client_jobs={c:state['jobs'][k]['job'] for c,k in state['current'].items()}))
  if len(done)==len(clients) and not active:break
  time.sleep(10)
 final=coordinator.finalize();proofs={c:load(root/f'client_verification/{c}.json') for c in clients}
 atomic_json(proof,dict(passed=True,identity=ident,scope=cfg['mode'],module_updates={c:p['module_updates'] for c,p in proofs.items()},frozen_sha256_by_client={c:p['frozen_sha256'] for c,p in proofs.items()},allocation='independent one-GPU jobs; GPUs may be reused across clients'))
 compact_completed_run(root,ident);atomic_json(root/'detached_status.json',dict(state='completed',clients=clients))
 return final
def pipeline():
 if not os.environ.get('SLURM_JOB_ID'):raise ValueError('CPU Slurm controller required')
 plan=validated_plan();base=Path(plan['root']);base.mkdir(parents=True,exist_ok=True)
 with (base/'controller.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  ident=detached_identity(resolved_config('M1',43,'engineering'));tag=digest(ident)[:16];passed=[]
  for method in ORDER:
   atomic_json(OUT/'status.json',dict(state='running',method=method,passed=passed,seed=43))
   run_method(resolved_config(method,43,'engineering'),ROOT/'runs/detached_engineering'/tag/method);passed.append(method)
  summary={k:ident[k] for k in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','execution')}
  summary.update(passed=True,seed=43,methods_passed=passed,mode='real_detached_client_engineering',scope='engineering budgets only',runs_root=str(ROOT/'runs/detached_engineering'/tag))
  atomic_json(OUT/'summary.json',summary);atomic_json(OUT/'status.json',dict(state='completed',methods_passed=passed))
  queue=WorkQueue(base/'scheduler',plan['tasks'])
  for method in ORDER:
   validated_plan();cfg=resolved_config(method,43,'formal');check_gate(cfg,summary)
   task=claim_filtered(queue,'controller',['detached_train'],method)
   if task is None:continue
   try:run_method(cfg,base/method/'seed43')
   except Exception:queue.finish('controller',task['id'],1);raise
   queue.finish('controller',task['id'],0)
  atomic_json(base/'controller_status.json',dict(state='completed',seed=43))
def evaluate(worker):
 if not os.environ.get('SLURM_JOB_ID'):raise ValueError('Slurm required')
 plan=validated_plan();seed,=plan['seeds'];check_gate(resolved_config('M1',seed,'formal'),load(OUT/'summary.json'))
 queue=WorkQueue(Path(plan['root'])/'scheduler',plan['tasks']);owner=f'eval-{worker}'
 with (queue.root/(owner+'.lock')).open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  while True:
   validated_plan()
   if shutil.disk_usage(ROOT).free<80*1024**3:raise RuntimeError('Disk below80GiB')
   task=claim_filtered(queue,owner,['rollout','prediction'])
   if task is None:
    if not remaining(queue,['rollout','prediction']):break
    time.sleep(30);continue
   log=queue.root/'logs'/(task['id']+'.log');log.parent.mkdir(exist_ok=True)
   atomic_json(queue.root/(owner+'.json'),dict(state='running',task=task['id'],log=str(log)))
   with log.open('a') as out:result=subprocess.run(task['argv'],cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
   queue.finish(owner,task['id'],result.returncode)
   if result.returncode:raise RuntimeError('Failed '+task['id'])
def main():
 p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','launch','pipeline','evaluate']);p.add_argument('--worker',type=int,choices=[0,1]);args=p.parse_args()
 if args.command=='prepare':prepare()
 elif args.command=='launch':launch()
 elif args.command=='pipeline':
  try:pipeline()
  except Exception as error:atomic_json(OUT/'pipeline_error.json',dict(state='failed',error=repr(error)));raise
 else:evaluate(args.worker)
if __name__=='__main__':main()
