"""Auditable ancestry, source-group allocation and bounded overlap conclusions."""
import sys,struct,json,hashlib,re
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,digest,file_hash
from fedwam.provenance import ordered_action_match,continuous_starts,allocate_groups,state_matches
from fedwam.rlds import feature_payloads
OUT=ROOT/'reports/data/provenance'

def main():
    import h5py,torch
    raw=load(ROOT/'manifests/raw_episodes.json')['rows']
    originals=load(ROOT/'manifests/original_hdf5.json')['rows']
    bytask=defaultdict(list)
    for r in raw:bytask[(r['suite'],r['source_file'])].append(r)
    exposed=set(load(ROOT/'reports/data/source_audit/summary.json')['engineering_exposed_exact_groups'])
    lineage=[];groups=[];original_records=[];task_reports=[]
    for done,origin in enumerate(originals):
        suite=origin['suite'];name=origin['source_file'];rows=bytask[suite,name]
        status(OUT,state='running',phase='source_lineage',tasks_done=done,tasks_total=len(originals))
        with h5py.File(origin['path'],'r') as h:
            demos={k:{'action':v['actions'][:], 'init':np.asarray(v.attrs['init_state']),
                      'first_state':v['states'][0], 'xml':str(v.attrs['model_file'])} for k,v in h['data'].items()}
        # Full simulator states and model XML are stored as audit artifacts, not inferred from RLDS state8.
        saved=OUT/'original_states'/suite; saved.mkdir(parents=True,exist_ok=True)
        for demo,d in demos.items():
            uid=f'{suite}/{name}/{demo}';key=digest(uid)
            np.savez_compressed(saved/f'{key}.npz',init=d['init'],first_state=d['first_state'])
            (saved/f'{key}.xml').write_text(d['xml'])
            original_records.append({'source':uid,'suite':suite,'source_file':name,'demo':demo,
                'key':key,'state_file':str(saved/f'{key}.npz'),'xml':str(saved/f'{key}.xml')})
        exact=defaultdict(list)
        for r in rows:exact[r['exact_group']].append(r)
        for exactid,members in exact.items():
            query=np.load(members[0]['numeric_path'])['action'];candidates=[]
            for demo,d in demos.items():
                indices=ordered_action_match(query,d['action'])
                if indices is None:continue
                backwards=ordered_action_match(query[::-1],d['action'][::-1])
                latest=[len(d['action'])-1-i for i in backwards[::-1]]
                unique_timing=indices==latest
                candidates.append(dict(source=f'{suite}/{name}/{demo}',demo=demo,indices=indices,
                    timing_unique=unique_timing,continuous_chunk_starts=continuous_starts(indices,8) if unique_timing else []))
            lineage.append({'exact_group':exactid,'suite':suite,'source_file':name,'records':[r['record_id'] for r in members],
                'candidates':candidates,'status':'unique_action_ancestry' if len(candidates)==1 else 'ambiguous' if candidates else 'unmatched',
                'actual_replay_full_state':'not_in_released_rlds','replay_environment_parameters':'not_in_released_rlds',
                'action_ancestry_is_not_full_state_equality':True,'exposed':exactid in exposed})
        selected=[x for x in lineage if x['suite']==suite and x['source_file']==name]
        task_reports.append({'suite':suite,'source_file':name,'status_counts':dict(Counter(x['status'] for x in selected))})
    # Union all possible shared ancestors; ambiguous candidates are kept together and quarantined.
    parent={x['exact_group']:x['exact_group'] for x in lineage}
    def find(x):
        while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
        return x
    def union(a,b):
        a,b=find(a),find(b)
        if a!=b:parent[max(a,b)]=min(a,b)
    ancestor={}
    for x in lineage:
        for c in x['candidates']:
            if c['source'] in ancestor:union(x['exact_group'],ancestor[c['source']])
            else:ancestor[c['source']]=x['exact_group']
    components=defaultdict(list)
    for x in lineage:components[find(x['exact_group'])].append(x)
    for component in components.values():
        sources=sorted({c['source'] for x in component for c in x['candidates']})
        gid=digest(sources if sources else sorted(x['exact_group'] for x in component))
        strata={(x['suite'],x['source_file']) for x in component}
        if len(strata)!=1:raise ValueError('Cross-task ancestry needs explicit handling')
        groups.append(dict(group=gid,stratum='/'.join(next(iter(strata))),sources=sources,
            exact_groups=sorted(x['exact_group'] for x in component),exposed=any(x['exposed'] for x in component),
            resolved=all(x['status']=='unique_action_ancestry' for x in component)))
    allocation=allocate_groups([g for g in groups if g['resolved']],20260921)
    exact_to_group={e:g for g in groups for e in g['exact_groups']}
    lines={x['exact_group']:x for x in lineage};splitrows=[]
    for r in raw:
        g=exact_to_group[r['exact_group']];lin=lines[r['exact_group']]
        c=lin['candidates'][0] if len(lin['candidates'])==1 else None
        splitrows.append(dict(record_id=r['record_id'],source_group=g['group'],exact_group=r['exact_group'],
            split=allocation.get(g['group'],'quarantine'),source_bucket=r['source_bucket'],suite=r['suite'],
            source_file=r['source_file'],continuous_chunk_starts=c['continuous_chunk_starts'] if c else [],
            accepted_for_strict_training=False))
    # RLDS field presence: published schema is homogeneous, check representative record; complete index already validated.
    first=raw[0]
    with open(first['shard'],'rb') as f:
        f.seek(first['offset']);size=struct.unpack('<Q',f.read(8))[0];f.read(4);feature_keys=sorted(feature_payloads(f.read(size)))
    instructions={b:sorted({r['task'] for r in raw if r['source_bucket']==b}) for b in sorted({r['source_bucket'] for r in raw})}
    summary=dict(raw_records=len(raw),exact_numeric_groups=len(lines),ancestral_groups=len(groups),
        ancestry_status=dict(Counter(x['status'] for x in lineage)),group_split_counts=dict(Counter(allocation.values())),
        record_split_counts=dict(Counter(r['split'] for r in splitrows)),
        records_with_temporal_gaps=sum(bool(lines[r['exact_group']]['candidates']) and any(np.any(np.diff(c['indices'])!=1) for c in lines[r['exact_group']]['candidates']) for r in raw),
        continuous_chunk_starts=sum(len(r['continuous_chunk_starts']) for r in splitrows),
        distinct_instructions={b:len(v) for b,v in instructions.items()},
        language_new_instructions=len(set(instructions['language'])-set().union(*(set(v) for k,v in instructions.items() if k!='language'))),
        feature_keys=feature_keys,source_buckets=dict(Counter(r['source_bucket'] for r in raw)),
        seven_client_training_gate='closed',
        limitations=['env=background is supported by paper and variant names, but no released generation log maps every record to texture parameters',
            'No object_layout or robot_initial source paths; language bucket has no extra instructions',
            'Action ancestry and split allocation do not establish actual PLUS replay initial state or environment identity',
            'Continuous original action indices are ancestry timing evidence, not independently recorded RLDS timestamps',
            'Fixed SFT initialization has its own original-LIBERO training exposure; strict novelty cannot be claimed relative to pretraining'])
    save(OUT/'lineage.json',lineage);save(OUT/'original_states.json',original_records);save(OUT/'tasks.json',task_reports)
    save(ROOT/'manifests/source_group_split.json',dict(schema='fedwam.source_split.v1',status='ancestry_allocation_not_training_acceptance',
        seed=20260921,ratios={'train':.7,'calibration':.1,'development':.1,'prediction_test':.1},
        raw_manifest_sha256=file_hash(ROOT/'manifests/raw_episodes.json'),groups=groups,rows=splitrows))
    save(OUT/'summary.json',summary)
    status(OUT,state='completed',phase='ancestry_and_split_audit',**summary)

if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));raise
