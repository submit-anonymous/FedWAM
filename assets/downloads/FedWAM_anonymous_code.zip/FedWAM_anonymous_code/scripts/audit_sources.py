"""Diagnostic source coverage and temporal near-duplicate candidates; emits no training split."""
from pathlib import Path
import sys,hashlib,traceback
from collections import defaultdict,Counter
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash
OUT=ROOT/'reports/data/source_audit'
def main():
    manifest=ROOT/'manifests/raw_episodes.json';rows=load(manifest)['rows']
    exact=defaultdict(list)
    for row in rows:exact[row['exact_group']].append(row)
    coverage=[]
    for suite,source in sorted({(r['suite'],r['source_file']) for r in rows}):
        selected=[r for r in rows if r['suite']==suite and r['source_file']==source]
        for bucket in ('light','camera_view','noise','language','env'):
            subset=[r for r in selected if r['source_bucket']==bucket]
            coverage.append({'suite':suite,'source_file':source,'source_bucket':bucket,
                'episodes':len(subset),'exact_numeric_groups':len({r['exact_group'] for r in subset}),
                'legal_chunk_starts':sum(r['legal_chunk_count'] for r in subset)})
    save(OUT/'coverage.json',coverage)
    by_task=defaultdict(list)
    for gid,group in exact.items():
        # Same numeric trajectory across renderings is one candidate source, not independent evidence.
        sources={(r['suite'],r['source_file']) for r in group}
        for task in sources:by_task[task].append((gid,group[0]))
    candidates=[];processed=0;window=8
    for task,groups in sorted(by_task.items()):
        windows=defaultdict(list);arrays={}
        for gid,row in groups:
            with np.load(row['numeric_path'],allow_pickle=False) as obj:
                array=np.concatenate([obj['action'],obj['state']],axis=1).astype(np.float32)
            arrays[gid]=array;matches=Counter()
            for t in range(len(array)-window+1):
                block=array[t:t+window]
                if np.max(np.std(block[:,:6],axis=0))<1e-5 and np.max(np.abs(block[-1,7:]-block[0,7:]))<1e-4:continue
                rounded=np.round(block,5);rounded[rounded==0]=0
                key=hashlib.sha256(rounded.astype('<f4').tobytes()).digest()
                for previous,start in windows[key]:
                    if previous!=gid:matches[(previous,start-t)]+=1
                windows[key].append((gid,t))
            for (previous,offset),n in matches.items():
                if n<3:continue
                old=arrays[previous];left=max(0,-offset);right=min(len(array),len(old)-offset)
                if right<=left:continue
                difference=np.abs(array[left:right]-old[left+offset:right+offset])
                candidates.append({'suite':task[0],'source_file':task[1],'groups':[previous,gid],
                    'frame_offset':offset,'matching_nonstatic_windows':n,'overlap_frames':right-left,
                    'overlap_max_abs':float(difference.max()),'overlap_rmse':float(np.sqrt(np.mean(difference**2))),
                    'status':'candidate_for_conservative_grouping_not_split_assignment'})
        processed+=1
        status(OUT,state='running',phase='source_overlap_audit',tasks_done=processed,tasks_total=len(by_task),candidates=len(candidates))
    probe=load(ROOT/'reports/control_probe/source_exposure.json')
    exposed=sorted({r['exact_group'] for r in rows if r['action_sha256']==probe['action_sha256'] and r['state_sha256']==probe['state_sha256']})
    report={'manifest_sha256':file_hash(manifest),'raw_records':len(rows),'exact_numeric_groups':len(exact),
        'legal_chunk_starts':sum(r['legal_chunk_count'] for r in rows),'source_bucket_counts':dict(Counter(r['source_bucket'] for r in rows)),
        'records_per_exact_group_histogram':dict(Counter(len(v) for v in exact.values())),
        'multi_source_file_exact_groups':sum(len({(r['suite'],r['source_file']) for r in v})>1 for v in exact.values()),
        'near_duplicate_candidates':candidates,'engineering_exposed_exact_groups':exposed,
        'unresolved_records':sum(r['category'] is None for r in rows),
        'not_yet_verified_training_categories':['background','object_layout','robot_initial'],
        'scope':'diagnostic; rounded-window matching is not an exhaustive near-duplicate proof; no train/calibration/development/test split generated'}
    save(OUT/'summary.json',report)
    status(OUT,state='completed',phase='source_audit_not_training_acceptance',records=len(rows),exact_groups=len(exact),
           near_duplicate_candidates=len(candidates),unresolved_records=report['unresolved_records'])
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
