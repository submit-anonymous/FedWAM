"""Render scientific figures from recorded frames and numerical predictions only."""
from pathlib import Path
import hashlib
import html
import json
import shutil
import textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import imageio.v2 as imageio
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reports/paper_media_20260926'
FIG=OUT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':8,'axes.titlesize':8,'pdf.fonttype':42,'ps.fonttype':42,'font.family':'DejaVu Sans'})

def save(fig,name):
    fig.savefig(FIG/f'{name}.png',dpi=240,bbox_inches='tight',facecolor='white')
    fig.savefig(FIG/f'{name}.pdf',dpi=300,bbox_inches='tight',facecolor='white')
    plt.close(fig)

def task_strip(arch):
    folder=OUT/f'{arch}_full_task';r=json.loads((folder/'result.json').read_text())
    if arch=='imagewam':
        steps=r['selected_frame_steps']
        imgs=[np.asarray(Image.open(folder/'frames'/f'step_{i:04d}.png')) for i in steps]
        label='ImageWAM | Original LIBERO SFT | H16 / replan12'
        footer=f"First predeclared attempt | seed42 / init0 | SUCCESS | {r['actions']} actions at20Hz"
    else:
        reader=imageio.get_reader(folder/'rollout.mp4');n=reader.count_frames()
        steps=np.linspace(0,n-1,6).round().astype(int).tolist()
        dual=[reader.get_data(i) for i in steps];reader.close()
        # Recorded frames concatenate front and wrist horizontally. Show the
        # front camera alone in the paper strip; retain original dual video.
        assert all(im.shape[1]==2*im.shape[0] for im in dual)
        imgs=[im[:,:im.shape[1]//2] for im in dual]
        label='LaWAM | LIBERO SFT engineering case | H8 / replan8'
        footer=f"LIBERO-Plus background case1 | Front camera | SUCCESS | {r['actions']} actions"
        (folder/'frames').mkdir(exist_ok=True)
        for i,img in zip(steps,imgs):Image.fromarray(img).save(folder/'frames'/f'frame_{i:04d}.png')
    fig,axes=plt.subplots(1,6,figsize=(7.2,2.0))
    for ax,img,step in zip(axes,imgs,steps):
        ax.imshow(img);ax.axis('off');ax.set_title(('step' if arch=='imagewam' else 'frame')+f' {step}')
    fig.suptitle(label,y=.98,fontsize=10)
    fig.text(.5,.02,footer,ha='center',fontsize=8)
    fig.subplots_adjust(left=.01,right=.99,bottom=.16,top=.84,wspace=.045)
    save(fig,f'{arch}_task_sequence')

def arrays(row,arch):
    p=OUT/'latent_data'/row['name']
    with np.load(p/f'{arch}.npz') as f:z0=f['current'];z1=f['future'];pred=f['prediction']
    assert z0.shape==z1.shape==pred.shape==(49,768)
    copy=((z1-z0)**2).mean(-1).reshape(7,7)
    error=((pred-z1)**2).mean(-1).reshape(7,7)
    truth=np.sqrt(copy)
    estimated=np.sqrt(((pred-z0)**2).mean(-1)).reshape(7,7)
    assert np.isfinite(np.concatenate([truth.ravel(),estimated.ravel(),error.ravel()])).all()
    return [np.asarray(Image.open(p/'current.png')),np.asarray(Image.open(p/'future.png')),truth,estimated,copy,error]

def latent_figure(rows,arch,name,scale):
    fig,axes=plt.subplots(len(rows),6,figsize=(7.2,1.23*len(rows)+.85),squeeze=False)
    titles=['Current RGB','GT RGB at t+8','GT change RMS','Pred. change RMS','Copy error MSE','Pred. error MSE']
    last=[]
    for i,row in enumerate(rows):
        values=arrays(row,arch)
        for j,(ax,value) in enumerate(zip(axes[i],values)):
            if j<2:ax.imshow(value)
            else:
                im=ax.imshow(value,cmap='viridis' if j<4 else 'magma',vmin=0,vmax=scale[0 if j<4 else 1],interpolation='nearest')
                if i==len(rows)-1:last.append(im)
            ax.set_xticks([]);ax.set_yticks([])
            for spine in ax.spines.values():spine.set_visible(False)
            if i==0:ax.set_title(titles[j],pad=5)
        d=row['domain'].replace('camera_pose','Viewpoint').replace('sensor_noise','Noise').capitalize()
        axes[i,0].set_ylabel(f"{d}\nq{row['quantile']}, t={row['t']}",fontsize=8)
    subtitle='Original LIBERO SFT' if arch=='lawam' else 'Local1000 + calibrated residual readout'
    fig.suptitle(f"{arch.replace('lawam','LaWAM').replace('imagewam','ImageWAM')} | {subtitle} | Development examples",fontsize=10,y=.99)
    fig.subplots_adjust(left=.075,right=.99,bottom=.19,top=.88,hspace=.14,wspace=.06)
    cb1=fig.add_axes([.40,.125,.20,.012]);cb2=fig.add_axes([.72,.125,.20,.012])
    fig.colorbar(last[0],cax=cb1,orientation='horizontal').set_label('Feature change RMS',fontsize=8)
    fig.colorbar(last[-1],cax=cb2,orientation='horizontal').set_label('Feature prediction MSE',fontsize=8)
    cb1.tick_params(labelsize=7);cb2.tick_params(labelsize=7)
    fig.text(.05,.008,'7x7 tokens; no spatial smoothing. Samples selected by GT change, not improvement.',fontsize=8)
    save(fig,name)

def main():
    task_strip('lawam');task_strip('imagewam')
    rows=json.loads((OUT/'latent_samples.json').read_text())
    expected={'lighting','camera_pose','sensor_noise','background'}
    assert len(rows)==12 and {r['domain'] for r in rows}==expected
    scale=[0.,0.]
    for arch in ('lawam','imagewam'):
        for r in rows:
            a=arrays(r,arch)
            scale[0]=max(scale[0],float(a[2].max()),float(a[3].max()))
            scale[1]=max(scale[1],float(a[4].max()),float(a[5].max()))
    for arch in ('lawam','imagewam'):
        latent_figure([r for r in rows if r['quantile']==50],arch,f'{arch}_latent_median',scale)
        for domain in ('lighting','camera_pose','sensor_noise','background'):
            latent_figure([r for r in rows if r['domain']==domain],arch,f'{arch}_latent_{domain}_quartiles',scale)
    (OUT/'figure_encoding.json').write_text(json.dumps(dict(change_rms_vmax=scale[0],error_mse_vmax=scale[1],
        color_scale='Identical for all domains, quantiles and both architectures; zero minimum; no clipping',
        raster='RGB observations and7x7numerical heatmaps; PDF text remains vector',
        note='Model adaptation stages differ; common scales do not imply a fair model ranking'),indent=2))
    shutil.copy2(__file__,OUT/'code'/Path(__file__).name)
    sections=['<h1>FedWAM qualitative media</h1><p>See README_CN.md for provenance, captions and limitations. Native control and development latents are separate experiments.</p>']
    for arch in ('imagewam','lawam'):
        video=f'{arch}_full_task/'+('rollout_front.mp4' if arch=='imagewam' else 'rollout.mp4')
        sections.append(f'<h2>{arch}: complete successful task</h2><video controls width="640" src="{video}"></video><p><a href="{video}">MP4</a></p><img width="100%" src="figures/{arch}_task_sequence.png">')
    for arch in ('imagewam','lawam'):
        sections.append(f'<h2>{arch}: latent development examples</h2><img width="100%" src="figures/{arch}_latent_median.png">')
    sections.append('<h2>Original observations and numerical arrays</h2><p>latent_data/: twelve source-traceable chunks; imagewam.npz and lawam.npz contain current, future and prediction, each49x768.</p>')
    sections.append('<h2>Historical LaWAM illustrative comparisons</h2><p>Selected early pilot cases, not current full experiment results.</p>')
    for p in sorted((OUT/'legacy_lawam/images').glob('*.png')):
        sections.append(f'<p>{html.escape(p.name)}</p><img width="100%" src="{p.relative_to(OUT)}">')
    (OUT/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>FedWAM media</title><style>body{max-width:1100px;margin:32px auto;font:16px sans-serif;color:#222}img{margin:12px 0}video{max-width:100%}</style>'+''.join(sections))
    print('Rendered12PNG+12PDF figures and local gallery.')

if __name__=='__main__':main()
