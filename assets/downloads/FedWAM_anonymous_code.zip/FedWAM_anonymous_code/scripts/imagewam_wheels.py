"""Stage official wheels with resumable transfers before uv installation."""
import concurrent.futures
import hashlib
import json
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'cache/imagewam/wheelhouse'


def checksum(path):
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda:source.read(8*1024**2),b''):digest.update(chunk)
    return digest.hexdigest()


def download(row):
    path=DEST/row['filename']
    if path.exists():
        if checksum(path)!=row['sha256']:raise ValueError('Existing wheel checksum mismatch: '+path.name)
        return
    part=path.with_name(path.name+'.partial')
    for attempt in range(6):
        result=subprocess.run(['aria2c','--continue=true','--auto-file-renaming=false',
            '--allow-overwrite=true','--file-allocation=none','--split=16',
            '--max-connection-per-server=16','--min-split-size=4M',
            '--connect-timeout=30','--timeout=180','--max-tries=12',
            '--retry-wait=5','--console-log-level=warn','--summary-interval=60',
            '--dir='+str(DEST),'--out='+part.name,row['url']])
        if result.returncode==0:break
        time.sleep(30)
    else:raise RuntimeError('Wheel transfer failed: '+path.name)
    if checksum(part)!=row['sha256']:raise ValueError('Downloaded wheel checksum mismatch: '+path.name)
    part.rename(path)
    print('Verified wheel:',path.name,flush=True)


if __name__=='__main__':
    DEST.mkdir(parents=True,exist_ok=True)
    rows=json.loads((ROOT/'manifests/imagewam_wheels.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(download,rows))
