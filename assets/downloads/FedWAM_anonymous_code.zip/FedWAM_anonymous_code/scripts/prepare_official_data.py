"""Accept the audited official release for four-client experiments, not strict unseen environments."""
import sys,traceback,hashlib
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash,digest
from fedwam.rlds import fingerprint,iter_records
from fedwam.official_data import CLIENT_BUCKETS,SPLITS,valid_starts,validate_groups,repair_calibration,RawChunkReader
OUT=ROOT/'reports/data/official_four_clients'
DEST=ROOT/'manifests/official_four_clients'

def main():
    import fcntl
    OUT.mkdir(parents=True,exist_ok=True)
    with (OUT/'prepare.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        run()

def run():
    inputs={key:ROOT/path for key,path in {'raw':'manifests/raw_episodes.json',
        'split':'manifests/source_group_split.json','lineage':'reports/data/provenance/lineage.json',
        'source_audit':'reports/data/source_audit/summary.json','protocol':'configs/protocol.json',
        'normalization':'runtime/lawam_libero_sft/dataset_statistics.json'}.items()}
    hashes={key:file_hash(path) for key,path in inputs.items()}
    sources=[Path(__file__),ROOT/'src/fedwam/official_data.py',ROOT/'src/fedwam/official_dataset.py',ROOT/'src/fedwam/rlds.py',ROOT/'src/fedwam/provenance.py']
    code={str(p.relative_to(ROOT)):file_hash(p) for p in sources}
    identity=digest({'inputs':hashes,'code':code})
    status(OUT,state='running',phase='join_and_numeric_audit',identity=identity,done=0)
    protocol=load(inputs['protocol'])
    if set(protocol['clients'])!=set(CLIENT_BUCKETS) or protocol['data_policy']['self_collection_enabled']:
        raise ValueError('Expected official-only four-client protocol')
    raw=load(inputs['raw'])['rows'];split=load(inputs['split']);lineage=load(inputs['lineage'])
    if split['raw_manifest_sha256']!=hashes['raw']:raise ValueError('Raw/source split hash mismatch')
    ids={r['record_id']:r for r in raw};sp={r['record_id']:r for r in split['rows']}
    if len(ids)!=len(raw) or len(sp)!=len(split['rows']) or set(ids)!=set(sp):raise ValueError('Raw/split record identities disagree')
    lin={r['exact_group']:r for r in lineage};groups={g['group']:g for g in split['groups']}
    if len(lin)!=len(lineage) or len(groups)!=len(split['groups']):raise ValueError('Duplicate lineage/group identity')
    audit=load(inputs['source_audit'])
    if audit['manifest_sha256']!=hashes['raw'] or audit['near_duplicate_candidates']:
        raise ValueError('Unreviewed near-duplicate source candidates')
    inverse={v:k for k,v in CLIENT_BUCKETS.items()};accepted=[];excluded=[]
    record_hashes={}
    min_action=np.full(7,np.inf);max_action=np.full(7,-np.inf);outside=0;action_steps=0;grippers=Counter();receipts={}
    stats=load(inputs['normalization'])['franka']['action'];lo=np.asarray(stats['min']);hi=np.asarray(stats['max'])
    for i,r in enumerate(raw):
        s=sp[r['record_id']]
        for key in ('exact_group','suite','source_bucket','source_file'):
            if r[key]!=s[key]:raise ValueError(f'Raw/split field mismatch: {key}')
        if r['source_bucket'] not in inverse:
            excluded.append({'record_id':r['record_id'],'reason':'no_effective_language_perturbations' if r['source_bucket']=='language' else 'unsupported_source_bucket'})
            continue
        g=groups[s['source_group']];l=lin[r['exact_group']]
        if not g['resolved'] or r['exact_group'] not in g['exact_groups'] or l['status']!='unique_action_ancestry' or len(l['candidates'])!=1:
            raise ValueError('Unresolved ancestry in selected official record')
        if g['stratum']!=f"{r['suite']}/{r['source_file']}" or (l['suite'],l['source_file'])!=(r['suite'],r['source_file']):raise ValueError('Cross-task lineage group')
        c=l['candidates'][0]
        if r['record_id'] not in l['records'] or c['source'] not in g['sources']:raise ValueError('Lineage membership mismatch')
        if not c['timing_unique']:
            excluded.append({'record_id':r['record_id'],'reason':'ambiguous_source_timing'});continue
        starts=valid_starts(c['indices'],r['length'])
        if starts!=s['continuous_chunk_starts'] or starts!=c['continuous_chunk_starts']:raise ValueError('Continuous chunk evidence changed')
        if not starts:
            excluded.append({'record_id':r['record_id'],'reason':'no_continuous_chunk_with_endpoint'});continue
        with np.load(r['numeric_path'],allow_pickle=False) as values:
            a=values['action'];state=values['state']
            if a.shape!=(r['length'],7) or state.shape!=(r['length'],8):raise ValueError('Wrong action/state length')
            if fingerprint(a,7)!=r['action_sha256'] or fingerprint(state,8)!=r['state_sha256']:raise ValueError('Numeric artifact changed')
            min_action=np.minimum(min_action,a.min(axis=0));max_action=np.maximum(max_action,a.max(axis=0))
            outside+=int(np.any((a[:,:6]<lo[:6]-1e-6)|(a[:,:6]>hi[:6]+1e-6),axis=1).sum());action_steps+=len(a)
            grippers.update(map(float,a[:,-1]))
        expected={'steps/observation/image','steps/observation/wrist_image'}
        if set(r['images'])!=expected or any(v['count']!=r['length'] for v in r['images'].values()):raise ValueError('Endpoint observation evidence missing')
        shard=Path(r['shard']);receipt_path=ROOT/'reports/data/recovery/shards'/f'{shard.name}.json'
        if str(shard) not in receipts:
            receipt=load(receipt_path)
            if shard.stat().st_size!=receipt['bytes']:raise ValueError('Raw shard size changed')
            indexed=load(ROOT/'reports/data/index/shards'/f'{shard.name.split("-")[-3]}.json')
            if indexed['sha256']!=receipt['sha256'] or not indexed['crc32c_verified']:raise ValueError('Missing CRC/SHA evidence')
            # Rebind current encoded observations, not only numeric metadata.
            import google_crc32c
            hasher=hashlib.sha256();found=[]
            for offset,payload in iter_records(shard,crc_function=google_crc32c.value,digest=hasher):
                record_hashes[str(shard),offset]=hashlib.sha256(payload).hexdigest();found.append(offset)
            if hasher.hexdigest()!=receipt['sha256']:raise ValueError('Current raw shard SHA differs from accepted original index')
            if found!=[entry['offset'] for entry in indexed['rows']]:raise ValueError('Indexed record offsets changed')
            receipts[str(shard)]={'sha256':receipt['sha256'],'bytes':receipt['bytes'],'recovery_receipt_sha256':file_hash(receipt_path)}
        accepted.append(dict(r,payload_sha256=record_hashes[str(shard),r['offset']],client=inverse[r['source_bucket']],source_group=s['source_group'],split=s['split'],
            continuous_chunk_starts=starts,chunk_count=len(starts),source_step_indices=c['indices'],
            source_demo=c['source'],replay_environment_overlap='unknown',timing_evidence='consecutive original action indices, no released timestamps'))
        if i%200==0:status(OUT,state='running',phase='join_and_numeric_audit',identity=identity,done=i+1,total=len(raw),accepted=len(accepted))
    exposed={g['group'] for g in groups.values() if g['exposed']}
    accepted,promotions=repair_calibration(accepted,exposed,seed=split['seed'],minimum=protocol['server']['calibration_min_groups'])
    assignments=validate_groups(accepted)
    for r in accepted:
        old=sp[r['record_id']]['split']
        if old in ('development','prediction_test') and old!=r['split']:raise ValueError('Held-out assignment changed')
        if r['source_group'] in exposed and r['split']!='train':raise ValueError('Engineering exposure escaped train')
    cells=defaultdict(list)
    for r in accepted:cells[r['client'],r['suite'],r['source_file'],r['split']].append(r)
    tasks=sorted({(r['suite'],r['source_file']) for r in raw})
    if len(tasks)!=40:raise ValueError('Expected all 40 official base tasks')
    coverage=[];decode=[];reader=RawChunkReader(max_cached_episodes=1)
    for client in CLIENT_BUCKETS:
        for suite,task in tasks:
            for split_name in SPLITS:
                rows=cells.get((client,suite,task,split_name),[])
                if not rows:raise ValueError(f'Missing client/task/split: {client}, {task}, {split_name}')
                group_count=len({r['source_group'] for r in rows})
                if split_name=='calibration' and group_count<protocol['server']['calibration_min_groups']:raise ValueError('Insufficient calibration')
                coverage.append(dict(client=client,suite=suite,task=task,split=split_name,records=len(rows),source_groups=group_count,chunks=sum(r['chunk_count'] for r in rows)))
                # Boundary samples exercise first and last allowed endpoint for each cell.
                row=min(rows,key=lambda r:r['record_id'])
                for t in sorted({row['continuous_chunk_starts'][0],row['continuous_chunk_starts'][-1]}):
                    sample=reader.read(row,t)
                    if sample['actions'].shape!=(8,7) or sample['future_t']!=t+8:raise ValueError('Chunk decode contract failure')
                    for k in ('primary','wrist','future'):
                        if sample[k].shape!=(256,256,3) or sample[k].dtype!=np.uint8:raise ValueError('Unexpected decoded RGB shape/dtype')
                    decode.append(dict(client=client,suite=suite,task=task,split=split_name,record_id=row['record_id'],t=t,future_t=t+8,passed=True))
                if len(coverage)%16==0:status(OUT,state='running',phase='real_chunk_decode',identity=identity,cells_done=len(coverage),total=640)
    if any(file_hash(path)!=hashes[key] for key,path in inputs.items()) or any(file_hash(ROOT/path)!=sha for path,sha in code.items()):
        raise ValueError('Inputs/code changed during audit; rerun with fixed identities')
    # Publication occurs only after all audits. The receipt below binds every file.
    files={};per_client={};split_counts={}
    for client in CLIENT_BUCKETS:
        client_rows=[r for r in accepted if r['client']==client]
        per_client[client]={'records':len(client_rows),'source_groups':len({r['source_group'] for r in client_rows}),
            'chunks':sum(r['chunk_count'] for r in client_rows),'tasks':len({(r['suite'],r['source_file']) for r in client_rows})}
        for split_name in SPLITS:
            rows=sorted([r for r in client_rows if r['split']==split_name],key=lambda r:r['record_id'])
            path=DEST/client/f'{split_name}.json'
            save(path,dict(schema='fedwam.official_chunks.v1',identity=identity,client=client,split=split_name,rows=rows))
            files[str(path.relative_to(ROOT))]=file_hash(path)
            split_counts[f'{client}/{split_name}']={'records':len(rows),'source_groups':len({r['source_group'] for r in rows}),'chunks':sum(r['chunk_count'] for r in rows)}
    save(OUT/'coverage.json',coverage);save(OUT/'decode_checks.json',decode);save(OUT/'exclusions.json',excluded)
    allocation={'identity':identity,'original_split_sha256':hashes['split'],'assignments':assignments,'train_to_calibration':promotions,
        'engineering_train_groups':sorted(exposed),'development_and_prediction_test_unchanged':True}
    save(DEST/'source_assignment.json',allocation);files[str((DEST/'source_assignment.json').relative_to(ROOT))]=file_hash(DEST/'source_assignment.json')
    summary=dict(schema='fedwam.official_data_acceptance.v1',identity=identity,status='accepted_official_release_scope',
        accepted_for_official_four_client_training=True,strict_unseen_replay_environment_claim=False,
        raw_records=len(raw),accepted_records=len(accepted),excluded_records=len(excluded),exclusion_reasons=dict(Counter(r['reason'] for r in excluded)),
        clients=per_client,client_splits=split_counts,source_groups=len(assignments),group_split_counts=dict(Counter(assignments.values())),
        train_to_calibration_promotions=len(promotions),cross_split_source_groups=0,engineering_exposure_train_only=True,
        total_continuous_chunks=sum(r['chunk_count'] for r in accepted),coverage_cells=len(coverage),decode_checks=len(decode),
        horizon=8,hz=20,timing_basis='consecutive source action indices; actual replay timestamps unavailable',
        action_audit={'steps':action_steps,'min':min_action.tolist(),'max':max_action.tolist(),'steps_outside_normalization_bounds':outside,'gripper_values':dict(grippers)},
        inputs=hashes,code=code,files=files,shard_receipts=receipts,
        limitations=['Official replay environment and initialization overlap with benchmark remains unknown.',
            'Visual client heterogeneity does not establish different physical dynamics or embodiments.',
            'These tasks were part of the original SFT domain; this is adaptation, not unseen-task pretraining independence.',
            'Four-way source grouping prevents derivative episodes crossing splits; rounded-window diagnostics are not an exhaustive semantic near-duplicate proof.',
            'Published language bucket excluded. No own demonstrations are included.'],
        sampling='uniform task, then source group, rendering record, continuous start; replacement with deterministic draw IDs')
    save(DEST/'acceptance.json',summary);save(OUT/'summary.json',summary)
    status(OUT,state='completed',phase='official_four_client_data_accepted',identity=identity,
        accepted_records=len(accepted),chunks=summary['total_continuous_chunks'],coverage_cells=len(coverage),decode_checks=len(decode),promotions=len(promotions))
    print({k:summary[k] for k in ('status','accepted_records','source_groups','group_split_counts','total_continuous_chunks','coverage_cells','decode_checks','train_to_calibration_promotions')},flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
