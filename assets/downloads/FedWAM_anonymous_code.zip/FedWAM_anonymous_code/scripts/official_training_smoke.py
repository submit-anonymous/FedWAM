"""One real effective-batch update per official client; discard all trained state.

This is optimizer/interface acceptance, not a scientific training comparison.
Only train-manifest samples are used; no calibration/development/test labels.
"""
import gc,sys,time,traceback,random
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash
from fedwam.official_data import CLIENT_BUCKETS
from fedwam.official_dataset import OfficialDataset
from fedwam.training import configure,encode,losses
import acceptance
from model_probe import frozen_hash
OUT=ROOT/'reports/official_training_smoke'

def main():
    import torch
    receipt=load(ROOT/'manifests/official_four_clients/acceptance.json')
    config=load(ROOT/'configs/protocol.json');settings=config['training']
    if receipt['inputs']['protocol']!=file_hash(ROOT/'configs/protocol.json'):
        raise ValueError('Protocol differs from data acceptance')
    if receipt['inputs']['normalization']!=file_hash(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json'):
        raise ValueError('Normalization differs from data acceptance')
    code={str(path.relative_to(ROOT)):file_hash(path) for path in [Path(__file__),ROOT/'src/fedwam/training.py',ROOT/'scripts/acceptance.py',ROOT/'scripts/model_probe.py']}
    datasets={c:OfficialDataset(ROOT,c,'train',42,max_cached_episodes=1) for c in CLIENT_BUCKETS}
    acceptance.OUT=OUT;status(OUT,state='running',phase='load_official_sft',data_identity=receipt['identity'])
    policy,client,transport=acceptance.model();backend=configure(policy)
    params={k:v for k,v in policy.named_parameters() if v.requires_grad}
    originals={k:v.detach().cpu().clone() for k,v in params.items()}
    frozen=frozen_hash(policy);results=[]
    stats=load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
    for name,dataset in datasets.items():
        with torch.no_grad():
            for key,p in params.items():p.copy_(originals[key].to(device=p.device))
        policy.zero_grad(set_to_none=True);random.seed(42);np.random.seed(42);torch.manual_seed(42)
        optimizer=torch.optim.AdamW(list(params.values()),lr=settings['lr'],weight_decay=settings['weight_decay'])
        torch.cuda.reset_peak_memory_stats();began=time.perf_counter();measures=[];exposures=[]
        effective=settings['effective_batch']
        status(OUT,state='running',phase='joint_optimizer_step',client=name,microbatches=effective,clients_done=len(results))
        for index in range(effective):
            sample=dataset.sample(index)
            if sample['split']!='train':raise ValueError('Non-training sample reached optimizer')
            batch,parity=encode(policy,sample,stats);value=losses(policy,batch)
            if not all(torch.isfinite(value[k]).all() for k in ('total','world','action')):raise ValueError('Nonfinite losses')
            (value['total']/effective).backward()
            measures.append({k:float(value[k].detach()) for k in ('total','world','action')})
            exposures.append({k:sample[k] for k in ('record_id','source_group','t','future_t','client','split')})
            del value,batch,sample
        norms={}
        for label,module in [('world',backend.lam.decoder),('action',backend.flow)]:
            norms[label]=sum(float(p.grad.detach().float().square().sum()) for p in module.parameters() if p.grad is not None)**.5
            if not np.isfinite(norms[label]) or norms[label]<=0:raise ValueError(f'No finite {label} gradient')
        grad_norm=torch.nn.utils.clip_grad_norm_(list(params.values()),settings['clip_grad_norm'],error_if_nonfinite=True)
        optimizer.step();optimizer.zero_grad(set_to_none=True)
        changed={key:False for key in ('world','action')}
        world_ids={id(p) for p in backend.lam.decoder.parameters()}
        for key,p in params.items():
            if not torch.isfinite(p).all():raise ValueError('Nonfinite updated parameter')
            label='world' if id(p) in world_ids else 'action'
            changed[label]|=not torch.equal(p.detach().cpu(),originals[key])
        if not all(changed.values()):raise ValueError(f'Optimizer did not update both modules: {changed}')
        if frozen_hash(policy)!=frozen:raise ValueError('Frozen encoder/intent/backbone was changed')
        torch.cuda.synchronize()
        results.append(dict(client=name,passed=True,effective_batch=effective,losses=measures,exposures=exposures,
            gradient_norms=norms,pre_clip_norm=float(grad_norm),modules_changed=changed,
            seconds=time.perf_counter()-began,peak_gpu_bytes=torch.cuda.max_memory_allocated(),cache_parity=parity))
        save(OUT/'client_checks.json',results)
        del optimizer;gc.collect();torch.cuda.empty_cache()
    with torch.no_grad():
        for key,p in params.items():p.copy_(originals[key].to(device=p.device))
    save(OUT/'summary.json',dict(passed=True,clients=results,data_identity=receipt['identity'],
        initialization='official SFT restored before each client',frozen_modules_sha256=frozen,code=code,
        protocol_sha256=receipt['inputs']['protocol'],normalization_sha256=receipt['inputs']['normalization'],
        trained_weights_discarded=True,scope='four-client optimizer interface acceptance, no trained experimental result'))
    transport.close();status(OUT,state='completed',phase='four_client_optimizer_verified',clients_passed=4,trained_weights_discarded=True)

if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
