"""CPU-only reports for final four-client models and the single pooled M9 model."""
import argparse
from collections import defaultdict
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT, digest, file_hash, load, save
from fedwam.federated_reporting import (CLIENTS, attach_base_tasks, build_report, cost_summary,
    paired_comparison, prediction_items, prediction_summary, run_settings, verify_manifest)


def read_run(run, manifest):
    run = Path(run).resolve()
    final = load(run/'final.json')
    identity = final['identity']
    if final['method'] != identity['method'] or final['seed'] != identity['seed']:
        raise ValueError('Final model identity mismatch')
    clients = ['pooled'] if final['method']=='M9' else list(CLIENTS)
    if set(final['clients']) != set(clients):
        raise ValueError('Incomplete or extra final client checkpoints')
    rows = {row['variant_id']:row for row in manifest['cases']}
    records = []
    predictions = {}
    final_sha = file_hash(run/'final.json')
    for client in clients:
        # Verify bytes without deserializing private state or importing GPU/model packages.
        checkpoint = (run/final['clients'][client]['path']).resolve()
        if not checkpoint.is_relative_to(run) or file_hash(checkpoint)!=final['clients'][client]['sha256']:
            raise ValueError('Final checkpoint checksum mismatch')
        identity_path = run/'evaluation/identities'/f'{client}.json'
        paths = sorted((run/'evaluation/cases'/client).glob('*/result.json'))
        if paths and not identity_path.exists():
            raise ValueError('Missing evaluation identity')
        evaluation = load(identity_path) if identity_path.exists() else None
        if evaluation:
            if (evaluation['training_identity']!=identity or evaluation['method']!=final['method']
                    or evaluation['seed']!=final['seed'] or evaluation['client']!=client
                    or evaluation['manifest_sha256']!=manifest['sha256']
                    or evaluation['final_sha256']!=final_sha
                    or evaluation['checkpoint_sha256']!=final['clients'][client]['sha256']):
                raise ValueError('Evaluation model/data identity mismatch')
        evaluation_sha = digest(evaluation) if evaluation else None
        for path in paths:
            value = load(path)
            case = value['case']
            if case != rows.get(case['variant_id']):
                raise ValueError('Result case differs from frozen manifest')
            if value['identity'] != {'evaluation':evaluation_sha,'case_sha256':digest(case)}:
                raise ValueError('Result evaluation identity mismatch')
            if value['client']!=client or value['seed']!=final['seed']:
                raise ValueError('Result client/seed mismatch')
            records.append(value)
        for scope in ('representative-per-group','all-chunks'):
            base = run/'evaluation/prediction_test'/scope/client
            if not base.exists():
                continue
            expected_keys = {}
            from fedwam.official_dataset import OfficialDataset
            for source_client in CLIENTS if client=='pooled' else [client]:
                data = OfficialDataset(ROOT,source_client,'prediction_test',final['seed'],max_cached_episodes=1)
                if data.identity!=identity['data_identity']:
                    raise ValueError('Prediction data identity mismatch')
                for row,t in prediction_items(data.rows,scope):
                    key = {'evaluation':evaluation_sha,'source_client':source_client,'record_id':row['record_id'],
                           'source_group':row['source_group'],'t':t,'scope':scope}
                    expected_keys[digest(key)] = key
            values = []
            for path in sorted((base/'cases').glob('*.json')):
                value = load(path)
                if value['identity'] != expected_keys.get(path.stem):
                    raise ValueError('Prediction input identity mismatch')
                if value['client']!=client or value['seed']!=final['seed']:
                    raise ValueError('Prediction model identity mismatch')
                values.append(value)
            predictions[scope+'/'+client] = prediction_summary(values,len(expected_keys))
    report = build_report(manifest,records,clients,seeds=[final['seed']])
    report.update(method=final['method'],seed=final['seed'],mode=identity.get('mode'),run=str(run),
                  identity=identity,costs=cost_summary(run),prediction_test=predictions)
    return final,records,report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs',nargs='+',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--bootstrap-replicates',type=int,default=2000)
    args = parser.parse_args()
    manifest = load(ROOT/'manifests/plus_full.json')
    verify_manifest(manifest)
    manifest['cases'] = attach_base_tasks(manifest['cases'],load(ROOT/'manifests/official_four_clients/lighting/train.json')['rows'])
    per_run = []
    all_records = defaultdict(list)
    run_identities = defaultdict(list)
    seen = set()
    for run in args.runs:
        final,records,report = read_run(run,manifest)
        key = (final['method'],final['seed'])
        if key in seen:
            raise ValueError('Duplicate method/seed run; compare budget/ablation settings in separate reports')
        seen.add(key)
        per_run.append(report)
        all_records[final['method']].extend(records)
        run_identities[final['method']].append(final['identity'])
    expected_seeds = load(ROOT/'configs/protocol.json')['seeds']
    methods = {}
    for method,records in all_records.items():
        identities = run_identities[method]
        # Seeds may differ; data, initialization, code and resolved settings must agree.
        invariant = [run_settings(identity) for identity in identities]
        if any(value!=invariant[0] for value in invariant[1:]):
            raise ValueError(f'Mixed run settings for method {method}')
        clients = ['pooled'] if method=='M9' else list(CLIENTS)
        methods[method] = build_report(manifest,records,clients,seeds=expected_seeds)
        methods[method]['available_seeds'] = sorted(s for m,s in seen if m==method)
        methods[method]['required_seeds'] = expected_seeds
        methods[method]['mode'] = identities[0].get('mode')
    contrasts = {}
    for comparator in ('M1','M2','M7','M8'):
        label = 'M6-'+comparator
        if 'M6' not in all_records or comparator not in all_records:
            contrasts[label] = {'available':False,'reason':'required method run missing'}
            continue
        left_identity = run_identities['M6'][0]
        right_identity = run_identities[comparator][0]
        for key in ('data_identity','data_acceptance_sha256','checkpoint_sha256','normalization_sha256','mode'):
            if left_identity[key]!=right_identity[key]:
                raise ValueError(f'Contrast {label} has incompatible {key}')
        contrasts[label] = {'available':True,'scopes':{},
                            'budget_match_requires_review':
                                {k:v for k,v in left_identity['config'].items() if k not in ('method','seed')}!=
                                {k:v for k,v in right_identity['config'].items() if k not in ('method','seed')}}
        for scope in ('all','E_seen','E_confirm'):
            ids = {r['variant_id'] for r in manifest['cases']} if scope=='all' else set(manifest[scope])
            left = [r for r in all_records['M6'] if r['case']['variant_id'] in ids]
            right = [r for r in all_records[comparator] if r['case']['variant_id'] in ids]
            contrasts[label]['scopes'][scope] = paired_comparison(left,right,replicates=args.bootstrap_replicates)
    result = {'schema':'fedwam.report.v1','manifest_sha256':manifest['sha256'],
              'runs':per_run,'methods':methods,'primary_contrasts':contrasts,
              'complete_requested_runs':all(r['complete'] for r in per_run),
              'complete_three_seed_methods':all(r['complete'] for r in methods.values()),
              'multiple_comparisons':'four prespecified primary contrasts; intervals are marginal and not familywise-adjusted; no secondary significance claims',
              'selection':'E_seen and E_confirm separate; no checkpoint/model selection from E_confirm',
              'scope':'reports only supplied methods; does not assert complete M0-M9 study or required ablations'}
    save(args.output.resolve(),result)
    print(f'Wrote {args.output}; requested rollout runs complete: {result["complete_requested_runs"]}')


if __name__=='__main__':
    main()
