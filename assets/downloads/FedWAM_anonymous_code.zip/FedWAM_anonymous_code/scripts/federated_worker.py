"""Persistent Slurm worker; schedules train/eval according to true dependencies."""
import argparse,sys,os,fcntl,time,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load
from fedwam.work_queue import WorkQueue
from fedwam.experiment_config import code_identity,formal_gate,identity,resolved_config
from fedwam.round_runtime import atomic_json

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--worker',type=int,choices=range(4));p.add_argument('--retry-task');a=p.parse_args()
 plan=load(a.plan)
 if plan['code']!=code_identity():raise ValueError('Frozen work plan code changed')
 scheduler=Path(plan['root'])/'scheduler';queue=WorkQueue(scheduler,plan['tasks']);owner=f'worker-{a.worker}'
 if a.retry_task:
  queue.retry(a.retry_task);print('Retry scheduled:',a.retry_task);return
 if not os.environ.get('SLURM_JOB_ID') or a.worker is None:raise RuntimeError('Worker requires Slurm GPU reservation and worker ID')
 formal_gate(identity(resolved_config('M1',42,'formal')),load(ROOT/'reports/federation_engineering/summary.json'))
 with (scheduler/f'{owner}.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prefer='train' if a.worker in (0,2) else 'rollout'
  while True:
   if shutil.disk_usage(ROOT).free<80*1024**3:raise RuntimeError('Less than80GiB free: preserving data, stop rather than fill disk')
   if plan['code']!=code_identity():raise ValueError('Code changed during active work plan')
   task=queue.claim(owner,prefer)
   if task is None:
    if queue.finished():break
    atomic_json(scheduler/f'{owner}.json',{'state':'waiting_for_dependencies','summary':queue.summary()});time.sleep(30);continue
   log=scheduler/'logs'/f"{task['id']}.log";log.parent.mkdir(exist_ok=True)
   atomic_json(scheduler/f'{owner}.json',{'state':'running','task':task['id'],'job':os.environ['SLURM_JOB_ID'],'log':str(log)})
   with log.open('a') as output:result=subprocess.run(task['argv'],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
   queue.finish(owner,task['id'],result.returncode)
   if result.returncode:raise RuntimeError(f"Task {task['id']} failed; inspect {log}")
  atomic_json(scheduler/f'{owner}.json',{'state':'completed_with_failures' if queue.summary().get('failed',0) or queue.summary().get('blocked',0) else 'completed','summary':queue.summary()})
if __name__=='__main__':main()
