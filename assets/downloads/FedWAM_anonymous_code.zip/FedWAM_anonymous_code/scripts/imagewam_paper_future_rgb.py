"""Decode actual FLUX.2 future frames at fixed points of the recorded rollout."""
import gc
import json
from pathlib import Path
import sys
import time
import traceback
from imagewam_model_acceptance import ROOT,write,load_initial_states,make_env,check_keys
OUT=ROOT/'reports/paper_prediction_media_20260926/imagewam'

def run():
    import numpy as np
    import torch
    from PIL import Image
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    sys.path[:0]=[str(ROOT/'third_party/ImageWAM'),str(ROOT/'third_party/ImageWAM/experiments/libero')]
    from experiments.libero import eval_libero_single as official
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from libero.libero import benchmark
    state=dict(state='running',phase='replay',seed=42);write(OUT/'status.json',state)
    source=ROOT/'reports/paper_media_20260926/imagewam_full_task'
    receipt=json.loads((source/'result.json').read_text());actions=np.load(source/'actions.npy')
    assert receipt['success'] and receipt['horizon']==16 and receipt['replan_steps']==12 and len(actions)==83
    cfg=OmegaConf.load(ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    torch.manual_seed(42);np.random.seed(42)
    suite=benchmark.get_benchmark_dict()['libero_spatial']();task=suite.get_task(0)
    states=load_initial_states(lambda:suite.get_task_init_states(0));env,instruction=make_env(task,256,42)
    snapshots=[]
    try:
        env.reset();obs=env.set_init_state(states[0])
        for _ in range(30):obs,_,_,_=env.step(official.get_libero_dummy_action())
        snapshots.append({k:v.copy() if hasattr(v,'copy') else v for k,v in obs.items()})
        for action in actions:
            obs,_,done,_=env.step(action.tolist());snapshots.append({k:v.copy() if hasattr(v,'copy') else v for k,v in obs.items()})
        assert done and env.check_success()
    finally:env.close()
    for i in receipt['selected_frame_steps']:
        actual=official.get_libero_image(snapshots[i])['image'];expected=np.asarray(Image.open(source/'frames'/f'step_{i:04d}.png'))
        if not np.array_equal(actual,expected):raise ValueError(f'Original rollout replay differs at{i}')
    state.update(phase='load_model',exact_replay=True);write(OUT/'status.json',state)
    model=instantiate(cfg.model,model_dtype=torch.bfloat16,device='cuda');keys={}
    def checked(module,result):
        check_keys(result.missing_keys,result.unexpected_keys);keys.update(missing=len(result.missing_keys),unexpected=len(result.unexpected_keys))
    hook=model.mot.register_load_state_dict_post_hook(checked)
    try:
        payload=model.load_checkpoint(str(cfg.ckpt));assert 'proprio_encoder' in payload;del payload
    finally:hook.remove()
    gc.collect();model.to('cuda').eval().requires_grad_(False)
    processor=instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    assert model.stack=='flux2' and int(cfg.data.train.num_frames)==17
    examples=[]
    for t in range(0,len(actions)-16+1,12):
        folder=OUT/f'chunk_{t:04d}';folder.mkdir(parents=True,exist_ok=True)
        image,proprio,imgs=official._obs_to_model_input(snapshots[t],cfg,processor,width=448,height=224,device='cuda',dtype=model.torch_dtype)
        start=time.monotonic()
        with torch.no_grad():
            result=model.infer_video_flux2(prompt=official.DEFAULT_PROMPT.format(task=instruction),input_image=image,
                proprio=proprio,num_inference_steps=10,seed=42,rand_device='cpu')
        value=result['image'].float()
        if value.shape!=(3,224,448) or not torch.isfinite(value).all():raise ValueError('Bad generated image')
        rgb=((value.clamp(-1,1)+1)*127.5).to(torch.uint8).permute(1,2,0).numpy()
        gt=official.get_libero_image(snapshots[t+16])
        def concat_views(x):return np.concatenate([official._center_crop_resize(x[k],224,224) for k in ('image','wrist_image')],axis=1)
        current=concat_views(imgs);actual=concat_views(gt)
        for name,arr in [('current',current),('predicted_future',rgb),('actual_future',actual)]:
            Image.fromarray(arr).save(folder/f'{name}_dual.png');Image.fromarray(arr[:,:224]).save(folder/f'{name}_front.png')
        np.savez_compressed(folder/'prediction.npz',image=value.numpy())
        item=dict(start=t,end=t+16,folder=folder.name,seconds=time.monotonic()-start,
            rgb_mse=float(np.mean(((rgb.astype(float)-actual)/255.)**2)),
            copy_rgb_mse=float(np.mean(((current.astype(float)-actual)/255.)**2)))
        examples.append(item);state.update(phase='generate_future_rgb',completed=len(examples));write(OUT/'status.json',state)
    write(OUT/'result.json',dict(seed=42,instruction=instruction,checkpoint=str(cfg.ckpt),checkpoint_compatibility=keys,
        examples=examples,exact_replay_frames=receipt['selected_frame_steps'],horizon=16,native_replan=12,
        shape=[224,448,3],method='infer_video_flux2 then native FLUX.2 VAE decode',steps=10,
        conditioning='Current RGB, language and proprio only; no future RGB or executed actions passed to generator',
        reference='Actual recorded closed-loop trajectory at t+16; policy replans at t+12, not an open-loop execution of the initial16actions',
        scope='Native checkpoint qualitative future-image generation; separate from shared DINO readout and no federation benefit claim'))
    state.update(state='completed',phase='future_rgb_recorded');write(OUT/'status.json',state)

if __name__=='__main__':
    if (OUT/'result.json').exists():raise SystemExit('Preserve first generated samples')
    try:run()
    except Exception as e:write(OUT/'status.json',dict(state='failed',error=repr(e)));traceback.print_exc();raise
