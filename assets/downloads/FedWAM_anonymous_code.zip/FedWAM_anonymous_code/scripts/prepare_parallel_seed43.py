"""Freeze the seed43-only parallel-client task graph without changing science."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT
from fedwam.round_runtime import atomic_json
from fedwam.parallel_execution import execution_code
from fedwam.work_queue import WorkQueue
from plan_federated import make_plan

def main():
 plan=make_plan('fedwam_seed43_parallel');plan['runs']=[r for r in plan['runs'] if r.endswith('/seed43')]
 plan['tasks']=[t for t in plan['tasks'] if '-s43-' in t['id']]
 for task in plan['tasks']:
  if task['kind']=='train':
   task['kind']='parallel_train';task['method']=task['argv'][task['argv'].index('--method')+1]
   task['argv']=[str(ROOT/'scripts/train_parallel.py') if x==str(ROOT/'scripts/train_federated.py') else x for x in task['argv']]
 plan.update(seeds=[43],deferred_seeds=[42,44],max_gpu_workers=6,training_jobs=10,rollout_cases=371110,
  parallel_code=execution_code(),scope='seed43 only; one independent GPU/process per client; M9 one pooled GPU; full methods and evaluation',
  expected_final_models=37,expected_prediction_inputs=1584830)
 path=ROOT/'manifests/fedwam_seed43_parallel_work_plan.json'
 if path.exists() and json.loads(path.read_text())!=plan:raise ValueError('Frozen parallel plan differs')
 atomic_json(path,plan);WorkQueue(Path(plan['root'])/'scheduler',plan['tasks'])
 print(json.dumps({'plan':str(path),'training_runs':10,'tasks':len(plan['tasks']),'seeds':plan['seeds'],'gpu_cap':6},indent=2))
if __name__=='__main__':main()
