"""Actual native1000 WAM/control graph and future-label independence for residual head."""
import argparse
import json
from pathlib import Path
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src')]
from imagewam_model_acceptance import write


def run(args):
    import gc
    import torch
    from fedwam.heterogeneous.residual_adapter import ResidualImageWAMAdapter
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.reference import REFERENCE_ID
    torch.manual_seed(42);torch.set_num_threads(4);torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=True
    output=args.output;output.mkdir(parents=True,exist_ok=True)
    state=dict(state='running',phase='admission',domain=args.domain);write(output/'status.json',state)
    base=Path('/workspace/reviewer/fedwam-residual-readout-v1')
    summaries={d:json.loads((base/d/'result.json').read_text()) for d in ('lighting','camera_pose','sensor_noise','background')}
    if not all(r['arms']['residual']['summary']['development']['mse']<r['baselines']['copy']['summary']['development']['mse'] for r in summaries.values()):
        state.update(state='blocked',phase='readout_gate',error='Residual candidate has not beaten copy in every domain')
        write(output/'status.json',state);return
    state['phase']='load';write(output/'status.json',state)
    adapter=ResidualImageWAMAdapter(ROOT,base/args.domain/'residual-head.pt')
    sample=HeterogeneousDataset(ROOT,'B',args.domain).sample(20000)
    native=adapter.prepare(sample)
    with torch.no_grad():
        before=adapter.predict(native).detach();before_action=adapter.action_output(sample,native)
        truth=adapter.reference([sample['future']]).detach()
        altered=dict(sample,future=255-sample['future'],future_wrist=255-sample['future_wrist'])
        other=adapter.prepare(altered);after_label=adapter.predict(other)
    leakage=float((before-after_label).abs().max())
    if leakage!=0:raise ValueError('Future label changes inference')
    del adapter.reference,other,after_label
    adapter.offload_text();gc.collect();torch.cuda.empty_cache()
    world=adapter.world.single_blocks[-1].linear1
    world.requires_grad_(True)
    versions={n:p._version for n,p in adapter.action.named_parameters()}
    state['phase']='world_gradient';write(output/'status.json',state)
    prediction=adapter.predict(native);loss=(prediction-truth).square().mean();loss.backward()
    grad=world.weight.grad
    if grad is None or not torch.isfinite(grad).all() or float(grad.float().norm())==0:raise ValueError('No finite world gradient')
    norm=float(grad.float().norm())
    if any(p.grad is not None for p in adapter.head.parameters()) or any(p.grad is not None for p in adapter.action.parameters()):
        raise ValueError('Private action or fixed head received gradient')
    with torch.no_grad():world.weight.add_((-1e-3*grad.float()/grad.float().square().mean().sqrt().clamp_min(1e-12)).to(world.weight.dtype))
    del prediction,loss,grad;world.zero_grad(set_to_none=True);world.requires_grad_(False)
    with torch.no_grad():after=adapter.predict(native);after_action=adapter.action_output(sample,native)
    prediction_change=float((after-before).abs().max());action_change=float((after_action-before_action).abs().max())
    if not torch.isfinite(after).all() or not torch.isfinite(after_action).all() or min(prediction_change,action_change)<=0:
        raise ValueError('World intervention did not change finite prediction/action outputs')
    if any(p._version!=versions[n] for n,p in adapter.action.named_parameters()):raise ValueError('Private action weights changed')
    result=dict(passed=True,domain=args.domain,seed=42,reference=REFERENCE_ID,future_label_effect=leakage,
        world_gradient_norm=norm,world_parameter='single_blocks[-1].linear1.weight',intervention_rms=1e-3,
        prediction_change=prediction_change,action_change=action_change,action_unchanged=True,head_frozen=True,
        artifact_sha256=adapter.version,updated_parameters_discarded=True,formal_federation_started=False,
        scope='Engineering differentiability/control connectivity only; not control improvement')
    write(output/'result.json',result);state.update(state='completed',phase='residual_graph');write(output/'status.json',state)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    try:run(args)
    except Exception as exc:
        p=args.output/'status.json';state=json.loads(p.read_text()) if p.exists() else {}
        state.update(state='failed',error=repr(exc));write(p,state);traceback.print_exc();raise SystemExit(1)
