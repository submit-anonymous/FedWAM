"""Real-model two-round method acceptance, never reported as scientific results."""
import sys,subprocess,time,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load
from fedwam.round_runtime import atomic_json
from fedwam.retention import compact_completed_run
from fedwam.experiment_config import METHODS,code_identity,identity,resolved_config
OUT=ROOT/'reports/federation_engineering'
def main():
 global OUT
 p=argparse.ArgumentParser();p.add_argument('--overrides',type=Path);p.add_argument('--output',type=Path,default=OUT);args=p.parse_args()
 OUT=args.output.resolve()
 if not OUT.is_relative_to(ROOT/'reports'):raise ValueError('Engineering reports must stay in project')
 overrides=load(args.overrides) if args.overrides else None
 ident=identity(resolved_config('M1',42,'engineering',overrides));code=ident['code']
 from fedwam.io import digest
 tag=digest(ident)[:16];methods=[];started=time.perf_counter()
 for method in METHODS:
  expected=identity(resolved_config(method,42,'engineering',overrides))
  run=ROOT/'runs/federation_engineering'/tag/method
  atomic_json(OUT/'status.json',{'state':'running','method':method,'passed':methods,'identity_tag':tag})
  completed=run/'verification.json'
  if not completed.exists() or load(completed).get('identity')!=expected:
   command=[sys.executable,'-u',str(ROOT/'scripts/train_federated.py'),'--mode','engineering','--method',method,'--seed','42','--run',str(run)]
   if args.overrides:command+=['--overrides',str(args.overrides.resolve())]
   subprocess.run(command,check=True,cwd=ROOT)
  result=load(completed)
  if not result.get('passed') or result.get('identity')!=expected:raise ValueError(f'Failed/stale engineering method {method}')
  compact_completed_run(run,expected)
  methods.append(method)
 if identity(resolved_config('M1',42,'engineering',overrides))!=ident:raise ValueError('Implementation/input changed during engineering run')
 summary={'passed':True,'mode':'real_model_two_round_engineering','methods_passed':methods,
  **{k:ident[k] for k in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256')},
  'experiment_overrides':overrides or {},'seconds':time.perf_counter()-started,'runs_root':str(ROOT/'runs/federation_engineering'/tag),
  'scope':'small two-round real model/interface checks; not full scientific experiment results'}
 atomic_json(OUT/'summary.json',summary);atomic_json(OUT/'status.json',{'state':'completed','methods_passed':methods,'seconds':summary['seconds']})
if __name__=='__main__':
 try:main()
 except Exception as e:atomic_json(OUT/'status.json',{'state':'failed','error':repr(e)});raise
