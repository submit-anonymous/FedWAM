"""Fresh full-model and all-cell native simulator acceptance; no scientific training."""
import argparse,os,sys,time,traceback,random
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash
from fedwam.alias_guard import validate_loaded_keys
OUT=ROOT/'reports/acceptance'

class Transport:
    def __init__(self,policy,metadata):self.policy=policy;self.metadata=metadata;self.calls=[]
    def close(self):pass
    def get_server_metadata(self):return self.metadata
    def predict_action(self,q):
        import torch,numpy as np
        torch.cuda.synchronize();start=time.perf_counter()
        result=self.policy.predict_action(**q);torch.cuda.synchronize()
        a=np.asarray(result['normalized_actions'])
        if a.shape!=(1,8,32) or not np.isfinite(a).all():raise ValueError('Invalid normalized action chunk')
        self.calls.append({'seconds':time.perf_counter()-start,'shape':list(a.shape),'min':float(a.min()),'max':float(a.max())})
        return {'ok':True,'data':result}

def model():
    import torch
    from starVLA.model.framework.base_framework import baseframework
    from deployment.model_server.server_policy import build_policy_server_metadata
    from examples.LIBERO.eval_files import model2libero_interface as interface
    from unittest.mock import patch
    if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('GPU acceptance requires Slurm')
    if Path(sys.prefix).resolve()!=ROOT/'.venv':raise RuntimeError('Independent project environment required')
    if torch.cuda.device_count()!=1:raise ValueError('Request exactly one GPU per worker')
    free,total=torch.cuda.mem_get_info()
    if free<30*1024**3:raise RuntimeError('Allocated GPU already occupied or insufficient memory; no other process will be touched')
    torch.set_num_threads(4);torch.manual_seed(42)
    checkpoint=str(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt')
    captures=[];original=torch.nn.Module.load_state_dict
    def checked(module,weights,*a,**kw):
        result=original(module,weights,*a,**kw)
        if any(k.startswith('policy_backend.') for k in weights):captures.append(validate_loaded_keys(module,weights,result))
        return result
    start=time.perf_counter()
    with patch.object(torch.nn.Module,'load_state_dict',checked):policy=baseframework.from_pretrained(checkpoint)
    if len(captures)!=1:raise RuntimeError('Full checkpoint inspection missing')
    policy=policy.to('cuda:0').eval();torch.cuda.synchronize()
    seconds=time.perf_counter()-start
    b=policy.policy_backend
    if int(b.model_cfg.num_action_queries)!=8 or bool(b.flow.config.use_state):raise ValueError('Unexpected policy action/state contract')
    if abs(float(b.flow.config.horizon_sec)-.4)>1e-6:raise ValueError('Unexpected action duration')
    metadata=build_policy_server_metadata(policy,ckpt_path=checkpoint,server_type='local_native_plus',env='libero',supported_eval_envs=['libero'])
    transport=Transport(policy,metadata)
    with patch.object(interface,'WebsocketClientPolicy',lambda *a,**kw:transport):
        client=interface.ModelClient(checkpoint,action_hz=20.,embodiment_id=25,eval_action_chunk_len=8)
    save(OUT/'model_load.json',dict(load_seconds=seconds,alias_verification=captures[0],cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        gpu=torch.cuda.get_device_name(),checkpoint_sha256=file_hash(checkpoint),normalization_sha256=file_hash(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')))
    return policy,client,transport

def rollout(row,client,transport,output,*,save_result=True):
    import torch,numpy as np,imageio.v2 as imageio
    from libero.libero import benchmark,get_libero_path
    from libero.libero.envs import OffScreenRenderEnv
    from examples.LIBERO.eval_files.libero_eval_core import _build_policy_example_from_obs,_response_to_delta_action
    output.mkdir(parents=True,exist_ok=True)
    random.seed(row['seed']);np.random.seed(row['seed']);torch.manual_seed(row['seed'])
    suite=benchmark.get_benchmark_dict()[row['suite']](task_order_index=0);idx=row['task_index'];task=suite.get_task(idx)
    if task.name!=row['name']:raise ValueError('Native case identity mismatch')
    with torch.serialization.safe_globals([np.core.multiarray._reconstruct,np.ndarray,np.dtype,type(np.dtype('float64')),type(np.dtype('float32'))]):states=suite.get_task_init_states(idx)
    env=OffScreenRenderEnv(bddl_file_name=str(Path(get_libero_path('bddl_files'))/task.problem_folder/task.bddl_file),camera_heights=256,camera_widths=256)
    start=time.perf_counter();start_calls=len(transport.calls);frames=[];actions=[];call_steps=[];done=False
    try:
        env.seed(row['seed']);env.reset();obs=env.set_init_state(np.asarray(states[row['init_state_index']]))
        if env.env.control_freq!=20:raise ValueError('Native control rate mismatch')
        language=env.language_instruction;client.reset(task_description=language)
        for _ in range(10):obs,_,_,_=env.step([0,0,0,0,0,0,-1])
        for step in range(row['max_steps']):
            example,front,wrist=_build_policy_example_from_obs(obs,language)
            if front.shape!=(256,256,3) or wrist.shape!=(256,256,3):raise ValueError('Native image shape mismatch')
            calls=len(transport.calls)
            response=client.step(example=example,step=step);action=_response_to_delta_action(response,language,step)
            if np.asarray(action).shape!=(7,) or not np.isfinite(action).all():raise ValueError('Invalid physical action')
            if len(transport.calls)>calls:call_steps.append(step)
            actions.append(action)
            if row.get('record_video',True):frames.append(np.concatenate([front,wrist],axis=1))
            obs,_,done,_=env.step(action.tolist())
            if done:break
        if call_steps!=list(range(0,len(actions),8)):raise ValueError('Action chunk execution cadence mismatch')
        np.save(output/'actions.npy',np.stack(actions))
        if frames:imageio.mimsave(output/'rollout.mp4',frames,fps=20)
        record=dict(passed=True,case=row,success=bool(done),actions=len(actions),physical_shape=[8,7],
            language=language,control_hz=20,policy_call_steps=call_steps,policy_calls=transport.calls[start_calls:],
            elapsed_seconds=time.perf_counter()-start,video=str(output/'rollout.mp4') if frames else None,scope=row.get('scope','engineering case, excluded from confirmatory subset'))
        if save_result:save(output/'result.json',record)
        return record
    finally:env.close()

def main():
    status(OUT,state='running',phase='model_load')
    policy,client,transport=model()
    manifest=load(ROOT/'manifests/plus_full.json');results=[]
    for i,row in enumerate(manifest['engineering']):
        output=OUT/'cases'/row['variant_id'].replace(':','_')
        status(OUT,state='running',phase='native_policy_rollouts',done=i,total=28,current=row['variant_id'])
        try:record=rollout(row,client,transport,output)
        except Exception as e:
            record=dict(passed=False,case=row,error=repr(e));save(output/'result.json',record);traceback.print_exc()
        results.append(record)
    failed=[r for r in results if not r['passed']]
    total_seconds=sum(r.get('elapsed_seconds',0) for r in results)
    save(OUT/'summary.json',dict(passed=28-len(failed),failed=len(failed),cases=28,
        engineering_successes=sum(bool(r.get('success')) for r in results),
        not_a_scientific_success_estimate=True,elapsed_seconds=total_seconds,
        gradient_cache_acceptance='pending separate probe',model_calls=transport.calls,
        projected_plus_baseline_gpu_hours=(total_seconds/len(results))*10030/3600 if not failed else None))
    if failed:raise RuntimeError(f'{len(failed)} engineering cells failed; inspect per-case results')
    status(OUT,state='completed',phase='model_and_native_interfaces',passed=28,failed=0,
           remaining_gates=['gradient/cache parity','full data/client coverage','scientific method implementation'])
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
