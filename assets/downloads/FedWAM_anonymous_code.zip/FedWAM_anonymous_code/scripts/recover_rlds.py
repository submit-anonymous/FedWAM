"""Recover all official shards, reusing verified local bytes, with bounded HTTP ranges.

No assumptions about LeRobot episode ordering; raw source paths remain authoritative.
"""
import argparse,concurrent.futures,os,struct,sys,time,zlib,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,save,load,status
from fedwam.data_contracts import checked_range,verify_file,cached_shard,publish_shard
REV='fb0c7029b076030d5d57227229e4f7460def1f7c'
PARTS=['libero_plus_mixdata.z01','libero_plus_mixdata.z02','libero_plus_mixdata.zip']
OLD=Path('/workspace/reference_assets/assets/libero_plus_data')
OUT=ROOT/'data/libero_plus_rlds/libero_mix/1.0.0'
REPORT=ROOT/'reports/data/recovery'

class SplitReader:
    def __init__(self):
        import requests
        self.urls=[f'https://huggingface.co/datasets/Sylvest/libero_plus_rlds/resolve/{REV}/{x}' for x in PARTS]
        self.sizes=[]
        for url in self.urls:
            with requests.get(url,headers={'Range':'bytes=0-0','Accept-Encoding':'identity'},stream=True,timeout=(30,120)) as r:
                r.raise_for_status()
                if r.status_code!=206:raise ValueError('Server did not honor byte range')
                total=int(r.headers['Content-Range'].split('/')[-1]);checked_range(r.raw,r.headers['Content-Range'],0,1,total)
                self.sizes.append(total)
        self.starts=[0,self.sizes[0],sum(self.sizes[:2])]
    def read(self,offset,n):
        import requests
        parts=[]
        while n:
            part=max(i for i,s in enumerate(self.starts) if s<=offset)
            local=offset-self.starts[part];take=min(n,self.sizes[part]-local)
            if take<=0:raise ValueError('Range exceeds archive')
            for attempt in range(8):
                try:
                    with requests.get(self.urls[part],headers={'Range':f'bytes={local}-{local+take-1}','Accept-Encoding':'identity'},stream=True,timeout=(30,180)) as r:
                        r.raise_for_status()
                        if r.status_code!=206:raise ValueError('Range ignored; refusing whole-archive download')
                        data=checked_range(r.raw,r.headers.get('Content-Range'),local,take,self.sizes[part])
                    break
                except Exception:
                    if attempt==7:raise
                    time.sleep(min(60,2**attempt))
            parts.append(data);offset+=take;n-=take
        return b''.join(parts)

def main():
    args=argparse.ArgumentParser();args.add_argument('--workers',type=int,default=3);args=args.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    index=load(ROOT/'manifests/rlds_zip_index.json')
    entries=sorted((Path(n).name,e) for n,e in index.items() if '.tfrecord-' in n)
    if len(entries)!=1024:raise ValueError('Incomplete archive index')
    lengths=list(map(int,load(ROOT/'manifests/rlds_dataset_info.json')['splits'][0]['shardLengths']))
    missing=[];reused=0;quarantined=0
    for name,entry in entries:
        path=OUT/name;source=cached_shard(OLD/'rlds_shards',name)
        if not path.exists() and source is not None:path.symlink_to(source)
        if path.exists():
            try:
                report=verify_file(path,entry['usize'],entry['crc32'])
            except ValueError as exc:
                # Never change reused external assets. Only quarantine files produced here.
                if path.is_symlink() or not path.resolve().is_relative_to(OUT.resolve()):raise
                quarantine=ROOT/'data/quarantine'/str(os.environ.get('SLURM_JOB_ID',os.getpid()))
                quarantine.mkdir(parents=True,exist_ok=True)
                target=quarantine/name
                if target.exists():raise RuntimeError('Quarantine collision')
                path.replace(target);quarantined+=1;missing.append((name,entry))
                save(REPORT/'quarantine'/f'{name}.json',{'path':str(target),'error':repr(exc)})
                (REPORT/'shards'/f'{name}.json').unlink(missing_ok=True)
            else:
                reused+=1
                save(REPORT/'shards'/f'{name}.json',dict(report,path=str(path),revision=REV,reused=True))
        else:missing.append((name,entry))
        status(REPORT,state='running',phase='verify_existing',reused=reused,total=1024,
               shards_checked=entries.index((name,entry))+1,missing_so_far=len(missing),quarantined=quarantined)
    info=load(ROOT/'manifests/rlds_dataset_info.json');save(OUT/'dataset_info.json',info)
    required=sum(e['usize'] for _,e in missing)
    import shutil
    if shutil.disk_usage(ROOT).free<required+60*1024**3:raise RuntimeError('Insufficient free storage with 60GiB reserve')
    save(REPORT/'plan.json',dict(revision=REV,reused=reused,missing=len(missing),missing_raw_bytes=required,
        missing_compressed_bytes=sum(e['csize'] for _,e in missing),expected_records=sum(lengths),
        scope='all 1024 original shards; no category or task subsampling'))
    reader=SplitReader() if missing else None
    def recover(item):
        name,e=item;raw=OUT/name;compressed=ROOT/'downloads/rlds'/f'{name}.deflate.partial'
        compressed.parent.mkdir(parents=True,exist_ok=True)
        pos=reader.starts[e['disk']]+e['lho'];header=reader.read(pos,30)
        if header[:4]!=b'PK\x03\x04':raise ValueError('Invalid ZIP local header')
        n,x=struct.unpack_from('<HH',header,26);pos+=30+n+x
        offset=compressed.stat().st_size if compressed.exists() else 0
        if offset>e['csize']:raise ValueError('Invalid partial download size')
        with compressed.open('ab') as f:
            while offset<e['csize']:
                data=reader.read(pos+offset,min(4*1024**2,e['csize']-offset));f.write(data);f.flush();offset+=len(data)
        data=compressed.read_bytes()
        if e['method']==8:data=zlib.decompress(data,-15)
        elif e['method']!=0:raise ValueError('Unsupported ZIP compression')
        check=publish_shard(raw,data,e['usize'],e['crc32']);del data
        save(REPORT/'shards'/f'{name}.json',dict(check,path=str(raw),revision=REV,reused=False))
        compressed.unlink();return name
    done=0
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(recover,x) for x in missing]
        for future in concurrent.futures.as_completed(futures):
            name=future.result();done+=1
            status(REPORT,state='running',phase='recover_missing',reused=reused,downloaded=done,total=1024,last=name)
    status(REPORT,state='completed',phase='all_raw_shards_available',reused=reused,downloaded=done,total=1024)
if __name__=='__main__':
    try:main()
    except Exception as e:
        previous=load(REPORT/'status.json') if (REPORT/'status.json').exists() else {}
        previous.pop('updated',None);previous.pop('job',None)
        previous.update(state='failed',error=repr(e));status(REPORT,**previous)
        traceback.print_exc();sys.exit(1)
