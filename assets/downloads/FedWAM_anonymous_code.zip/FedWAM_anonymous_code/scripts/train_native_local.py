"""Official LaWAM local loss/optimizer on accepted PLUS train chunks from LIBERO SFT."""
import argparse,fcntl,os,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,NATIVE_LOCAL_STORAGE_ROOT,load,file_hash
from fedwam.experiment_config import identity,resolved_config
from fedwam.round_runtime import RoundStore,atomic_json,atomic_torch,cpu_tree,rng_state,restore_rng
from fedwam.native_local import (local_contract,make_native_sample,make_collator,
                                 auxiliary_state,restore_auxiliary_state)

FILES=('src/fedwam/io.py','src/fedwam/native_local.py','scripts/train_native_local.py',
       'scripts/native_local_client.slurm','scripts/native_local_controller.py',
       'scripts/native_local_controller.slurm')
def run_identity(mode,steps,microbatch):
 cfg=resolved_config('M1',42,'formal')
 value=identity(cfg);value['code'].update({p:file_hash(ROOT/p) for p in FILES})
 value.update(method='M1',mode=mode,native_local_recipe=local_contract())
 value['config']=dict(cfg,native_local_steps=steps,native_local_microbatch=microbatch,
                      recipe_kind='official-LaWAM-local-post-LIBERO-SFT.v2-with-auxiliary')
 return value
def main():
 p=argparse.ArgumentParser();p.add_argument('--client',choices=['lighting','camera_pose','sensor_noise','background'],required=True)
 p.add_argument('--mode',choices=['engineering','formal'],required=True);args=p.parse_args()
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Native local training requires Slurm GPU')
 import torch
 from omegaconf import OmegaConf
 from starVLA.training.train_starvla import setup_optimizer_and_scheduler
 from starVLA.model.framework.latent_world.runtime.freeze_policy import parse_policy_freeze_config,apply_policy_freeze
 from fedwam.official_dataset import OfficialDataset
 from fedwam.training import configure
 import acceptance
 c=local_contract();steps=2 if args.mode=='engineering' else c['steps'];micro=2 if args.mode=='engineering' else c['per_device_batch']
 ident=run_identity(args.mode,steps,micro)
 root=NATIVE_LOCAL_STORAGE_ROOT/args.mode/args.client;root.mkdir(parents=True,exist_ok=True)
 store=RoundStore(root,ident)
 result=root/'status.json';state={'state':'starting','client':args.client,'mode':args.mode,'job':os.environ['SLURM_JOB_ID']}
 atomic_json(result,state)
 with (root/'worker.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  if (root/'verification.json').exists() and load(root/'verification.json').get('passed'):
   if load(root/'verification.json').get('identity')!=ident:raise ValueError('Stale native checkpoint')
   return
  transport=None
  try:
   acceptance.OUT=root/'acceptance'
   policy,_,transport=acceptance.model();b=policy.policy_backend
   official=OmegaConf.load(ROOT/'third_party/LaWAM/starVLA/config/training/train_libero.yaml')
   apply_policy_freeze(b,parse_policy_freeze_config(official.trainer.freeze));b.flow.requires_grad_(True)
   policy.train();collator=make_collator(policy)
   optimizer,scheduler=setup_optimizer_and_scheduler(policy,official)
   data=OfficialDataset(ROOT,args.client,'train',42,max_cached_episodes=1)
   stats=load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
   checkpoint=store.path('current.pt');done=0;draw=0;exposure={}
   if checkpoint.exists():
    saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    if saved['identity']!=ident or saved['client']!=args.client:raise ValueError('Native resume identity changed')
    b.vlm.load_state_dict(saved['vlm'],strict=True);b.lam.decoder.load_state_dict(saved['world'],strict=True)
    b.flow.load_state_dict(saved['action'],strict=True)
    restore_auxiliary_state(policy,saved['aux'])
    optimizer.load_state_dict(saved['optimizer']);scheduler.load_state_dict(saved['scheduler'])
    restore_rng(saved['rng']);done=saved['done'];draw=saved['draw'];exposure=saved['exposure']
    if draw!=done*micro:raise ValueError('Native resume draw count changed')
   else:
    import random,numpy as np
    random.seed(42);np.random.seed(42);torch.manual_seed(42);torch.cuda.manual_seed_all(42)
   def snapshot(done):
    from fedwam.round_runtime import atomic_torch
    value=dict(identity=ident,client=args.client,done=done,draw=draw,exposure=exposure,
        vlm=cpu_tree(b.vlm.state_dict()),world=cpu_tree(b.lam.decoder.state_dict()),action=cpu_tree(b.flow.state_dict()),
        aux=auxiliary_state(policy),
        optimizer=cpu_tree(optimizer.state_dict()),scheduler=scheduler.state_dict(),rng=rng_state())
    atomic_torch(checkpoint,value)
   started=time.perf_counter()
   for step in range(done,steps):
    optimizer.zero_grad(set_to_none=True);totals={k:0. for k in ('loss_total','loss_flow','loss_perceptual','loss_distill')}
    for _ in range(micro):
     row,t=data.sampler.draw(draw);sample=data.reader.read(row,t)
     raw=make_native_sample(sample,stats)
     batch={k:v.to('cuda:0') if isinstance(v,torch.Tensor) else v for k,v in collator([raw]).items()}
     out=b.forward(batch=batch)
     if not torch.isfinite(out['loss_total']):raise FloatingPointError('Nonfinite native LaWAM loss')
     (out['loss_total']/micro).backward()
     for k in totals:totals[k]+=float(out[k].detach())/micro
     draw+=1;exposure[row['source_group']]=exposure.get(row['source_group'],0)+1
     del batch,out,raw,sample
    torch.nn.utils.clip_grad_norm_([p for p in policy.parameters() if p.requires_grad],float(official.trainer.gradient_clipping),error_if_nonfinite=True)
    optimizer.step();scheduler.step()
    if (step+1)%50==0 or step+1==steps:
     if __import__('shutil').disk_usage(NATIVE_LOCAL_STORAGE_ROOT).free<80*1024**3:raise RuntimeError('Disk floor reached; previous native checkpoint retained')
     snapshot(step+1)
     state.update(state='running',updates=step+1,draw=draw,last_losses=totals,
         learning_rates=[group['lr'] for group in optimizer.param_groups],seconds=time.perf_counter()-started)
     atomic_json(result,state)
   private=dict(vlm=cpu_tree(b.vlm.state_dict()),world=cpu_tree(b.lam.decoder.state_dict()),
                action=cpu_tree(b.flow.state_dict()),aux=auxiliary_state(policy),
                total_updates=steps,exposure=exposure)
   final=dict(schema='fedwam.client.v1',identity=ident,method='M1',seed=42,client=args.client,done=steps,
              steps=steps,state=private,inference_only=True,native_local_recipe=c)
   ref=store.write(f'checkpoints/final/{args.client}.pt',final)
   atomic_json(root/'verification.json',dict(passed=True,identity=ident,ref=ref,client=args.client,
       updates=steps,draw=draw,scope='native LaWAM local post-SFT adaptation'))
   checkpoint.unlink(missing_ok=True)
   state.update(state='completed',updates=steps,draw=draw);atomic_json(result,state)
  except Exception as error:
   state.update(state='failed',error=repr(error),traceback=traceback.format_exc()[-4000:]);atomic_json(result,state);raise
  finally:
   if transport:transport.close()
if __name__=='__main__':main()
