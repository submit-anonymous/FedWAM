"""Independent uninterrupted rerun to distinguish GPU variability from restore errors."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from imagewam_native_adaptation import run
from imagewam_model_acceptance import write


output=Path('/workspace/reviewer/fedwam-heterogeneous-native-repeat-check/lighting')
with patch('fedwam.heterogeneous.native_checkpoint.save_training',lambda *args,**kwargs:None):
    run(SimpleNamespace(output=output,domain='lighting',batch_size=32,total_steps=25000,stop_at=2))
write(output/'diagnostic.json',dict(scope='uninterrupted repeat, intentionally no checkpoint saved',seed=42))
