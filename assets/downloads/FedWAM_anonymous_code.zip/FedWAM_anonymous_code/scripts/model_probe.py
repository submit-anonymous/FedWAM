"""Action-only gradient test, deployed-query parity, and fixed-RNG causal intervention."""
from pathlib import Path
import sys,io,traceback,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,save,load,status,digest
from fedwam.rlds import iter_records,feature_payloads,feature_values,parse_episode
from fedwam.training import configure,encode,losses
import acceptance
OUT=ROOT/'reports/control_probe'

def frozen_hash(policy):
    import torch
    h=hashlib.sha256()
    for name,p in policy.named_parameters():
        if p.requires_grad:continue
        h.update(name.encode());h.update(str(p.dtype).encode())
        for chunk in p.detach().reshape(-1).view(torch.uint8).split(8*1024**2):h.update(chunk.cpu().numpy().tobytes())
    return h.hexdigest()

def main():
    import numpy as np,torch
    from PIL import Image
    acceptance.OUT=OUT
    status(OUT,state='running',phase='load_model')
    policy,client,transport=acceptance.model();b=configure(policy)
    paths=sorted((ROOT/'data/libero_plus_rlds/libero_mix/1.0.0').glob('*.tfrecord-*'))
    if not paths:raise RuntimeError('No verified raw shard links yet')
    for offset,payload in iter_records(paths[0]):
        record=parse_episode(payload)
        if record['length']>8:break
    features=feature_payloads(payload)
    def frame(key,t):
        with Image.open(io.BytesIO(feature_values(features[key],1)[t])) as im:return np.asarray(im.convert('RGB')).copy()
    sample={'primary':frame('steps/observation/image',0),'wrist':frame('steps/observation/wrist_image',0),'future':frame('steps/observation/image',8),
        't':0,'future_t':8,'actions':feature_values(features['steps/action'],2).reshape(-1,7)[:8],'lang':record['task']}
    save(OUT/'source_exposure.json',dict(record,shard=str(paths[0]),offset=offset,role='engineering, exclude source group from confirmatory prediction split'))
    stats=load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
    status(OUT,state='running',phase='cache_and_gradient_checks')
    batch,parity=encode(policy,sample,stats);hash_before=frozen_hash(policy)
    gradients={}
    for detach in (False,True):
        policy.zero_grad(set_to_none=True);torch.manual_seed(123)
        result=losses(policy,batch,detach_feedback=detach);result['action'].backward()
        world_norm=sum(float(p.grad.float().square().sum()) for p in b.lam.decoder.parameters() if p.grad is not None)**.5
        action_norm=sum(float(p.grad.float().square().sum()) for p in b.flow.parameters() if p.grad is not None)**.5
        if (not detach and world_norm<=0) or (detach and world_norm!=0) or action_norm<=0:raise RuntimeError('Incorrect action-only gradient routing')
        gradients[str(detach)]={'world_norm':world_norm,'action_norm':action_norm,'loss':float(result['action'])}
        del result
    policy.zero_grad(set_to_none=True)
    example={'lang':sample['lang'],'primary_image':[sample['primary']],'wrist_image':[sample['wrist']],'action_hz':20.,'embodiment_id':25}
    def predict():
        torch.manual_seed(999)
        return np.asarray(policy.predict_action(examples=[example])['normalized_actions']).copy()
    before=predict();torch.manual_seed(123);result=losses(policy,batch);old_pred=result['prediction'].detach().clone()
    result['world'].backward()
    optimizer=torch.optim.SGD(b.lam.decoder.parameters(),lr=1e-4)
    optimizer.step();optimizer.zero_grad(set_to_none=True)
    after=predict();torch.manual_seed(123)
    with torch.no_grad():new_pred=losses(policy,batch)['prediction']
    delta=float(np.max(np.abs(before-after)));world_delta=float((old_pred-new_pred).abs().max())
    if world_delta<=0 or delta<=0:raise RuntimeError(f'World update did not change control: world={world_delta}, action={delta}')
    if frozen_hash(policy)!=hash_before:raise RuntimeError('Frozen module state changed')
    save(OUT/'result.json',dict(passed=True,action_only_gradient=gradients,cache_parity=parity,
        frozen_state_sha256=hash_before,world_update_prediction_max_abs=world_delta,world_update_action_max_abs=delta,
        action_expert_update_during_intervention=False,trained_weights_discarded=True,scope='causal engineering test, not task improvement'))
    status(OUT,state='completed',phase='world_to_control_verified')
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));traceback.print_exc();sys.exit(1)
