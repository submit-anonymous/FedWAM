"""Real two-architecture transport/reception probe. Not a formal multi-round run."""
import argparse
import gc
import json
from pathlib import Path
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'third_party/ImageWAM')]
from imagewam_model_acceptance import write


def query(adapter,sample,reference,language):
    import torch
    state,mask=adapter.state(sample)
    return dict(z=reference([sample['primary']]).detach().cpu(),
                language=language[sample['lang']].reshape(1,7680).float(),state=state,
                state_mask=mask,horizon=torch.full((1,1),8.))


def run(args):
    import torch
    from fedwam.heterogeneous.interface import SCHEMA,CommonTeacher,reliability
    from fedwam.heterogeneous.reference import ReferenceEncoder,REFERENCE_ID
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.packet_io import save_packet,load_packet,masked_language
    from fedwam.heterogeneous.packets import reception_loss
    from fedwam.heterogeneous.teacher import fit_teacher
    torch.manual_seed(42);torch.set_num_threads(4)
    output=args.output;output.mkdir(parents=True,exist_ok=True)
    status=dict(state='running',phase=args.mode,architecture=args.architecture,seed=42,
                scope='real mixed-architecture engineering round; not scientific training')
    write(output/'status.json',status)
    if args.mode=='server':
        packets=[load_packet(p,round_id=1) for p in args.packets]
        if len(packets)!=2:raise ValueError('This engineering probe requires exactly two sender packets')
        if {p['architecture'] for p in packets}!={'lawam','imagewam'}:raise ValueError('Expected both architectures')
        groups=[set(p['source_groups']) for p in packets]
        if groups[0]&groups[1]:raise ValueError('Private sender source allocations overlap')
        checkpoint=output/'teacher.pt'
        resume=torch.load(checkpoint,map_location='cpu',weights_only=True) if checkpoint.exists() else None
        def save(payload):
            temp=checkpoint.with_suffix('.tmp');torch.save(payload,temp);temp.replace(checkpoint)
        payload=fit_teacher(packets,round_id=1,steps=args.steps,batch_size=16,device='cuda',resume=resume,checkpoint=save)
        save(payload)
        result=dict(passed=True,steps=payload['updates'],sender_clients=payload['sender_clients'],
                    validation_mse=payload['validation_mse'],future_truth_uploaded=False,
                    private_sources_disjoint=True,packet_bytes=sum(p.stat().st_size for p in args.packets))
    else:
        from fedwam.heterogeneous.adapters import LaWAMAdapter,ImageWAMAdapter
        adapter=(LaWAMAdapter(ROOT) if args.architecture=='lawam' else ImageWAMAdapter(ROOT,args.readout))
        if args.architecture=='imagewam' and adapter.domain!=args.domain:raise ValueError('Readout/client domain mismatch')
        dataset=HeterogeneousDataset(ROOT,adapter.subset,args.domain)
        if args.mode=='export' and args.architecture=='imagewam':
            from imagewam.datasets.lerobot.robot_video_dataset import DEFAULT_PROMPT
            language={}
            for task in sorted({row['task'] for row in dataset.rows}):
                hidden,mask=adapter.text(DEFAULT_PROMPT.format(task=task))
                language[task]=masked_language(hidden,mask).cpu()
            args.language.parent.mkdir(parents=True,exist_ok=True)
            torch.save(dict(schema='public-qwen3-4b-masked-mean-v1',reference_id=REFERENCE_ID,language=language),args.language)
        else:
            payload=torch.load(args.language,map_location='cpu',weights_only=True)
            if payload['reference_id']!=REFERENCE_ID or payload['schema']!='public-qwen3-4b-masked-mean-v1':
                raise ValueError('Common public language definition mismatch')
            language=payload['language']
        reference=ReferenceEncoder(ROOT/'assets/dinov3-vitb16-pretrain-lvd1689m')
        if args.mode=='export':
            records=[]
            for draw in range(args.samples):
                sample=dataset.sample(draw);native=adapter.prepare(sample)
                with torch.no_grad():prediction=adapter.predict(native).cpu()
                records.append(dict(query=query(adapter,sample,reference,language),prediction=prediction,
                    source_group=sample['source_group'],task=sample['lang'],query_id=f"{sample['record_id']}:{sample['t']}"))
            if len({r['query_id'] for r in records})!=len(records):raise ValueError('Duplicate sampled upload chunks')
            packet=dict(schema=SCHEMA,round=1,client=args.architecture+'-'+args.domain,architecture=args.architecture,
                model_version=adapter.version,representation='future',
                query={k:torch.cat([r['query'][k] for r in records]) for k in records[0]['query']},
                prediction=torch.cat([r['prediction'] for r in records]),
                source_groups=[r['source_group'] for r in records],tasks=[r['task'] for r in records],
                query_ids=[r['query_id'] for r in records])
            receipt=save_packet(output/'packet.pt',packet,round_id=1,max_bytes=64*1024**2)
            result=dict(passed=True,samples=len(records),sources=len(set(packet['source_groups'])),
                        future_truth_uploaded=False,action_parameters_uploaded=False,upload=receipt)
        elif args.mode=='receive':
            teacher_state=torch.load(args.teacher,map_location='cpu',weights_only=True)
            if teacher_state['schema']!=SCHEMA or teacher_state['round']!=1:raise ValueError('Teacher contract mismatch')
            teacher=CommonTeacher(**teacher_state['config']).cuda().eval().requires_grad_(False)
            teacher.load_state_dict(teacher_state['model'],strict=True)
            calibration=HeterogeneousDataset(ROOT,adapter.subset,args.domain,'calibration')
            errors=[]
            for draw in range(16):
                sample=calibration.sample(draw);native=adapter.prepare(sample)
                q={k:v.cuda() for k,v in query(adapter,sample,reference,language).items()}
                with torch.no_grad():
                    truth=reference([sample['future']]);local=adapter.predict(native);shared=teacher(q)
                errors.append(dict(local=float((local-truth).square().mean()),teacher=float((shared-truth).square().mean())))
            local_error=sum(r['local'] for r in errors)/len(errors)
            teacher_error=sum(r['teacher'] for r in errors)/len(errors)
            gate=reliability(local_error,teacher_error)
            # This engineering intervention explicitly uses g=1 even when calibration
            # rejects the teacher. Never report it as an accepted scientific update.
            sample=dataset.sample(10000);native=adapter.prepare(sample)
            q={k:v.cuda() for k,v in query(adapter,sample,reference,language).items()}
            with torch.no_grad():
                target=teacher(q).detach();before=adapter.predict(native).detach()
                before_action=adapter.action_output(sample,native)
            del reference,teacher,truth,local,shared
            if hasattr(adapter,'offload_text'):adapter.offload_text()
            gc.collect();torch.cuda.empty_cache()
            adapter.world.requires_grad_(True)
            parameters=list(adapter.world.parameters())
            action_versions={n:p._version for n,p in adapter.action.named_parameters()}
            optimizer=torch.optim.AdamW(parameters,lr=1e-5,foreach=False)
            optimizer.zero_grad(set_to_none=True)
            prediction=adapter.predict(native)
            loss=reception_loss(prediction,target,1.)
            loss.backward()
            grads=[p.grad for p in parameters if p.grad is not None]
            if not grads or not all(torch.isfinite(g).all() for g in grads):raise ValueError('Invalid reception gradients')
            norm=float(torch.nn.utils.clip_grad_norm_(parameters,1.))
            if norm<=0:raise ValueError('Zero world reception gradient')
            if any(p.grad is not None for p in adapter.action.parameters()):raise ValueError('Private action received teacher gradients')
            if hasattr(adapter,'head') and any(p.grad is not None for p in adapter.head.parameters()):raise ValueError('Frozen readout updated')
            optimizer.step();optimizer.zero_grad(set_to_none=True)
            adapter.world.requires_grad_(False)
            with torch.no_grad():after=adapter.predict(native);after_action=adapter.action_output(sample,native)
            if any(p._version!=action_versions[n] for n,p in adapter.action.named_parameters()):raise ValueError('Private action parameters changed')
            change=float((after-before).abs().max());action_change=float((after_action-before_action).abs().max())
            if not torch.isfinite(after).all() or not torch.isfinite(after_action).all() or change==0 or action_change==0:
                raise ValueError('Reception did not change finite prediction/action outputs')
            result=dict(passed=True,local_calibration_mse=local_error,teacher_calibration_mse=teacher_error,
                calibration_scope='16-draw unweighted engineering diagnostic, not formal reliability estimator',
                calibrated_gate=gate,applied_probe_gate=1.,scientific_update_accepted=False,
                probe_only_forced_gate=True,full_world_trainable_parameters=sum(p.numel() for p in parameters),
                gradient_norm=norm,prediction_change_max_abs=change,action_change_max_abs=action_change,
                action_parameters_unchanged=True,readout_frozen=True,peak_gpu_bytes=torch.cuda.max_memory_allocated(),
                local_post_adaptation_performed=False,updated_parameters_discarded=True)
        else:raise ValueError('Unknown operation')
    write(output/'result.json',result)
    status.update(state='completed');write(output/'status.json',status)
    print(json.dumps(result))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=['export','server','receive'])
    p.add_argument('--architecture',choices=['lawam','imagewam'],default='lawam')
    p.add_argument('--domain',default='lighting')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--readout',type=Path)
    p.add_argument('--language',type=Path,default=ROOT/'reports/heterogeneous/common-language.pt')
    p.add_argument('--packets',type=Path,nargs='*',default=[])
    p.add_argument('--teacher',type=Path)
    p.add_argument('--samples',type=int,default=64)
    p.add_argument('--steps',type=int,default=500)
    args=p.parse_args()
    try:run(args)
    except Exception as exc:
        path=args.output/'status.json';status=json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed',error=repr(exc)[:2000]);write(path,status)
        traceback.print_exc();raise SystemExit(1)
