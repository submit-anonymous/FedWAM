"""Materialize audited index-only partitions without copying video/RLDS data."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from fedwam.heterogeneous.data import allocate_sources, partition_records


def sha(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()


def save(path, value):
    text = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n'
    if path.exists() and path.read_text() != text:
        raise ValueError(f'Refusing to overwrite a different frozen allocation: {path}')
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.tmp')
    tmp.write_text(text)
    tmp.replace(path)


def main():
    base = ROOT / 'manifests/official_four_clients'
    receipt = json.loads((base / 'acceptance.json').read_text())
    if receipt.get('accepted_for_official_four_client_training') is not True:
        raise ValueError('Parent official-data acceptance failed')
    for group in ('files', 'code'):
        for relative, expected in receipt[group].items():
            path = (ROOT / relative).resolve()
            if not path.is_relative_to(ROOT) or sha(path) != expected:
                raise ValueError('Parent audit checksum mismatch: ' + relative)
    records = []
    parents = {}
    clients = ('lighting', 'camera_pose', 'sensor_noise', 'background')
    for client in clients:
        for path in sorted((base / client).glob('*.json')):
            value = json.loads(path.read_text())
            if value['identity'] != receipt['identity']:
                raise ValueError('Parent identity mismatch')
            relative = str(path.relative_to(ROOT))
            if relative not in receipt['files']:
                raise ValueError('Unaudited input manifest')
            parents[relative] = sha(path)
            for index, row in enumerate(value['rows']):
                if row['client'] != client or row['split'] != value['split']:
                    raise ValueError('Parent row header mismatch')
                records.append({key: row[key] for key in
                                ('source_group', 'suite', 'task', 'split', 'client', 'record_id', 'chunk_count')} |
                               {'parent_manifest': relative, 'parent_row': index})
    parts = partition_records(records)
    allocation = allocate_sources(records)
    output = ROOT / 'manifests/heterogeneous_seed42_v1'
    files = {}
    counts = {}
    for subset, rows in parts.items():
        selections = [('all', rows)] if subset == 'heldout' else [
            (client, [r for r in rows if r['client'] == client]) for client in clients]
        for client, selected in selections:
            name = f'{subset}/{client}.json'
            payload = {'schema': 'heterogeneous-source-index-v1', 'seed': 42,
                       'parent_identity': receipt['identity'], 'subset': subset, 'domain': client,
                       'rows': selected}
            save(output / name, payload)
            files[name] = sha(output / name)
            counts[name] = {'episodes': len(selected), 'chunks_h8': sum(r['chunk_count'] for r in selected),
                            'sources': len({r['source_group'] for r in selected}),
                            'tasks': len({(r['suite'], r['task']) for r in selected})}
    result = {'schema': 'heterogeneous-source-allocation-v1', 'seed': 42,
              'parent_identity': receipt['identity'], 'parents': parents,
              'parent_receipt_sha256': sha(base / 'acceptance.json'),
              'assignments': allocation, 'files': files, 'counts': counts,
              'logical_clients': [{'id': f'{architecture}-{client}', 'architecture': architecture,
                                   'domain': client, 'train_index': f'{subset}/{client}.json'}
                                  for architecture, subset in (('lawam', 'A'), ('imagewam', 'B'))
                                  for client in clients],
              'heldout_reuse': 'Identical untouched parent held-out sets for paired architecture evaluation',
              'homogeneous_controls': 'Use same A/B indexes; change architecture labels only',
              'data_swap_control': 'Swap architecture labels A/B without changing records',
              'public_access': 'Same public pool accessible to all methods; removed from private train indexes',
              'passed': True, 'common_h8_adapter_validated': False}
    save(output / 'acceptance.json', result)
    print(json.dumps({'passed': True, 'clients': 8, 'counts': counts}, indent=2))


if __name__ == '__main__':
    main()
