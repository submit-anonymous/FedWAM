"""Record native action-path LaWM subgoals and their actual chunk endpoints."""
import json
import os
from pathlib import Path
import random
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from imagewam_model_acceptance import write,load_initial_states
OUT=ROOT/'reports/paper_prediction_media_20260926/lawam'

def run():
    import numpy as np
    import torch
    import imageio.v2 as imageio
    from PIL import Image
    from unittest.mock import patch
    from fedwam.heterogeneous.adapters import LaWAMAdapter
    from deployment.model_server.server_policy import build_policy_server_metadata
    from examples.LIBERO.eval_files import model2libero_interface as interface
    from examples.LIBERO.eval_files.libero_eval_core import _build_policy_example_from_obs,_response_to_delta_action
    from acceptance import Transport
    from libero.libero import benchmark,get_libero_path
    from libero.libero.envs import OffScreenRenderEnv
    state=dict(state='running',phase='load',seed=42);write(OUT/'status.json',state)
    random.seed(42);np.random.seed(42);torch.manual_seed(42)
    adapter=LaWAMAdapter(ROOT);policy=adapter.model;backend=policy.policy_backend
    checkpoint=str(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt')
    metadata=build_policy_server_metadata(policy,ckpt_path=checkpoint,server_type='local_native_plus',env='libero',supported_eval_envs=['libero'])
    transport=Transport(policy,metadata)
    with patch.object(interface,'WebsocketClientPolicy',lambda *a,**kw:transport):
        client=interface.ModelClient(checkpoint,action_hz=20.,embodiment_id=25,eval_action_chunk_len=8)
    cache=[];original=backend._run_shared_encoding_infer
    def capture(**kwargs):
        shared=original(**kwargs)
        current=shared.h_t_original[0].detach().float().cpu().numpy()
        prediction=shared.h_t1_pred[0].detach().float().cpu().numpy()
        if current.shape!=prediction.shape or current.shape!=(256,768):raise ValueError('Unexpected original token grid')
        cache.append(dict(current=current,prediction=prediction))
        return shared
    backend._run_shared_encoding_infer=capture
    suite=benchmark.get_benchmark_dict()['libero_spatial'](task_order_index=0);task=suite.get_task(0)
    states=load_initial_states(lambda:suite.get_task_init_states(0))
    env=OffScreenRenderEnv(bddl_file_name=str(Path(get_libero_path('bddl_files'))/task.problem_folder/task.bddl_file),camera_heights=256,camera_widths=256)
    frames=[];actions=[];chunks=[];success=False
    try:
        env.seed(42);env.reset();obs=env.set_init_state(states[0]);language=env.language_instruction
        assert env.env.control_freq==20
        client.reset(task_description=language)
        for _ in range(10):obs,_,_,_=env.step([0,0,0,0,0,0,-1])
        _,front,_=_build_policy_example_from_obs(obs,language);frames.append(front.copy())
        (OUT/'frames').mkdir(exist_ok=True);Image.fromarray(front).save(OUT/'initial.png')
        for step in range(400):
            example,front,wrist=_build_policy_example_from_obs(obs,language)
            n=len(cache);response=client.step(example=example,step=step)
            action=_response_to_delta_action(response,language,step)
            if len(cache)>n:
                assert len(cache)==n+1 and step%8==0
                chunks.append(dict(start=step,index=len(cache)-1))
            if np.asarray(action).shape!=(7,) or not np.isfinite(action).all():raise ValueError('Invalid action')
            obs,_,done,_=env.step(action.tolist());actions.append(action)
            _,front,_=_build_policy_example_from_obs(obs,language);frames.append(front.copy())
            if done:success=bool(done);break
        if success!=bool(env.check_success()):raise ValueError('Success flag mismatch')
    finally:env.close();backend._run_shared_encoding_infer=original
    assert [c['start'] for c in chunks]==list(range(0,len(actions),8))
    complete=[]
    for c in chunks:
        start=c['start'];end=start+8
        if end>len(actions):continue
        folder=OUT/f'chunk_{start:04d}';folder.mkdir(exist_ok=True)
        np.savez_compressed(folder/'features.npz',**cache[c['index']])
        Image.fromarray(frames[start]).save(folder/'current.png')
        Image.fromarray(frames[end]).save(folder/'actual_end.png')
        complete.append(dict(start=start,end=end,folder=folder.name))
    for i,frame in enumerate(frames):Image.fromarray(frame).save(OUT/'frames'/f'{i:04d}.png')
    with imageio.get_writer(OUT/'rollout.mp4',fps=20,codec='libx264',quality=9,macro_block_size=1) as w:
        for frame in frames:w.append_data(frame)
    np.save(OUT/'actions.npy',np.asarray(actions))
    write(OUT/'result.json',dict(success=success,seed=42,suite='libero_spatial',task_id=0,init_state_index=0,
        instruction=language,actions=len(actions),frame_count=len(frames),horizon=8,replan=8,control_hz=20,wait_steps=10,
        chunks=complete,partial_final_chunk_excluded=len(complete)<len(chunks),checkpoint=checkpoint,
        capture='Actual _run_shared_encoding_infer output used by action expert; no separate world prediction',
        shape=[16,16,768],scope='One native qualitative trajectory, not federated training'))
    state.update(state='completed',phase='subgoals_recorded',success=success,actions=len(actions),chunks=len(complete));write(OUT/'status.json',state)

if __name__=='__main__':
    if (OUT/'result.json').exists():raise SystemExit('Preserve existing trajectory')
    try:run()
    except Exception as e:write(OUT/'status.json',dict(state='failed',error=repr(e)));traceback.print_exc();raise
