"""Read-only one-step native LaWAM recipe feasibility check on accepted PLUS data."""
import json,os,sys,time,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load
from fedwam.round_runtime import atomic_json

OUT=ROOT/'reports/official_local_recipe_probe'
def raw_sample(sample,stats):
 import torch
 from fedwam.training import action_tensors
 def frame(x):
  if x.shape!=(256,256,3):raise ValueError('Unexpected frame shape')
  return torch.as_tensor(x.copy()).permute(2,0,1).contiguous()
 actions=action_tensors(sample['actions'],stats)['actions'][0,:8,:7].contiguous()
 return {'primary_videos':torch.stack([frame(sample['primary']),frame(sample['future'])])[None],
         'wrist_images':frame(sample['wrist'])[None], 'lang':sample['lang'],
         'state':torch.zeros(1,32),'action':actions,'embodiment_id':25,'action_hz':20.}
def main():
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Slurm GPU allocation required')
 import torch,yaml
 from starVLA.dataloader.latent_world_train_collator import LatentWorldTrainCollator
 from starVLA.model.framework.latent_world.processor_utils import build_latent_world_processor_spec
 from starVLA.model.framework.latent_world.runtime.freeze_policy import parse_policy_freeze_config,apply_policy_freeze
 from fedwam.official_dataset import OfficialDataset
 import acceptance
 from fedwam.io import file_hash
 acceptance.OUT=OUT/'acceptance'
 status=dict(state='loading',job=os.environ['SLURM_JOB_ID'],checkpoint_sha256=file_hash(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'))
 atomic_json(OUT/'status.json',status)
 transport=None
 try:
  policy,_,transport=acceptance.model();b=policy.policy_backend
  cfg=yaml.safe_load((ROOT/'third_party/LaWAM/starVLA/config/training/train_libero.yaml').read_text())
  apply_policy_freeze(b,parse_policy_freeze_config(cfg['trainer']['freeze']))
  b.flow.requires_grad_(True);policy.train()
  trainable={name:sum(p.numel() for p in module.parameters() if p.requires_grad) for name,module in
             [('vlm',b.vlm),('world',b.lam.decoder),('action',b.flow)]}
  if min(trainable.values())<1:raise ValueError('Official trainable-module selection incomplete')
  stats=load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
  dataset=OfficialDataset(ROOT,'lighting','train',43,max_cached_episodes=1)
  sample=dataset.sample(0);raw=raw_sample(sample,stats)
  spec=build_latent_world_processor_spec(policy_cfg=b.model_cfg,vlm_model_id=str(ROOT/'assets/qwen3-vl-2b'))
  collator=LatentWorldTrainCollator(policy_cfg=b.model_cfg,processor_spec=spec,
      act_queries=int(b.model_cfg.num_action_queries),flow_queries=int(b.model_cfg.flow_action_num_queries),
      enable_primary_video_aug=False,enable_primary_random_resized_crop=False).train()
  batch={k:v.to('cuda:0') if isinstance(v,torch.Tensor) else v for k,v in collator([raw]).items()}
  if batch['primary_video'].shape[1]!=2:raise ValueError('Native two-frame training contract missing')
  status.update(state='forward',trainable=trainable,batch_size=1,
      action_chunk=8,source_group=sample['source_group'],num_input_frames=2)
  atomic_json(OUT/'status.json',status)
  torch.cuda.reset_peak_memory_stats();started=time.perf_counter()
  out=b.forward(batch=batch)
  if not torch.isfinite(out['loss_total']):raise FloatingPointError('Nonfinite native LaWAM loss')
  status.update(state='backward',losses={k:float(out[k].detach()) for k in ('loss_flow','loss_perceptual','loss_distill','loss_total')})
  atomic_json(OUT/'status.json',status)
  out['loss_total'].backward()
  gradients={name:sum(float(p.grad.detach().abs().sum()) for p in module.parameters() if p.grad is not None)
             for name,module in [('vlm',b.vlm),('world',b.lam.decoder),('action',b.flow)]}
  if min(gradients.values())<=0:raise ValueError('Missing gradient in official trainable module')
  params=[p for p in policy.parameters() if p.requires_grad]
  optimizer=torch.optim.AdamW(params,lr=1e-4,betas=(.9,.95),weight_decay=1e-8)
  optimizer.step()
  status.update(state='completed',gradients=gradients,seconds=time.perf_counter()-started,
      peak_gpu_bytes=torch.cuda.max_memory_allocated(),gpu_total_bytes=torch.cuda.get_device_properties(0).total_memory,
      scope='one native LaWAM step on accepted PLUS train sample; no weight saved or scientific result')
  atomic_json(OUT/'status.json',status)
 except Exception as error:
  status.update(state='failed',error=repr(error),traceback=traceback.format_exc()[-4000:])
  atomic_json(OUT/'status.json',status);raise
 finally:
  if transport:transport.close()
if __name__=='__main__':main()
