"""Compare equal-budget development heads and report gates without starting training."""
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
from imagewam_model_acceptance import write
BASE=ROOT/'reports/heterogeneous'
DOMAINS=('lighting','camera_pose','sensor_noise','background')
JOBS={'learned_query':(10420,10423,10424,10425),'spatial':(10433,10434,10435,10436)}


def main():
    candidates={};sample_identity={}
    for kind,jobs in JOBS.items():
        metrics=[]
        for domain,job in zip(DOMAINS,jobs):
            path=BASE/f'readout-{domain}-{job}'/'result.json'
            if not path.exists():
                metrics.append(dict(domain=domain,job=job,state='not_completed'));continue
            result=json.loads(path.read_text())
            if result['steps']!=4000 or len(result['samples']['train'])!=4096 or len(result['samples']['development'])!=256:
                raise ValueError('Unequal readout development budget')
            identity=hashlib.sha256(json.dumps(result['samples'],sort_keys=True).encode()).hexdigest()
            if domain in sample_identity and identity!=sample_identity[domain]:raise ValueError('Readout samples differ')
            sample_identity[domain]=identity
            row=result['curves'][-1]
            metrics.append(dict(domain=domain,job=job,state='completed',mse=row['mse'],copy_mse=row['copy_mse'],
                ratio=row['mse']/row['copy_mse'],beats_copy=row['mse']<row['copy_mse']))
        complete=all(r['state']=='completed' for r in metrics)
        candidates[kind]=dict(metrics=metrics,complete=complete,
            all_domains_beat_copy=complete and all(r['beats_copy'] for r in metrics),
            mean_relative_mse=sum(r['ratio'] for r in metrics)/4 if complete else None)
    eligible=[kind for kind,value in candidates.items() if value['all_domains_beat_copy']]
    selected=min(eligible,key=lambda kind:candidates[kind]['mean_relative_mse']) if eligible else None
    completed={}
    for name,path in {
        'imagewam_native_h16':'native-imagewam-10403/result.json',
        'imagewam_native_h8':'native-imagewam-10437/result.json',
        'lawam_common_reference':'lawam-common-10414/result.json',
        'imagewam_native_backward':'native-update-10415/result.json',
        'lawam_simulator_h8':'lawam-sim-10432/result.json',
        'server':'mixed-round-v1/server/result.json',
        'lawam_reception':'mixed-round-v1/lawam-receive/result.json',
        'imagewam_reception':'mixed-round-v1/imagewam-receive/result.json',
    }.items():
        file=BASE/path
        completed[name]=json.loads(file.read_text()).get('passed',False) if file.exists() else False
    report=dict(seed=42,scope='engineering and development only',candidates=candidates,
        selection_rule='One head architecture for all four domains; require each to beat copy, then lowest mean dev MSE/copy ratio',
        selected_readout=selected,sample_identity=sample_identity,component_checks=completed,
        formal_training_started=False,formal_admission=False,
        remaining=['native joint-training recipe and precision/budget freeze',
                   'eight-client resumable rounds with post-reception adaptation',
                   'integrated task/source-balanced calibration',
                   'capacity admission and formal controlled rollout evaluation'])
    if selected is None:report['remaining'].insert(0,'readout does not yet pass all four domains')
    write(BASE/'acceptance_report.json',report)
    print('Real model/component checks:',sum(completed.values()),'/',len(completed))
    for kind,value in candidates.items():
        passed=sum(r.get('beats_copy',False) for r in value['metrics'])
        print(f'{kind}: completed={value["complete"]}, beats copy={passed}/4')
    print('Selected common readout:',selected or 'none; further development required')
    print('Formal heterogeneous training: NOT STARTED')


if __name__=='__main__':main()
