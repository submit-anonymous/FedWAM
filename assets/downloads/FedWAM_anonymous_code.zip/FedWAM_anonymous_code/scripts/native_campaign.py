"""Seed-42 native LaWAM campaign with independent client GPU jobs."""
import argparse
import fcntl
import json
import os
import shutil
import sys
import time
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from fedwam.io import ROOT, NATIVE_STORAGE_ROOT, digest, file_hash, load
from fedwam.experiment_config import code_identity
from fedwam.native_engine import NativeDetachedEngine
from fedwam.native_execution import native_gate, native_identity
from fedwam.native_federation import native_config
from fedwam.native_retention import compact_native_run
from fedwam.parallel_execution import claim_filtered
from fedwam.round_runtime import atomic_json
from fedwam.work_queue import WorkQueue
from plan_federated import make_plan
import detached_campaign as base


PLAN = ROOT/'manifests/fedwam_seed42_native_v6_work_plan.json'
OUT = ROOT/'reports/native_fedwam_engineering_v6'
RUNS = NATIVE_STORAGE_ROOT/'engineering-v6'
ORDER = base.ORDER
SCRIPTS = {
    'detached_client.slurm': 'native_federated_client.slurm',
    'detached_pipeline.slurm': 'native_federated_pipeline.slurm',
    'detached_eval.slurm': 'native_federated_eval.slurm',
}


def make_native_plan(shards=16):
    plan = make_plan('fedwam_seed42_native_v6', shards=shards)
    original_root = plan['root']
    native_root = str(NATIVE_STORAGE_ROOT/'seed42-native-v6')
    plan['root'] = native_root
    plan['runs'] = [run.replace(original_root, native_root, 1) for run in plan['runs']]
    for task in plan['tasks']:
        task['argv'] = [arg.replace(original_root, native_root, 1)
                        if arg.startswith(original_root) else arg for arg in task['argv']]
    plan['runs'] = [run for run in plan['runs'] if run.endswith('/seed42')]
    plan['tasks'] = [task for task in plan['tasks'] if '-s42-' in task['id']]
    for task in plan['tasks']:
        if task['kind'] == 'train':
            task.update(kind='detached_train',
                        method=task['argv'][task['argv'].index('--method')+1])
        else:
            task['argv'] = [arg.replace('scripts/evaluate_federated.py',
                                        'scripts/evaluate_native_federated.py')
                            for arg in task['argv']]
    plan.update(seeds=[42], deferred_seeds=[43, 44], max_gpu_workers=4,
                training_jobs=10, expected_final_models=37,
                rollout_cases=37*10030,expected_prediction_inputs=1584830,
                execution_code=native_identity(native_config('M1', 'engineering'))['code'],
                scope='Native LaWAM post-SFT: 25000 updates per client, private VLM/action, '
                      'native three-loss training; engineering gate before formal training')
    return plan


def prepare():
    plan = make_native_plan()
    if PLAN.exists() and load(PLAN) != plan:
        raise ValueError('Frozen native plan changed')
    atomic_json(PLAN, plan)
    WorkQueue(Path(plan['root'])/'scheduler', plan['tasks'])
    print(json.dumps({'plan': str(PLAN), 'tasks': len(plan['tasks']),
                      'training_jobs': plan['training_jobs']}, indent=2))


def validated_plan():
    plan = load(PLAN)
    if plan['seeds'] != [42] or plan['code'] != code_identity():
        raise ValueError('Native plan or shared scientific code changed')
    if plan['execution_code'] != native_identity(native_config('M1', 'engineering'))['code']:
        raise ValueError('Native execution code changed')
    return plan


def _bind_existing_controller():
    original = base.ensure_job

    def native_job(state, key, args, path, marker):
        replaced = [next((arg.replace(old, new) for old, new in SCRIPTS.items()
                          if old in arg), arg) for arg in args]
        return original(state, key, replaced, path, marker.replace('fwdet:', 'fwnat:'))

    base.ensure_job = native_job
    base.detached_identity = native_identity
    base.resolved_config = lambda method, seed, mode: native_config(method, mode, seed=seed)
    base.DetachedEngine = NativeDetachedEngine
    base.compact_completed_run = compact_native_run
    base.check_gate = native_gate
    base.validated_plan = validated_plan
    base.PLAN = PLAN
    base.OUT = OUT
    class NativeDiskUsage:
        @staticmethod
        def disk_usage(_path):
            return shutil.disk_usage(NATIVE_STORAGE_ROOT)
    base.shutil = NativeDiskUsage


def capacity_requirement(largest_resume, largest_final, final_models=37):
    if min(largest_resume, largest_final, final_models) <= 0:
        raise ValueError('Invalid native disk projection inputs')
    return 80*1024**3 + 16*largest_resume + final_models*largest_final


def storage_admission(free_bytes,largest_resume,largest_final,previously_admitted=False):
    required=80*1024**3 if previously_admitted else capacity_requirement(largest_resume,largest_final)
    passed=free_bytes>=required
    return dict(passed=passed,state='ready' if passed else 'waiting_for_storage',
                free_bytes=free_bytes,required_free_bytes=required,
                missing_bytes=max(0,required-free_bytes),
                largest_resume_checkpoint_bytes=largest_resume,
                largest_final_checkpoint_bytes=largest_final,
                active_checkpoint_multiplier=16,final_models=37,
                previously_admitted=previously_admitted)


def startup_storage_status():
    # Conservative fallback until actual native acceptance sizes are known.
    resume,final=14*1024**3,5*1024**3
    evidence=[]
    for path in NATIVE_STORAGE_ROOT.glob('engineering*/*/*/retention.json'):
        row=load(path)
        if row.get('state')!='completed':continue
        resume=max(resume,int(row.get('largest_resume_checkpoint_bytes',0)))
        final=max(final,int(row.get('largest_final_checkpoint_bytes',0)))
        evidence.append(str(path))
    admitted_path=OUT/'storage_plan_admission.json'
    plan_sha=file_hash(PLAN) if PLAN.exists() else None
    admitted=load(admitted_path) if admitted_path.exists() else {}
    # This is a capacity estimate, not a filesystem reservation. On restart,
    # preserve the safety floor without counting already-written finals twice.
    previous=bool(plan_sha and admitted.get('passed') is True and admitted.get('plan_sha256')==plan_sha)
    report=storage_admission(shutil.disk_usage(NATIVE_STORAGE_ROOT).free,resume,final,previous)
    report.update(storage_root=str(NATIVE_STORAGE_ROOT),size_receipts=evidence,
                  scope='capacity admission only; not engineering acceptance')
    atomic_json(OUT/'startup_storage.json',report)
    if report['passed'] and not previous and plan_sha:
        atomic_json(admitted_path,dict(report,plan_sha256=plan_sha))
    return report


def wait_for_storage():
    while True:
        report=startup_storage_status()
        if report['passed']:return
        atomic_json(OUT/'status.json',dict(state='waiting_for_storage',seed=42,
                    missing_gib=round(report['missing_bytes']/1024**3,1),
                    gpu_jobs_started=False,passed=[]))
        time.sleep(60)


def prune_engineering_weights(root, methods, summary):
    root = Path(root).resolve()
    if summary.get('passed') is not True or set(summary.get('methods_passed', [])) != set(methods):
        raise ValueError('Cannot remove incomplete engineering weights')
    for method in methods:
        if not (root/method/'final.json').exists():
            raise ValueError('Engineering final receipt missing: '+method)
    removed = 0
    for method in methods:
        for path in (root/method).rglob('*.pt'):
            if not path.resolve().is_relative_to(root):
                raise ValueError('Engineering weight path escapes run root')
            removed += path.stat().st_size
            path.unlink()
    marker = root/'weights_pruned_after_gate.json'
    previous = load(marker) if marker.exists() else {}
    value = dict(state='completed', methods=list(methods),
                 removed_bytes=previous.get('removed_bytes', 0)+removed,
                 purpose='engineering-only weights removed after ten-method acceptance; JSON receipts retained')
    atomic_json(marker, value)
    return value


def prune_verified_engineering_method(root, identity):
    """Keep proof and size receipts; drop weights after one method passes."""
    root = Path(root).resolve()
    proof = load(root/'verification.json')
    final = load(root/'final.json')
    retention = load(root/'retention.json')
    if (proof.get('passed') is not True or proof.get('identity') != identity
            or final.get('identity') != identity
            or retention.get('state') != 'completed'):
        raise ValueError('Cannot prune unverified engineering method')
    removed = 0
    for path in root.rglob('*.pt'):
        if not path.resolve().is_relative_to(root):
            raise ValueError('Engineering weight path escapes run root')
        removed += path.stat().st_size
        path.unlink()
    receipt = dict(state='completed', identity=identity,
                   removed_bytes=removed,
                   purpose='verified engineering weights; JSON proof and size receipts retained')
    atomic_json(root/'weights_pruned_after_method.json', receipt)
    return receipt


def audit_native_storage(engineering_root, summary):
    if summary.get('passed') is not True or set(summary.get('methods_passed', [])) != set(ORDER):
        raise ValueError('Disk audit requires complete native method acceptance')
    retention = [load(engineering_root/method/'retention.json') for method in ORDER]
    largest_resume = max(row['largest_resume_checkpoint_bytes'] for row in retention)
    largest_final = max(row['largest_final_checkpoint_bytes'] for row in retention)
    prune_engineering_weights(engineering_root, ORDER, summary)
    free = shutil.disk_usage(NATIVE_STORAGE_ROOT).free
    previous_path=OUT/'disk_peak_audit.json'
    previous=load(previous_path) if previous_path.exists() else {}
    same_plan=previous.get('passed') is True and previous.get('plan_sha256')==file_hash(PLAN)
    required = 80*1024**3 if same_plan else capacity_requirement(largest_resume, largest_final)
    report = dict(passed=free >= required, free_bytes=free,
                  required_free_bytes=required,
                  largest_resume_checkpoint_bytes=largest_resume,
                  largest_final_checkpoint_bytes=largest_final,
                  final_models=37, active_checkpoint_multiplier=16,
                  reserve_bytes=80*1024**3,
                  storage_root=str(NATIVE_STORAGE_ROOT),previously_admitted=same_plan,
                  plan_sha256=file_hash(PLAN))
    atomic_json(OUT/'disk_peak_audit.json', report)
    if not report['passed']:
        raise RuntimeError('Native storage capacity audit failed; formal training not admitted')
    return report


def native_local_dependency(summary_path=None):
    summary_path = summary_path or (ROOT/'reports/native_local_seed42_v3/engineering/summary.json')
    rows = base.command(['squeue', '-u', str(os.getuid()), '-h', '-o', '%i|%j'])
    jobs = [row.split('|', 1)[0] for row in rows.splitlines()
            if row.split('|', 1)[-1] in
            ('fwfull-native-summary', 'fwfull-native-local-retry')]
    if len(jobs) > 1:
        raise ValueError('Multiple native local summary jobs')
    if jobs:
        return jobs[0]
    if not Path(summary_path).exists() or load(summary_path).get('passed') is not True:
        raise ValueError('Native local four-client acceptance must finish first')
    return None


def launch():
    plan = validated_plan()
    local_job = native_local_dependency()
    path = ROOT/'reports/scheduling/seed42_native_v6_jobs.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state = load(path) if path.exists() else dict(state='submitting',
                   plan_sha256=file_hash(PLAN), jobs={}, max_total_gpus=4, seeds=[42])
        if state['plan_sha256'] != file_hash(PLAN):
            raise ValueError('Native submission plan differs')
        tag = 'fwnat:' + state['plan_sha256'][:12]
        controller_args = ([f'--dependency=afterok:{local_job}'] if local_job else [])
        controller_args.append(str(ROOT/'scripts/native_federated_pipeline.slurm'))
        controller = base.ensure_job(state, 'controller',
             controller_args, path, tag+':controller')
        evaluation = base.ensure_job(state, 'evaluation',
             ['--dependency=afterok:'+controller,
              str(ROOT/'scripts/native_federated_eval.slurm')], path, tag+':evaluation')
        base.ensure_job(state, 'report',
             ['--dependency=afterany:'+evaluation,
              str(ROOT/'scripts/native_finalize.slurm'), str(PLAN)], path, tag+':report')
        state['state'] = 'submitted'
        atomic_json(path, state)
        print(json.dumps(state, indent=2))


def pipeline():
    if not os.environ.get('SLURM_JOB_ID'):
        raise ValueError('CPU Slurm controller required')
    _bind_existing_controller()
    plan = validated_plan()
    root = Path(plan['root'])
    root.mkdir(parents=True, exist_ok=True)
    with (root/'controller.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        wait_for_storage()
        validated_plan()
        ident = native_identity(native_config('M1', 'engineering'))
        tag = digest(ident)[:16]
        engineering_root = RUNS/tag
        summary_path = OUT/'summary.json'
        if summary_path.exists():
            summary = load(summary_path)
            native_gate(native_config('M1', 'engineering'), summary)
        else:
            passed = []
            for method in ORDER:
                atomic_json(OUT/'status.json', dict(state='running', method=method,
                                                    passed=passed, seed=42))
                cfg = native_config(method, 'engineering')
                method_root = engineering_root/method
                retained = method_root/'retention.json'
                if not (retained.exists() and load(retained).get('state') == 'completed'):
                    base.run_method(cfg, method_root)
                prune_verified_engineering_method(method_root, native_identity(cfg))
                passed.append(method)
            keys = ('code', 'data_identity', 'checkpoint_sha256',
                    'normalization_sha256', 'protocol_sha256', 'model_config_sha256',
                    'native_protocol_sha256', 'execution')
            summary = {key: ident[key] for key in keys}
            summary.update(passed=True, seed=42, methods_passed=passed,
                           mode='real_detached_client_engineering',
                           scope='new native three-loss GPU engineering only',
                           runs_root=str(engineering_root))
            atomic_json(summary_path, summary)
            atomic_json(OUT/'status.json', dict(state='completed', methods_passed=passed))
        audit_native_storage(engineering_root, summary)
        queue = WorkQueue(root/'scheduler', plan['tasks'])
        for method in ORDER:
            validated_plan()
            cfg = native_config(method, 'formal')
            native_gate(cfg, summary)
            task = claim_filtered(queue, 'controller', ['detached_train'], method)
            if task is None:
                continue
            try:
                base.run_method(cfg, root/method/'seed42')
            except Exception:
                queue.finish('controller', task['id'], 1)
                raise
            queue.finish('controller', task['id'], 0)
        atomic_json(root/'controller_status.json', dict(state='completed', seed=42))


def evaluate(worker):
    _bind_existing_controller()
    base.evaluate(worker)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'launch', 'pipeline', 'evaluate','preflight'])
    parser.add_argument('--worker', type=int, choices=[0, 1])
    args = parser.parse_args()
    if args.command == 'prepare':
        prepare()
    elif args.command == 'launch':
        launch()
    elif args.command == 'pipeline':
        try:
            pipeline()
        except Exception as error:
            atomic_json(OUT/'pipeline_error.json', dict(state='failed', error=repr(error)))
            raise
    elif args.command=='preflight':
        report=startup_storage_status()
        print(json.dumps({k:report[k] for k in ('state','free_bytes','required_free_bytes','missing_bytes','storage_root')},indent=2))
    else:
        evaluate(args.worker)


if __name__ == '__main__':
    main()
