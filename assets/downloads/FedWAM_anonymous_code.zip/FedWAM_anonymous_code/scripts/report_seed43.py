"""CPU-only full-PLUS and held-out prediction report for the seed43 study."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from fedwam.io import ROOT, load, save
from fedwam.federated_reporting import (
    CLIENTS, attach_base_tasks, build_report, paired_comparison,
    prediction_items, prediction_summary, verify_manifest,
)
from report_federated import read_run

METHODS = tuple(f'M{i}' for i in range(1, 10)) + ('Local-adapter',)
SEEDS = [43]
LIMITATION = ('One training seed (43) only; between-seed variability cannot be estimated. '
              'Task bootstrap intervals are conditional on seed43 and do not establish seed robustness.')


def prediction_expectations():
    """Count the complete accepted held-out universe even before evaluation starts."""
    from fedwam.official_dataset import OfficialDataset
    counts = {}
    for client in CLIENTS:
        data = OfficialDataset(ROOT, client, 'prediction_test', 43, max_cached_episodes=1)
        counts[client] = sum(1 for _ in prediction_items(data.rows, 'all-chunks'))
    return counts


def complete_prediction_scope(summary, clients, expected):
    predictions = summary.setdefault('prediction_test', {})
    for client in clients:
        key = 'all-chunks/' + client
        count = sum(expected.values()) if client == 'pooled' else expected[client]
        if key not in predictions:
            predictions[key] = prediction_summary([], count)
        elif predictions[key]['expected'] != count:
            raise ValueError('Prediction denominator differs from accepted scope')
    summary['prediction_complete'] = all(
        predictions['all-chunks/' + client]['complete'] for client in clients)
    summary['complete_with_prediction'] = summary['complete'] and summary['prediction_complete']


def create_report(runs, manifest, prediction_expected, *, bootstrap_replicates=2000):
    if bootstrap_replicates < 1:
        raise ValueError('Positive bootstrap replicate count required')
    if set(prediction_expected) != set(CLIENTS) or any(
            type(v) is not int or v < 1 for v in prediction_expected.values()):
        raise ValueError('Expected nonempty accepted prediction counts for all four clients')
    per_run, records_by_method, identities, methods = [], {}, {}, {}
    for run in runs:
        # Reject other seeds and engineering runs before potentially costly reads.
        header = load(Path(run) / 'final.json')
        if header['seed'] != 43 or header['identity'].get('mode') != 'formal':
            raise ValueError('Only formal seed43 final runs belong in this report')
        method = header['method']
        if method not in METHODS:
            raise ValueError(f'Unexpected study method: {method}')
        if method in records_by_method:
            raise ValueError(f'Duplicate method/seed run: {method}/43')
        # Existing reader checks final checkpoint bytes and every recorded result identity.
        final, records, summary = read_run(run, manifest)
        for client in summary['clients']:
            if (Path(run) / 'evaluation/prediction_test').exists():
                has_predictions = any((Path(run) / 'evaluation/prediction_test').glob(f'*/{client}/cases/*.json'))
                if has_predictions and not (Path(run) / 'evaluation/identities' / f'{client}.json').exists():
                    raise ValueError('Missing prediction evaluation identity')
        complete_prediction_scope(summary, summary['clients'], prediction_expected)
        summary['single_seed_limitation'] = LIMITATION
        per_run.append(summary)
        records_by_method[method], identities[method] = records, final['identity']
        methods[method] = dict(summary)

    for method in METHODS:
        clients = ['pooled'] if method == 'M9' else list(CLIENTS)
        if method not in methods:
            methods[method] = build_report(manifest, [], clients, seeds=SEEDS)
            complete_prediction_scope(methods[method], clients, prediction_expected)
            methods[method]['mode'] = None
        methods[method].update(required_seeds=SEEDS, available_seeds=SEEDS if method in identities else [],
                               missing_seeds=[] if method in identities else SEEDS,
                               single_seed_limitation=LIMITATION)

    contrasts = {}
    for comparator in ('M1', 'M2', 'M7', 'M8'):
        label = 'M6-' + comparator
        if 'M6' not in identities or comparator not in identities:
            contrasts[label] = dict(available=False, complete=False, reason='required method run missing')
            continue
        left_identity, right_identity = identities['M6'], identities[comparator]
        for key in ('data_identity', 'data_acceptance_sha256', 'checkpoint_sha256',
                    'normalization_sha256', 'protocol_sha256', 'model_config_sha256', 'code', 'mode'):
            if left_identity.get(key) != right_identity.get(key):
                raise ValueError(f'Contrast {label} has incompatible {key}')
        contrast = dict(available=False, complete=False, scopes={}, single_seed_limitation=LIMITATION,
                        budget_match_requires_review=
                        {k: v for k, v in left_identity['config'].items() if k not in ('method', 'seed')} !=
                        {k: v for k, v in right_identity['config'].items() if k not in ('method', 'seed')})
        for scope in ('all', 'E_seen', 'E_confirm'):
            ids = {row['variant_id'] for row in manifest['cases']} if scope == 'all' else set(manifest[scope])
            left = [r for r in records_by_method['M6'] if r['case']['variant_id'] in ids]
            right = [r for r in records_by_method[comparator] if r['case']['variant_id'] in ids]
            comparison = paired_comparison(left, right, replicates=bootstrap_replicates)
            expected = len(ids) * len(CLIENTS)
            comparison.update(expected_pairs=expected, missing_pairs=expected - comparison['paired_cases'],
                              left_missing=expected - len(left), right_missing=expected - len(right),
                              available=comparison['paired_cases'] > 0,
                              complete=comparison['paired_cases'] == expected and all(
                                  r.get('completed') is True and not r.get('error') for r in left + right))
            comparison['single_seed_limitation'] = LIMITATION
            contrast['scopes'][scope] = comparison
        contrast['available'] = contrast['scopes']['all']['available']
        contrast['complete'] = contrast['scopes']['all']['complete']
        contrasts[label] = contrast

    return dict(schema='fedwam.seed43-report.v1', manifest_sha256=manifest['sha256'],
                required_methods=list(METHODS), required_seeds=SEEDS,
                missing_methods=[m for m in METHODS if m not in identities],
                runs=per_run, methods=methods, primary_contrasts=contrasts,
                complete_requested_runs=bool(per_run) and all(r['complete_with_prediction'] for r in per_run),
                complete_rollout_study=all(r['complete'] for r in methods.values()),
                complete_prediction_study=all(r['prediction_complete'] for r in methods.values()),
                complete_study=all(r['complete_with_prediction'] for r in methods.values()),
                single_seed_limitation=LIMITATION,
                missing_policy='Missing rollouts remain in the full denominator; incomplete rates are provisional lower bounds. Missing/error predictions have undefined MSE, never zero.',
                multiple_comparisons='Four prespecified primary contrasts; intervals are marginal, not familywise-adjusted; no secondary significance claims.',
                selection='E_seen and E_confirm separate; no checkpoint/model selection from E_confirm.',
                scope='Seed43 only, M1-M9 and Local-adapter; four clients by seven full-PLUS targets except pooled M9; all accepted held-out prediction chunks.')


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--runs', nargs='*', type=Path, default=[])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bootstrap-replicates', type=int, default=2000)
    args = parser.parse_args(argv)
    manifest = load(ROOT / 'manifests/plus_full.json')
    verify_manifest(manifest)
    manifest['cases'] = attach_base_tasks(manifest['cases'], load(
        ROOT / 'manifests/official_four_clients/lighting/train.json')['rows'])
    result = create_report(args.runs, manifest, prediction_expectations(),
                           bootstrap_replicates=args.bootstrap_replicates)
    save(args.output.resolve(), result)
    print(f'Wrote {args.output}; complete seed43 study: {result["complete_study"]}')


if __name__ == '__main__':
    main()
