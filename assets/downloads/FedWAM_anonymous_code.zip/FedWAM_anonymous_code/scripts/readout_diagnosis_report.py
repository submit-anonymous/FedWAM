"""Bounded summary of completed diagnostic controls; never opens formal gates."""
import argparse
import json
from pathlib import Path
from imagewam_model_acceptance import write
ROOT=Path(__file__).resolve().parents[1]
DOMAINS=('lighting','camera_pose','sensor_noise','background')


def main(base):
    results=[]
    for domain in DOMAINS:
        folder=base/domain;path=folder/'result.json'
        if not path.exists():
            state=json.loads((folder/'status.json').read_text()) if (folder/'status.json').exists() else {}
            results.append(dict(domain=domain,complete=False,state=state));continue
        r=json.loads(path.read_text());arms=r['matched_arms']
        row=dict(domain=domain,complete=True,reference_parity=r['parity_max_abs'])
        for split in ('train','development'):
            current=arms['current']['summary'][split];future=arms['future']['summary'][split]
            original=r['original']['spatial']['summary'][split]
            row[split]=dict(copy_mse=future['copy_mse'],current_reconstruction_mse=current['current_mse'],
                future_prediction_mse=future['mse'],original_future_mse=original['mse'],
                current_reconstruction_beats_copy=current['current_mse']<future['copy_mse'],
                future_beats_copy=future['mse']<future['copy_mse'],
                high_feature_change=dict(prediction=future['high_feature_change_mse'],copy=future['high_feature_change_copy_mse']),
                low_feature_change=dict(prediction=future['low_feature_change_mse'],copy=future['low_feature_change_copy_mse']),
                high_pixel_change=dict(prediction=future['high_pixel_change_mse'],copy=future['high_pixel_change_copy_mse']),
                low_pixel_change=dict(prediction=future['low_pixel_change_mse'],copy=future['low_pixel_change_copy_mse']))
        results.append(row)
    value=dict(complete=all(r['complete'] for r in results),clients=results,formal_admission=False,
        interpretation_limits=['H0 reconstruction is a same-budget diagnostic, not a proven information-theoretic bound',
            'Pixel/feature change masks are evaluation proxies; no claim of ground-truth object segmentation',
            'No final prediction-test or control-success evaluation was performed'])
    write(ROOT/'reports/heterogeneous/readout_diagnosis_summary.json',value)
    for row in results:
        if row['complete']:
            x=row['development'];print(row['domain'],'H0 reconstruction',round(x['current_reconstruction_mse'],6),
                'H8 future',round(x['future_prediction_mse'],6),'copy',round(x['copy_mse'],6))
        else:print(row['domain'],row['state'].get('state','not_started'),row['state'].get('phase',''),row['state'].get('step',row['state'].get('extracted','')))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path('/workspace/reviewer/fedwam-readout-diagnosis-v3'))
    main(p.parse_args().root)
