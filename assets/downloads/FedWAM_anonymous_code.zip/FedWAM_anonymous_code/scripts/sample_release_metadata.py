"""Read just the first record of alternate official RLDS releases, not full archives."""
import sys,zipfile,struct
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save
from fedwam.rlds import feature_payloads,feature_values
from inspect_release_archives import Remote
base=ROOT/'reports/data/provenance_research'
for filename in ['libero_plus_camparam_rlds_api.json','libero_plus_data_4suite_api.json']:
    api=load(base/filename)
    for r in api['siblings']:
        name=r['rfilename']
        if name!='libero_plus_camparam_rlds.zip' and not name.startswith('rlds/'):continue
        result={'repository':api['id'],'revision':api['sha'],'archive':name,'scope':'one record only, not full release category census'}
        try:
            with zipfile.ZipFile(Remote(f'https://huggingface.co/datasets/{api["id"]}/resolve/{api["sha"]}/{name}')) as z:
                shard=sorted(n for n in z.namelist() if '.tfrecord-' in n)[0]
                with z.open(shard) as f:
                    header=f.read(12);size=struct.unpack('<Q',header[:8])[0]
                    if size>32*1024**2:raise ValueError('Refusing oversized sample record')
                    record=f.read(size);features=feature_payloads(record)
                    result.update(shard=shard,record_bytes=size,feature_keys=sorted(features),
                        source_paths=[v.decode() for v in feature_values(features['episode_metadata/file_path'],1)],
                        instruction=feature_values(features['steps/language_instruction'],1)[0].decode())
        except Exception as e:result['error']=repr(e)
        save(base/'archive_samples'/f'{name.replace("/","__")}.json',result)
        print(name,result.get('source_paths'),result.get('error'),flush=True)
