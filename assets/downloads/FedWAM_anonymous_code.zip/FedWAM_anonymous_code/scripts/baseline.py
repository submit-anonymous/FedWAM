"""Full M0 benchmark evaluation, independently resumable per case.

Results are baseline measurements; do not tune methods on E_confirm outcomes.
"""
import argparse,sys,traceback,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,save,load,status,digest,file_hash
from fedwam.evaluation import partition,reusable
import acceptance

def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,required=True);p.add_argument('--count',type=int,default=16);args=p.parse_args()
    base=ROOT/'runs/M0_plus_full';out=base/'workers'/f'{args.index:03d}';acceptance.OUT=out
    approved=load(ROOT/'reports/acceptance/summary.json')
    if approved.get('passed')!=28 or approved.get('failed')!=0:raise RuntimeError('All 28 engineering cells must pass first')
    manifest=load(ROOT/'manifests/plus_full.json')
    sources=[Path(__file__),ROOT/'scripts/acceptance.py',ROOT/'src/fedwam/evaluation.py']
    identity={'method':'M0','case_manifest':manifest['sha256'],
        'checkpoint':file_hash(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'),
        'code':{str(x.relative_to(ROOT)):file_hash(x) for x in sources},
        'normalization':file_hash(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json'),
        'suite_horizons':'250/300/320/550','initialization':'published index 0','variant_noise_seeds':'manifest fixed',
        'policy':'official SFT; no adaptation; eight 20Hz actions per chunk',
        'use_for_model_selection':False}
    if (out/'identity.json').exists() and load(out/'identity.json')!=identity:raise RuntimeError('Evaluation identity changed')
    save(out/'identity.json',identity)
    policy,client,transport=acceptance.model();rows=partition(manifest['cases'],args.index,args.count)
    done=0;errors=0;seen_cells=set();consecutive_errors=0
    for row in rows:
        cell=base/'cases'/row['variant_id'].replace(':','_');key=dict(identity,case=row)
        path=cell/'result.json'
        if path.exists() and reusable(load(path),key):done+=1;continue
        tag=row['suite']+'/'+row['category']
        current=dict(row,scope='full fixed-model baseline; no training or selection use',record_video=tag not in seen_cells)
        seen_cells.add(tag)
        status(out,state='running',phase='full_baseline_rollouts',done=done,assigned=len(rows),errors=errors,current=row['variant_id'])
        try:
            result=acceptance.rollout(current,client,transport,cell,save_result=False)
            result.update(identity=key,completed=True,error=None);consecutive_errors=0;done+=1
        except Exception as e:
            result={'identity':key,'completed':False,'success':False,'error':repr(e)};errors+=1;consecutive_errors+=1;traceback.print_exc()
        save(path,result)
        if consecutive_errors>=3:raise RuntimeError('Three consecutive execution errors; stopping this shard for diagnosis')
    status(out,state='completed' if not errors else 'failed',phase='full_baseline_rollouts',done=done,assigned=len(rows),errors=errors)
    if errors:raise RuntimeError(f'{errors} cases have execution errors, retained in denominator')
if __name__=='__main__':main()
