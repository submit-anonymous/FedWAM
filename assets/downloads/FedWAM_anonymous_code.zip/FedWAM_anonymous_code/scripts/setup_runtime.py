"""Install native dependencies into this fresh project using existing package archives."""
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import sys

ROOT=Path(__file__).resolve().parents[1]
if Path(sys.prefix).resolve()!=(ROOT/'.venv').resolve():raise RuntimeError('Fresh project environment required')
spec=importlib.util.spec_from_file_location('native_installer',ROOT/'vendor/native_runtime/install.py')
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
native.ROOT=ROOT;native.ALLOWED=ROOT
archive=ROOT/'downloads/native_runtime_v6/micromamba-2.9.0-0.tar.bz2'
archive.parent.mkdir(parents=True,exist_ok=True)
source=Path('/workspace/reference_assets/downloads/native_runtime_v6/micromamba-2.9.0-0.tar.bz2')
if not archive.exists():shutil.copyfile(source,archive)
env=native.environment()
# Reuse only downloaded package archives; install a new native prefix.
env['CONDA_PKGS_DIRS']='/workspace/reference_assets/cache/imagemagick_runtime_v6/pkgs'
prefix=native.install_runtime(env)
env=native.native_environment(env,prefix)
# LaWAM's imports may load an older JPEG SONAME before ImageMagick/libtiff.
env['LD_PRELOAD']=str(prefix/'lib/libjpeg.so.8')+' '+env['LD_PRELOAD']
snippet=ROOT/'runtime/native.env'
keys=('MAGICK_HOME','MAGICK_TMPDIR','LD_PRELOAD','MPLCONFIGDIR','NUMBA_CACHE_DIR','TMPDIR','XDG_CACHE_HOME')
snippet.write_text(''.join('export '+key+'='+shlex.quote(env[key])+'\n' for key in keys))
benchmark=ROOT/'third_party/LIBERO-plus/libero/libero'
assets=benchmark/'assets'
if not assets.exists():assets.symlink_to(ROOT/'assets/libero_plus_assets',target_is_directory=True)
config=ROOT/'runtime/libero_config';config.mkdir(parents=True,exist_ok=True)
(config/'config.yaml').write_text(json.dumps({'benchmark_root':str(benchmark),
    'bddl_files':str(benchmark/'bddl_files'),'init_states':str(benchmark/'init_files'),
    'assets':str(assets),'datasets':str(ROOT/'data')},indent=2))
from importlib.metadata import version
(ROOT/'reports/environment/ready.json').write_text(json.dumps({'python':sys.version,'prefix':sys.prefix,
    'slurm_job':os.environ.get('SLURM_JOB_ID'),'native_runtime':str(prefix),
    'versions':{k:version(k) for k in ('torch','torchvision','transformers','numpy','mujoco','robosuite','Wand','pytorch3d')}},indent=2))
print('Fresh Python and native runtime installed:',ROOT)
