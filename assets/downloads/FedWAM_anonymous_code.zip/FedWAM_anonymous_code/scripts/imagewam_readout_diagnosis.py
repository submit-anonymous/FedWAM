"""Matched current-reconstruction/future probes on existing private train/dev data."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'third_party/ImageWAM')]
from imagewam_model_acceptance import write


def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def run(args):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    import numpy as np
    import torch
    from torch.nn import functional as F
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.adapters import ImageWAMAdapter
    from fedwam.heterogeneous.imagewam import prefix_cache,control_features_from_cache
    from fedwam.heterogeneous.reference import ReferenceEncoder,REFERENCE_ID
    from fedwam.heterogeneous.interface import FutureReadout
    from fedwam.heterogeneous.spatial_readout import SpatialFutureReadout
    from fedwam.heterogeneous.packets import balanced_weights
    from fedwam.heterogeneous.readout_diagnostics import error_row,summarize,verified_readout,DeterministicSpatialReadout
    torch.set_num_threads(4);torch.manual_seed(42)
    torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True;torch.backends.cuda.matmul.allow_tf32=False
    # Preserve the accepted reference's FP32 tensor / TF32-convolution policy.
    # Probe10471: disabling convolution TF32 changes DINO targets by .0226;
    # enabling it matches the accepted reference within1.20e-5.
    torch.backends.cudnn.allow_tf32=True
    output=args.output;output.mkdir(parents=True,exist_ok=True)
    originals={kind:ROOT/f'reports/heterogeneous/adapted-readout-{kind}-{args.domain}-10456' for kind in ('learned_query','spatial')}
    receipts={k:json.loads((p/'result.json').read_text()) for k,p in originals.items()}
    for kind,path in originals.items():verified_readout(path/'readout.pt',receipts[kind])
    r=receipts['spatial']
    if any(v['samples']!=r['samples'] or v['native_adaptation']!=r['native_adaptation'] for v in receipts.values()):
        raise ValueError('Original heads lack matched inputs/native initialization')
    if r['reference_id']!=REFERENCE_ID or len(r['samples']['train'])!=4096 or len(r['samples']['development'])!=256:
        raise ValueError('Original diagnostic reference/sample budget mismatch')
    identity=dict(seed=42,domain=args.domain,reference=REFERENCE_ID,precision=dict(deterministic=True,matmul_tf32=False,convolution_tf32=True),original_results={k:digest(p/'result.json') for k,p in originals.items()},
        code={p:digest(ROOT/p) for p in ('scripts/imagewam_readout_diagnosis.py','src/fedwam/heterogeneous/readout_diagnostics.py',
            'src/fedwam/heterogeneous/imagewam.py','src/fedwam/heterogeneous/adapters.py','src/fedwam/heterogeneous/reference.py',
            'src/fedwam/heterogeneous/data.py','src/fedwam/heterogeneous/spatial_readout.py','src/fedwam/heterogeneous/interface.py')})
    source_payload=None
    if args.source_cache is not None:
        source_identity=json.loads((args.source_cache.parent/'identity.json').read_text())
        if any(source_identity[k]!=identity[k] for k in ('seed','domain','reference','precision','original_results')):
            raise ValueError('Cached extraction inputs differ from current diagnosis')
        archive=ROOT/'reports/heterogeneous/diagnosis10472-code'
        for name,expected in source_identity['code'].items():
            if digest(archive/name)!=expected:raise ValueError('Original extraction code archive mismatch')
        identity['source_cache']=dict(path=str(args.source_cache.resolve()),sha256=digest(args.source_cache),identity=source_identity)
        source_payload=torch.load(args.source_cache,map_location='cpu',weights_only=True,mmap=True)
        if source_payload['identity']!=source_identity:raise ValueError('Feature cache metadata mismatch')
        for split,rows in source_payload['data'].items():
            metadata=[{k:x[k] for k in ('task','source_group','record_id','t')} for x in rows]
            if metadata!=r['samples'][split]:raise ValueError('Cached sample replay mismatch')
    identity_path=output/'identity.json'
    if identity_path.exists() and json.loads(identity_path.read_text())!=identity:raise ValueError('Diagnostic identity changed')
    write(identity_path,identity)
    if (output/'result.json').exists():print('Diagnosis already completed');return
    status=dict(state='running',phase='extract',domain=args.domain,seed=42,scope='train/development diagnostics; not formal admission')
    write(output/'status.json',status)
    cache_path=output/'features.pt'
    if source_payload is not None:
        data=source_payload['data'];diff=source_payload['parity_max_abs']
    elif not cache_path.exists():
        if shutil.disk_usage(output).free<64*1024**3:raise ValueError('Insufficient diagnostic cache reserve')
        adapter=ImageWAMAdapter(ROOT,originals['spatial']/'readout.pt')
        encoder=ReferenceEncoder(ROOT/'assets/dinov3-vitb16-pretrain-lvd1689m')
        from imagewam_model_acceptance import load_initial_states
        parity=load_initial_states(lambda:torch.load(ROOT/'reports/heterogeneous/lawam-common-10414/cross_environment.pt',map_location='cpu'))
        diff=float((encoder([np.asarray(parity['primary']),np.asarray(parity['future'])]).cpu()-parity['reference']).abs().max())
        if diff>1e-3:raise ValueError(f'Diagnostic common-reference parity failed: {diff}')
        data={}
        for split,count in (('train',4096),('development',256)):
            dataset=HeterogeneousDataset(ROOT,'B',args.domain,split);rows=[];seen=set();draw=0
            while len(rows)<count:
                sample=dataset.sample(draw);draw+=1;key=(sample['record_id'],sample['t'])
                if draw>count*100:raise ValueError('Insufficient unique matched chunks')
                if key in seen:continue
                seen.add(key);expected=r['samples'][split][len(rows)]
                if any(sample[a]!=expected[b] for a,b in (('record_id','record_id'),('t','t'),('source_group','source_group'),('lang','task'))):
                    raise ValueError('Sample replay differs from original experiment')
                native=adapter.prepare(sample)
                with torch.no_grad():
                    h=control_features_from_cache(prefix_cache(adapter.model,native['current_frame'],native['text_hidden_states'],native['text_attention_mask'],native['proprio']))
                    z0,z1=encoder([sample['primary'],sample['future']])
                    pixels=torch.from_numpy(np.abs(sample['future'].astype(np.float32)-sample['primary'].astype(np.float32)).mean(-1)/255.)
                    change=F.adaptive_avg_pool2d(pixels[None,None],(7,7)).flatten()
                rows.append(dict(h=h[0].cpu().half(),current=z0.cpu(),future=z1.cpu(),pixel_change=change,**expected))
                if len(rows)%64==0 or len(rows)==count:
                    status.update(phase='extract_'+split,extracted=len(rows));write(output/'status.json',status)
            data[split]=rows
        if {x['source_group'] for x in data['train']} & {x['source_group'] for x in data['development']}:
            raise ValueError('Diagnostic source leakage')
        # Free WAM before serializing the local, never-uploaded diagnostic cache.
        del h,native,encoder,adapter;gc.collect();torch.cuda.empty_cache()
        tmp=cache_path.with_suffix('.tmp');torch.save(dict(identity=identity,data=data,parity_max_abs=diff),tmp);tmp.replace(cache_path)
    else:
        saved=torch.load(cache_path,map_location='cpu',weights_only=True,mmap=True)
        if saved['identity']!=identity:raise ValueError('Diagnostic feature cache changed identity')
        data=saved['data'];diff=saved['parity_max_abs']
    # Fixed task/source-balanced train diagnostic sample; independent of head/target.
    weights=balanced_weights([dict(client=args.domain,task=x['task'],source_group=x['source_group']) for x in data['train']])
    idx=torch.multinomial(weights,256,replacement=False,generator=torch.Generator().manual_seed(4201)).tolist()
    evaluation=dict(train=[data['train'][i] for i in idx],development=data['development'])
    def evaluate(head):
        head.eval();summary={};details={}
        with torch.no_grad():
            for split,records in evaluation.items():
                metrics=[]
                for x in records:
                    with torch.autocast('cuda',dtype=torch.bfloat16):pred=head(x['h'][None].cuda())[0].float().cpu()
                    metrics.append(dict(error_row(pred,x['current'],x['future'],x['pixel_change']),
                        **{k:x[k] for k in ('task','source_group','record_id','t')}))
                summary[split]=summarize(metrics);details[split]=metrics
        head.train();return dict(summary=summary,rows=details)
    original={}
    for kind in originals:
        cls=FutureReadout if kind=='learned_query' else SpatialFutureReadout
        head=cls(3072).cuda();payload=verified_readout(originals[kind]/'readout.pt',receipts[kind])
        head.load_state_dict(payload['head'],strict=True);del payload
        value=evaluate(head)
        old=receipts[kind]['curves'][-1]['mse'];observed=value['summary']['development']['mse']
        if abs(old-observed)>max(1e-5,old*.003):raise ValueError('Saved head fails original prediction replay')
        original[kind]=value;write(output/f'original-{kind}.json',value);del head
    arms={}
    for target in ('current','future'):
        arm_path=output/f'{target}-result.json'
        if arm_path.exists():arms[target]=json.loads(arm_path.read_text());continue
        torch.manual_seed(42);head=DeterministicSpatialReadout(3072).cuda()
        optimizer=torch.optim.AdamW(head.parameters(),lr=1e-4,weight_decay=.01)
        generator=torch.Generator().manual_seed(42);curves=[]
        status.update(phase='fit_'+target,step=0);write(output/'status.json',status)
        for step in range(1,4001):
            indices=torch.multinomial(weights,16,replacement=True,generator=generator).tolist()
            h=torch.stack([data['train'][i]['h'] for i in indices]).cuda()
            y=torch.stack([data['train'][i][target] for i in indices]).cuda()
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.bfloat16):pred=head(h)
            loss=(pred.float()-y).square().mean()
            if not torch.isfinite(loss):raise ValueError('Nonfinite diagnostic head loss')
            loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);optimizer.step()
            if step%1000==0:
                value=evaluate(head);curves.append(dict(step=step,batch_loss=float(loss),**value['summary']))
                status.update(step=step,latest=curves[-1]);write(output/'status.json',status)
        value=evaluate(head)
        arms[target]=dict(target=target,steps=4000,curves=curves,**value)
        torch.save(dict(identity=identity,target=target,head={k:v.cpu() for k,v in head.state_dict().items()}),output/f'{target}-head.pt')
        write(arm_path,arms[target]);del head,optimizer;gc.collect();torch.cuda.empty_cache()
    result=dict(completed=True,seed=42,domain=args.domain,identity=identity,original=original,matched_arms=arms,
        fixed_train_indices=idx,parity_max_abs=diff,formal_admission=False,
        note='Current and future arms share initialization/order/budget. High pixel change is a proxy, not object segmentation. No model/action update.')
    write(output/'result.json',result);status.update(state='completed',phase='diagnosis');write(output/'status.json',status)
    print(json.dumps({k:{s:v for s,v in a['summary'].items()} for k,a in arms.items()}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True,choices=['lighting','camera_pose','sensor_noise','background'])
    p.add_argument('--output',required=True,type=Path);p.add_argument('--source-cache',type=Path);args=p.parse_args()
    try:run(args)
    except Exception as exc:
        path=args.output/'status.json';state=json.loads(path.read_text()) if path.exists() else {}
        state.update(state='failed',error=repr(exc));write(path,state);traceback.print_exc();raise SystemExit(1)
