"""Full-parameter native local development adaptation on official private PLUS data."""
import argparse
import gc
import hashlib
import json
import os
import random
import shutil
import sys
import time
import traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'third_party/ImageWAM')]
from imagewam_model_acceptance import check_keys,write


def run(args):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    import numpy as np
    import torch
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    from types import SimpleNamespace
    from imagewam.trainer import Wan22Trainer
    from imagewam.datasets.lerobot.robot_video_dataset import DEFAULT_PROMPT
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.imagewam import make_training_sample
    from fedwam.heterogeneous.native_checkpoint import save_training,restore_training
    from fedwam.round_runtime import sha
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
    if args.batch_size!=32 or args.total_steps!=25000 or not 0<args.stop_at<=1000:
        raise ValueError('Development initial adaptation is restricted to effective batch32, <=1000/25000 updates')
    cfg=OmegaConf.load(ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    files=['scripts/imagewam_native_adaptation.py','src/fedwam/heterogeneous/imagewam.py',
           'src/fedwam/heterogeneous/native_checkpoint.py','src/fedwam/heterogeneous/data.py',
           'third_party/ImageWAM/src/imagewam/models/backbones/imagewam.py',
           'third_party/ImageWAM/src/imagewam/trainer.py','third_party/ImageWAM/configs/data/libero_omnigen2_pair.yaml',
           'manifests/heterogeneous_seed42_v1/acceptance.json','reports/imagewam_preparation/native_eval_config.yaml']
    write(output/'status.json',dict(state='running',phase='verify_assets',domain=args.domain,seed=42))
    assets=[Path(str(cfg.ckpt)),Path(str(cfg.EVALUATION.dataset_stats_path)),
            Path(str(cfg.model.ae_model_path)),Path(str(cfg.model.flux2_model_path))]
    assets+=sorted(p for p in Path(str(cfg.model.qwen3_model_spec)).glob('*') if p.is_file())
    identity=dict(seed=42,domain=args.domain,subset='B',horizon=8,effective_batch=32,total_steps=25000,
        lr=1e-4,weight_decay=.01,betas=[.9,.95],warmup=1250,
        precision='BF16 parameters/Adam moments, no DeepSpeed FP32 masters; single-GPU development recipe',
        deterministic=dict(algorithms=True,cudnn=True,benchmark=False,cublas_workspace=':4096:8',tf32=False),
        code={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in files},
        assets={str(p.resolve()):sha(p) for p in assets})
    identity_path=output/'identity.json'
    if identity_path.exists() and json.loads(identity_path.read_text())!=identity:raise ValueError('Adaptation identity changed')
    write(identity_path,identity)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cuda.matmul.allow_tf32=False
    if os.environ['CUBLAS_WORKSPACE_CONFIG']!=':4096:8':raise ValueError('Unexpected cuBLAS reproducibility setting')
    torch.set_num_threads(4);torch.manual_seed(42);np.random.seed(42);random.seed(42)
    state=dict(state='running',phase='load',domain=args.domain,seed=42,stop_at=args.stop_at,
               scope='native local development adaptation; not formal FedWAM method comparison')
    write(output/'status.json',state)
    if shutil.disk_usage(output).free<64*1024**3:raise ValueError('Insufficient atomic private checkpoint headroom')
    model=instantiate(cfg.model,model_dtype=torch.bfloat16,device='cuda')
    hook=model.mot.register_load_state_dict_post_hook(lambda m,k:check_keys(k.missing_keys,k.unexpected_keys))
    try:
        payload=model.load_checkpoint(str(cfg.ckpt))
        if 'proprio_encoder' not in payload:raise ValueError('Missing proprio initialization')
        del payload
    finally:hook.remove()
    model.eval().requires_grad_(False)
    processor=instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    dataset=HeterogeneousDataset(ROOT,'B',args.domain)
    augmentation=instantiate(OmegaConf.load(ROOT/'third_party/ImageWAM/configs/data/libero_omnigen2_pair.yaml').train.video_augmentation)
    text_cache={}
    with torch.no_grad():
        for task in sorted({row['task'] for row in dataset.rows}):
            hidden,mask=model._encode_flux2_prompts([DEFAULT_PROMPT.format(task=task)])
            text_cache[task]=(hidden.cpu(),mask.cpu())
    model.text_encoder.model.to('cpu');gc.collect();torch.cuda.empty_cache()
    Wan22Trainer._apply_dit_only_train_mode(model)
    params=[p for p in model.dit.parameters() if p.requires_grad]+[p for p in model.proprio_encoder.parameters() if p.requires_grad]
    if len({id(p) for p in params})!=len(params):raise ValueError('Duplicate trainable parameters')
    optimizer=torch.optim.AdamW(params,lr=1e-4,betas=(.9,.95),weight_decay=.01,foreach=False)
    scheduler=Wan22Trainer._build_scheduler(SimpleNamespace(optimizer=optimizer,learning_rate=1e-4),
                                            'cosine',25000,warmup_steps=1250)
    modules=dict(mot=model.mot,proprio_encoder=model.proprio_encoder)
    checkpoint=output/'latest.pt';start=0
    if checkpoint.exists():
        start=restore_training(checkpoint,modules,optimizer,scheduler,identity=identity)
    if start>args.stop_at:raise ValueError('Requested stop precedes saved updates')
    state.update(phase='joint_native_training',resumed_at=start,step=start,trainable_parameters=sum(p.numel() for p in params))
    write(output/'status.json',state)
    began=time.monotonic()
    for step in range(start,args.stop_at):
        optimizer.zero_grad(set_to_none=True);losses=[];exposures=[];step_start=time.monotonic()
        lr=optimizer.param_groups[0]['lr']
        for micro in range(32):
            sample=dataset.sample(step*32+micro)
            if sample['split']!='train':raise ValueError('Non-training data reached native optimizer')
            native=make_training_sample(sample,processor,augmentation)
            native['text_hidden_states'],native['text_attention_mask']=tuple(t.cuda() for t in text_cache[sample['lang']])
            with torch.autocast('cuda',dtype=torch.bfloat16):loss,parts=model.training_loss(native)
            if not torch.isfinite(loss):raise ValueError('Nonfinite native objective')
            (loss/32).backward()
            losses.append(dict(total=float(loss),**parts))
            exposures.append(dict(record_id=sample['record_id'],source_group=sample['source_group'],t=sample['t']))
            del native,loss
        norm=torch.nn.utils.clip_grad_norm_(params,1.,error_if_nonfinite=True)
        optimizer.step();scheduler.step();optimizer.zero_grad(set_to_none=True)
        torch.cuda.synchronize()
        row=dict(step=step+1,lr=lr,losses={k:sum(r[k] for r in losses)/32 for k in losses[0]},
                 gradient_norm=float(norm),seconds=time.monotonic()-step_start,exposures=exposures)
        # Semantic step filenames survive retries without duplicate accounting.
        write(output/'steps'/f'{step+1:06d}.json',row)
        state.update(step=step+1,latest={k:v for k,v in row.items() if k!='exposures'},
                     peak_gpu_bytes=torch.cuda.max_memory_allocated(),elapsed_this_attempt=time.monotonic()-began)
        write(output/'status.json',state)
        if (step+1)%100==0 or step+1==args.stop_at:
            if shutil.disk_usage(output).free<64*1024**3:raise ValueError('Cannot atomically checkpoint with reserve intact')
            state.update(phase='checkpoint');write(output/'status.json',state)
            save_training(checkpoint,modules,optimizer,scheduler,step=step+1,identity=identity)
            state.update(phase='joint_native_training',checkpoint_step=step+1);write(output/'status.json',state)
    state.update(state='completed',phase='native_initial_adaptation',scientific_method_comparison=False)
    write(output/'status.json',state)
    print(json.dumps({k:state[k] for k in ('state','domain','step','resumed_at')}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--domain',choices=['lighting','camera_pose','sensor_noise','background'],required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--stop-at',type=int,default=1000)
    p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--total-steps',type=int,default=25000)
    args=p.parse_args()
    try:run(args)
    except Exception as exc:
        path=args.output/'status.json';state=json.loads(path.read_text()) if path.exists() else {}
        state.update(state='failed',error=repr(exc)[:2000]);write(path,state);traceback.print_exc();raise SystemExit(1)
