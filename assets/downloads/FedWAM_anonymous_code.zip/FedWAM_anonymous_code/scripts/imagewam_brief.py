"""Short preparation status; never treats partial files as downloaded weights."""
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT/'reports/imagewam_preparation'


def read(path):
    try:return json.loads(path.read_text())
    except (OSError,ValueError):return {}


manifest=read(ROOT/'manifests/imagewam_assets.json')
receipt=read(REPORTS/'downloads.json')
verified=[r for r in receipt.get('files',[]) if r.get('state')=='verified']
print('公开资产校验:',len(verified),'/',len(manifest.get('files',[])),
      '| 已核验 GB:',round(sum(r['size'] for r in verified)/1e9,2),
      '/',round(manifest.get('total_bytes',0)/1e9,2))
env=read(REPORTS/'environment.json')
print('独立环境:', '通过' if env.get('passed') else ('导入检查失败' if env else '尚未验收'))
ae=read(REPORTS/'ae.json')
print('VAE:',ae.get('state','等待下载程序就绪'))
check=read(REPORTS/'cpu_validation.json')
print('数据/配置检查:', '通过' if check.get('passed') else ('失败' if check else '尚未执行'))
print('ActionDiT 初始化:', '文件已生成' if (ROOT/'assets/imagewam/action_dit_flux2_4b_libero_init.pt').is_file() else '尚未生成')
print('GPU 模型冒烟及 FedWAM H=8 适配: 尚未验收；正式训练未启动')
jobs=subprocess.run(['squeue','-u','anonymous','-h','-o','%i %j %T %r'],capture_output=True,text=True)
for line in jobs.stdout.splitlines():
    if 'fw-imagewam-' in line:print(line)
