"""Verify common DINO targets against the actual native LaWAM checkpoint."""
import json
from pathlib import Path
import sys
import os
import traceback

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from imagewam_model_acceptance import write


def run(output):
    import torch
    from unittest.mock import patch
    from starVLA.model.framework.base_framework import baseframework
    from fedwam.alias_guard import validate_loaded_keys
    from fedwam.heterogeneous.reference import ReferenceEncoder,REFERENCE_ID
    from fedwam.heterogeneous.interface import pool_spatial
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.training import encode,amp
    status=dict(state='running',phase='load',seed=42,scope='common reference/LaWAM graph acceptance')
    write(output/'status.json',status)
    torch.manual_seed(42)
    original=torch.nn.Module.load_state_dict
    captures=[]
    def checked(module,weights,*args,**kwargs):
        result=original(module,weights,*args,**kwargs)
        if any(k.startswith('policy_backend.') for k in weights):
            captures.append(validate_loaded_keys(module,weights,result))
        return result
    with patch.object(torch.nn.Module,'load_state_dict',checked):
        policy=baseframework.from_pretrained(str(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'))
    if len(captures)!=1:
        raise ValueError('Missing checkpoint compatibility verification')
    policy=policy.cuda().eval().requires_grad_(False)
    backend=policy.policy_backend
    native_encoder=backend.lam.vision_encoder
    if not native_encoder.enable_norm or native_encoder.norm_layer_type!='ln':
        raise ValueError('Native feature norm differs from common reference')
    sample=HeterogeneousDataset(ROOT,'A','lighting').sample(0)
    stats=json.loads((ROOT/'runtime/lawam_libero_sft/dataset_statistics.json').read_text())['franka']['action']
    batch,_=encode(policy,sample,stats)
    ref=ReferenceEncoder(ROOT/'assets/dinov3-vitb16-pretrain-lvd1689m')
    native_state=native_encoder.model.state_dict()
    reference_state=ref.model.state_dict()
    if set(native_state)!=set(reference_state):
        raise ValueError('Checkpoint DINO keys differ from reference')
    different=[k for k,v in native_state.items() if not torch.equal(v,reference_state[k])]
    if different:
        raise ValueError(f'Native frozen DINO differs from reference: {different[:3]}')
    reference=ref([sample['primary'],sample['future']])
    native_bf16=torch.cat((pool_spatial(batch['h_t'].float()),pool_spatial(batch['future_target'].float())))
    import numpy as np
    native_fp32=[]
    with torch.no_grad(),torch.autocast('cuda',enabled=False):
        for key in ('primary','future'):
            pixels=torch.from_numpy(np.asarray(sample[key]).copy()).permute(2,0,1)[None].cuda().float()/255.
            pixels=(pixels-ref.mean)/ref.std
            native_fp32.append(pool_spatial(native_encoder.encode(pixels,n=-2)[:,0].float()))
    expected=torch.cat(native_fp32)
    delta=(reference-expected).abs().max().item()
    single=torch.cat([ref([sample[key]]) for key in ('primary','future')])
    diagnostics=dict(max_abs=delta,mse=float((reference-expected).square().mean()),
                     single_max_abs=float((single-expected).abs().max()),single_mse=float((single-expected).square().mean()),
                     native_layer_norm_eps=native_encoder.latent_norms[0].eps,
                     native_bf16_vs_shared_fp32_mse=float((native_bf16-reference).square().mean()),
                     native_bf16_vs_shared_fp32_max_abs=float((native_bf16-reference).abs().max()),
                     image_hw=list(policy.policy_infer_batch_builder.infer_image_hw),
                     native_dtype=str(batch['h_t'].dtype))
    write(output/'reference_diagnostics.json',diagnostics)
    if delta>1e-4:
        raise ValueError(f'Native/common reference feature mismatch: {delta}')
    # Persist a small cross-environment check without moving private data off-server.
    torch.save(dict(primary=torch.from_numpy(sample['primary']),future=torch.from_numpy(sample['future']),reference=reference.cpu(),
                    reference_id=REFERENCE_ID,source_group=sample['source_group']),output/'cross_environment.pt')
    backend.lam.decoder.requires_grad_(True)
    status['phase']='world_gradient'
    write(output/'status.json',status)
    with amp('cuda'):
        predicted=backend._decode_future_tokens_strict_single_query(h_t=batch['h_t'],pred_action_emb=batch['intent'],source='heterogeneous_probe')
    loss=(pool_spatial(predicted.float())-reference[1:]).square().mean()
    loss.backward()
    gradient=sum(float(p.grad.float().square().sum()) for p in backend.lam.decoder.parameters() if p.grad is not None)**.5
    if gradient<=0 or any(p.grad is not None for p in backend.flow.parameters()):
        raise ValueError('Invalid common-interface world/action gradient boundary')
    result=dict(passed=True,seed=42,reference_id=REFERENCE_ID,max_abs_reference_error=delta,
                backbone_weights_identical=True,world_gradient_norm=gradient,
                shared_shape=list(reference.shape),private_intent_not_exported=True,
                action_gradients_absent=True,scientific_training=False)
    write(output/'result.json',result)
    status.update(state='completed',phase='common_interface_acceptance')
    write(output/'status.json',status)
    print(json.dumps(result))


if __name__=='__main__':
    output=ROOT/'reports/heterogeneous'/('lawam-common-'+os.environ['SLURM_JOB_ID'])
    try:
        run(output)
    except Exception as exc:
        path=output/'status.json'
        status=json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed',error=repr(exc)[:2000])
        write(path,status)
        traceback.print_exc()
        raise SystemExit(1)
