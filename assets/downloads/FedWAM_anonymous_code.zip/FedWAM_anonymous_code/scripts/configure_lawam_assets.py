"""Create local path overlays without changing downloaded upstream assets."""
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
RUNTIME = ROOT / "runtime"
REPO = ROOT / "third_party/LaWAM"


def link(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_symlink() and target.resolve() == source.resolve():
        return
    if target.exists() or target.is_symlink():
        raise FileExistsError(f"Refusing to replace existing path: {target}")
    target.symlink_to(source, target_is_directory=source.is_dir())


def dump(data, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(data, sort_keys=False))


def local_paths(config):
    # Released checkpoint YAML predates the current upstream registry name.
    if config["framework"]["name"] == "LatentWorldVLAIndependent":
        config["framework"]["name"] = "LaWAM"
    config["framework"]["qwenvl"]["base_vlm"] = str(ASSETS / "qwen3-vl-2b")
    action = config["framework"]["action_model"]
    action["lam_ckpt_path"] = str(ASSETS / "lawam_lam/checkpoints/pytorch_model.pt")
    action["lam_yaml_path"] = str(RUNTIME / "lawam_lam/dino_large_vae.yaml")
    if "datasets" in config and "vla_data" in config["datasets"]:
        config["datasets"]["vla_data"]["data_root_dir"] = str(ASSETS)
    if config.get("trainer", {}).get("pretrained_checkpoint"):
        config["trainer"]["pretrained_checkpoint"] = str(
            RUNTIME / "lawam_pretrain/final_model/pytorch_model.pt")
    return config


def main():
    dino = ASSETS / "dinov3-vitb16-pretrain-lvd1689m"
    dino.mkdir(parents=True, exist_ok=True)
    config = yaml.safe_load((ASSETS / "lawam_lam/dino_large_vae.yaml").read_text())
    config["model"]["vision_model_id"] = str(dino)
    dump(config, RUNTIME / "lawam_lam/dino_large_vae.yaml")
    link(ASSETS / "lawam_lam/checkpoints", RUNTIME / "lawam_lam/checkpoints")
    for name in ("lawam_pretrain", "lawam_libero_sft"):
        config = yaml.safe_load((ASSETS / name / "config.yaml").read_text())
        dump(local_paths(config), RUNTIME / name / "config.yaml")
        for filename in ("final_model", "dataset_statistics.json"):
            link(ASSETS / name / filename, RUNTIME / name / filename)
    train = yaml.safe_load((REPO / "starVLA/config/training/train_libero.yaml").read_text())
    train["run_root_dir"] = str(ROOT / "outputs/lawam_libero")
    dump(local_paths(train), ROOT / "configs/lawam_libero_local.yaml")
    for source, target in (
        (ASSETS / "qwen3-vl-2b", REPO / "results/Checkpoints/qwen3_weights"),
        (RUNTIME / "lawam_lam", REPO / "latent_action_model/logs/dino_large_vae/lam_release"),
        (RUNTIME / "lawam_pretrain", REPO / "results/Checkpoints/pretrain/lawam_pretrain"),
        (RUNTIME / "lawam_libero_sft", REPO / "results/Checkpoints/libero/lawam_libero_sft_release"),
        (ASSETS / "libero_merged_no_noops_20hz", REPO / "dataset/libero_merged_no_noops_20hz"),
        (dino, REPO / "weights/dinov3-vitb16-pretrain-lvd1689m"),
    ):
        link(source, target)
    print("Local LaWAM path overlays configured; DINOv3 HF-format loading still needs validation.")


if __name__ == "__main__":
    main()
