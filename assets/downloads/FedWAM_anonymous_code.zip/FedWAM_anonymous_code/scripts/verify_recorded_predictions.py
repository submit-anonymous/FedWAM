from pathlib import Path
import json
import numpy as np
import imageio.v2 as imageio
from PIL import Image
from subgoal_visual_math import cosine_map,project_pca
base=Path(__file__).resolve().parents[1]/'reports/paper_prediction_media_20260926'
lawam=json.loads((base/'lawam/result.json').read_text())
assert lawam['success'] and lawam['actions']==80 and lawam['frame_count']==81
assert [r['start'] for r in lawam['chunks']]==list(range(0,80,8))
with np.load(base/'lawam/pca_projection.npz') as f:
 pca={k:f[k] for k in f.files}
for row in lawam['chunks']:
 assert row['end']-row['start']==8
 p=base/'lawam'/row['folder']
 with np.load(p/'features.npz') as f:
  assert all(f[k].shape==(256,768) and np.isfinite(f[k]).all() for k in f.files)
  np.testing.assert_allclose(cosine_map(pca['reference_patch_feature'],f['prediction']).reshape(16,16),np.load(p/'patch_cosine.npy'),atol=1e-12)
  rgb=np.clip((project_pca(f['prediction'],pca)-pca['color_min'])/(pca['color_max']-pca['color_min']),0,1).reshape(16,16,3)
  expected=(rgb*255).round().astype('uint8')
  assert np.array_equal(expected,np.asarray(Image.open(p/'predicted_pca_16x16.png')))
 assert np.array_equal(np.asarray(Image.open(p/'actual_end.png')),np.asarray(Image.open(base/'lawam/frames'/f"{row['end']:04d}.png")))
imagewam=json.loads((base/'imagewam/result.json').read_text())
assert [r['start'] for r in imagewam['examples']]==[0,12,24,36,48,60]
for row in imagewam['examples']:
 assert row['end']-row['start']==16
 p=base/'imagewam'/row['folder']
 with np.load(p/'prediction.npz') as f:
  x=f['image'];assert x.shape==(3,224,448) and np.isfinite(x).all()
  rgb=((np.clip(x,-1,1)+1)*127.5).astype(np.uint8).transpose(1,2,0)
  assert np.array_equal(rgb,np.asarray(Image.open(p/'predicted_future_dual.png')))
  assert np.array_equal(rgb[:,:224],np.asarray(Image.open(p/'predicted_future_front.png')))
 gt=np.asarray(Image.open(p/'actual_future_dual.png'))
 assert abs(float(np.mean(((rgb.astype(float)-gt)/255.)**2))-row['rgb_mse'])<1e-12
for p in base.rglob('*.png'):
 with Image.open(p) as im:im.verify()
for p in (base/'figures').glob('*.pdf'):assert p.read_bytes().startswith(b'%PDF')
video=[]
for p in sorted(base.rglob('*.mp4')):
 reader=imageio.get_reader(p);meta=reader.get_meta_data();n=0
 for frame in reader:
  assert frame.ndim==3 and frame.shape[-1]==3;n+=1
 reader.close();assert n>0
 if 'lawam/' in str(p):assert n==81 and meta['fps']==20
 else:assert n==6 and meta['fps']==1
 video.append(dict(file=str(p.relative_to(base)),frames=n,fps=meta['fps']))
result=dict(passed=True,videos=video,lawam_complete_chunks=10,imagewam_predicted_rgb_samples=6,
 tests='raw features to display equality, PNG integrity, endpoint alignment and decoded RGB metrics checked; videos distributed separately',
 counts={ext:len(list(base.rglob('*.'+ext))) for ext in ['png','pdf','mp4','npz','npy']})
(base/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
