"""Resource-only extension for workers 4/5; frozen scientific implementation unchanged."""
import argparse,sys,os,fcntl,time,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,file_hash
from fedwam.work_queue import WorkQueue
from fedwam.experiment_config import code_identity,formal_gate,identity,resolved_config
from fedwam.round_runtime import atomic_json

def validate_extension(root,plan_path,extension,worker):
 if extension.get('max_total_gpus')!=6 or extension.get('extra_worker_ids')!=[4,5] or worker not in (4,5):raise ValueError('Unapproved resource extension')
 if extension.get('base_plan_sha256')!=file_hash(plan_path):raise ValueError('Base work plan changed')
 if not extension.get('code'):raise ValueError('Missing extension code identity')
 for name,sha in extension['code'].items():
  path=(Path(root)/name).resolve()
  if not path.is_relative_to(Path(root).resolve()) or file_hash(path)!=sha:raise ValueError('Resource extension code changed')

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--worker',type=int,choices=(4,5));p.add_argument('--retry-task');p.add_argument('--extension',type=Path,required=True);a=p.parse_args()
 extension=load(a.extension);validate_extension(ROOT,a.plan,extension,a.worker)
 plan=load(a.plan)
 if plan['code']!=code_identity():raise ValueError('Frozen work plan code changed')
 scheduler=Path(plan['root'])/'scheduler';queue=WorkQueue(scheduler,plan['tasks']);owner=f'worker-{a.worker}'
 if a.retry_task:
  queue.retry(a.retry_task);print('Retry scheduled:',a.retry_task);return
 if not os.environ.get('SLURM_JOB_ID') or a.worker is None:raise RuntimeError('Worker requires Slurm GPU reservation and worker ID')
 formal_gate(identity(resolved_config('M1',42,'formal')),load(ROOT/'reports/federation_engineering/summary.json'))
 with (scheduler/f'{owner}.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  prefer='train' if a.worker==4 else 'rollout'
  while True:
   if shutil.disk_usage(ROOT).free<80*1024**3:raise RuntimeError('Less than80GiB free: preserving data, stop rather than fill disk')
   validate_extension(ROOT,a.plan,extension,a.worker)
   if plan['code']!=code_identity():raise ValueError('Code changed during active work plan')
   task=queue.claim(owner,prefer)
   if task is None:
    if queue.finished():break
    atomic_json(scheduler/f'{owner}.json',{'state':'waiting_for_dependencies','summary':queue.summary()});time.sleep(30);continue
   log=scheduler/'logs'/f"{task['id']}.log";log.parent.mkdir(exist_ok=True)
   atomic_json(scheduler/f'{owner}.json',{'state':'running','task':task['id'],'job':os.environ['SLURM_JOB_ID'],'log':str(log)})
   with log.open('a') as output:result=subprocess.run(task['argv'],cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
   queue.finish(owner,task['id'],result.returncode)
   if result.returncode:raise RuntimeError(f"Task {task['id']} failed; inspect {log}")
  atomic_json(scheduler/f'{owner}.json',{'state':'completed_with_failures' if queue.summary().get('failed',0) or queue.summary().get('blocked',0) else 'completed','summary':queue.summary()})
if __name__=='__main__':main()
