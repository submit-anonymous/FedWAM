"""Seed43-only method jobs and evaluation workers share a filtered durable queue."""
import argparse,fcntl,os,subprocess,sys,time,uuid,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load
from fedwam.experiment_config import code_identity,resolved_config
from fedwam.parallel_execution import execution_code,check_gate,claim_filtered,remaining
from fedwam.round_runtime import atomic_json
from fedwam.work_queue import WorkQueue

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--method');g.add_argument('--eval-worker',type=int,choices=[0,1]);args=p.parse_args()
 plan=load(args.plan)
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Slurm reservation required')
 if plan.get('seeds')!=[43] or plan['code']!=code_identity() or plan['parallel_code']!=execution_code():raise ValueError('Plan code/scope changed')
 check_gate(resolved_config('M1',43,'formal'),load(ROOT/'reports/parallel_engineering/summary.json'))
 queue=WorkQueue(Path(plan['root'])/'scheduler',plan['tasks']);owner='train-'+args.method if args.method else f'eval-{args.eval_worker}'
 kinds=['parallel_train'] if args.method else ['rollout','prediction']
 with (queue.root/(owner+'.lock')).open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  while True:
   if shutil.disk_usage(ROOT).free<80*1024**3:raise RuntimeError('Less than80GiB free; preserving checkpoints')
   if plan['code']!=code_identity() or plan['parallel_code']!=execution_code():raise ValueError('Active code changed')
   task=claim_filtered(queue,owner,kinds,args.method)
   if task is None:
    if not remaining(queue,kinds,args.method):break
    atomic_json(queue.root/(owner+'.json'),{'state':'waiting_for_training','summary':queue.summary()});time.sleep(30);continue
   log=queue.root/'logs'/(task['id']+'.log');log.parent.mkdir(exist_ok=True)
   atomic_json(queue.root/(owner+'.json'),{'state':'running','task':task['id'],'job':os.environ['SLURM_JOB_ID'],'log':str(log)})
   command=task['argv']
   if args.method:
    n=1 if args.method=='M9' else 4
    command=['srun','--exclusive',f'--ntasks={n}','--cpus-per-task=8','--gpus-per-task=staff:1','--gpu-bind=single:1','--kill-on-bad-exit=1']+command+['--attempt',uuid.uuid4().hex]
   with log.open('a') as out:result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=subprocess.STDOUT)
   queue.finish(owner,task['id'],result.returncode)
   if result.returncode:raise RuntimeError('Failed '+task['id']+'; inspect '+str(log))
  atomic_json(queue.root/(owner+'.json'),{'state':'completed','summary':queue.summary()})
if __name__=='__main__':main()
