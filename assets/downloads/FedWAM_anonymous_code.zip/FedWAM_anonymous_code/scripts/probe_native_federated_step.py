"""One real-model native federated training step; engineering acceptance only."""
import os
import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT
from fedwam.round_runtime import atomic_json


OUT = ROOT/'reports/native_federated_step_probe_v3'


def main():
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('Slurm GPU allocation required')
    import torch
    import acceptance
    from fedwam.native_federation import NativeLaWAMFederation, native_config

    status = {'state': 'loading', 'job': os.environ['SLURM_JOB_ID'],
              'scope': 'single-step engineering acceptance; no scientific result'}
    atomic_json(OUT/'status.json', status)
    transport = None
    try:
        acceptance.OUT = OUT/'model_acceptance'
        policy, _, transport = acceptance.model()
        cfg = native_config('M1', 'engineering')
        backend = NativeLaWAMFederation(policy, cfg, OUT/'run', 'probe-native-v3')
        groups = backend._enable('pre')
        names = ('world', 'action', 'vlm', 'auxiliary')
        trainable = {name: sum(p.numel() for p in group)
                     for name, group in zip(names, groups)}
        sample = backend.sample('lighting', 0)
        batch = backend.native_batch(sample)
        started = time.perf_counter()
        losses, _ = backend._native_forward(batch)
        if not torch.isfinite(losses['loss_total']):
            raise FloatingPointError('Nonfinite native federated loss')
        losses['loss_total'].backward()
        gradients = {name: sum(float(p.grad.detach().abs().sum())
                               for p in group if p.grad is not None)
                     for name, group in zip(names, groups)}
        if not all(value > 0 for value in gradients.values()):
            raise ValueError('Missing native module gradient')
        changed = {}
        for name, group in zip(names, groups):
            parameter = next(p for p in group if p.grad is not None and p.grad.detach().abs().sum() > 0)
            before = parameter.detach().clone()
            optimizer = torch.optim.AdamW(group, lr=1e-4, betas=(.9, .95),
                                          weight_decay=1e-8)
            optimizer.step()
            changed[name] = not torch.equal(before, parameter.detach())
        if not all(changed.values()):
            raise ValueError('Missing native module optimizer update')
        status.update(state='completed', trainable=trainable, gradients=gradients,
                      changed=changed, losses={key: float(losses[key].detach())
                                               for key in ('loss_flow', 'loss_perceptual',
                                                           'loss_distill', 'loss_total')},
                      seconds=time.perf_counter()-started,
                      peak_gpu_bytes=torch.cuda.max_memory_allocated())
        atomic_json(OUT/'status.json', status)
    except Exception as error:
        status.update(state='failed', error=repr(error), traceback=traceback.format_exc()[-5000:])
        atomic_json(OUT/'status.json', status)
        raise
    finally:
        if transport:
            transport.close()


if __name__ == '__main__':
    main()
