"""Real native H16 engineering checks, not scientific success-rate evaluation."""
import argparse
import gc
import json
import os
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]


def action_summary(value, horizon):
    import numpy as np
    value = np.asarray(value)
    if value.shape != (horizon, 7) or not np.isfinite(value).all():
        raise ValueError(f'Invalid action chunk: {value.shape}, expected ({horizon}, 7), finite')
    return {'shape': list(value.shape), 'min': float(value.min()), 'max': float(value.max())}


def check_keys(missing, unexpected):
    if missing or unexpected:
        raise ValueError(f'Policy checkpoint mismatch: missing={len(missing)} '
                         f'unexpected={len(unexpected)} examples={list(missing)[:3] + list(unexpected)[:3]}')


def load_initial_states(loader):
    import numpy as np
    import torch
    allowed = [np.core.multiarray._reconstruct, np.ndarray, np.dtype,
               type(np.dtype('float64')), type(np.dtype('float32'))]
    existing = set(torch.serialization.get_safe_globals())
    allowed = [item for item in allowed if item not in existing]
    with torch.serialization.safe_globals(allowed):
        return loader()


def make_env(task, resolution, seed, *, env_class=None, bddl_root=None):
    if env_class is None:
        from libero.libero.envs import OffScreenRenderEnv
        env_class = OffScreenRenderEnv
    if bddl_root is None:
        from libero.libero import get_libero_path
        bddl_root = Path(get_libero_path('bddl_files'))
    env = env_class(bddl_file_name=str(bddl_root / task.problem_folder / task.bddl_file),
                    camera_heights=resolution, camera_widths=resolution)
    env.seed(seed)
    return env, task.language


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(data, indent=2, allow_nan=False))
    tmp.replace(path)


def run(output, horizon=16, replan=12):
    if horizon not in (8,16) or not 1<=replan<=horizon:
        raise ValueError('Invalid engineering horizon/replan')
    import numpy as np
    import torch
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    source = ROOT / 'third_party/ImageWAM'
    sys.path[:0] = [str(source), str(source / 'experiments/libero')]
    from experiments.libero import eval_libero_single as official
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from libero.libero import benchmark

    status = {'state': 'running', 'phase': 'load_model', 'seed': 42,
              'scope': f'H{horizon}/replan{replan} engineering acceptance only', 'job': os.getenv('SLURM_JOB_ID')}
    write(output / 'status.json', status)
    cfg = OmegaConf.load(ROOT / 'reports/imagewam_preparation/native_eval_config.yaml')
    # Fail before expensive model load if benchmark adapters are incompatible.
    status['phase'] = 'simulator_preflight'
    write(output / 'status.json', status)
    import contextlib
    import io
    suites = {}
    for name in ('libero_spatial', 'libero_object', 'libero_goal', 'libero_10'):
        with contextlib.redirect_stdout(io.StringIO()):
            suite = benchmark.get_benchmark_dict()[name]()
        suites[name] = suite
        states = load_initial_states(lambda: suite.get_task_init_states(0))
        env, _ = make_env(suite.get_task(0), official.LIBERO_ENV_RESOLUTION, 42)
        try:
            env.reset()
            env.set_init_state(states[0])
            env.step(official.get_libero_dummy_action())
        finally:
            env.close()
    status['phase'] = 'load_model'
    write(output / 'status.json', status)
    torch.manual_seed(42)
    np.random.seed(42)
    start = time.monotonic()
    model = instantiate(cfg.model, model_dtype=torch.bfloat16, device='cuda')
    compatibility = {}

    def loaded(module, keys):
        compatibility.update(missing=len(keys.missing_keys), unexpected=len(keys.unexpected_keys))
        check_keys(keys.missing_keys, keys.unexpected_keys)

    hook = model.mot.register_load_state_dict_post_hook(loaded)
    try:
        payload = model.load_checkpoint(str(cfg.ckpt))
        if model.proprio_encoder is not None and 'proprio_encoder' not in payload:
            raise ValueError('Policy checkpoint lacks proprio_encoder weights')
        del payload
    finally:
        hook.remove()
    gc.collect()
    model = model.to('cuda').eval()
    model.requires_grad_(False)
    torch.cuda.synchronize()
    load_seconds = time.monotonic() - start
    processor = instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    normalized = []
    original_infer = model.infer_action

    def capture(**kwargs):
        pred = original_infer(**kwargs)
        normalized.append(action_summary(pred['action'].cpu().numpy(), horizon))
        return pred

    model.infer_action = capture
    results = []
    for suite_name in ('libero_spatial', 'libero_object', 'libero_goal', 'libero_10'):
        status.update(phase='simulator_and_inference', suite=suite_name, completed_suites=len(results))
        write(output / 'status.json', status)
        suite = suites[suite_name]
        task = suite.get_task(0)
        states = load_initial_states(lambda: suite.get_task_init_states(0))
        env, instruction = make_env(task, official.LIBERO_ENV_RESOLUTION, 42)
        frames = []
        try:
            env.reset()
            obs = env.set_init_state(states[0])
            for _ in range(int(cfg.EVALUATION.num_steps_wait)):
                obs, _, _, _ = env.step(official.get_libero_dummy_action())
            latencies = []
            chunk_summaries = []
            repeat = []
            for _ in range(2):
                torch.cuda.synchronize()
                start = time.monotonic()
                actions, _, _ = official._predict_action_chunk(
                    obs, instruction, model, processor, cfg, action_horizon=horizon,
                    input_w=448, input_h=224, model_device='cuda')
                torch.cuda.synchronize()
                latencies.append(time.monotonic() - start)
                chunk_summaries.append(action_summary(actions, horizon))
                repeat.append(actions)
            if not np.allclose(repeat[0], repeat[1], atol=1e-5, rtol=1e-5):
                raise ValueError('Repeated seed42 inference on fixed observation differs')
            # Check normalization with the official continuous action normalizer.
            norm = processor.normalizer.normalizers['action']['default']
            probe = torch.linspace(-0.8, 0.8, horizon * 7).reshape(1, horizon, 7)
            roundtrip = (norm.forward(norm.backward(probe)) - probe).abs().max().item()
            if roundtrip > 1e-4:
                raise ValueError(f'Action normalization roundtrip error {roundtrip}')
            done = False
            steps = 0
            # Two closed-loop replans are an interface probe, not a full task evaluation.
            for replan in range(2):
                if replan:
                    actions, _, _ = official._predict_action_chunk(
                        obs, instruction, model, processor, cfg, action_horizon=horizon,
                        input_w=448, input_h=224, model_device='cuda')
                    action_summary(actions, horizon)
                for action in actions[:replan]:
                    obs, _, done, _ = env.step(action.tolist())
                    frames.append(official.get_libero_image(obs)['image'])
                    steps += 1
                    if done:
                        break
                if done:
                    break
            import imageio.v2 as imageio
            video = output / f'{suite_name}-interface-probe.mp4'
            imageio.mimsave(video, frames, fps=20)
            results.append({'suite': suite_name, 'task': task.name, 'instruction': instruction,
                            'passed': True, 'action_chunks': chunk_summaries,
                            'inference_seconds': latencies, 'fixed_input_repeat_equal': True,
                            'normalization_roundtrip_max_error': roundtrip,
                            'simulation_steps': steps, 'terminated_within_probe': bool(done),
                            'video': str(video)})
            write(output / 'suites.json', results)
        finally:
            env.close()
    result = {'passed': True, 'seed': 42, 'native_horizon': 16, 'native_replan': 12,
              'executed_horizon': horizon, 'executed_replan': replan,
              'common_h8_validated': horizon==8 and replan==8, 'scientific_evaluation': False,
              'load_seconds': load_seconds, 'checkpoint_compatibility': compatibility,
              'normalized_actions': normalized, 'peak_gpu_allocated_bytes': torch.cuda.max_memory_allocated(),
              'suites': results}
    write(output / 'result.json', result)
    status.update(state='completed', phase='native_model_acceptance', completed_suites=len(results))
    write(output / 'status.json', status)
    print(json.dumps({'passed': True, 'suites': len(results), 'load_seconds': load_seconds}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--horizon', type=int, default=16)
    parser.add_argument('--replan', type=int, default=12)
    args = parser.parse_args()
    try:
        run(args.output,args.horizon,args.replan)
    except Exception as exc:
        path = args.output / 'status.json'
        status = json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed', error=repr(exc)[:2000])
        write(path, status)
        traceback.print_exc()
        raise SystemExit(1)
