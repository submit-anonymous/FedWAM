from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts')]
import torch
import numpy as np
from fedwam.heterogeneous.reference import ReferenceEncoder
from imagewam_model_acceptance import load_initial_states,write
x=load_initial_states(lambda:torch.load(ROOT/'reports/heterogeneous/lawam-common-10414/cross_environment.pt',map_location='cpu'))
torch.set_num_threads(4)
encoder=ReferenceEncoder(ROOT/'assets/dinov3-vitb16-pretrain-lvd1689m')
results=[]
for deterministic in (False,True):
 for convolution_tf32 in (False,True):
  torch.use_deterministic_algorithms(deterministic)
  torch.backends.cudnn.deterministic=deterministic
  torch.backends.cudnn.benchmark=False
  torch.backends.cuda.matmul.allow_tf32=False
  torch.backends.cudnn.allow_tf32=convolution_tf32
  z=encoder([np.asarray(x['primary']),np.asarray(x['future'])]).cpu()
  results.append(dict(deterministic=deterministic,conv_tf32=convolution_tf32,max_abs=float((z-x['reference']).abs().max())))
print(results)
write(ROOT/'reports/heterogeneous/readout_reference_precision.json',results)
