"""Bounded, honest status: component checks are not completed federation runs."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
base=ROOT/'reports/heterogeneous'
selection=ROOT/'manifests/heterogeneous_residual_readout_seed42_v1.json'
if selection.exists() and '--history' not in sys.argv:
    s=json.loads(selection.read_text())
    print(f"开发选定接口: {s['selected_readout']} | seed {s['seed']}")
    print(f"开发接口就绪: {s['development_interface_ready']} | 正式联邦准入: {s['formal_admission']}")
    for row in s['clients']:
        print(f"{row['domain']}: dev MSE {row['residual_mse']:.6f} | copy {row['copy_mse']:.6f} | 实模型链路通过 {row['graph_passed']}")
    print(f"正式异构联邦已启动: {s['formal_federation_started']}")
    for item in s['remaining']:
        print('待完成: '+item)
    print('以上为冻结开发结果，不代表实时作业状态；Slurm请用squeue查看。历史记录加 --history。')
    raise SystemExit(0)
for label,pattern in [('ImageWAM原生验收','native-imagewam-*'),
                      ('ImageWAM控制链路','imagewam-graph-*'),
                      ('LaWAM共同接口','lawam-common-*'),
                      ('ImageWAM完整原生更新','native-update-*')]:
    paths=sorted(base.glob(pattern),key=lambda p:int(p.name.rsplit('-',1)[-1]))
    if not paths:
        print(label+': 尚无记录');continue
    p=paths[-1]
    status=json.loads((p/'status.json').read_text()) if (p/'status.json').exists() else {}
    print(f"{label}: {status.get('state','pending')} | {status.get('phase','')} | {p.name.rsplit('-',1)[-1]}")
    if status.get('error'):print('  '+status['error'].replace('\n',' ')[:180])
for domain in ('lighting','camera_pose','sensor_noise','background'):
    paths=sorted(base.glob('readout-'+domain+'-*'),key=lambda p:int(p.name.rsplit('-',1)[-1]))
    if not paths:continue
    active=[]
    for candidate in paths:
        status_path=candidate/'status.json'
        if status_path.exists() and json.loads(status_path.read_text()).get('state')=='running':
            active.append(candidate)
    # Show the common expanded recipe, not a later, smaller alternative-head diagnostic.
    expanded=[]
    for candidate in paths:
        path=candidate/'status.json'
        s=json.loads(path.read_text()) if path.exists() else {}
        if s.get('train_samples')==4096 and s.get('steps')==4000:expanded.append(candidate)
    p=(active or expanded or paths)[-1]
    status=json.loads((p/'status.json').read_text()) if (p/'status.json').exists() else {}
    print(f"读出/{domain}: {status.get('state','pending')} | {status.get('phase','')} | job {p.name.rsplit('-',1)[-1]} | step {status.get('step',0)}/{status.get('steps','?')}")
    if status.get('latest'):
        metrics=status['latest'];print(f"  dev MSE {metrics['mse']:.6f} | current-copy {metrics['copy_mse']:.6f}")
    if status.get('error'):print('  '+status['error'].replace('\n',' ')[:180])
for stage in ('imagewam-export','lawam-export','server','imagewam-receive','lawam-receive'):
    path=base/'mixed-round-v1'/stage/'status.json'
    if path.exists():
        s=json.loads(path.read_text());print(f"双架构闭环/{stage}: {s.get('state')} | {s.get('phase')}")
        if s.get('error'):print('  '+s['error'].replace('\n',' ')[:180])
for domain in ('lighting','camera_pose','sensor_noise','background'):
    path=Path('/workspace/reviewer/fedwam-heterogeneous-native-v4')/domain/'status.json'
    if path.exists():
        s=json.loads(path.read_text())
        progress=f"{s['step']}/{s.get('stop_at','?')}" if 'step' in s else '加载中，等待恢复检查点'
        print(f"原生初始适配/{domain}: {s.get('state')} | {s.get('phase')} | {progress}")
        if s.get('error'):print('  '+s['error'].replace('\n',' ')[:180])
execution=ROOT/'manifests/heterogeneous_20260926_execution.json'
if execution.exists():
    run=json.loads(execution.read_text());job=run.get('current_four_client_initial_pipeline')
    if job:
        for domain in ('lighting','camera_pose','sensor_noise','background'):
            for kind in ('learned_query','spatial'):
                path=base/f'adapted-readout-{kind}-{domain}-{job}'/'status.json'
                if path.exists():
                    s=json.loads(path.read_text())
                    progress=(f"{s.get('extracted',0)} chunks" if str(s.get('phase','')).startswith('extract_')
                              else f"{s.get('step',0)}/{s.get('steps','?')} updates")
                    print(f"适配后读出/{domain}/{kind}: {s.get('state')} | {s.get('phase')} | {progress}")
                    if s.get('error'):print('  '+s['error'].replace('\n',' ')[:180])
print('以上为历史工程记录；当前选定接口请不带 --history 运行本脚本。')
