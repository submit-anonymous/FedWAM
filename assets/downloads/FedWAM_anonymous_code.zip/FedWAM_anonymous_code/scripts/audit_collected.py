"""Final collection coverage and observed source/split/state checks; no partial acceptance."""
import json,sys
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np,h5py
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash,digest
from fedwam.collection import validate_episode
OUT=ROOT/'reports/data/supplement_audit'
def main():
    plan=load(ROOT/'manifests/fresh_collection_plan.json')['rows'];rows=[];missing=[];errors=[];bygroup=defaultdict(list);bytask=defaultdict(list)
    for expected in plan:
        p=ROOT/'reports/data/supplement/episodes'/f'{expected["id"]}.json'
        if not p.exists():missing.append({'id':expected['id'],'reason':'not_collected'});continue
        receipt=load(p)
        if not receipt.get('accepted'):missing.append({'id':expected['id'],'reason':'attempt_budget_without_success'});continue
        try:
            if receipt['case']!=expected:raise ValueError('Collection case identity mismatch')
            path=Path(receipt['path'])
            if file_hash(path)!=receipt['sha256']:raise ValueError('Episode checksum mismatch')
            with h5py.File(path,'r') as h:
                a=h['actions'][:];states=h['sim_states'][:];times=h['sim_times'][:]
                validate_episode(a,states,times,True)
                if len(h['front_jpeg'])!=len(a)+1 or len(h['wrist_jpeg'])!=len(a)+1:raise ValueError('Image/transition length mismatch')
                base=h['base_reset_state'][:];start=h['sim_states'][0]
            bygroup[expected['source_group']].append((expected,base))
            bytask[(expected['suite'],expected['source_file'])].append((expected,start))
            rows.append(dict(expected,path=str(path),sha256=receipt['sha256'],actions=len(a),legal_chunk_starts=len(a)-7,accepted_for_training=False))
        except Exception as e:errors.append({'id':expected['id'],'error':repr(e)})
    cross_split_collisions=[];minimum_distances=[]
    for task,items in bytask.items():
        for i,(row,state) in enumerate(items):
            candidates=[(other,otherstate) for other,otherstate in items[:i] if row['split']!=other['split'] and len(state)==len(otherstate)]
            if not candidates:continue
            distances=np.max(np.abs(np.array([v for _,v in candidates])[:,1:]-state[None,1:]),axis=1);best=int(np.argmin(distances))
            minimum_distances.append(float(distances[best]))
            if distances[best]<1e-4:cross_split_collisions.append({'ids':[row['id'],candidates[best][0]['id']],'distance':float(distances[best])})
    for group,items in bygroup.items():
        if len({r['split'] for r,_ in items})!=1:errors.append({'group':group,'error':'source group crosses splits'})
        if any(not np.array_equal(items[0][1],s) for _,s in items[1:]):errors.append({'group':group,'error':'shared fresh base state differs across clients'})
    complete=len(rows)==len(plan) and not missing and not errors and not cross_split_collisions
    for row in rows:row['accepted_for_training']=complete
    summary={'target':len(plan),'accepted_demonstrations':len(rows),'missing':len(missing),'errors':len(errors),
        'cross_split_near_state_collisions':len(cross_split_collisions),'minimum_cross_split_state_linf':min(minimum_distances) if minimum_distances else None,
        'client_counts':dict(Counter(r['client'] for r in rows)),'split_counts':dict(Counter(r['split'] for r in rows)),
        'training_gate':'passed' if complete else 'closed_incomplete_or_overlap','scope':'own collected data only; exact/1e-4 state checks are not a semantic near-duplicate guarantee',
        'planned_training_methods_not_started_by_this_script':True}
    save(OUT/'missing.json',missing);save(OUT/'errors.json',errors);save(OUT/'state_collisions.json',cross_split_collisions)
    save(ROOT/'manifests/fresh_training_data.json',{'summary':summary,'rows':rows})
    save(OUT/'summary.json',summary);status(OUT,state='completed' if complete else 'incomplete',phase='collection_coverage_and_overlap',**summary)
    if not complete:raise RuntimeError('Full training dataset not accepted; see coverage and overlap reports')
if __name__=='__main__':main()
