"""Compare real full-model interrupted and uninterrupted private native checkpoints."""
import json
from pathlib import Path
import sys
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
from imagewam_model_acceptance import write


def main(paths,output):
    values=[torch.load(p,map_location='cpu',weights_only=False,mmap=True) for p in paths]
    differences=[];counts=dict(tensors=0,elements=0)
    def compare(a,b,key):
        if isinstance(a,torch.Tensor):
            counts['tensors']+=1;counts['elements']+=a.numel()
            if a.shape!=b.shape or a.dtype!=b.dtype or not torch.equal(a,b):
                differences.append(dict(key=key,max_abs=float((a.float()-b.float()).abs().max()) if a.shape==b.shape else None))
        elif isinstance(a,np.ndarray):
            if not np.array_equal(a,b):differences.append(dict(key=key))
        elif isinstance(a,dict):
            if set(a)!=set(b):differences.append(dict(key=key,reason='keys'));return
            for name in a:compare(a[name],b[name],key+'/'+str(name))
        elif isinstance(a,(tuple,list)):
            if len(a)!=len(b):differences.append(dict(key=key,reason='length'));return
            for i,(x,y) in enumerate(zip(a,b)):compare(x,y,key+'/'+str(i))
        elif a!=b:differences.append(dict(key=key))
    compare(values[0],values[1],'checkpoint')
    if values[0]['step']!=2:raise ValueError('Expected two real optimizer updates')
    report=dict(passed=not differences,step=2,paths=[str(p) for p in paths],
                comparisons=counts,difference_count=len(differences),differences= differences[:20],
                checked=['all model parameters','all Adam state','scheduler','Python/NumPy/Torch/CUDA RNG','identity'])
    write(output,report)
    print(json.dumps({k:report[k] for k in ('passed','step','comparisons','difference_count')}))
    if differences:raise SystemExit(1)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--resumed',type=Path,required=True)
    p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args();main([args.resumed,args.baseline],args.output)
