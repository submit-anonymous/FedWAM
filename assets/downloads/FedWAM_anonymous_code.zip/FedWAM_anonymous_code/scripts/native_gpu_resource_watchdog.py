"""Audit bounded retry rollovers while peer clients occupy usable GPUs."""
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

from fedwam.io import NATIVE_STORAGE_ROOT, load
from fedwam.round_runtime import atomic_json

CLIENTS = {'lighting', 'camera_pose', 'sensor_noise', 'background', 'pooled'}
ROOTS = (NATIVE_STORAGE_ROOT/'engineering-v4', NATIVE_STORAGE_ROOT/'seed43-native-v4')
MAX_TOTAL_ALLOCATION_ATTEMPTS = 120


def queue():
    output = subprocess.check_output(['squeue', '-u', str(os.getuid()), '-h',
                                      '-o', '%j|%T'], text=True)
    return [tuple(row.split('|', 1)) for row in output.splitlines() if '|' in row]


def candidates():
    for root in ROOTS:
        if not root.exists():
            continue
        for path in root.glob('**/resource_retries/*.json'):
            if path.stem in CLIENTS:
                yield path


def maybe_rollover(path, rows):
    value = load(path)
    if value.get('count', 0) < 9 or value.get('limit') != 12:
        return False
    client = path.stem
    run = path.parent.parent
    method = run.name if run.name.startswith('M') or run.name == 'Local-adapter' else run.parent.name
    prefix = f'fwfull-{"eng" if "engineering-v4" in str(run) else "for"}-{method}-'
    peer_running = any(name.startswith(prefix) and not name.endswith('-'+client)
                       and state == 'RUNNING' for name, state in rows)
    target_active = any(name == prefix+client and state in ('RUNNING', 'PENDING')
                        for name, state in rows)
    status_path = run/'client_job_state'/f'{client}.json'
    status = load(status_path) if status_path.exists() else {}
    if not peer_running or target_active or status.get('state') != 'waiting_dependency' or status.get('reason') != 'allocated_gpu_occupied':
        return False
    previous = sorted(path.parent.glob(f'{client}_operational_rollover_*.json'))
    prior = sum(load(p)['previous']['count'] for p in previous)
    if prior + value['count'] >= MAX_TOTAL_ALLOCATION_ATTEMPTS:
        return False
    number = len(previous)+1
    audit = path.parent/f'{client}_operational_rollover_{number:03d}.json'
    atomic_json(audit, {'previous': value, 'at': datetime.now(timezone.utc).isoformat(),
                        'reason': 'Other client jobs occupy usable GPUs; allocated GPU lacks free memory',
                        'prior_allocation_attempts': prior, 'new_counter': 0,
                        'max_total_allocation_attempts': MAX_TOTAL_ALLOCATION_ATTEMPTS})
    atomic_json(path, {'count': 0, 'limit': 12, 'client': client})
    print(f'Allocation retry rollover for {method}/{client}: {prior+value["count"]} total attempts', flush=True)
    return True


def main():
    if not os.environ.get('SLURM_JOB_ID'):
        raise RuntimeError('CPU Slurm job required')
    absent_seconds = 0
    while True:
        rows = queue()
        if not any(name == 'fwfull-native-controller' and state == 'RUNNING'
                   for name, state in rows):
            absent_seconds += 5
            if absent_seconds >= 60:
                return
            time.sleep(5)
            continue
        absent_seconds = 0
        for path in candidates():
            maybe_rollover(path, rows)
        time.sleep(5)


if __name__ == '__main__':
    main()
