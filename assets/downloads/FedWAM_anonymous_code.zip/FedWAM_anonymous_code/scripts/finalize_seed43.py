"""Finalize verified seed43 final runs, retaining explicit missing-run accounting."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from fedwam.io import ROOT, load, save


def training_status(plan):
    if plan.get('seeds') != [43]:
        raise ValueError('Finalizer requires an explicit seed43-only plan')
    paths = [str(Path(run).resolve()) for run in plan['runs']]
    if len(set(paths)) != len(paths):
        raise ValueError('Duplicate planned training run')
    verified, unverified = [], []
    for run in paths:
        root = Path(run)
        try:
            receipt, final = load(root / 'verification.json'), load(root / 'final.json')
            if receipt.get('passed') is not True:
                raise ValueError('training verification did not pass')
            if receipt.get('identity') != final.get('identity'):
                raise ValueError('verification identity differs from final model')
            if final.get('seed') != 43 or final['identity'].get('seed') != 43:
                raise ValueError('final model is not seed43')
            if final['identity'].get('mode') != 'formal':
                raise ValueError('final model is not formal')
            verified.append(run)
        except (OSError, ValueError, KeyError, TypeError) as error:
            unverified.append(dict(run=run, reason=str(error)))
    return dict(expected_training_runs=len(paths), runs_with_training_verification=verified,
                unverified_runs=unverified, complete_training=bool(paths) and not unverified)


def queue_status(plan):
    """Read optional queue state without initializing or altering its scheduler."""
    path = Path(plan['root']) / 'scheduler/queue.json'
    if not path.exists():
        return dict(available=False, reason='queue state absent')
    queue = load(path)
    expected = hashlib.sha256(json.dumps(plan['tasks'], sort_keys=True).encode()).hexdigest()
    if queue.get('identity') != expected:
        return dict(available=False, reason='queue identity differs from current plan')
    return dict(available=True, states=dict(Counter(v['state'] for v in queue['tasks'].values())))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--bootstrap-replicates', type=int, default=2000)
    args = parser.parse_args(argv)
    plan = load(args.plan)
    summary = training_status(plan)
    summary['queue'] = queue_status(plan)
    output = (args.output or ROOT / 'reports' / plan['name']).resolve()
    save(output / 'queue_summary.json', summary)
    # An empty report is still necessary: it explicitly marks all methods absent.
    subprocess.run([sys.executable, str(ROOT / 'scripts/report_seed43.py'),
                    '--runs', *summary['runs_with_training_verification'],
                    '--output', str(output / 'results.json'),
                    '--bootstrap-replicates', str(args.bootstrap_replicates)], check=True)


if __name__ == '__main__':
    main()
