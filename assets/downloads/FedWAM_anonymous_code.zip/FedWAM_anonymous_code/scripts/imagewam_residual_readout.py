"""Matched zero-output initialization control and current-plus-world-change candidate."""
import argparse
import gc
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src')]
from imagewam_model_acceptance import write


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def run(args):
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    import torch
    from fedwam.heterogeneous.residual_readout import ResidualFutureReadout
    from fedwam.heterogeneous.readout_diagnostics import error_row,summarize
    from fedwam.heterogeneous.packets import balanced_weights
    torch.set_num_threads(4);torch.manual_seed(42);torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.backends.cudnn.allow_tf32=True;torch.backends.cuda.matmul.allow_tf32=False
    output=args.output;output.mkdir(parents=True,exist_ok=True)
    folder=Path('/workspace/reviewer/fedwam-readout-diagnosis-v3')/args.domain
    diagnosis=json.loads((folder/'result.json').read_text())
    if not diagnosis['completed'] or diagnosis['domain']!=args.domain:raise ValueError('Missing completed matched diagnosis')
    source=diagnosis['identity']['source_cache']
    if sha(source['path'])!=source['sha256']:raise ValueError('Frozen diagnostic feature cache changed')
    saved=torch.load(source['path'],map_location='cpu',weights_only=True,mmap=True)
    if saved['identity']!=source['identity']:raise ValueError('Frozen diagnostic identity mismatch')
    data=saved['data']
    files=('scripts/imagewam_residual_readout.py','src/fedwam/heterogeneous/residual_readout.py',
           'src/fedwam/heterogeneous/readout_diagnostics.py','src/fedwam/heterogeneous/spatial_readout.py',
           'src/fedwam/heterogeneous/interface.py')
    identity=dict(seed=42,domain=args.domain,diagnosis_sha256=sha(folder/'result.json'),
        feature_sha256=source['sha256'],code={p:sha(ROOT/p) for p in files},
        native_adaptation=json.loads((ROOT/f'reports/heterogeneous/adapted-readout-spatial-{args.domain}-10456/result.json').read_text())['native_adaptation'],
        train_samples=4096,dev_samples=256,steps=4000,batch_size=16,readout='spatial',initialization='zero_output_both_arms')
    if (output/'identity.json').exists() and json.loads((output/'identity.json').read_text())!=identity:
        raise ValueError('Residual experiment identity changed')
    write(output/'identity.json',identity)
    if (output/'result.json').exists():print('Residual experiment already completed');return
    state=dict(state='running',phase='training_only_baselines',domain=args.domain,seed=42);write(output/'status.json',state)
    weights=balanced_weights([dict(client=args.domain,task=x['task'],source_group=x['source_group']) for x in data['train']])
    idx=diagnosis['fixed_train_indices'];evaluation=dict(train=[data['train'][i] for i in idx],development=data['development'])
    mean=torch.zeros_like(data['train'][0]['current'],dtype=torch.float64);task_means={};totals={}
    for w,x in zip(weights,data['train']):
        delta=(x['future']-x['current']).double();mean.add_(delta,alpha=float(w));task=x['task']
        task_means.setdefault(task,torch.zeros_like(mean)).add_(delta,alpha=float(w));totals[task]=totals.get(task,0.)+float(w)
    mean=mean.float();task_means={t:(v/totals[t]).float() for t,v in task_means.items()}
    def evaluate(predict):
        values={};details={}
        with torch.no_grad():
            for split,rows in evaluation.items():
                metrics=[]
                for x in rows:
                    pred=predict(x).float().cpu()
                    metrics.append(dict(error_row(pred,x['current'],x['future'],x['pixel_change']),
                        **{k:x[k] for k in ('task','source_group','record_id','t')}))
                values[split]=summarize(metrics);details[split]=metrics
        return dict(summary=values,rows=details)
    baselines={}
    for kind in ('copy','train_mean_change','train_task_mean_change'):
        def predict(x):
            if kind=='copy':return x['current']
            return x['current']+(mean if kind=='train_mean_change' else task_means[x['task']])
        baselines[kind]=evaluate(predict)
    write(output/'baselines.json',baselines)
    results={}
    for arm in ('absolute_zero','residual'):
        path=output/f'{arm}-result.json'
        if path.exists():results[arm]=json.loads(path.read_text());continue
        torch.manual_seed(42);head=ResidualFutureReadout(3072).cuda()
        optimizer=torch.optim.AdamW(head.parameters(),lr=1e-4,weight_decay=.01)
        generator=torch.Generator().manual_seed(42);curves=[]
        def predict(x):
            with torch.autocast('cuda',dtype=torch.bfloat16):
                h=x['h'][None].cuda();z=x['current'][None].cuda()
                return (head(h,z) if arm=='residual' else head.delta(h))[0]
        state.update(phase='fit_'+arm,step=0);write(output/'status.json',state)
        for step in range(1,4001):
            indices=torch.multinomial(weights,16,replacement=True,generator=generator).tolist()
            h=torch.stack([data['train'][i]['h'] for i in indices]).cuda()
            z=torch.stack([data['train'][i]['current'] for i in indices]).cuda()
            truth=torch.stack([data['train'][i]['future'] for i in indices]).cuda()
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.bfloat16):pred=head(h,z) if arm=='residual' else head.delta(h)
            loss=(pred.float()-truth).square().mean()
            if not torch.isfinite(loss):raise ValueError('Nonfinite readout objective')
            loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);optimizer.step()
            if step%1000==0:
                head.eval();value=evaluate(predict);head.train()
                curves.append(dict(step=step,**value['summary']));state.update(step=step,latest=curves[-1]);write(output/'status.json',state)
        head.eval();value=evaluate(predict)
        # Negative control: exchange world features within the same task, retaining
        # current reference. This measures feature use without changing instruction.
        shuffled={}
        for split,rows in evaluation.items():
            groups={}
            for i,x in enumerate(rows):groups.setdefault(x['task'],[]).append(i)
            replacements={indices[j]:indices[(j+1)%len(indices)] for indices in groups.values() for j in range(len(indices))}
            metrics=[]
            with torch.no_grad():
                for i,x in enumerate(rows):
                    altered=dict(x,h=rows[replacements[i]]['h']);pred=predict(altered).float().cpu()
                    metrics.append(dict(error_row(pred,x['current'],x['future'],x['pixel_change']),
                        **{k:x[k] for k in ('task','source_group','record_id','t')}))
            shuffled[split]=summarize(metrics)
        results[arm]=dict(arm=arm,steps=4000,curves=curves,shuffled_world_features=shuffled,**value)
        torch.save(dict(schema='imagewam-residual-development-v1',identity=identity,arm=arm,
            head={k:v.cpu() for k,v in head.state_dict().items()}),output/f'{arm}-head.pt')
        results[arm]['head_sha256']=sha(output/f'{arm}-head.pt')
        write(path,results[arm]);del head,optimizer;gc.collect();torch.cuda.empty_cache()
    result=dict(completed=True,seed=42,domain=args.domain,identity=identity,baselines=baselines,arms=results,formal_admission=False,
        note='Candidate adds a fixed current-DINO skip. Learned change reads only world control features. No WAM/action updates; test/control success not evaluated.')
    write(output/'result.json',result);state.update(state='completed',phase='residual_development');write(output/'status.json',state)
    print(json.dumps({a:r['summary']['development']['mse'] for a,r in results.items()}))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--domain',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    try:run(args)
    except Exception as exc:
        path=args.output/'status.json';state=json.loads(path.read_text()) if path.exists() else {}
        state.update(state='failed',error=repr(exc));write(path,state);traceback.print_exc();raise SystemExit(1)
