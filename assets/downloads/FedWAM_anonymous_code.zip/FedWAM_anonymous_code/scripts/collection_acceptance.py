"""CPU native-simulation acceptance for each self-collected client recipe, all four suites."""
import sys,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,file_hash
from fedwam.collection import CLIENTS,perturb,refresh,corrupt_observation
OUT=ROOT/'reports/data/collection_acceptance'
def main():
    import numpy as np
    from libero.libero.envs import OffScreenRenderEnv
    from PIL import Image
    rows=load(ROOT/'manifests/raw_episodes.json')['rows'];results=[]
    for suite in sorted({r['suite'] for r in rows}):
        task=min(r['source_file'] for r in rows if r['suite']==suite)
        path=ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files/libero_mix'/task.replace('_demo.hdf5','.bddl')
        for ci,client in enumerate(CLIENTS):
            env=None;record={'suite':suite,'client':client,'task':task,'passed':False}
            try:
                env=OffScreenRenderEnv(bddl_file_name=str(path),camera_heights=256,camera_widths=256)
                env.seed(20260921);obs=env.reset();before=obs['agentview_image'].copy()
                recipe,obs=perturb(env,client,20260921+ci,env.language_instruction,set())
                for _ in range(10):obs,_,_,_=env.step([0,0,0,0,0,0,-1])
                obs=corrupt_observation(obs,recipe,np.random.default_rng(42));state=env.get_sim_state()
                if not np.isfinite(state).all() or obs['agentview_image'].shape!=(256,256,3):raise ValueError('Invalid native state/image')
                out=OUT/'cases'/f'{suite}_{client}';out.mkdir(parents=True,exist_ok=True)
                Image.fromarray(before[::-1,::-1]).save(out/'before.png');Image.fromarray(obs['agentview_image'][::-1,::-1]).save(out/'after.png')
                record.update(passed=True,recipe=recipe,state_dimensions=len(state),physical_state_sha256=__import__('hashlib').sha256(np.asarray(state).tobytes()).hexdigest())
            except Exception as e:record['error']=repr(e);traceback.print_exc()
            finally:
                if env is not None:env.close()
            results.append(record);save(OUT/'cases'/f'{suite}_{client}'/'result.json',record)
            status(OUT,state='running',phase='recipe_native_acceptance',done=len(results),passed=sum(r['passed'] for r in results),total=28)
    save(OUT/'summary.json',{'recipe_sha256':file_hash(ROOT/'src/fedwam/collection.py'),'passed':sum(r['passed'] for r in results),'total':28,'failures':[r for r in results if not r['passed']],
        'scope':'reset/perturb/step and artifact acceptance only; no policy demonstration yet'})
    status(OUT,state='completed' if all(r['passed'] for r in results) else 'failed',phase='recipe_native_acceptance',passed=sum(r['passed'] for r in results),total=28)
    if not all(r['passed'] for r in results):raise RuntimeError('Collection recipe acceptance failed')
if __name__=='__main__':main()
