"""One predeclared native task, using the upstream complete episode loop."""
import gc
import hashlib
import os
from pathlib import Path
import sys
import time
import traceback
from imagewam_model_acceptance import ROOT, write, make_env, load_initial_states, check_keys, action_summary


def run(output):
    import numpy as np
    import torch
    import imageio.v2 as imageio
    from PIL import Image
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    sys.path[:0] = [str(ROOT/'third_party/ImageWAM'),str(ROOT/'third_party/ImageWAM/experiments/libero')]
    from experiments.libero import eval_libero_single as official
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from libero.libero import benchmark
    status=dict(state='running',phase='load',seed=42,suite='libero_spatial',task_id=0,init_state_index=0)
    write(output/'status.json',status)
    cfg=OmegaConf.load(ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    assert int(cfg.EVALUATION.action_horizon)==16 and int(cfg.EVALUATION.replan_steps)==12
    assert not cfg.EVALUATION.visualize_future_video
    torch.manual_seed(42);np.random.seed(42)
    started=time.monotonic()
    model=instantiate(cfg.model,model_dtype=torch.bfloat16,device='cuda')
    keys={}
    def checked(module,result):
        check_keys(result.missing_keys,result.unexpected_keys)
        keys.update(missing=len(result.missing_keys),unexpected=len(result.unexpected_keys))
    handle=model.mot.register_load_state_dict_post_hook(checked)
    try:
        payload=model.load_checkpoint(str(cfg.ckpt))
        if 'proprio_encoder' not in payload:raise ValueError('Missing proprio encoder')
        del payload
    finally:handle.remove()
    gc.collect();model.to('cuda').eval().requires_grad_(False)
    processor=instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    suite=benchmark.get_benchmark_dict()['libero_spatial']()
    task=suite.get_task(0)
    states=load_initial_states(lambda:suite.get_task_init_states(0))
    env,instruction=make_env(task,official.LIBERO_ENV_RESOLUTION,42)
    actions=[];frames=[];chunks=[];last_obs=None
    original_step=env.step
    wait=int(cfg.EVALUATION.num_steps_wait)
    def record_step(action):
        nonlocal last_obs
        result=original_step(action);last_obs=result[0]
        actions.append(np.asarray(action,dtype=np.float32))
        if len(actions)>=wait:
            frames.append(official.get_libero_image(last_obs))
        if len(actions)%24==0:
            status.update(phase='rollout',actions=max(0,len(actions)-wait))
            write(output/'status.json',status)
        return result
    env.step=record_step
    original_predict=official._predict_action_chunk
    def predict(*args,**kwargs):
        start=time.monotonic();result=original_predict(*args,**kwargs)
        chunks.append(dict(step=len(actions)-wait,seconds=time.monotonic()-start,**action_summary(result[0],16)))
        return result
    official._predict_action_chunk=predict
    status.update(phase='rollout');write(output/'status.json',status)
    try:
        success,replay,_,_=official.run_single_episode(env,states[0],instruction,model,processor,cfg,0,
            action_horizon=16,input_w=448,input_h=224,model_device='cuda')
        success_check=bool(env.check_success())
        if success!=success_check:raise ValueError('Episode terminal and benchmark success disagree')
    finally:
        official._predict_action_chunk=original_predict
        env.close()
    executed=len(actions)-wait
    if executed!=len(replay) or len(frames)!=executed+1 or not 0<executed<=400:
        raise ValueError('Incomplete rollout recording')
    if [x['step'] for x in chunks]!=list(range(0,executed,12)):
        raise ValueError('Replan schedule differs from12')
    for name in ('front','dual'):
        path=output/f'rollout_{name}.mp4'
        with imageio.get_writer(path,fps=20,codec='libx264',quality=9,macro_block_size=1) as writer:
            for frame in frames:
                writer.append_data(frame['image'] if name=='front' else np.concatenate([frame['image'],frame['wrist_image']],axis=1))
    selected=np.linspace(0,executed,6).round().astype(int).tolist()
    for i in selected:
        (output/'frames').mkdir(exist_ok=True)
        Image.fromarray(frames[i]['image']).save(output/'frames'/f'step_{i:04d}.png')
    np.save(output/'actions.npy',np.asarray(actions[wait:]))
    result=dict(success=success,benchmark_success_check=success_check,actions=executed,frame_count=len(frames),
        seed=42,suite='libero_spatial',task_id=0,task=task.name,instruction=instruction,init_state_index=0,
        horizon=16,replan_steps=12,control_hz=20,wait_steps=wait,max_steps=400,checkpoint=str(cfg.ckpt),
        checkpoint_compatibility=keys,selected_frame_steps=selected,chunks=chunks,
        elapsed_seconds=time.monotonic()-started,model='ImageWAM-FLUX.2-4B-LIBERO original checkpoint',
        source_loop=str(Path(official.__file__).resolve()),
        source_loop_sha256=hashlib.sha256(Path(official.__file__).read_bytes()).hexdigest(),
        scope='One predeclared qualitative native rollout; not federation or aggregate success rate')
    write(output/'result.json',result)
    status.update(state='completed',phase='full_episode_recorded',success=success,actions=executed)
    write(output/'status.json',status)
    print(status)


if __name__=='__main__':
    output=ROOT/'reports/paper_media_20260926/imagewam_full_task'
    if (output/'result.json').exists():raise SystemExit('Already recorded; preserve first attempt')
    try:run(output)
    except Exception as exc:
        write(output/'status.json',dict(state='failed',error=repr(exc)))
        traceback.print_exc();raise
