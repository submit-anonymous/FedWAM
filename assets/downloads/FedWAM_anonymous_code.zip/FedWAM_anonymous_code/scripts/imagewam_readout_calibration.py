"""Source-isolated readout development experiment; never a FedWAM success claim."""
import argparse
import gc
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'third_party/ImageWAM')]
from imagewam_model_acceptance import check_keys, write


def run(args):
    import numpy as np
    import torch
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.imagewam import make_native_sample, prefix_cache, control_features_from_cache
    from fedwam.heterogeneous.interface import FutureReadout, pool_spatial
    from fedwam.heterogeneous.reference import ReferenceEncoder,REFERENCE_ID

    torch.manual_seed(42)
    torch.set_num_threads(4)
    output = args.output
    if (output/'result.json').exists():
        print('Completed calibration exists; no duplicate run')
        return
    status = dict(state='running', phase='load', domain=args.domain, seed=42,
                  train_samples=args.train_samples, development_samples=args.dev_samples,
                  steps=args.steps, scope='readout development only; world/action remain frozen')
    write(output/'status.json', status)
    cfg = OmegaConf.load(ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    model = instantiate(cfg.model, model_dtype=torch.bfloat16, device='cuda')
    hook = model.mot.register_load_state_dict_post_hook(lambda m,k:check_keys(k.missing_keys,k.unexpected_keys))
    try:
        payload = model.load_checkpoint(str(cfg.ckpt))
        if 'proprio_encoder' not in payload:
            raise ValueError('Missing proprio checkpoint')
        del payload
    finally:
        hook.remove()
    adaptation=None
    if args.native_checkpoint is not None:
        # Account-owned local native checkpoint, including NumPy RNG state.
        payload=torch.load(args.native_checkpoint,map_location='cpu',weights_only=False)
        if payload.get('schema')!='heterogeneous-private-native-v1' or payload['step']!=1000:
            raise ValueError('Readout requires completed1000-step native initial adaptation')
        if payload['identity']['domain']!=args.domain or payload['identity']['seed']!=42:
            raise ValueError('Native adaptation client/seed mismatch')
        from fedwam.round_runtime import sha
        for name,expected in payload['identity']['assets'].items():
            if sha(name)!=expected:raise ValueError('Frozen native asset changed after adaptation: '+name)
        config_key='reports/imagewam_preparation/native_eval_config.yaml'
        if sha(ROOT/config_key)!=payload['identity']['code'][config_key]:
            raise ValueError('Native configuration changed after adaptation')
        model.mot.load_state_dict(payload['modules']['mot'],strict=True)
        model.proprio_encoder.load_state_dict(payload['modules']['proprio_encoder'],strict=True)
        adaptation=dict(path=str(args.native_checkpoint.resolve()),sha256=sha(args.native_checkpoint),
                        step=payload['step'],identity=payload['identity'])
        del payload
    gc.collect()
    model.eval().requires_grad_(False)
    processor = instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    reference = ROOT/'assets/dinov3-vitb16-pretrain-lvd1689m'
    encoder = ReferenceEncoder(reference)
    if args.parity_reference is None:
        raise ValueError('Native LaWAM reference parity artifact is required')
    from imagewam_model_acceptance import load_initial_states
    native_reference=load_initial_states(lambda:torch.load(args.parity_reference,map_location='cpu'))
    if native_reference['reference_id']!=REFERENCE_ID:
        raise ValueError('Cross-environment reference definition mismatch')
    check=encoder([np.asarray(native_reference['primary']),np.asarray(native_reference['future'])])
    parity=(check.cpu()-native_reference['reference']).abs().max().item()
    if parity>1e-3:
        raise ValueError(f'ImageWAM/LaWAM environment encoder disagreement: {parity}')
    status.update(reference_id=REFERENCE_ID,cross_environment_max_abs=parity)
    write(output/'status.json',status)
    text_cache = {}
    data = {}
    started = time.monotonic()
    for split, count in [('train',args.train_samples),('development',args.dev_samples)]:
        dataset = HeterogeneousDataset(ROOT,'B',args.domain,split)
        records = []
        seen = set()
        draw = 0
        status.update(phase='extract_'+split, extracted=0)
        write(output/'status.json',status)
        while len(records)<count:
            sample = dataset.sample(draw)
            draw += 1
            key = (sample['record_id'],sample['t'])
            if key in seen:
                if draw>count*100:
                    raise ValueError('Insufficient distinct eligible chunks')
                continue
            seen.add(key)
            native = make_native_sample(sample,processor)
            prompt = native['instruction']
            if prompt not in text_cache:
                text_cache[prompt]=model._encode_flux2_prompts([prompt])
            text,mask=text_cache[prompt]
            with torch.no_grad():
                h=control_features_from_cache(prefix_cache(model,native['current_frame'],text,mask,native['proprio']))
                z0,z1=encoder([sample['primary'],sample['future']]).chunk(2)
            records.append(dict(h=h[0].to('cpu',torch.float16),current=z0[0].cpu(),target=z1[0].cpu(),
                                task=sample['lang'],source_group=sample['source_group'],
                                record_id=sample['record_id'],t=sample['t']))
            if len(records)%16==0 or len(records)==count:
                status.update(extracted=len(records),extraction_seconds=time.monotonic()-started)
                write(output/'status.json',status)
        data[split]=records
    if {r['source_group'] for r in data['train']} & {r['source_group'] for r in data['development']}:
        raise ValueError('Readout development source leakage')
    # Keep only small receipts/head checkpoints; extracted features stay in RAM.
    del h,z0,z1,text_cache,text,mask,encoder
    model.text_encoder.model.to('cpu')
    model.to('cpu')
    del model
    gc.collect()
    torch.cuda.empty_cache()
    if args.readout=='spatial':
        from fedwam.heterogeneous.spatial_readout import SpatialFutureReadout
        head=SpatialFutureReadout(data['train'][0]['h'].shape[-1]).cuda()
    else:
        head=FutureReadout(data['train'][0]['h'].shape[-1]).cuda()
    optimizer=torch.optim.AdamW(head.parameters(),lr=1e-4,weight_decay=.01)
    generator=torch.Generator().manual_seed(42)
    # Balance task then source, then choose a cached temporal sample.
    from fedwam.heterogeneous.packets import balanced_weights
    weights=balanced_weights([dict(client=args.domain,task=r['task'],source_group=r['source_group']) for r in data['train']])
    status.update(phase='fit_readout',step=0)
    write(output/'status.json',status)
    curves=[]
    def evaluate():
        head.eval()
        rows=[]
        with torch.no_grad():
            for r in data['development']:
                with torch.autocast('cuda',dtype=torch.bfloat16):
                    pred=head(r['h'][None].cuda())
                mse=(pred[0].float().cpu()-r['target']).square().mean().item()
                copy=(r['current']-r['target']).square().mean().item()
                rows.append(dict(task=r['task'],source_group=r['source_group'],mse=mse,copy_mse=copy))
        w=balanced_weights([dict(client=args.domain,task=r['task'],source_group=r['source_group']) for r in rows])
        model_error=sum(float(v)*r['mse'] for v,r in zip(w,rows))
        copy_error=sum(float(v)*r['copy_mse'] for v,r in zip(w,rows))
        threshold=float(np.median([r['copy_mse'] for r in rows]))
        strata={}
        for name,condition in [('small_change',lambda x:x<=threshold),('large_change',lambda x:x>threshold)]:
            selected=[r for r in rows if condition(r['copy_mse'])]
            strata[name]=dict(n=len(selected),mse=float(np.mean([r['mse'] for r in selected])) if selected else None,
                             copy_mse=float(np.mean([r['copy_mse'] for r in selected])) if selected else None)
        head.train()
        return dict(mse=model_error,copy_mse=copy_error,strata=strata)
    for step in range(1,args.steps+1):
        indices=torch.multinomial(weights,args.batch_size,replacement=True,generator=generator).tolist()
        h=torch.stack([data['train'][i]['h'] for i in indices]).cuda()
        target=torch.stack([data['train'][i]['target'] for i in indices]).cuda()
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast('cuda',dtype=torch.bfloat16):
            pred=head(h)
        loss=(pred.float()-target).square().mean()
        if not torch.isfinite(loss):
            raise ValueError('Nonfinite readout loss')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(head.parameters(),1.)
        optimizer.step()
        if step%100==0 or step==args.steps:
            metrics=evaluate()
            curves.append(dict(step=step,train_loss=float(loss),**metrics))
            status.update(step=step,latest=curves[-1])
            write(output/'status.json',status)
    final=curves[-1]
    payload=dict(schema='imagewam-readout-development-v1',seed=42,domain=args.domain,
                 head={k:v.cpu() for k,v in head.state_dict().items()},input_feature='last_single_cache_v_image_tokens',
                 horizon_original_steps=8,training_steps=args.steps,reference_id=REFERENCE_ID,
                 spatial_memory_positions=True,readout_kind=args.readout,native_adaptation=adaptation)
    temporary=output/'readout.pt.tmp'
    torch.save(payload,temporary)
    temporary.replace(output/'readout.pt')
    with (output/'readout.pt').open('rb') as f:
        sha=hashlib.file_digest(f,'sha256').hexdigest()
    result=dict(completed=True,seed=42,domain=args.domain,steps=args.steps,curves=curves,
                development_beats_copy=final['mse']<final['copy_mse'],
                formal_admission=False,world_updated=False,head_sha256=sha,reference_id=REFERENCE_ID,
                spatial_memory_positions=True,cross_environment_max_abs=parity,readout_kind=args.readout,native_adaptation=adaptation,
                samples={s:[{k:v for k,v in r.items() if k not in ('h','current','target')} for r in rows] for s,rows in data.items()},
                elapsed_seconds=time.monotonic()-started,
                initialized_from_native_adaptation=adaptation is not None,
                note='Development readout evidence only; world frozen within this job; native adaptation provenance is separate; formal round runner still required')
    write(output/'result.json',result)
    status.update(state='completed',phase='readout_development',development_beats_copy=result['development_beats_copy'])
    write(output/'status.json',status)
    print(json.dumps({k:result[k] for k in ('completed','domain','development_beats_copy','elapsed_seconds')}))


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--domain',required=True,choices=['lighting','camera_pose','sensor_noise','background'])
    p.add_argument('--output',required=True,type=Path)
    p.add_argument('--train-samples',type=int,default=256)
    p.add_argument('--dev-samples',type=int,default=64)
    p.add_argument('--steps',type=int,default=1000)
    p.add_argument('--batch-size',type=int,default=16)
    p.add_argument('--parity-reference',type=Path)
    p.add_argument('--readout',choices=['learned_query','spatial'],default='learned_query')
    p.add_argument('--native-checkpoint',type=Path)
    args=p.parse_args()
    try:
        if min(args.train_samples,args.dev_samples,args.steps,args.batch_size)<1:
            raise ValueError('Positive sample/update counts required')
        run(args)
    except Exception as exc:
        path=args.output/'status.json'
        status=json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed',error=repr(exc)[:2000])
        write(path,status)
        traceback.print_exc()
        raise SystemExit(1)
