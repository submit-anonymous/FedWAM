"""Generate and audit all 2000 fresh source initial states before any GPU collection."""
import sys,hashlib
from pathlib import Path
from collections import defaultdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,digest,file_hash
OUT=ROOT/'reports/data/fresh_resets'
def main():
    from libero.libero.envs.env_wrapper import ControlEnv
    plan=load(ROOT/'manifests/fresh_collection_plan.json');unique={r['source_group']:r for r in plan['rows']}
    reserve=load(ROOT/'reports/data/overlap/published_init_reserve.json')['rows'];bytask=defaultdict(list)
    for row in unique.values():bytask[(row['suite'],row['source_file'])].append(row)
    records=[];rejections=[];nearest_other=[]
    for (suite,source),rows in sorted(bytask.items()):
        path=ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files/libero_mix'/source.replace('_demo.hdf5','.bddl')
        env=ControlEnv(bddl_file_name=str(path),use_camera_obs=False,has_offscreen_renderer=False,has_renderer=False,hard_reset=False)
        accepted=[]
        try:
            for row in sorted(rows,key=lambda r:r['source_group']):
                chosen=None
                for attempt in range(50):
                    seed=(row['reset_seed']+attempt*999983)%(2**32);env.seed(seed);env.reset();state=np.asarray(env.get_sim_state()).copy()
                    if not np.isfinite(state).all():raise ValueError('Nonfinite generated reset state')
                    candidates=np.asarray([r['state'] for r in reserve if r['suite']==suite and r['name'].startswith(source.removesuffix('_demo.hdf5')) and len(r['state'])==len(state)])
                    if candidates.ndim!=2 or not len(candidates):raise ValueError('Missing published state comparison pool')
                    near_pub=float(np.min(np.max(np.abs(candidates[:,1:]-state[None,1:]),axis=1)))
                    near_fresh=float(np.min(np.max(np.abs(np.asarray(accepted)[:,1:]-state[None,1:]),axis=1))) if accepted else None
                    if near_pub<1e-4 or (near_fresh is not None and near_fresh<1e-4):
                        rejections.append({'source_group':row['source_group'],'attempt':attempt,'seed':seed,'near_published':near_pub,'near_fresh':near_fresh});continue
                    chosen=(state,seed,near_pub,near_fresh);break
                if chosen is None:raise RuntimeError(f'Cannot generate independent resets for {suite}/{source}; no duplicate padding')
                state,seed,near_pub,near_fresh=chosen;accepted.append(state)
                p=OUT/'states'/f'{row["source_group"]}.npz';p.parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(p,state=state)
                records.append({'source_group':row['source_group'],'suite':suite,'source_file':source,'split':row['split'],'path':str(p),
                    'seed':seed,'sha256':file_hash(p),'joint_names':list(env.sim.model.joint_names),
                    'nearest_published_state_linf':near_pub,'nearest_previous_fresh_state_linf':near_fresh,
                    'published_comparisons':len(candidates),'state_space_metric':'full flattened physical-state Linf, excluding simulation clock; not semantic near-state proof'})
                if near_fresh is not None:nearest_other.append(near_fresh)
                status(OUT,state='running',phase='fresh_initial_state_generation',done=len(records),total=len(unique))
        finally:env.close()
    save(ROOT/'manifests/fresh_initial_states.json',{'rows':records,'plan_sha256':file_hash(ROOT/'manifests/fresh_collection_plan.json'),
        'published_reserve_sha256':file_hash(ROOT/'reports/data/overlap/published_init_reserve.json'),'rejected_candidates':rejections,
        'minimum_fresh_pair_linf':min(nearest_other),'threshold':1e-4,'status':'all_fresh_groups_checked'})
    status(OUT,state='completed',phase='fresh_initial_state_generation',done=len(records),total=len(unique),rejected_candidates=len(rejections))
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));raise
