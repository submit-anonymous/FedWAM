"""Read official release ZIP directories and dataset metadata via small bounded ranges."""
import io,json,sys,zipfile,concurrent.futures
from pathlib import Path
import requests
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save
from fedwam.data_contracts import checked_range
OUT=ROOT/'reports/data/provenance_research'
class Remote(io.RawIOBase):
    def __init__(self,url):
        self.url=url;self.pos=0
        with requests.get(url,headers={'Range':'bytes=0-0','Accept-Encoding':'identity'},stream=True,timeout=(30,90)) as r:
            r.raise_for_status()
            if r.status_code!=206:raise ValueError('Range not honored')
            self.size=int(r.headers['Content-Range'].split('/')[-1]);checked_range(r.raw,r.headers['Content-Range'],0,1,self.size)
    def seek(self,pos,whence=0):
        self.pos=pos if whence==0 else self.pos+pos if whence==1 else self.size+pos
        return self.pos
    def tell(self):return self.pos
    def read(self,n=-1):
        if n<0:n=self.size-self.pos
        if not n:return b''
        if n>8*1024**2:raise ValueError('Refusing large metadata read')
        with requests.get(self.url,headers={'Range':f'bytes={self.pos}-{self.pos+n-1}','Accept-Encoding':'identity'},stream=True,timeout=(30,90)) as r:
            r.raise_for_status()
            if r.status_code!=206:raise ValueError('Range not honored')
            b=checked_range(r.raw,r.headers['Content-Range'],self.pos,n,self.size)
        self.pos+=n;return b

def one(job):
    repo,revision,name=job;url=f'https://huggingface.co/datasets/{repo}/resolve/{revision}/{name}'
    report={'repo':repo,'revision':revision,'archive':name}
    try:
        remote=Remote(url)
        with zipfile.ZipFile(remote) as z:
            files=z.namelist();report.update(archive_bytes=remote.size,files=len(files),hdf5_files=sum(n.endswith('.hdf5') for n in files),tfrecord_files=sum('.tfrecord-' in n for n in files))
            for n in files:
                if Path(n).name in ('dataset_info.json','features.json'):
                    if z.getinfo(n).file_size>4*1024**2:raise ValueError('Metadata unexpectedly large')
                    report[n]=json.loads(z.read(n))
    except Exception as e:report['error']=repr(e)
    key=(repo+'_'+name).replace('/','__');save(OUT/'archive_metadata'/f'{key}.json',report)
    print(name,report.get('tfrecord_files'),report.get('error'),flush=True)
    return report
if __name__=='__main__':
    jobs=[]
    for file in ['libero_plus_data_4suite_api.json','libero_plus_camparam_rlds_api.json']:
        api=load(OUT/file)
        for r in api['siblings']:
            if r['rfilename'].startswith('rlds/') or r['rfilename']=='libero_plus_camparam_rlds.zip':jobs.append((api['id'],api['sha'],r['rfilename']))
    with concurrent.futures.ThreadPoolExecutor(3) as pool:list(pool.map(one,jobs))
