"""Summarize whatever is actually complete; never label missing runs as successes."""
import argparse,sys,subprocess
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load
from fedwam.round_runtime import atomic_json
from fedwam.work_queue import WorkQueue
p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);args=p.parse_args()
plan=load(args.plan);queue=WorkQueue(Path(plan['root'])/'scheduler',plan['tasks'])
runs=[r for r in plan['runs'] if (Path(r)/'verification.json').exists() and load(Path(r)/'verification.json').get('passed')]
output=ROOT/'reports'/plan['name'];output.mkdir(parents=True,exist_ok=True)
atomic_json(output/'queue_summary.json',{'tasks':queue.summary(),'runs_with_training_verification':runs,'expected_training_runs':30})
if runs:subprocess.run([sys.executable,str(ROOT/'scripts/report_federated.py'),'--runs',*runs,'--output',str(output/'results.json')],check=True)
