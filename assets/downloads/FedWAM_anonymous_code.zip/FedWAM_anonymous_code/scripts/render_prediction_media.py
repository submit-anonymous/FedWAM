"""Paper-style latent displays and native future RGB, with fixed visual mappings."""
from pathlib import Path
import json
import shutil
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import imageio.v2 as imageio
from subgoal_visual_math import cosine_map,fit_pca,project_pca
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'reports/paper_prediction_media_20260926'
FIG=OUT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':8,'axes.titlesize':8,'pdf.fonttype':42,'font.family':'DejaVu Sans'})

def save(fig,name):
    fig.savefig(FIG/f'{name}.png',dpi=240,bbox_inches='tight',facecolor='white')
    fig.savefig(FIG/f'{name}.pdf',dpi=300,bbox_inches='tight',facecolor='white');plt.close(fig)

def no_axis(ax):
    ax.set_xticks([]);ax.set_yticks([])
    for spine in ax.spines.values():spine.set_visible(False)

def lawam():
    folder=OUT/'lawam';r=json.loads((folder/'result.json').read_text())
    data=[]
    for c in r['chunks']:
        p=folder/c['folder']
        with np.load(p/'features.npz') as f:data.append(dict(c,**{k:f[k] for k in f.files},
            rgb=np.asarray(Image.open(p/'current.png')),actual=np.asarray(Image.open(p/'actual_end.png'))))
    # Manual choice from the initial RGB ONLY, before reading similarities.
    patch_row,patch_col=2,7
    query=data[0]['current'][patch_row*16+patch_col]
    pca=fit_pca(data[0]['current'])
    projections=[project_pca(d[k],pca) for d in data for k in ('current','prediction')]
    lo=np.min(np.concatenate(projections),axis=0);hi=np.max(np.concatenate(projections),axis=0)
    assert np.all(hi>lo)
    np.savez_compressed(folder/'pca_projection.npz',**pca,color_min=lo,color_max=hi,reference_patch_feature=query)
    cmap=plt.get_cmap('magma')
    for d in data:
        scores=cosine_map(query,d['prediction']).reshape(16,16)
        projected=project_pca(d['prediction'],pca)
        colors=np.clip((projected-lo)/(hi-lo),0,1).reshape(16,16,3)
        p=folder/d['folder']
        np.save(p/'patch_cosine.npy',scores)
        Image.fromarray((colors*255).round().astype('uint8')).save(p/'predicted_pca_16x16.png')
        d['cosine']=scores;d['pca_rgb']=colors
    def overlay(ax,actual,scores):
        ax.imshow(actual)
        return ax.imshow(scores,cmap=cmap,vmin=-1,vmax=1,extent=(-.5,255.5,255.5,-.5),
                         interpolation='bilinear',alpha=.5)
    def panels(selected,name):
        fig,axes=plt.subplots(4,len(selected),figsize=(7.2,6.3),squeeze=False)
        for col,d in enumerate(selected):
            axes[0,col].imshow(d['rgb'])
            if d['start']==0:axes[0,col].add_patch(Rectangle((patch_col*16,patch_row*16),16,16,fill=False,edgecolor='#00ff00',linewidth=1.5))
            axes[0,col].set_title(f"t={d['start']} -> {d['end']}")
            axes[1,col].imshow(d['pca_rgb'],interpolation='nearest')
            im=overlay(axes[2,col],d['actual'],d['cosine'])
            axes[3,col].imshow(d['actual'])
        for ax in axes.flat:no_axis(ax)
        for ax,label in zip(axes[:,0],['Current RGB','Predicted\nsubgoal PCA','Similarity on\nactual end','Actual RGB\nat t+8']):ax.set_ylabel(label)
        fig.suptitle('LaWAM | Native 16x16 subgoals used by the action expert',fontsize=10,y=.985)
        fig.subplots_adjust(left=.09,right=.99,top=.91,bottom=.13,wspace=.07,hspace=.12)
        cb=fig.add_axes([.68,.061,.23,.013]);fig.colorbar(im,cax=cb,orientation='horizontal').set_label('Cosine similarity (fixed reference)',fontsize=8)
        fig.text(.04,.068,'Green box: initial robot-arm patch.\nFixed PCA and color mapping for the entire sequence.',fontsize=8)
        save(fig,name)
    selected=[data[i] for i in np.linspace(0,len(data)-1,5).round().astype(int)]
    panels(selected,'lawam_subgoal_sequence')
    for start in range(0,len(data),5):panels(data[start:start+5],f'lawam_subgoal_all_{start//5+1}')
    # Every frame is an actual simulator frame; hold each prediction through
    # its executed chunk. At a chunk endpoint show the prediction that targeted it.
    with imageio.get_writer(folder/'subgoal_overlay_video.mp4',fps=20,codec='libx264',quality=9,macro_block_size=1) as writer:
        fig,axes=plt.subplots(1,3,figsize=(9,3.6),dpi=100)
        for step in range(r['frame_count']):
            d=data[min(max(step-1,0)//8,len(data)-1)]
            actual=np.asarray(Image.open(folder/'frames'/f'{step:04d}.png'))
            for ax in axes:ax.clear();no_axis(ax)
            axes[0].imshow(actual);axes[0].set_title(f'Actual observation | step {step}')
            axes[1].imshow(d['pca_rgb'],interpolation='nearest');axes[1].set_title(f"Subgoal PCA | target {d['end']}")
            overlay(axes[2],actual,d['cosine']);axes[2].set_title('Fixed-patch future similarity')
            fig.suptitle(f"LaWAM | Prediction from step {d['start']} | H8 | actual control at20Hz",fontsize=11)
            fig.subplots_adjust(left=.01,right=.99,bottom=.03,top=.85,wspace=.03)
            fig.canvas.draw();writer.append_data(np.asarray(fig.canvas.buffer_rgba())[:,:,:3].copy())
        plt.close(fig)
    protocol=dict(patch=dict(row=patch_row,col=patch_col,pixel_box_xywh=[112,32,16,16],selection='Manual robot gripper/arm patch in initial RGB only, fixed thereafter'),
        pca='Fit3components on initial current256x768features; deterministic signs; one fixed basis for all chunks',
        color_mapping='Common per-component min/max of projected current and predicted features over the recorded sequence; no GT features used',
        explained_variance_ratio=pca['explained_variance_ratio'].tolist(),
        similarity='Cosine of initial patch feature and each predicted feature; display range[-1,1]',
        display='PCA nearest-neighbor16x16; similarity bilinear display overlay, alpha0.5. Raw cosine maps preserved.',
        endpoint_alignment='t->t+8exactly8executed actions; all10complete chunks included',
        paper_reference='https://arxiv.org/html/2606.15768v1#A2',
        scope='Reimplementation of paper-style visualization, not original author plotting code; no latent editing')
    (folder/'visualization_protocol.json').write_text(json.dumps(protocol,indent=2))

def imagewam():
    folder=OUT/'imagewam';r=json.loads((folder/'result.json').read_text());rows=r['examples']
    def figure(selected,name,view='front'):
        fig,axes=plt.subplots(3,len(selected),figsize=(7.2,4.25),squeeze=False)
        for col,row in enumerate(selected):
            p=folder/row['folder']
            for line,key in enumerate(['current','predicted_future','actual_future']):
                axes[line,col].imshow(np.asarray(Image.open(p/f'{key}_{view}.png')));no_axis(axes[line,col])
            axes[0,col].set_title(f"{row['start']} -> {row['end']}")
        for ax,label in zip(axes[:,0],['Current RGB','MODEL\nprediction','Actual rollout\nRGB at t+16']):ax.set_ylabel(label)
        fig.suptitle('ImageWAM | Native predicted future RGB | All six prespecified samples',fontsize=10,y=.99)
        fig.subplots_adjust(left=.085,right=.99,top=.9,bottom=.12,wspace=.045,hspace=.1)
        fig.text(.045,.04,'H16; actual trajectory replans every12steps. Generated images are not simulator observations.',fontsize=8)
        save(fig,name)
    figure(rows,'imagewam_future_rgb_sequence')
    figure(rows[:3],'imagewam_future_rgb_dual_1','dual')
    figure(rows[3:],'imagewam_future_rgb_dual_2','dual')
    with imageio.get_writer(folder/'future_rgb_comparison_slideshow.mp4',fps=1,codec='libx264',quality=9,macro_block_size=1) as writer:
        for row in rows:
            fig,axes=plt.subplots(1,3,figsize=(9,3.6),dpi=100)
            for ax,key,label in zip(axes,['current','predicted_future','actual_future'],['Current observation','MODEL predicted future','Actual rollout endpoint']):
                ax.imshow(np.asarray(Image.open(folder/row['folder']/f'{key}_front.png')));ax.set_title(label,fontsize=10);no_axis(ax)
            fig.suptitle(f"ImageWAM | t={row['start']} -> t={row['end']} | Six-sample slideshow, 1s/sample",fontsize=11)
            fig.subplots_adjust(left=.01,right=.99,bottom=.03,top=.85,wspace=.04)
            fig.canvas.draw();writer.append_data(np.asarray(fig.canvas.buffer_rgba())[:,:,:3].copy());plt.close(fig)

if __name__=='__main__':
    lawam();imagewam()
    (OUT/'code').mkdir(exist_ok=True)
    for file in ['lawam_paper_subgoals.py','imagewam_paper_future_rgb.py','render_prediction_media.py','subgoal_visual_math.py']:
        shutil.copy2(ROOT/'scripts'/file,OUT/'code'/file)
    print('Rendered LaWAM native subgoal figures/video and ImageWAM generated RGB comparisons.')
