"""Freeze a complete main-matrix work queue; this command does not use GPUs."""
import argparse,sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT
from fedwam.experiment_config import code_identity,METHODS
from fedwam.round_runtime import atomic_json
from fedwam.work_queue import WorkQueue

def make_plan(name,shards=16):
 if not name or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in name):raise ValueError('Simple experiment name required')
 if shards<1:raise ValueError('Positive evaluation shards required')
 base=ROOT/'runs'/name;tasks=[];runs=[]
 order=['M1','M2','M4','M6','M7','M8','M5','M3','Local-adapter','M9']
 for seed in (42,43,44):
  for method in order:
   run=base/method/f'seed{seed}';tag=f'{method}-s{seed}';runs.append(str(run))
   tasks.append({'id':tag+'-train','kind':'train','depends':[],
    'argv':[str(ROOT/'.venv/bin/python'),'-u',str(ROOT/'scripts/train_federated.py'),'--method',method,'--seed',str(seed),'--mode','formal','--run',str(run)]})
 for seed in (42,43,44):
  for method in order:
   run=base/method/f'seed{seed}';tag=f'{method}-s{seed}';clients=['pooled'] if method=='M9' else ['lighting','camera_pose','sensor_noise','background']
   for client in clients:
    for index in range(shards):
     argv=[str(ROOT/'.venv/bin/python'),'-u',str(ROOT/'scripts/evaluate_federated.py'),'--run',str(run),'--client',client,'--index',str(index),'--count',str(shards)]
     tasks.append({'id':f'{tag}-{client}-rollout-{index:02d}','kind':'rollout','depends':[tag+'-train'],'argv':argv})
     tasks.append({'id':f'{tag}-{client}-prediction-{index:02d}','kind':'prediction','depends':[tag+'-train'],'argv':argv+['--prediction-test','--prediction-scope','all-chunks']})
 return {'schema':'fedwam.work-plan.v1','name':name,'code':code_identity(),'root':str(base),'runs':runs,'tasks':tasks,
  'max_gpu_workers':4,'training_jobs':30,'rollout_cases':sum((1 if m=='M9' else 4)*3*10030 for m in order),
  'scope':'full main methods M1–M9 plus Local-adapter,3seeds,4trainingclients,7evalcategories;M0 separate',
  'prediction_scope':'all accepted held-out chunks; original-LIBERO50trial replication and history/cross-embodiment extensions separate'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--name',default='fedwam_official_full');p.add_argument('--shards',type=int,default=16);args=p.parse_args()
 plan=make_plan(args.name,args.shards);path=ROOT/'manifests'/f'{args.name}_work_plan.json'
 if path.exists() and json.loads(path.read_text())!=plan:raise ValueError('Existing frozen plan differs; choose new experiment name')
 atomic_json(path,plan);WorkQueue(Path(plan['root'])/'scheduler',plan['tasks'])
 print(json.dumps({'plan':str(path),'tasks':len(plan['tasks']),'training_jobs':plan['training_jobs'],'rollout_cases':plan['rollout_cases'],'max_gpu_workers':4},indent=2))
if __name__=='__main__':main()
