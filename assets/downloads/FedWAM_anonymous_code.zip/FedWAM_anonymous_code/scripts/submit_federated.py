"""Idempotently submit the <=4-GPU DAG without interrupting active M0 workers."""
import argparse, fcntl, json, os, re, subprocess, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from fedwam.io import ROOT, load, file_hash
from fedwam.round_runtime import atomic_json
from fedwam.experiment_config import code_identity


def command(args):
    return subprocess.check_output(args, text=True).strip()


def own_baseline(job):
    text = command(['scontrol', 'show', 'job', '-o', job])
    uids = re.findall(r'UserId=\S+\((\d+)\)', text)
    if not uids or any(int(x) != os.getuid() for x in uids) or 'JobName=fwfull-M0 ' not in text:
        raise ValueError('Expected own active M0 array')
    return text


def submit_dag(state, location):
    """Held jobs make interrupted creation safe; comments recover a lost receipt.

    Accounting is disabled on this cluster. Held jobs remain in squeue until the
    complete DAG is durably recorded, so recovery does not depend on sacct.
    """
    def submit(key, *options):
        if key in state['jobs']:
            return state['jobs'][key]
        marker = 'fedwam:' + state['plan_sha256'][:24] + ':' + key
        rows = command(['squeue', '-u', str(os.getuid()), '-h', '-o', '%i|%k']).splitlines()
        matches = {row.split('|')[0].split('_')[0] for row in rows if row.partition('|')[2] == marker}
        if len(matches) > 1:
            raise ValueError('Duplicate scheduler marker: ' + marker)
        job = matches.pop() if matches else command(['sbatch', '--parsable', '--hold', '--comment=' + marker, *options]).split(';')[0]
        if not job.isdigit():
            raise ValueError('Invalid scheduler job ID')
        state['jobs'][key] = job
        atomic_json(location, state)
        return job

    intern_baseline = state['baseline_intern']
    staff_baseline = state['baseline_staff']
    plan = state['plan']
    eng = submit('engineering', '--dependency=afterany:' + state['baseline_predecessor'], str(ROOT / 'scripts/federation_engineering.slurm'))
    submit('restore_baseline', '--dependency=afterany:' + eng, str(ROOT / 'scripts/restore_baseline_slots.slurm'), intern_baseline)
    intern = submit('intern_workers', '--gres=gpu:intern:1', '--array=0-1%2', f'--dependency=afterok:{eng},afterany:{intern_baseline}', str(ROOT / 'scripts/federated_worker.slurm'), plan)
    staff = submit('staff_workers', '--gres=gpu:staff:1', '--array=2-3%2', f'--dependency=afterok:{eng},afterany:{staff_baseline}', str(ROOT / 'scripts/federated_worker.slurm'), plan)
    submit('final_report', f'--dependency=afterany:{intern}:{staff}', str(ROOT / 'scripts/federated_finalize.slurm'), plan)
    if state['state'] == 'submitting':
        # Do this only after the full held DAG (including restoration) exists.
        # A repeated update before the state write is harmless: engineering is held.
        current = subprocess.run(['scontrol', 'show', 'job', '-o', intern_baseline], capture_output=True, text=True)
        if current.returncode == 0:
            own_baseline(intern_baseline)
            subprocess.run(['scontrol', 'update', f'JobId={intern_baseline}', 'ArrayTaskThrottle=1'], check=True)
        state['state'] = 'releasing'
        atomic_json(location, state)
    # Engineering goes last, after its automatic throttle-restoration successor.
    for key in ('restore_baseline', 'intern_workers', 'staff_workers', 'final_report', 'engineering'):
        if key in state.setdefault('released', []):
            continue
        job = state['jobs'][key]
        result = subprocess.run(['scontrol', 'show', 'job', '-o', job], capture_output=True, text=True)
        if result.returncode == 0 and ('Reason=JobHeldUser' in result.stdout or 'Reason=JobHeldAdmin' in result.stdout):
            if 'Reason=JobHeldAdmin' in result.stdout:
                raise RuntimeError('Administrator-held job requires investigation: ' + job)
            subprocess.run(['scontrol', 'release', job], check=True)
        state['released'].append(key)
        atomic_json(location, state)
    state['state'] = 'submitted'
    atomic_json(location, state)
    return state


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--baseline-intern', default='9022')
    p.add_argument('--baseline-staff', default='9025')
    p.add_argument('--replace-smoke', default='9079')
    args = p.parse_args()
    planpath = args.plan.resolve()
    plan = load(planpath)
    if plan['code'] != code_identity():
        raise ValueError('Plan implementation changed')
    location = ROOT / 'reports/scheduling' / f"{plan['name']}_jobs.json"
    location.parent.mkdir(parents=True, exist_ok=True)
    with location.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if location.exists():
            state = load(location)
            if state['plan_sha256'] != file_hash(planpath):
                raise ValueError('Submitted plan changed')
            if state['state'] == 'submitted':
                print(json.dumps(state, indent=2))
                return
        else:
            own_baseline(args.baseline_intern)
            own_baseline(args.baseline_staff)
            queue = command(['squeue', '-u', str(os.getuid()), '-h', '-o', '%i|%j|%T']).splitlines()
            if any('fwfull-federation-worker' in line or 'fwfull-round-engineering' in line for line in queue):
                raise ValueError('Another full federation schedule already exists')
            candidates = [line.split('|')[0] for line in queue if line.startswith(args.baseline_intern + '_') and '|RUNNING' in line]
            if not candidates:
                raise ValueError('No current intern baseline worker to release a slot naturally')
            predecessor = sorted(candidates, key=lambda x: int(x.split('_')[1]))[0]
            smoke = [line for line in queue if line.startswith(args.replace_smoke + '|')]
            if smoke:
                if smoke[0].split('|')[1:] != ['fwfull-official-train-smoke', 'PENDING']:
                    raise ValueError('Do not replace an active or unknown job')
                subprocess.run(['scancel', args.replace_smoke], check=True)
            state = {'plan': str(planpath), 'plan_sha256': file_hash(planpath), 'jobs': {}, 'max_total_gpus': 4,
                     'baseline_intern': args.baseline_intern, 'baseline_staff': args.baseline_staff,
                     'baseline_predecessor': predecessor, 'state': 'submitting'}
            atomic_json(location, state)
        print(json.dumps(submit_dag(state, location), indent=2))


if __name__ == '__main__':
    main()
