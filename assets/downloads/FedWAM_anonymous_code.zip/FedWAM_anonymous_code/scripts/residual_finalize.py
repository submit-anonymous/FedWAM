"""Freeze only the developed readout/graph receipt, never formal experiment admission."""
import hashlib
import json
import math
from pathlib import Path
from imagewam_model_acceptance import write
ROOT=Path(__file__).resolve().parents[1]


def sha(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def validate_domains(rows):
    if len(rows)!=4 or {r['domain'] for r in rows}!={'lighting','camera_pose','sensor_noise','background'}:
        raise ValueError('Expected exactly four distinct developed client domains')


def graph_matches(row,graph):
    positives=[graph.get(k) for k in ('world_gradient_norm','prediction_change','action_change')]
    return (graph.get('passed') is True and graph.get('seed')==42 and graph.get('domain')==row['domain']
        and graph.get('artifact_sha256')=='imagewam-native1000-residual-'+row['sha256']
        and graph.get('future_label_effect')==0 and graph.get('action_unchanged') is True and graph.get('head_frozen') is True
        and all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and v>0 for v in positives))


def main():
    summary=json.loads((ROOT/'reports/heterogeneous/residual_development_summary.json').read_text())
    validate_domains(summary['clients'])
    clients=[]
    for row in summary['clients']:
        domain=row['domain'];head=Path(row['head'])
        if sha(head)!=row['sha256']:raise ValueError('Selected head artifact changed')
        r=json.loads((head.parent/'result.json').read_text())
        if r['seed']!=42 or r['domain']!=domain or r['arms']['residual']['steps']!=4000:
            raise ValueError('Selected result identity mismatch')
        if r['arms']['residual']['summary']['development']['mse']!=row['residual_mse']:
            raise ValueError('Summary does not match original result')
        path=ROOT/f'reports/heterogeneous/residual-graph-{domain}-10486/result.json'
        graph=json.loads(path.read_text()) if path.exists() else {}
        passed=graph_matches(row,graph)
        clients.append(dict(**row,graph_passed=passed,graph=graph,native_adaptation=r['identity']['native_adaptation']))
    files=('src/fedwam/heterogeneous/residual_adapter.py','src/fedwam/heterogeneous/residual_readout.py',
           'src/fedwam/heterogeneous/readout_diagnostics.py','src/fedwam/heterogeneous/reference.py',
           'src/fedwam/heterogeneous/interface.py','src/fedwam/heterogeneous/spatial_readout.py',
           'src/fedwam/heterogeneous/adapters.py','scripts/imagewam_residual_graph.py')
    ready=all(r['graph_passed'] and r['residual_mse']<r['copy_mse'] for r in clients)
    receipt=dict(seed=42,selected_readout='current_plus_world_delta' if ready else None,
        development_interface_ready=ready,formal_admission=False,formal_federation_started=False,
        clients=clients,code={p:sha(ROOT/p) for p in files},reference_tensor_dtype='float32',reference_conv_tf32=True,
        scope='Developed ImageWAM common-future readout with actual world/control graph checks',
        remaining=['Integrate eight-client resumable multi-round training with native post-reception updates',
                   'Freeze equal-budget Interface Local and sharing controls, storage and full rollout protocol',
                   'Evaluate held-out prediction quality and control success after protocol freeze'])
    write(ROOT/'manifests/heterogeneous_residual_readout_seed42_v1.json',receipt)
    print('Readout and real model graph gates:',sum(c['graph_passed'] for c in clients),'/4')
    print('Development interface ready:',ready,'| Formal federation admitted: False')


if __name__=='__main__':main()
