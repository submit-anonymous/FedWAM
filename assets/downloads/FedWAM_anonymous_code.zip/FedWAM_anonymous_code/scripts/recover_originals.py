"""Reuse local original LIBERO HDF5, downloading only missing tasks from pinned HF."""
import concurrent.futures, hashlib, json, os, sys, time
from pathlib import Path
import requests
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT, load, save, status

OUT=ROOT/'reports/data/originals'
LOCAL=Path('/workspace/reference_assets/original_libero')

def main():
    api=load(ROOT/'reports/data/provenance_research/original_libero_api.json')
    entries={r['rfilename']:r for r in api['siblings']}
    tasks=sorted({(r['suite'],r['source_file']) for r in load(ROOT/'manifests/raw_episodes.json')['rows']})
    def one(task):
        suite,name=task;relative=f'{suite}/{name}';entry=entries[relative]
        local=LOCAL/relative;dest=ROOT/'data/original_libero'/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        if local.is_file():
            path=local;origin='existing_readonly'
        else:
            path=dest;origin='official_pinned_download'
            if not dest.exists():
                url=f'https://huggingface.co/datasets/yifengzhu-hf/LIBERO-datasets/resolve/{api["sha"]}/{relative}'
                part=dest.with_name(dest.name+'.partial')
                for attempt in range(6):
                    try:
                        with requests.get(url,stream=True,timeout=(30,120)) as response:
                            response.raise_for_status()
                            with part.open('wb') as f:
                                for b in response.iter_content(4*1024**2):f.write(b)
                        if part.stat().st_size!=entry['size']:raise ValueError('Original HDF5 size mismatch')
                        h=hashlib.sha256()
                        with part.open('rb') as f:
                            for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
                        if h.hexdigest()!=entry['lfs']['sha256']:raise ValueError('Original HDF5 SHA256 mismatch')
                        os.replace(part,dest);break
                    except Exception:
                        if attempt==5:raise
                        time.sleep(2**attempt)
        import h5py
        with h5py.File(path,'r') as h:
            demos=len(h['data'])
            if demos!=50 or any('states' not in d or 'actions' not in d for d in h['data'].values()):
                raise ValueError('Original data contract failed')
        record=dict(suite=suite,source_file=name,path=str(path),origin=origin,episodes=demos,
                    revision=api['sha'] if origin=='official_pinned_download' else None,
                    sha256=entry['lfs']['sha256'] if origin=='official_pinned_download' else None)
        save(OUT/'tasks'/f'{suite}__{name}.json',record);return record
    results=[]
    with concurrent.futures.ThreadPoolExecutor(3) as pool:
        for result in pool.map(one,tasks):
            results.append(result);status(OUT,state='running',phase='original_hdf5',done=len(results),total=len(tasks))
    save(ROOT/'manifests/original_hdf5.json',{'rows':results,'scope':'original source ancestry, not actual PLUS replay initial-state proof'})
    status(OUT,state='completed',phase='original_hdf5',done=len(results),total=len(tasks))

if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));raise
