"""One independently scheduled private client; exit successfully at a dependency."""
import argparse,os,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,digest
from fedwam.experiment_config import resolved_config,identity,formal_gate,METHODS
from fedwam.detached_execution import detached_identity,check_gate
from fedwam.detached_engine import DetachedEngine,DependencyPending
from fedwam.round_runtime import atomic_json

def main():
 p=argparse.ArgumentParser();p.add_argument('--method',choices=METHODS,required=True)
 p.add_argument('--mode',choices=['engineering','formal'],required=True);p.add_argument('--run',type=Path,required=True)
 p.add_argument('--client',required=True);p.add_argument('--attempt',required=True);p.add_argument('--token',required=True);args=p.parse_args()
 if not os.environ.get('SLURM_JOB_ID'):raise RuntimeError('Slurm allocation required')
 cfg=resolved_config(args.method,43,args.mode);ident=detached_identity(cfg);root=args.run.resolve()
 if not root.is_relative_to(ROOT/'runs'):raise ValueError('Run outside project')
 clients=['pooled'] if args.method=='M9' else cfg['clients']
 if args.client not in clients:raise ValueError('Unknown client')
 if args.mode=='formal':check_gate(cfg,load(ROOT/'reports/detached_engineering/summary.json'))
 else:formal_gate(identity(cfg),load(ROOT/'reports/federation_engineering/summary.json'))
 result=root/f'client_job_state/{args.client}.json';transport=None;engine=None
 def status(**kw):atomic_json(result,dict(attempt=args.attempt,token=args.token,job=os.environ['SLURM_JOB_ID'],client=args.client,**kw))
 try:
  status(state='loading_model')
  import torch,acceptance
  from model_probe import frozen_hash
  from fedwam.lawam_federation import LaWAMFederation
  acceptance.OUT=root/'model_acceptance'/args.client/args.token
  policy,_,transport=acceptance.model()
  if torch.cuda.device_count()!=1:raise ValueError('Each client job must see exactly one GPU')
  uuid=str(getattr(torch.cuda.get_device_properties(0),'uuid',''))
  if not uuid:raise ValueError('Missing GPU UUID')
  interface=digest({k:ident[k] for k in ('data_identity','checkpoint_sha256','normalization_sha256','model_config_sha256')})+':deployed-intent:H8:20Hz:'+cfg['representation']
  backend=LaWAMFederation(policy,cfg,root,interface);backend._enable('pre');frozen=frozen_hash(policy)
  engine=DetachedEngine(root,ident,cfg,backend,args.client,args.attempt)
  pending=None;ref=None
  try:ref=engine.run_client()
  except DependencyPending as error:pending=error.name
  backend._enable('pre')
  if frozen_hash(policy)!=frozen:raise ValueError('Frozen foundation/intent changed')
  if pending:
   status(state='waiting_dependency',wait=pending,gpu_uuid=uuid,gpu_released_on_exit=True)
  else:
   state=engine.store.read_ref(ref)['state']
   changed={k:any(not torch.equal(v,getattr(backend,'base_'+k)[name]) for name,v in state[k].items()) for k in ('world','action')}
   changed['updates']=state['total_updates']
   if not changed['world'] or not changed['action']:raise ValueError('Expected private updates absent')
   atomic_json(root/f'client_verification/{args.client}.json',dict(passed=True,identity=ident,attempt=args.attempt,ref=ref,module_updates=changed,frozen_sha256=frozen,gpu_uuid=uuid))
   status(state='training_completed',gpu_uuid=uuid)
 except Exception as error:
  if engine:engine.fail(error)
  status(state='failed',error=repr(error));raise
 finally:
  if transport:transport.close()
if __name__=='__main__':main()
