"""CPU preparation checks; does not claim GPU inference or scientific acceptance."""
import importlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    import av
    import numpy as np
    import pyarrow.parquet as pq
    from hydra import compose, initialize_config_dir
    from omegaconf import OmegaConf
    checks = {}
    for module in ('imagewam.runtime','imagewam.datasets.lerobot.robot_video_dataset',
                   'flux2.model','flux2.autoencoder','flux2.text_encoder',
                   'libero.libero.benchmark','libero.libero.envs'):
        try:
            importlib.import_module(module); checks[module] = 'ok'
        except Exception as e:
            checks[module] = repr(e)
    data = []
    for dataset in sorted((ROOT/'data/imagewam_libero').glob('*_lerobot')):
        info = json.loads((dataset/'meta/info.json').read_text())
        table = pq.read_table(next(dataset.glob('data/**/*.parquet')))
        actions = np.asarray(table['action'].to_pylist())
        assert actions.ndim == 2 and actions.shape[1] == 7 and np.isfinite(actions).all()
        cameras = []
        for key in ('observation.images.image','observation.images.wrist_image'):
            video = next(dataset.glob('videos/**/'+key+'/*.mp4'))
            with av.open(str(video)) as container:
                frame = next(container.decode(video=0)).to_ndarray(format='rgb24')
            assert frame.shape == (512,512,3)
            cameras.append({'key':key,'video':str(video),'shape':list(frame.shape)})
        data.append({'suite':dataset.name,'fps':info['fps'],'action_shape':list(actions.shape),'cameras':cameras})
    with initialize_config_dir(version_base=None, config_dir=str(ROOT/'third_party/ImageWAM/configs')):
        cfg=compose(config_name='sim_libero_omnigen2',overrides=[
            'task=libero_flux2_klein_4b_base_imagewam','seed=42','wandb.enabled=false',
            'model.flux2_src_path='+os.environ['FLUX2_SRC'],
            'model.flux2_model_path='+os.environ['FLUX2_MODEL_PATH'],
            'model.ae_model_path='+os.environ['FLUX2_AE_MODEL_PATH'],
            'model.qwen3_model_spec='+os.environ['FLUX2_QWEN3_MODEL_SPEC'],
            'ckpt='+os.environ['CKPT_PATH'],
            'EVALUATION.dataset_stats_path='+os.environ['DATASET_STATS_PATH'],
            'EVALUATION.action_horizon=16','EVALUATION.replan_steps=12',
            'data.train.dataset_dirs=['+','.join(str(p) for p in sorted((ROOT/'data/imagewam_libero').glob('*_lerobot')))+']',
            'data.train.qwen_text_cache_dir='+os.environ['QWEN_CACHE_DIR']])
        OmegaConf.save(cfg,ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    result={'scope':'CPU assets/import/config/data checks only','seed':42,'imports':checks,
            'datasets':data,'passed':len(data)==4 and all(v=='ok' for v in checks.values()),
            'gpu_inference_completed':False,'fedwam_h8_adapter_validated':False}
    (ROOT/'reports/imagewam_preparation/cpu_validation.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'passed':result['passed'],'decoded_suites':len(data),'imports':checks},indent=2))
    if not result['passed']:raise SystemExit(1)


if __name__=='__main__':main()
