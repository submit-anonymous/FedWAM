"""Observe reset, full-state loading and settling; do not change native evaluation."""
import re,sys,contextlib,io
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status
OUT=ROOT/'reports/data/robot_initialization_probe'
def main():
    from libero.libero.envs.env_wrapper import ControlEnv
    native=load(ROOT/'reports/data/overlap/native_initial_states.json')['rows'];rows=[]
    for suite in sorted({x['suite'] for x in native}):
        row=next(r for r in native if r['suite']==suite and r['category']=='robot_initial')
        path=ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files'/suite/(row['name']+'.bddl')
        results={}
        for mode,p in [('native',path),('zero_initial_variant',path.with_name(re.sub(r'_initstate_\d+','_initstate_0',path.name)))]:
            env=ControlEnv(bddl_file_name=str(p),use_camera_obs=False,has_offscreen_renderer=False,has_renderer=False)
            try:
                env.seed(42);env.reset();indices=env.robots[0]._ref_joint_pos_indexes
                stages={'configured_init_qpos':np.asarray(env.robots[0].init_qpos).tolist(),'after_reset':env.sim.data.qpos[indices].copy().tolist()}
                env.set_init_state(np.asarray(row['state']));stages['after_set_init_state']=env.sim.data.qpos[indices].copy().tolist()
                for _ in range(10):env.step([0,0,0,0,0,0,-1])
                stages['after_10_settling_steps']=env.sim.data.qpos[indices].copy().tolist();results[mode]=stages
            finally:env.close()
        differences={stage:float(np.max(np.abs(np.asarray(results['native'][stage])-np.asarray(results['zero_initial_variant'][stage])))) for stage in results['native']}
        rows.append({'suite':suite,'variant':row['variant_id'],'name':row['name'],'stages':results,'native_vs_zero_max_joint_difference':differences})
        status(OUT,state='running',phase='actual_joint_state_probe',done=len(rows),total=4)
    save(OUT/'result.json',{'rows':rows,'scope':'four representative native paired checks, not all robot variants; existing evaluation unchanged'})
    status(OUT,state='completed',phase='actual_joint_state_probe',done=len(rows),total=4)
if __name__=='__main__':
    try:main()
    except Exception as e:status(OUT,state='failed',error=repr(e));raise
