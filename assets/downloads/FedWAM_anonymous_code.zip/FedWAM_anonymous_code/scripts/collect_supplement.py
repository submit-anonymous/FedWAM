"""Fresh closed-loop official-SFT collection, with full provenance and no-op preservation."""
import argparse,io,os,random,sys,time,traceback
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from fedwam.io import ROOT,load,save,status,digest,file_hash
from fedwam.collection import collection_plan,perturb,corrupt_observation,validate_episode
from fedwam.provenance import state_matches
import acceptance
OUT=ROOT/'reports/data/supplement'
DATA=ROOT/'data/fresh_supplement_v1'

def forbidden_instructions():
    import re
    root=ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files';values=set()
    for suite in ['libero_spatial','libero_object','libero_goal','libero_10']:
        for p in (root/suite).glob('*.bddl'):
            hit=re.search(r'\(:language\s+(.*?)\)',p.read_text(),flags=re.S)
            if hit:values.add(' '.join(hit[1].split()))
    return values

def encode_image(array):
    from PIL import Image
    buffer=io.BytesIO();Image.fromarray(array).save(buffer,format='JPEG',quality=95,subsampling=0)
    return np.frombuffer(buffer.getvalue(),dtype=np.uint8)

def attempt(row,number,client,transport,native,forbidden,fresh):
    import torch,h5py
    from libero.libero.envs import OffScreenRenderEnv
    from examples.LIBERO.eval_files.libero_eval_core import _build_policy_example_from_obs,_response_to_delta_action
    cell=OUT/'attempts'/row['id']/f'{number:02d}';cell.mkdir(parents=True,exist_ok=True)
    filename=row['source_file'].replace('_demo.hdf5','.bddl')
    path=ROOT/'third_party/LIBERO-plus/libero/libero/bddl_files/libero_mix'/filename
    seed=(row['recipe_seed']+number*7919)%(2**32);random.seed(seed);np.random.seed(row['reset_seed']);torch.manual_seed(seed)
    rng=np.random.default_rng(seed);env=OffScreenRenderEnv(bddl_file_name=str(path),camera_heights=256,camera_widths=256)
    result={'case':row,'attempt':number,'seed':seed,'success':False,'accepted':False};start=time.perf_counter()
    try:
        reset=fresh[row['source_group']]
        if list(env.sim.model.joint_names)!=reset['joint_names']:raise ValueError('Fresh initial-state joint schema mismatch')
        if file_hash(reset['path'])!=reset['sha256']:raise ValueError('Fresh initial-state artifact changed')
        env.seed(reset['seed']);env.reset()
        base_state=np.load(reset['path'])['state'].copy();obs=env.set_init_state(base_state)
        counterfactual_state=None;counterfactual_qpos=None
        if row['client'] in ('robot_initial','object_layout'):
            for _ in range(10):env.step([0,0,0,0,0,0,-1])
            counterfactual_state=env.get_sim_state().copy();counterfactual_qpos=env.sim.data.qpos.copy()
            env.seed(reset['seed']);env.reset();obs=env.set_init_state(base_state)

        recipe,obs=perturb(env,row['client'],seed,env.language_instruction,forbidden)
        perturbed_state=env.get_sim_state().copy();language=recipe.get('instruction',env.language_instruction)
        # Compare freshly generated states with every compatible published variant, before settling.
        relevant=[x for x in native if x['suite']==row['suite'] and x['name'].startswith(filename[:-5]) and len(x['state'])==len(base_state)]
        if not relevant:raise ValueError('No compatible published states available for overlap guard')
        candidates=np.asarray([x['state'] for x in relevant]);hits=state_matches(base_state,candidates)+state_matches(perturbed_state,candidates)
        nearest=float(np.min(np.max(np.abs(candidates[:,1:]-perturbed_state[None,1:]),axis=1)))
        if hits or nearest<1e-4:raise ValueError('Fresh initialization overlaps a published state')
        warmup=[]
        for _ in range(10):
            obs,_,_,_=env.step([0,0,0,0,0,0,-1]);warmup.append(env.get_sim_state().copy())
        if row['client']=='robot_initial':
            actual=env.sim.data.qpos[env.robots[0]._ref_joint_pos_indexes].copy()
            recipe['after_settling_qpos']=actual.tolist()
            recipe['effective_joint_delta_linf']=float(np.max(np.abs(actual-counterfactual_qpos[env.robots[0]._ref_joint_pos_indexes])))
            if recipe['effective_joint_delta_linf']<.02:raise ValueError('Perturbation ineffective after settling')
        elif row['client']=='object_layout':
            actual=[np.asarray(env.sim.data.get_joint_qpos(x['joint'])).copy() for x in recipe['joint_changes']]
            recipe['after_settling_joint_positions']=[x.tolist() for x in actual]
            reference=[counterfactual_qpos[env.sim.model.get_joint_qpos_addr(old['joint'])[0]:env.sim.model.get_joint_qpos_addr(old['joint'])[0]+2] for old in recipe['joint_changes']]
            recipe['effective_xy_delta_linf']=max(float(np.max(np.abs(x[:2]-ref))) for x,ref in zip(actual,reference))
            if recipe['effective_xy_delta_linf']<.004:raise ValueError('Perturbation ineffective after settling')
        if env.check_success():raise ValueError('Goal already satisfied before policy rollout')
        # Changed pose may cause invalid placements; do not silently count these as valid demos.
        if not np.isfinite(env.get_sim_state()).all():raise ValueError('Invalid settled state')
        client.reset(task_description=language);states=[];times=[];actions=[];fronts=[];wrists=[];proprio=[];calls=[]
        xml=env.sim.model.get_xml();hz=float(env.env.control_freq)
        if hz!=20:raise ValueError('Unexpected native control rate')
        max_steps={'libero_spatial':250,'libero_object':300,'libero_goal':320,'libero_10':550}[row['suite']]
        def record_observation(obs):
            example,front,wrist=_build_policy_example_from_obs(obs,language)
            states.append(env.get_sim_state().copy());times.append(float(env.sim.data.time))
            fronts.append(encode_image(front));wrists.append(encode_image(wrist));proprio.append(example['state'][0])
            return example
        for step in range(max_steps):
            obs=corrupt_observation(obs,recipe,rng);example=record_observation(obs);old=len(transport.calls)
            response=client.step(example=example,step=step);action=_response_to_delta_action(response,language,step)
            if len(transport.calls)>old:calls.append(step)
            actions.append(np.asarray(action));obs,_,done,_=env.step(action.tolist())
            if done:break
        obs=corrupt_observation(obs,recipe,rng);record_observation(obs)
        result.update(success=bool(done),steps=len(actions),recipe=recipe,language=language,
            source_bddl=str(path),source_bddl_sha256=file_hash(path),xml_sha256=__import__('hashlib').sha256(xml.encode()).hexdigest(),
            nearest_published_state_linf=nearest,compared_published_states=len(candidates),
            reset_seed=reset['seed'],fresh_reset_source=reset,step_hz=hz,policy_call_steps=calls,
            simulator_state_storage='full flattened state at every observation, including terminal observation',
            image_orientation='official LaWAM interface rotates both axes; JPEG95 no chroma subsampling',
            collection_kind='FedWAM self-collected native LIBERO-compatible perturbations; not official PLUS demonstrations')
        if done:
            validate_episode(actions,states,times,done)
            if calls!=list(range(0,len(actions),8)):raise ValueError('Wrong action chunk cadence')
            DATA.mkdir(parents=True,exist_ok=True);target=DATA/f'{row["id"]}.hdf5';tmp=target.with_name(target.name+f'.{os.getpid()}.partial')
            with h5py.File(tmp,'w') as h:
                for key,value in [('actions',actions),('sim_states',states),('sim_times',times),('state7',proprio),
                                  ('base_reset_state',base_state),('perturbed_reset_state',perturbed_state),('warmup_states',warmup)]:
                    h.create_dataset(key,data=np.asarray(value),compression='gzip')
                for key,images in [('front_jpeg',fronts),('wrist_jpeg',wrists)]:
                    dataset=h.create_dataset(key,(len(images),),dtype=h5py.vlen_dtype(np.dtype('uint8')))
                    for i,value in enumerate(images):dataset[i]=value
                h.attrs['metadata']=__import__('json').dumps(result);h.attrs['model_xml']=xml
                if counterfactual_state is not None:h.create_dataset('unperturbed_settled_reference_state',data=counterfactual_state)
                for key in ('cam_pos','cam_quat','light_pos','light_dir','light_diffuse','light_ambient','light_specular'):
                    h.create_dataset('model_parameters/'+key,data=np.asarray(getattr(env.sim.model,key)))
                # Runtime texture edits are stored in addition to XML so replay does not use original textures.
                if row['client']=='background':h.create_dataset('texture_rgb',data=env.sim.model.tex_rgb,compression='gzip')
            with h5py.File(tmp,'r') as h:validate_episode(h['actions'][:],h['sim_states'][:],h['sim_times'][:],True)
            os.replace(tmp,target);result.update(accepted=True,path=str(target),sha256=file_hash(target))
        result['elapsed_seconds']=time.perf_counter()-start
    except Exception as e:
        result.update(error=repr(e),elapsed_seconds=time.perf_counter()-start,
                      expected_rejection=any(x in str(e) for x in ('outside joint limits','overlaps a published state','Goal already satisfied','Perturbation ineffective')))
        if not result['expected_rejection']:traceback.print_exc()
    finally:env.close()
    save(cell/'result.json',result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--index',type=int,default=0);p.add_argument('--count',type=int,default=16);p.add_argument('--pilot',action='store_true');args=p.parse_args()
    check=load(ROOT/'reports/data/collection_acceptance/summary.json')
    if check['passed']!=28:raise RuntimeError('All recipe/suite acceptance cells must pass')
    if check.get('recipe_sha256')!=file_hash(ROOT/'src/fedwam/collection.py'):raise RuntimeError('Collection recipes changed after native acceptance')
    overlap=load(ROOT/'reports/data/overlap/summary.json')
    if overlap['native_cases']!=10030:raise RuntimeError('Full benchmark initialization audit required')
    rows=load(ROOT/'manifests/raw_episodes.json')['rows'];plan=collection_plan(rows)
    planpath=ROOT/'manifests/fresh_collection_plan.json'
    if not planpath.exists():raise RuntimeError('Freeze collection manifest before launch')
    if load(planpath)['rows']!=plan:raise RuntimeError('Collection plan drift')
    if args.pilot:
        selected=[]
        for suite in sorted({r['suite'] for r in plan}):
            task=min(r['source_file'] for r in plan if r['suite']==suite)
            selected.extend(r for r in plan if r['suite']==suite and r['source_file']==task and r['group_index']==0)
    else:
        pilot=load(OUT/'pilot.json')
        if pilot.get('accepted_cells')!=28:raise RuntimeError('All 28 closed-loop pilot cells must have accepted demos before expansion')
        selected=plan[args.index::args.count]
    worker=OUT/('pilot_worker' if args.pilot else f'workers/{args.index:03d}')
    acceptance.OUT=worker;policy,client,transport=acceptance.model()
    native=load(ROOT/'reports/data/overlap/published_init_reserve.json')['rows'];forbidden=forbidden_instructions()
    reset_manifest=load(ROOT/'manifests/fresh_initial_states.json')
    if reset_manifest['plan_sha256']!=file_hash(planpath):raise ValueError('Fresh reset manifest plan mismatch')
    fresh={r['source_group']:r for r in reset_manifest['rows']}
    if len(fresh)!=2000:raise ValueError('All 2000 fresh initial states required')
    identity={'recipe_sha256':file_hash(ROOT/'src/fedwam/collection.py'),'collector_sha256':file_hash(Path(__file__)),
        'plan_sha256':file_hash(planpath),'fresh_resets_sha256':file_hash(ROOT/'manifests/fresh_initial_states.json'),'checkpoint_sha256':file_hash(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'),
        'acceptance_sha256':file_hash(ROOT/'reports/data/collection_acceptance/summary.json')}
    accepted=0;failed=0;execution_errors=0
    for index,row in enumerate(selected):
        receipt=OUT/'episodes'/f'{row["id"]}.json'
        if receipt.exists():
            previous=load(receipt)
            if previous.get('identity')!=identity:raise RuntimeError('Existing episode identity differs; preserve artifact and diagnose')
            if previous.get('accepted'):accepted+=1;continue
        status(worker,state='running',phase='closed_loop_collection',done=index,total=len(selected),accepted=accepted,failed=failed,current=row['id'])
        import shutil
        if shutil.disk_usage(DATA.parent).free<80*1024**3:raise RuntimeError('Collection stopped at 80GiB free-space reserve')
        for number in range(4):
            result=attempt(row,number,client,transport,native,forbidden,fresh)
            if result['accepted']:break
        result['identity']=identity;save(receipt,result)
        execution_errors=execution_errors+1 if result.get('error') and not result.get('expected_rejection') else 0
        if execution_errors>=3:
            status(worker,state='failed',phase='execution_error_guard',accepted=accepted,failed=failed+1,error=result['error'])
            raise RuntimeError('Three consecutive collection execution errors; stopped without wasting the remaining collection budget')
        accepted+=int(result['accepted']);failed+=int(not result['accepted'])
    result=dict(state='completed' if failed==0 else 'incomplete_coverage',phase='closed_loop_collection',accepted=accepted,failed=failed,total=len(selected),identity=identity)
    status(worker,**result)
    if args.pilot:save(OUT/'pilot.json',dict(result,accepted_cells=accepted))
    if failed:raise RuntimeError(f'{failed} collection cells lack successful demonstrations; do not invent quota completion')
if __name__=='__main__':main()
