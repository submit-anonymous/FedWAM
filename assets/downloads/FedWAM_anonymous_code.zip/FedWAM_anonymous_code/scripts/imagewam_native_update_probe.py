"""Full native H8 backward/AdamW resource check, no saved scientific checkpoint."""
import gc
import json
import os
from pathlib import Path
import sys
import time
import traceback
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'third_party/ImageWAM')]
from imagewam_model_acceptance import check_keys,write


def run(output):
    import torch
    from hydra.utils import instantiate
    from omegaconf import OmegaConf
    from imagewam.trainer import Wan22Trainer
    from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
    from fedwam.heterogeneous.data import HeterogeneousDataset
    from fedwam.heterogeneous.imagewam import make_native_sample
    torch.manual_seed(42)
    status=dict(state='running',phase='load',seed=42,scope='full native update resource acceptance only')
    write(output/'status.json',status)
    cfg=OmegaConf.load(ROOT/'reports/imagewam_preparation/native_eval_config.yaml')
    model=instantiate(cfg.model,model_dtype=torch.bfloat16,device='cuda')
    hook=model.mot.register_load_state_dict_post_hook(lambda m,k:check_keys(k.missing_keys,k.unexpected_keys))
    try:
        payload=model.load_checkpoint(str(cfg.ckpt))
        if 'proprio_encoder' not in payload:raise ValueError('Missing proprio weights')
        del payload
    finally:hook.remove()
    processor=instantiate(cfg.data.train.processor).eval()
    processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
    sample=HeterogeneousDataset(ROOT,'B','lighting').sample(0)
    native=make_native_sample(sample,processor)
    native['text_hidden_states'],native['text_attention_mask']=model._encode_flux2_prompts([native['instruction']])
    # Frozen text encoding is cached for this update, exactly as official cached-text training.
    model.text_encoder.model.to('cpu')
    gc.collect();torch.cuda.empty_cache()
    Wan22Trainer._apply_dit_only_train_mode(model)
    parameters=[p for p in model.dit.parameters() if p.requires_grad]
    parameters += [p for p in model.proprio_encoder.parameters() if p.requires_grad]
    if len({id(p) for p in parameters})!=len(parameters):raise ValueError('Duplicate optimizer parameters')
    optimizer=torch.optim.AdamW(parameters,lr=float(cfg.learning_rate),weight_decay=float(cfg.weight_decay),
                                 betas=(.9,.95),foreach=False)
    trainable=sum(p.numel() for p in parameters)
    rows=[]
    for step in range(2):
        status.update(phase='native_forward_backward',step=step,trainable_parameters=trainable)
        write(output/'status.json',status)
        optimizer.zero_grad(set_to_none=True)
        start=time.monotonic()
        with torch.autocast('cuda',dtype=torch.bfloat16):
            loss,components=model.training_loss(native)
        if not torch.isfinite(loss):raise ValueError('Nonfinite native objective')
        loss.backward()
        norms={}
        for name,module in [('world',model.video_expert),('action',model.action_expert),('proprio',model.proprio_encoder)]:
            gradients=[p.grad for p in module.parameters() if p.requires_grad and p.grad is not None]
            if not gradients or not all(torch.isfinite(g).all() for g in gradients):
                raise ValueError('Invalid full native gradients: '+name)
            norms[name]=sum(float(g.float().square().sum()) for g in gradients)**.5
            if norms[name]==0:raise ValueError('Zero full native gradient: '+name)
        norm=torch.nn.utils.clip_grad_norm_(parameters,1.)
        status.update(phase='adamw_step',step=step)
        write(output/'status.json',status)
        optimizer.step()
        torch.cuda.synchronize()
        rows.append(dict(step=step+1,loss=float(loss),components=components,gradient_norms=norms,
                         gradient_norm_before_clip=float(norm),seconds=time.monotonic()-start,
                         peak_gpu_bytes=torch.cuda.max_memory_allocated()))
        write(output/'updates.json',rows)
    result=dict(passed=True,seed=42,updates=rows,trainable_parameters=trainable,
                native_freeze_policy='Wan22Trainer._apply_dit_only_train_mode',horizon=8,
                effective_batch=1,full_training_budget=False,
                optimizer='torch AdamW betas(.9,.95), foreach=False; no DeepSpeed FP32 master weights',
                scope='engineering acceptance; parameters discarded, no scientific checkpoint')
    write(output/'result.json',result)
    status.update(state='completed',phase='native_update_acceptance',step=2)
    write(output/'status.json',status)
    print(json.dumps(result))


if __name__=='__main__':
    output=ROOT/'reports/heterogeneous'/('native-update-'+os.environ['SLURM_JOB_ID'])
    try:run(output)
    except Exception as exc:
        path=output/'status.json'
        status=json.loads(path.read_text()) if path.exists() else {}
        status.update(state='failed',error=repr(exc)[:2000])
        write(path,status);traceback.print_exc();raise SystemExit(1)
