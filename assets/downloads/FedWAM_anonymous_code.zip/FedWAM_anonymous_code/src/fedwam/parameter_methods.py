"""Public world-only parameter exchange for M2, M3 and Local-adapter.

M2 averages absolute decoder states. M3 exchanges effective additive updates,
never averages the nonidentifiable LoRA factors. Artifacts contain no private
action expert or optimizer state. Pass the decoder itself, not a whole policy.
"""
from collections.abc import Mapping
import copy
import hashlib
import json
import math

import torch
from torch import nn
from torch.nn import functional as F

WORLD_SCHEMA = 'fedwam.world_parameters.v1'
ADAPTER_SCHEMA = 'fedwam.world_adapters.v1'
VERSION = 1
_PRIVATE_PARTS = {'action', 'action_expert', 'action_decoder', 'flow', 'optimizer',
                  'world_optimizer', 'action_optimizer', 'param_groups', 'state',
                  'policy_backend', 'policy', 'intent', 'backbone', 'actions',
                  'action_labels', 'future_target', 'future_labels', 'rng',
                  'exposure', 'draw', 'total_updates', 'lora_a', 'lora_b'}


def _key(key):
    if not isinstance(key, str) or not key or any(not p for p in key.split('.')):
        raise ValueError('Invalid module-local world key')
    if any(p.lower() in _PRIVATE_PARTS or 'optimizer' in p.lower() for p in key.split('.')):
        raise ValueError(f'Private/non-world state in public parameters: {key}')


def _state(state):
    if not isinstance(state, Mapping) or not state:
        raise ValueError('Expected nonempty module-local world tensor state')
    for key, value in state.items():
        _key(key)
        if not isinstance(value, torch.Tensor) or value.layout != torch.strided or value.is_complex():
            raise ValueError(f'Expected dense real world tensor: {key}')
        if value.device.type == 'meta' or not torch.isfinite(value).all():
            raise ValueError(f'Nonfinite/unmaterialized world tensor: {key}')
    return state


def average_world(states):
    """Uniform absolute-state mean on CPU; immutable integer buffers must agree."""
    if not isinstance(states, (list, tuple)) or not states:
        raise ValueError('At least one world state is required')
    for state in states:
        _state(state)
    reference = states[0]
    for state in states[1:]:
        if set(state) != set(reference):
            raise ValueError('World tensor keys disagree')
        for key, value in state.items():
            if value.shape != reference[key].shape or value.dtype != reference[key].dtype:
                raise ValueError(f'World tensor shape/dtype mismatch: {key}')
    result = {}
    for key, value in reference.items():
        if value.is_floating_point():
            total = torch.zeros(value.shape, dtype=torch.float64)
            for state in states:
                total.add_(state[key].detach().to(device='cpu', dtype=torch.float64), alpha=1 / len(states))
            result[key] = total.to(dtype=value.dtype)
        else:
            result[key] = value.detach().cpu().clone()
            if any(not torch.equal(result[key], state[key].detach().cpu()) for state in states[1:]):
                raise ValueError(f'Nonfloating world buffer differs: {key}')
    return result


def world_export(decoder):
    """Construct a strict public envelope from a module-local decoder state."""
    return {'schema': WORLD_SCHEMA, 'version': VERSION, 'module': 'world_decoder',
            'state': {k: v.detach().cpu().clone() for k, v in _state(decoder.state_dict()).items()}}


def validate_world_artifact(artifact):
    """Reject private checkpoint envelopes and return the checked tensor mapping."""
    if (not isinstance(artifact, Mapping) or set(artifact) != {'schema', 'version', 'module', 'state'}
            or artifact['schema'] != WORLD_SCHEMA or type(artifact['version']) is not int
            or artifact['version'] != VERSION
            or artifact['module'] != 'world_decoder'):
        raise ValueError('Invalid public world parameter schema')
    return _state(artifact['state'])


def _hash_state(state):
    h = hashlib.sha256()
    for key, value in sorted(_state(state).items()):
        value = value.detach().cpu().contiguous()
        header = json.dumps([key, str(value.dtype), list(value.shape)]).encode()
        h.update(len(header).to_bytes(8, 'little')); h.update(header)
        h.update(value.reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


class _AdapterLinear(nn.Module):
    """Unit-scaled BA update with a frozen original Linear and efficient forward."""
    def __init__(self, base, rank, generator):
        super().__init__()
        self.base = base
        self.in_features = base.in_features; self.out_features = base.out_features
        a = torch.empty(rank, base.in_features, dtype=torch.float32)
        a.uniform_(-1 / math.sqrt(base.in_features), 1 / math.sqrt(base.in_features), generator=generator)
        self.lora_A = nn.Parameter(a.to(device=base.weight.device, dtype=base.weight.dtype))
        self.lora_B = nn.Parameter(torch.zeros(base.out_features, rank, device=base.weight.device, dtype=base.weight.dtype))
        self.train(base.training)

    def forward(self, value):
        return self.base(value) + F.linear(F.linear(value, self.lora_A), self.lora_B)


def _adapters(decoder):
    return {name: module for name, module in decoder.named_modules() if isinstance(module, _AdapterLinear)}


def _base_state(decoder):
    adapters = _adapters(decoder)
    result = {}
    for key, value in decoder.state_dict().items():
        matched = False
        for name in adapters:
            if key.startswith(name + '.'):
                tail = key[len(name) + 1:]
                if tail.startswith('base.'):
                    result[name + '.' + tail[5:]] = value
                matched = True
                break
        if not matched:
            result[key] = value
    return result


def install_adapters(decoder, rank=8, seed=0):
    """Freeze decoder and wrap directly called Linear layers; install before load.

    nn.MultiheadAttention uses its projection tensors functionally, bypassing
    Linear.forward. Its entire subtree remains frozen. The world decoder's
    action_in_proj is a valid target: it projects deployed intent, not actions.
    The same function and settings must be used for M3 and Local-adapter.
    """
    if type(rank) is not int or rank < 1 or type(seed) is not int:
        raise ValueError('Positive integer rank and integer seed required')
    if _adapters(decoder) or hasattr(decoder, '_fedwam_adapter_metadata'):
        raise ValueError('Adapters already installed')
    if isinstance(decoder, nn.Linear):
        raise ValueError('Pass a decoder container, e.g. nn.Sequential(linear)')
    state = _state(decoder.state_dict())
    blocked = [name for name, module in decoder.named_modules() if isinstance(module, nn.MultiheadAttention)]
    targets = {}
    for name, module in decoder.named_modules(remove_duplicate=False):
        if isinstance(module, nn.Linear) and not any(name == b or name.startswith(b + '.') for b in blocked):
            _key(name)
            if not module.weight.is_floating_point():
                raise ValueError('Adapter base weights must be floating point')
            targets[name] = module
    if not targets or len({id(v) for v in targets.values()}) != len(targets):
        raise ValueError('Need unshared, directly called decoder Linear modules')
    base_hash = _hash_state(state)
    modules = {name: {'shape': list(module.weight.shape), 'dtype': str(module.weight.dtype)}
               for name, module in sorted(targets.items())}
    metadata = {'schema': ADAPTER_SCHEMA, 'version': VERSION, 'rank': rank, 'seed': seed,
                'base_sha256': base_hash, 'modules': modules,
                'excluded_attention': sorted(blocked), 'scaling': 1.0}
    for parameter in decoder.parameters():
        parameter.requires_grad_(False); parameter.grad = None
    generator = torch.Generator(device='cpu').manual_seed(seed)
    for name, module in sorted(targets.items()):
        parent_name, _, leaf = name.rpartition('.')
        parent = decoder.get_submodule(parent_name) if parent_name else decoder
        setattr(parent, leaf, _AdapterLinear(module, rank, generator))
    decoder._fedwam_adapter_metadata = copy.deepcopy(metadata)
    return copy.deepcopy(metadata)


def _metadata(decoder):
    metadata = getattr(decoder, '_fedwam_adapter_metadata', None)
    if metadata is None or not _adapters(decoder):
        raise ValueError('No world adapters installed')
    if metadata['version'] != VERSION or _hash_state(_base_state(decoder)) != metadata['base_sha256']:
        raise ValueError('Adapter version or frozen base changed')
    factors = {id(p) for module in _adapters(decoder).values() for p in (module.lora_A, module.lora_B)}
    if any(p.requires_grad for p in decoder.parameters() if id(p) not in factors):
        raise ValueError('Adapter base parameters must stay frozen')
    return metadata


def adapter_parameters(decoder):
    """Yield only the trainable low-rank factors; never base/action parameters."""
    if not _adapters(decoder):
        raise ValueError('No world adapters installed')
    for _, module in sorted(_adapters(decoder).items()):
        yield module.lora_A
        yield module.lora_B


def adapter_export(decoder):
    """Export CPU effective matrices BA, tied to the complete immutable base."""
    metadata = _metadata(decoder)
    updates = {}
    with torch.no_grad():
        for name, module in sorted(_adapters(decoder).items()):
            dtype = torch.float64 if module.lora_A.dtype == torch.float64 else torch.float32
            updates[name] = module.lora_B.detach().cpu().to(dtype) @ module.lora_A.detach().cpu().to(dtype)
    artifact = {key: copy.deepcopy(metadata[key]) for key in ('schema', 'version', 'rank', 'base_sha256', 'modules')}
    artifact['updates'] = updates
    _validate_adapter(artifact)
    return artifact


def _validate_adapter(artifact):
    fields = {'schema', 'version', 'rank', 'base_sha256', 'modules', 'updates'}
    if (not isinstance(artifact, Mapping) or set(artifact) != fields
            or artifact['schema'] != ADAPTER_SCHEMA or type(artifact['version']) is not int
            or artifact['version'] != VERSION or type(artifact['rank']) is not int or artifact['rank'] < 1):
        raise ValueError('Invalid public adapter schema/version/rank')
    base = artifact['base_sha256']
    if not isinstance(base, str) or len(base) != 64 or any(c not in '0123456789abcdef' for c in base):
        raise ValueError('Invalid adapter base identity')
    modules = artifact['modules']; updates = _state(artifact['updates'])
    if not isinstance(modules, Mapping) or set(modules) != set(updates):
        raise ValueError('Adapter module/update keys disagree')
    for name, spec in modules.items():
        _key(name)
        if not isinstance(spec, Mapping) or set(spec) != {'shape', 'dtype'}:
            raise ValueError('Invalid adapter module metadata')
        value = updates[name]
        expected_dtype = torch.float64 if spec['dtype'] == 'torch.float64' else torch.float32
        if (spec['dtype'] not in ('torch.float16', 'torch.bfloat16', 'torch.float32', 'torch.float64')
                or len(spec['shape']) != 2 or any(type(n) is not int or n < 1 for n in spec['shape'])
                or list(value.shape) != spec['shape'] or value.dtype != expected_dtype):
            raise ValueError(f'Adapter update shape/dtype mismatch: {name}')
    return artifact


def _factor(value, rank):
    # CPU SVD fixes backend/device choice. Canonical signs make the resulting
    # factors reproducible as well as their sign-invariant effective matrix.
    value = value.detach().cpu()
    u, singular, vh = torch.linalg.svd(value, full_matrices=False)
    k = min(rank, singular.numel())
    u = u[:, :k]; vh = vh[:k]
    pivot = vh.abs().argmax(dim=1)
    signs = torch.where(vh[torch.arange(k), pivot] < 0, -1., 1.).to(vh.dtype)
    roots = singular[:k].sqrt()
    a = vh * signs[:, None] * torch.where(roots > 0, roots, torch.ones_like(roots))[:, None]
    b = (u * signs[None, :]) * roots[None, :]
    # Keep A nonzero even for zero singular values, so receiving a zero update
    # does not trap both factors at a zero-gradient stationary point.
    if rank > k:
        extra = torch.zeros(rank - k, value.shape[1], dtype=value.dtype)
        extra[torch.arange(rank - k), torch.arange(rank - k) % value.shape[1]] = 1
        a = torch.cat((a, extra)); b = F.pad(b, (0, rank - k))
    return a, b


def aggregate_adapters(exports, rank):
    """Uniform effective-update mean then fixed-rank deterministic truncated SVD.

    Returned first value is a complete artifact accepted by load_adapter_updates.
    Communication accounting must use actual serialized bytes: these in-memory
    exports are dense effective matrices, not a claim of compressed wire size.
    """
    if not isinstance(exports, (list, tuple)) or not exports or type(rank) is not int or rank < 1:
        raise ValueError('Adapter exports and positive fixed rank required')
    for artifact in exports:
        _validate_adapter(artifact)
    reference = exports[0]
    for artifact in exports:
        if artifact['rank'] != rank or any(artifact[key] != reference[key] for key in ('schema', 'version', 'base_sha256', 'modules')):
            raise ValueError('Adapter base/modules/version/rank disagree')
    averaged = average_world([artifact['updates'] for artifact in exports])
    projected = {}; errors = {}; error_sq = 0.; norm_sq = 0.
    for name, value in averaged.items():
        a, b = _factor(value, rank); projected[name] = b @ a
        residual = float((value.double() - projected[name].double()).square().sum())
        norm = float(value.double().square().sum())
        errors[name] = {'frobenius_error': math.sqrt(residual),
                        'relative_frobenius_error': math.sqrt(residual / norm) if norm else 0.}
        error_sq += residual; norm_sq += norm
    result = {key: copy.deepcopy(reference[key]) for key in reference if key != 'updates'}
    result['updates'] = projected
    return result, {'clients': len(exports), 'rank': rank, 'modules': errors,
                    'frobenius_error': math.sqrt(error_sq),
                    'relative_frobenius_error': math.sqrt(error_sq / norm_sq) if norm_sq else 0.}


def load_adapter_updates(decoder, updates):
    """Replace local factors from a base-matched effective public update."""
    _validate_adapter(updates)
    metadata = _metadata(decoder)
    if any(updates[key] != metadata[key] for key in ('schema', 'version', 'rank', 'base_sha256', 'modules')):
        raise ValueError('Adapter receiver base/modules/version/rank mismatch')
    # Validate and factor everything before touching any live parameter.
    factors = {}
    for name, module in _adapters(decoder).items():
        value = updates['updates'][name].detach().cpu()
        a, b = _factor(value, metadata['rank'])
        tolerance = 1e-10 if value.dtype == torch.float64 else 1e-5
        norm = float(torch.linalg.vector_norm(value.double()))
        if float(torch.linalg.vector_norm((b @ a).double() - value.double())) > tolerance * max(norm, 1e-30):
            raise ValueError(f'Adapter update exceeds fixed rank: {name}')
        a = a.to(module.lora_A); b = b.to(module.lora_B)
        if not torch.isfinite(a).all() or not torch.isfinite(b).all():
            raise ValueError(f'Adapter factors cannot represent update in receiver dtype: {name}')
        factors[name] = a, b
    with torch.no_grad():
        for name, module in _adapters(decoder).items():
            a, b = factors[name]
            module.lora_A.copy_(a); module.lora_B.copy_(b)
