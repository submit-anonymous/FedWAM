"""Bounded TF Example reader and conservative numerical provenance matching."""
from collections import defaultdict
import hashlib
from pathlib import Path
import struct
import numpy as np

SUITES = ('libero_spatial', 'libero_object', 'libero_goal', 'libero_10')
CATEGORIES = ('Background Textures', 'Robot Initial States', 'Camera Viewpoints',
              'Language Instructions', 'Sensor Noise', 'Objects Layout', 'Light Conditions')


def varint(buf, pos):
    value = 0
    for shift in range(0, 70, 7):
        if pos >= len(buf): raise ValueError('Truncated protobuf varint')
        b = buf[pos]; pos += 1
        value |= (b & 127) << shift
        if not b & 128: return value, pos
    raise ValueError('Protobuf varint too long')


def fields(data):
    buf = memoryview(data); pos = 0
    while pos < len(buf):
        tag, pos = varint(buf, pos); field, wire = tag >> 3, tag & 7
        if field == 0: raise ValueError('Invalid protobuf field zero')
        if wire == 0:
            value, pos = varint(buf, pos)
        else:
            if wire == 2: size, pos = varint(buf, pos)
            elif wire == 1: size = 8
            elif wire == 5: size = 4
            else: raise ValueError(f'Unsupported protobuf wire: {wire}')
            if size > len(buf) - pos: raise ValueError('Truncated protobuf field')
            value = buf[pos:pos+size]; pos += size
        yield field, wire, value


def feature_payloads(record):
    outer = [(f,w,v) for f,w,v in fields(record) if f == 1 and w == 2]
    if len(outer) != 1: raise ValueError('Expected one tf.Example Features')
    out = {}
    for f,w,entry in fields(outer[0][2]):
        if f != 1 or w != 2: continue
        parts = {k:v for k,t,v in fields(entry) if t == 2}
        if set(parts) != {1,2}: raise ValueError('Malformed feature map entry')
        key = bytes(parts[1]).decode('utf-8')
        if key in out: raise ValueError('Duplicate feature key')
        out[key] = parts[2]
    return out


def feature_values(payload, kind):
    chosen = [v for f,w,v in fields(payload) if f == kind and w == 2]
    if len(chosen) != 1: raise ValueError('Wrong feature value type')
    if kind == 1:
        return [bytes(v) for f,w,v in fields(chosen[0]) if f == 1 and w == 2]
    parts = []
    for f,w,v in fields(chosen[0]):
        if f == 1 and w in (2,5): parts.append(bytes(v))
        else: raise ValueError('Invalid float list encoding')
    return np.frombuffer(b''.join(parts), dtype='<f4')


def fingerprint(values, width):
    a = np.asarray(values, dtype='<f4').copy()
    if a.ndim != 2 or a.shape[1] != width or not np.isfinite(a).all():
        raise ValueError('Expected finite numeric sequence of correct width')
    a[a == 0] = 0
    return hashlib.sha256(struct.pack('<QQ', *a.shape) + a.tobytes()).hexdigest()


def source_parts(path):
    parts = str(path).split('/')
    if parts.count('pro_data') != 1: raise ValueError('Missing/ambiguous source path marker')
    tail = parts[parts.index('pro_data')+1:]
    if len(tail) != 3 or tail[1] not in SUITES or not tail[2].endswith('.hdf5'):
        raise ValueError('Unrecognized source path structure')
    return tuple(tail)


def parse_episode(record):
    features = feature_payloads(record)
    paths = feature_values(features['episode_metadata/file_path'], 1)
    if len(paths) != 1: raise ValueError('Expected one source path')
    path = paths[0].decode('utf-8')
    tasks = feature_values(features['steps/language_instruction'], 1)
    if not tasks or len(set(tasks)) != 1: raise ValueError('Missing/varying episode instruction')
    a = feature_values(features['steps/action'], 2).reshape(-1, 7)
    s = feature_values(features['steps/observation/state'], 2).reshape(-1, 8)
    if len(a) != len(s) or len(a) != len(tasks): raise ValueError('Inconsistent sequence lengths')
    bucket, suite, source = source_parts(path)
    return {'raw_file_path': path, 'source_bucket': bucket, 'suite': suite, 'source_file': source,
            'task': tasks[0].decode('utf-8'), 'length': len(a),
            'action_sha256': fingerprint(a,7), 'state_sha256': fingerprint(s,8)}


def iter_records(path, crc_function=None, digest=None):
    def masked(data):
        value = crc_function(data)
        return (((value >> 15) | (value << 17)) + 0xa282ead8) & 0xffffffff
    with Path(path).open('rb') as f:
        while True:
            offset = f.tell(); header = f.read(12)
            if not header: return
            if len(header) != 12: raise ValueError('Truncated TFRecord header')
            size, checksum = struct.unpack('<QI', header)
            if size > 512*1024**2: raise ValueError('Record too large or compressed TFRecord unsupported')
            if crc_function and masked(header[:8]) != checksum: raise ValueError('TFRecord header CRC mismatch')
            payload = f.read(size); trailer = f.read(4)
            if len(payload) != size or len(trailer) != 4: raise ValueError('Truncated TFRecord payload')
            if crc_function and masked(payload) != struct.unpack('<I', trailer)[0]:
                raise ValueError('TFRecord payload CRC mismatch')
            if digest is not None:
                digest.update(header); digest.update(payload); digest.update(trailer)
            yield offset, payload


def match_candidates(rows, action_hash, state_hash, length, task):
    # Exact instruction match. Never use episode order to break ties.
    return [r for r in rows if r['action_sha256'] == action_hash and r['state_sha256'] == state_hash
            and r['length'] == length and r['task'] == task]


def select_cases(classification):
    result = []
    for suite in SUITES:
        rows = classification[suite]
        for category in CATEGORIES:
            candidates = [r for r in rows if r['category'] == category]
            if not candidates: raise ValueError(f'Missing benchmark cell: {suite}/{category}')
            row = min(candidates, key=lambda r: int(r['id']))
            result.append({'suite':suite, 'category':category, 'id':int(row['id']), 'name':row['name']})
    return result
