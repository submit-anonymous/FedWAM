"""Explicit self-collected supplement; never relabel released data as new perturbations."""
import numpy as np
from .io import digest
from .provenance import allocate_groups
CLIENTS=('lighting','camera_pose','sensor_noise','background','object_layout','robot_initial','language')

def collection_plan(tasks,seed=20260921):
    tasks=sorted({(t['suite'],t['source_file']) for t in tasks});groups=[];lookup={}
    for suite,source in tasks:
        for index in range(50):
            group=digest(['fresh-reset-v1',seed,suite,source,index]);stratum=f'{suite}/{source}'
            groups.append(dict(group=group,stratum=stratum,exposed=index==0))
            lookup[group]=(suite,source,index)
    splits=allocate_groups(groups,seed);rows=[]
    for group,(suite,source,index) in lookup.items():
        reset_seed=int(digest(['reset',group])[:8],16)
        for client in CLIENTS:
            rows.append(dict(suite=suite,source_file=source,group_index=index,source_group=group,
                split=splits[group],client=client,reset_seed=reset_seed,
                recipe_seed=int(digest(['recipe',group,client])[:8],16),
                id=digest([group,client])[:24],engineering_exposed=index==0))
    return rows

def rewritten_instruction(command,index,forbidden):
    command=command.strip().rstrip('.')
    templates=['Your goal in this scene is to {x}.','Please carry out this instruction: {x}.',
        'Perform this manipulation: {x}.','For the current task, {x}.',
        'Use the robot to {x}.','Complete the following operation: {x}.',
        'The requested action is: {x}.','In the current scene, {x}.']
    normalized={x.strip().lower() for x in forbidden}|{command.lower()}
    for offset in range(len(templates)):
        value=templates[(index+offset)%len(templates)].format(x=command)
        if value.strip().lower() not in normalized:return value
    raise ValueError('No unused semantics-preserving instruction template')

def validate_episode(actions,states,times,success):
    actions=np.asarray(actions);states=np.asarray(states);times=np.asarray(times)
    if not success:raise ValueError('Unsuccessful rollout is not an accepted demonstration')
    if actions.ndim!=2 or actions.shape[1]!=7 or len(actions)<8:raise ValueError('Invalid action sequence')
    if len(states)!=len(actions)+1 or len(times)!=len(states):raise ValueError('Missing terminal observation/state')
    if not all(np.isfinite(x).all() for x in (actions,states,times)):raise ValueError('Nonfinite episode')
    if not np.allclose(np.diff(times),.05,atol=1e-7,rtol=0):raise ValueError('Not continuous 20Hz steps')

def refresh(env):
    env.sim.forward();env._post_process();env._update_observables(force=True)
    return env.env._get_observations()

def perturb(env,client,seed,command,forbidden):
    rng=np.random.default_rng(seed);m=env.sim.model;d=env.sim.data;record={'client':client,'seed':seed}
    if client=='robot_initial':
        idx=np.array(env.robots[0]._ref_joint_pos_indexes);before=d.qpos[idx].copy()
        delta=rng.uniform(.06,.12,len(idx))*rng.choice([-1,1],len(idx));after=before+delta
        joint_ids=np.array(env.robots[0]._ref_joint_indexes)
        limits=m.jnt_range[joint_ids]
        if np.any(after<limits[:,0]+.01) or np.any(after>limits[:,1]-.01):raise ValueError('Robot perturbation outside joint limits')
        d.qpos[idx]=after;record.update(before=before.tolist(),after=after.tolist(),delta_rad=delta.tolist())
    elif client=='object_layout':
        changed=[]
        for name,obj in sorted(env.env.objects_dict.items()):
            for joint in obj.joints:
                jid=m.joint_name2id(joint)
                if int(m.jnt_type[jid])!=0:continue
                before=np.asarray(d.get_joint_qpos(joint)).copy();after=before.copy()
                delta=rng.uniform(.008,.02,2)*rng.choice([-1,1],2);after[:2]+=delta
                d.set_joint_qpos(joint,after);changed.append({'object':name,'joint':joint,'before':before.tolist(),'after':after.tolist()})
        if not changed:raise ValueError('No movable objects to perturb')
        record['joint_changes']=changed
    elif client=='lighting':
        before=m.light_diffuse.copy();scale=rng.uniform(.55,.85,before.shape);m.light_diffuse[:]=before*scale
        record.update(before=before.tolist(),after=m.light_diffuse.tolist(),scale=scale.tolist())
    elif client=='camera_pose':
        camera=m.camera_name2id('agentview');before=m.cam_pos[camera].copy();delta=rng.uniform(.015,.035,3)*rng.choice([-1,1],3)
        m.cam_pos[camera]=before+delta;record.update(camera='agentview',before=before.tolist(),after=m.cam_pos[camera].tolist())
    elif client=='background':
        changed=[]
        for mat_id in range(m.nmat):
            import mujoco
            name=mujoco.mj_id2name(m._model,mujoco.mjtObj.mjOBJ_MATERIAL,mat_id) or ''
            if not any(k in name.lower() for k in ('table','floor','wall')):continue
            texture=int(m.mat_texid[mat_id])
            if texture<0:continue
            offset=int(m.tex_adr[texture]);width=int(m.tex_width[texture]);height=int(m.tex_height[texture]);n=width*height*3
            tex=m.tex_rgb[offset:offset+n].reshape(height,width,3);old=tex.copy()
            yy,xx=np.indices((height,width));period=int(rng.integers(17,47));a=rng.integers(45,215,3);b=rng.integers(45,215,3)
            pattern=((xx+yy)//period)%2;tex[:]=np.where(pattern[...,None],a,b).astype(np.uint8)
            changed.append({'material':name,'texture':texture,'period':period,'colors':[a.tolist(),b.tolist()],
                'before_sha256':__import__('hashlib').sha256(old.tobytes()).hexdigest(),
                'after_sha256':__import__('hashlib').sha256(tex.tobytes()).hexdigest()})
            # The renderer already exists after reset; upload the changed texture.
            context=env.sim._render_context_offscreen
            if context is not None:
                context.gl_ctx.make_current()
                mujoco.mjr_uploadTexture(m._model,context.con,texture)
        if not changed:raise ValueError('No background materials matched')
        record['textures']=changed
    elif client=='sensor_noise':
        # New collection distribution, explicitly Gaussian sensor corruption; not renamed native fog/blur.
        record.update(noise_type='independent_additive_gaussian_RGB',sigma=float(rng.uniform(3.,8.)),
                      cameras=['agentview_image','robot0_eye_in_hand_image'])
    elif client=='language':
        record.update(original_instruction=command,instruction=rewritten_instruction(command,seed,forbidden),
                      generator='semantics-preserving template; not LLM paraphrase')
    else:raise ValueError(client)
    env.sim.forward()
    for robot in env.robots:
        robot.controller.update(force=True);robot.controller.reset_goal()
    return record,refresh(env)

def corrupt_observation(obs,recipe,rng):
    if recipe['client']!='sensor_noise':return obs
    out=dict(obs)
    for key in recipe['cameras']:
        x=obs[key].astype(np.float32)+rng.normal(0,recipe['sigma'],obs[key].shape)
        out[key]=np.clip(x,0,255).astype(np.uint8)
    return out
