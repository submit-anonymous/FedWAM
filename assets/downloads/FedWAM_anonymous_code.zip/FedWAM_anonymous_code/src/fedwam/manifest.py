"""Complete native case identities and conservative evaluation exposure."""
import ast
from collections import Counter
from .io import ROOT,save,load,digest,file_hash
SUITES=('libero_spatial','libero_object','libero_goal','libero_10')
CATEGORY_MAP={'Background Textures':'background','Robot Initial States':'robot_initial',
 'Camera Viewpoints':'camera_pose','Language Instructions':'language','Sensor Noise':'sensor_noise',
 'Objects Layout':'object_layout','Light Conditions':'lighting'}
HORIZONS={'libero_spatial':250,'libero_object':300,'libero_goal':320,'libero_10':550}
def partition_exposure(rows,seen):
    ids={r['variant_id'] for r in rows}
    if len(ids)!=len(rows):raise ValueError('Duplicate native variant identity')
    if not set(seen)<=ids:raise ValueError(f'Exposure IDs absent from benchmark: {set(seen)-ids}')
    return rows,[r for r in rows if r['variant_id'] in seen],[r for r in rows if r['variant_id'] not in seen]
def build():
    inner=ROOT/'third_party/LIBERO-plus/libero/libero'
    classification=load(inner/'benchmark/task_classification.json')
    tree=ast.parse((inner/'benchmark/libero_suite_task_map.py').read_text())
    maps=ast.literal_eval(tree.body[0].value)
    rows=[];engineering=[]
    for suite in SUITES:
        for r in classification[suite]:
            idx=int(r['id'])-1
            if maps[suite][idx]!=r['name']:raise ValueError('Classification/order mismatch')
            rows.append(dict(variant_id=f'{suite}:{r["id"]}',suite=suite,task_index=idx,name=r['name'],
                category=CATEGORY_MAP[r['category']],native_category=r['category'],init_state_index=0,
                seed=int(digest([20260921,suite,idx])[:8],16),max_steps=HORIZONS[suite]))
        for category in CATEGORY_MAP.values():
            engineering.append(min((r for r in rows if r['suite']==suite and r['category']==category),key=lambda r:r['task_index']))
    if len(rows)!=10030:raise ValueError(f'Expected full 10030-case benchmark: {len(rows)}')
    history=load(ROOT/'manifests/history_exposure.json')['reserved_variant_sources']
    seen=set(history)|{r['variant_id'] for r in engineering}
    all_rows,seen_rows,confirm_rows=partition_exposure(rows,seen)
    manifest=dict(schema='fedwam.full.cases.v1',revision='4976dc30028e805ff8094b55501d532c48fec182',
        classification_sha256=file_hash(inner/'benchmark/task_classification.json'),cases=all_rows,
        engineering=engineering,E_seen=[r['variant_id'] for r in seen_rows],E_confirm=[r['variant_id'] for r in confirm_rows],
        caveat='E_confirm excludes known historical/engineering exposure; training-data overlap gate is separate',
        counts=dict(Counter(r['category'] for r in rows)))
    manifest['sha256']=digest(manifest);save(ROOT/'manifests/plus_full.json',manifest)
    print('Full native cases:',len(rows),'engineering:',len(engineering),'known exposed:',len(seen_rows))
if __name__=='__main__':build()
