"""Retain native private VLM/world/action weights after verified training."""
from .round_runtime import RoundStore, atomic_json
from .federated_reporting import load_final_checkpoint


def compact_native_run(root, identity):
    store = RoundStore(root, identity)
    from .io import load
    proof = load(store.path('verification.json'))
    final = load(store.path('final.json'))
    if proof.get('passed') is not True or proof.get('identity') != identity:
        raise ValueError('Cannot compact an unverified native run')
    if final.get('identity') != identity:
        raise ValueError('Native final identity changed')
    previous_retention = store.path('retention.json')
    largest_resume_checkpoint_bytes = (
        load(previous_retention).get('largest_resume_checkpoint_bytes', 0)
        if previous_retention.exists() else 0)
    if final.get('retention') != 'verified-native-final-weights.v1':
        largest_resume_checkpoint_bytes = max(
            ref['bytes'] for ref in final['clients'].values())
        refs = {}
        for client in final['clients']:
            checkpoint = load_final_checkpoint(store.root, final, client)
            if not {'vlm', 'world', 'action', 'aux'} <= checkpoint['state'].keys():
                raise ValueError('Missing private native module')
            for key in ('vlm_optimizer', 'world_optimizer', 'action_optimizer',
                        'aux_optimizer'):
                checkpoint['state'][key] = None
            checkpoint['state'].pop('self_teacher_world', None)
            checkpoint['inference_only'] = True
            refs[client] = store.write(f'checkpoints/final/{client}.pt', checkpoint)
        latest = store.latest()
        server_ref = latest.get('server') if latest else None
        if server_ref:
            server = store.read_ref(server_ref)
            def public(teacher):
                return {k: teacher[k] for k in
                        ('schema', 'config', 'model', 'support', 'interface_version', 'metrics')
                        if k in teacher}
            if server['kind'] == 'teacher':
                server['teacher'] = public(server['teacher'])
            elif server['kind'] == 'self_teachers':
                server['teachers'] = {c: public(t) for c, t in server['teachers'].items()}
            final['server'] = store.write('checkpoints/final/server.pt', server)
        final['clients'] = refs
        final['retention'] = 'verified-native-final-weights.v1'
        atomic_json(store.path('final.json'), final)
    largest_final_checkpoint_bytes = max(ref['bytes'] for ref in final['clients'].values())
    for client in final['clients']:
        load_final_checkpoint(store.root, final, client)
    if final.get('server'):
        store.read_ref(final['server'])
    removed = 0
    for prefix in ('phases', 'server', 'public'):
        folder = store.path(prefix)
        if not folder.exists():
            continue
        for path in folder.rglob('*.pt'):
            if not path.resolve().is_relative_to(store.root):
                raise ValueError('Cleanup path escapes native run')
            removed += path.stat().st_size
            path.unlink()
    atomic_json(store.path('retention.json'),
                {'state': 'completed', 'policy': final['retention'],
                 'removed_bytes_this_attempt': removed,
                 'largest_resume_checkpoint_bytes': largest_resume_checkpoint_bytes,
                 'largest_final_checkpoint_bytes': largest_final_checkpoint_bytes,
                 'preserved': ['private VLM/world/action/auxiliary weights', 'phase receipts',
                               'exposure', 'communication events']})
    atomic_json(store.path('status.json'),
                {'state': 'completed', 'phase': 'all_rounds_committed',
                 'rounds': final.get('rounds'), 'clients': list(final['clients'])})
    return final
