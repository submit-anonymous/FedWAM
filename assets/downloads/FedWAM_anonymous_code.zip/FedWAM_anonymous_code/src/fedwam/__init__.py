"""Full FedWAM restart implementation."""
