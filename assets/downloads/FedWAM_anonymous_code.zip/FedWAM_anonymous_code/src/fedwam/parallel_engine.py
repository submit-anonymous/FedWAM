"""Process-per-client execution; private phase state and public-only round barriers."""
import fcntl,io,json,shutil,time
from pathlib import Path
import torch
from .round_runtime import RoundStore,PhaseRunner,atomic_json

INDEPENDENT={'M1','M7','Local-adapter','M9'}
class ParallelEngine:
 def __init__(self,root,identity,config,backend,client,attempt,timeout=86400,poll=2.,fault_hook=None):
  root=Path(root);root.mkdir(parents=True,exist_ok=True)
  with (root/'identity.lock').open('a') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX);self.store=RoundStore(root,identity)
  if not attempt or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in attempt):raise ValueError('Unsafe attempt identifier')
  self.cfg=config;self.backend=backend;self.client=client;self.attempt=attempt;self.timeout=timeout;self.poll=poll
  self.clients=['pooled'] if config['method']=='M9' else config['clients']
  if client not in self.clients:raise ValueError('Unknown client')
  self.coordinator=client==self.clients[0];self.independent=config['method'] in INDEPENDENT
  self.phases=PhaseRunner(self.store);self.hook=fault_hook or (lambda _:None)
 def fail(self,error):
  atomic_json(self.store.path(f'attempts/{self.attempt}/errors/{self.client}.json'),{'client':self.client,'error':repr(error)})
 def wait(self,name,predicate=None):
  path=self.store.path(name);start=time.monotonic()
  while True:
   failures=list(self.store.path(f'attempts/{self.attempt}/errors').glob('*.json'))
   if failures:raise RuntimeError('Parallel peer failed: '+failures[0].read_text()[:500])
   if path.exists():
    value=json.loads(path.read_text())
    if predicate is None or predicate(value):return value
   if time.monotonic()-start>self.timeout:raise TimeoutError('Waiting for '+name)
   time.sleep(self.poll)
 def phase(self,state,round,phase,steps,context):
  key=f'r{round:04d}/{self.client}/{phase}'
  status={'state':'running','round':round,'phase':phase,'client':self.client,'steps':steps}
  atomic_json(self.store.path(f'client_status/{self.client}.json'),status)
  if self.coordinator:atomic_json(self.store.path('status.json'),status)
  metadata={'method':self.cfg['method'],'seed':self.cfg['seed'],'client':self.client,'round':round,'phase':phase}
  state=self.phases.run(key,state,steps,lambda s,start,save:self.backend.train(self.client,s,phase,steps,context,start,save),metadata)
  self.hook(f'round{round}:{phase}:{self.client}')
  return state,self.phases.ref(key)
 def artifact(self,key,compute):
  receipt=self.store.path(key+'.json')
  if receipt.exists():
   ref=json.loads(receipt.read_text());return self.store.read_ref(ref),ref
  value=compute();ref=self.store.write(key+'.pt',value);atomic_json(receipt,ref);return value,ref
 def run_client(self):
  with self.store.path(f'client_{self.client}.lock').open('a') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
   return self._run_client()
 def _run_client(self):
  cfg=self.cfg;b=cfg['training'];factor=len(cfg['clients']) if cfg['method']=='M9' else 1
  if self.independent:
   path=self.store.path(f'client_committed/{self.client}.json');latest=json.loads(path.read_text()) if path.exists() else None
   start_round=latest['round']+1 if latest else 0
   if latest and latest['identity']!=self.store.identity:raise ValueError('Private commit identity changed')
   state=self.store.read_ref(latest['ref'])['state'] if latest else None
  else:
   if self.coordinator:atomic_json(self.store.path(f'attempts/{self.attempt}/start.json'),{'latest':self.store.latest()})
   latest=self.wait(f'attempts/{self.attempt}/start.json')['latest']
   start_round=latest['round']+1 if latest else 0
   state=self.store.read_ref(latest['clients'][self.client])['state'] if latest else None
  if state is None:
   state,ref=self.phase(self.backend.initialize(self.client),-1,'warmup',b['warmup']*factor,{'kind':'none'})
   if self.independent:atomic_json(self.store.path(f'client_committed/{self.client}.json'),{'identity':self.store.identity,'round':-1,'ref':ref})
  else:ref=latest['ref'] if self.independent else latest['clients'][self.client]
  previous=self.store.read_ref(latest['server']) if latest and latest.get('server') and self.coordinator else None
  if cfg['method']=='M4':
   if self.coordinator:
    self.backend.public_queries();atomic_json(self.store.path(f'attempts/{self.attempt}/queries_ready.json'),{'ready':True})
   self.wait(f'attempts/{self.attempt}/queries_ready.json')
  for round in range(start_round,b['rounds']):
   begin=time.perf_counter();state,_=self.phase(state,round,'pre',b['pre_receive_joint']*factor,{'kind':'none'})
   upload=download=0;packet_seconds=0.;server_ref=None
   if self.independent:context={'kind':'none'}
   else:
    export,export_ref=self.artifact(f'public/r{round:04d}/{self.client}',lambda:self.backend.publish(self.client,state,round))
    upload=self.backend.upload_bytes(export);packet_seconds=export.get('packet_seconds',0.)
    if self.coordinator:
     exports={c:self.store.read_ref(self.wait(f'public/r{round:04d}/{c}.json')) for c in self.clients}
     server,server_ref=self.artifact(f'server/r{round:04d}',lambda:self.backend.aggregate(exports,previous,round,self.store.path(f'server/progress/r{round:04d}')))
     self.hook(f'round{round}:server_published')
     for c in self.clients:self.artifact(f'broadcasts/r{round:04d}/{c}',lambda c=c:self.backend.broadcast(server,c))
     previous=server
    context=self.store.read_ref(self.wait(f'broadcasts/r{round:04d}/{self.client}.json'))
    buf=io.BytesIO();torch.save(context,buf);download=len(buf.getvalue()) if context['kind']!='none' else 0
   state,_=self.phase(state,round,'post',b['post_receive_joint']*factor,context)
   state,ref=self.phase(state,round,'action',b['final_world_action_only']*factor,{'kind':'none'})
   event={'ref':ref,'upload_bytes':upload,'download_bytes':download,'packet_seconds':packet_seconds,
          'metrics':state.get('metrics',{}),'seconds_this_attempt':time.perf_counter()-begin}
   atomic_json(self.store.path(f'client_events/r{round:04d}/{self.client}.json'),event)
   if self.independent:
    atomic_json(self.store.path(f'client_committed/{self.client}.json'),{'identity':self.store.identity,'round':round,'ref':ref})
    self.prune_private(round)
   else:
    if self.coordinator:
     events={c:self.wait(f'client_events/r{round:04d}/{c}.json') for c in self.clients}
     ledger=self.ledger(events,previous)
     self.store.event(f'round_{round:04d}',ledger)
     self.store.commit(round,{c:events[c]['ref'] for c in self.clients},self.clients,server_ref,ledger)
     self.hook(f'round{round}:committed')
     self.prune_shared(round)
    self.wait(f'commits/round_{round:04d}.json')
  atomic_json(self.store.path(f'client_status/{self.client}.json'),{'state':'training_completed','rounds':b['rounds'],'client':self.client})
  return ref
 def ledger(self,events,server=None):
  seconds=0.
  if server and server['kind']=='teacher':seconds=server['teacher']['metrics']['training_seconds']
  if server and server['kind']=='self_teachers':seconds=sum(t['metrics']['training_seconds'] for t in server['teachers'].values())
  return {'server_seconds':seconds,'packet_seconds':sum(v['packet_seconds'] for v in events.values()),
          'upload_bytes':{c:v['upload_bytes'] for c,v in events.items()},'download_bytes':{c:v['download_bytes'] for c,v in events.items()},
          'client_cumulative_metrics':{c:v['metrics'] for c,v in events.items()},'client_attempt_seconds':{c:v['seconds_this_attempt'] for c,v in events.items()},
          'transport':'serialized same-host process-per-client federation; not network throughput'}
 def prune_private(self,round):
  if not self.cfg.get('prune',True):return
  path=self.store.path(f'phases/r{round-2:04d}/{self.client}')
  if path.exists():shutil.rmtree(path)
 def prune_shared(self,round):
  if not self.cfg.get('prune',True):return
  old=round-2
  for prefix in ('phases','server/progress','broadcasts'):
   path=self.store.path(f'{prefix}/r{old:04d}')
   if path.exists():shutil.rmtree(path)
  path=self.store.path(f'server/r{old:04d}.pt')
  if path.exists():path.unlink()
  path=self.store.path(f"public/r{round-int(self.cfg.get('server',{}).get('replay_rounds',4)):04d}")
  if path.exists():shutil.rmtree(path)
 def finalize(self):
  if not self.coordinator:raise ValueError('Only coordinator finalizes')
  proofs={c:self.wait(f'client_verification/{c}.json',lambda p:p.get('attempt')==self.attempt) for c in self.clients}
  for proof in proofs.values():
   if proof.get('passed') is not True or proof.get('identity')!=self.store.identity:raise ValueError('Client verification failed')
  refs={c:p['ref'] for c,p in proofs.items()}
  if self.independent:
   for round in range(self.cfg['training']['rounds']):
    events={c:self.wait(f'client_events/r{round:04d}/{c}.json') for c in self.clients};self.store.event(f'round_{round:04d}',self.ledger(events))
   self.store.commit(self.cfg['training']['rounds']-1,refs,self.clients)
  latest=self.store.latest()
  if latest['clients']!=refs:raise ValueError('Final proof differs from committed round')
  final={'identity':self.store.identity,'method':self.cfg['method'],'seed':self.cfg['seed'],'clients':refs,
         'rounds':self.cfg['training']['rounds'],'scope':self.store.identity.get('mode'),
         'adapter_rank':self.cfg.get('adapter_rank',8) if self.cfg['method'] in ('M3','Local-adapter') else None}
  atomic_json(self.store.path('final.json'),final)
  return final
