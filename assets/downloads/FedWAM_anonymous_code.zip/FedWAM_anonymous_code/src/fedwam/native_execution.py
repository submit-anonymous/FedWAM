"""Isolate full native LaWAM science from the older restricted adaptation."""
from .io import ROOT,file_hash
from .parallel_execution import parallel_identity
from .native_federation import native_config
from .experiment_config import METHODS

FILES=('scripts/report_seed42.py','scripts/finalize_seed42.py','scripts/native_finalize.slurm','src/fedwam/io.py','src/fedwam/native_federation.py','src/fedwam/native_local.py','src/fedwam/native_execution.py',
 'src/fedwam/native_engine.py','src/fedwam/native_retention.py','src/fedwam/detached_engine.py',
 'scripts/detached_campaign.py',
 'configs/native_fedwam_protocol_v2.json','scripts/train_native_federated.py','scripts/native_campaign.py',
 'scripts/native_federated_client.slurm','scripts/native_federated_pipeline.slurm',
 'scripts/native_federated_eval.slurm','scripts/evaluate_native_federated.py',
 'third_party/LaWAM/starVLA/config/training/train_libero.yaml',
 'third_party/LaWAM/starVLA/dataloader/latent_world_train_collator.py',
 'third_party/LaWAM/starVLA/model/framework/vlas/lawam.py',
 'third_party/LaWAM/starVLA/model/framework/vlas/flowmatching_expert.py',
 'third_party/LaWAM/starVLA/model/framework/latent_world/runtime/freeze_policy.py',
 'third_party/LaWAM/starVLA/training/train_starvla.py')
def native_code():return {p:file_hash(ROOT/p) for p in FILES}
def native_identity(cfg):
 value=parallel_identity(cfg);value['code'].update(native_code())
 value['native_protocol_sha256']=file_hash(ROOT/'configs/native_fedwam_protocol_v2.json')
 value['execution']={'kind':'native-LaWAM-independent-clients.v2','private_vlm':True,'native_three_loss_training':True}
 return value
def native_gate(cfg,receipt):
 x=native_identity(cfg)
 if cfg['seed']!=42 or receipt.get('seed')!=42 or receipt.get('passed') is not True or receipt.get('mode')!='real_detached_client_engineering':
  raise ValueError('New native all-method GPU engineering required')
 for key in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','native_protocol_sha256','execution'):
  if receipt.get(key)!=x[key]:raise ValueError('Stale native engineering: '+key)
 if set(receipt.get('methods_passed',[]))!=set(METHODS):raise ValueError('Incomplete native acceptance')
