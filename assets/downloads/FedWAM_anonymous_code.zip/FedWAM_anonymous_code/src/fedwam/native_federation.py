"""Federated LaWAM backend using the native three-loss local training path."""
from pathlib import Path
import math,time
import torch
import torch.nn.functional as F
from omegaconf import OmegaConf
from .io import ROOT,load
from .experiment_config import resolved_config
from .lawam_federation import LaWAMFederation
from .native_local import (OFFICIAL,make_collator,make_native_sample,local_contract,
                           auxiliary_parameters,auxiliary_state,restore_auxiliary_state)
from .round_runtime import cpu_tree,rng_state,restore_rng
from .parameter_methods import adapter_parameters,load_adapter_updates
from .server_teacher import select_prediction
from .reception import reception_weights

def native_config(method,mode,seed=42):
 if seed!=42:raise ValueError('Current native study is seed42 only')
 cfg=resolved_config(method,seed,mode)
 p=load(ROOT/'configs/native_fedwam_protocol_v2.json');t=p['training']
 if p['seed']!=seed:raise ValueError('Native protocol seed differs from execution')
 cfg['training'].update(warmup=t['warmup_local_updates'],rounds=t['federation_rounds'],
       pre_receive_joint=t['pre_receive_joint_updates'],post_receive_joint=t['post_receive_joint_updates'],
       final_world_action_only=t['action_only_updates'],effective_batch=t['effective_batch_per_client'],
       lr=t['lr'],weight_decay=t['adamw_weight_decay'],clip_grad_norm=t['clip_grad_norm'])
 cfg['training'].update(intent='private native trainable prediction with latent-action distillation',
       action_feedback_to_world=False,world_optimizer_receive='continuous private state')
 cfg['native_recipe']=p['schema'];cfg['representation']=p['aggregation']['representation_default']
 cfg['action_feedback']=False
 if mode=='engineering':
  cfg['training'].update(warmup=1,rounds=2,pre_receive_joint=1,post_receive_joint=1,final_world_action_only=0,effective_batch=2)
  cfg['server'].update(steps_per_round=4,batch=2,max_queries=8,packet_budget_bytes=16*1024**2)
  cfg.update(checkpoint_every=1,server_checkpoint_every=1)
 return cfg

def native_lr(step,total=25000,warmup=1500,base=1e-4,floor=5e-7):
 if step<0 or total<=warmup:raise ValueError('Invalid scheduler budget')
 if step<warmup:return base*step/warmup
 progress=min(1.,(step-warmup)/(total-warmup))
 return floor+(base-floor)*.5*(1+math.cos(math.pi*progress))

class NativeLaWAMFederation(LaWAMFederation):
 def __init__(self,policy,config,run_root,interface_version):
  self.initial_trainable={name for name,parameter in policy.named_parameters() if parameter.requires_grad}
  super().__init__(policy,config,run_root,interface_version)
  self.official=OmegaConf.load(OFFICIAL)
  if not self.b.model_cfg.detach_future_feature or not self.b.model_cfg.enable_loss_distill:
   raise ValueError('Loaded SFT configuration does not expose the official loss contract')
  self._enable('pre')
  self.collator=make_collator(policy)
  self.base_vlm=cpu_tree(self.b.vlm.state_dict())
  self.base_aux=auxiliary_state(policy)
 def initialize(self,client):
  state=super().initialize(client)
  state['vlm']=cpu_tree(self.base_vlm);state['vlm_optimizer']=None
  state['aux']=cpu_tree(self.base_aux);state['aux_optimizer']=None
  state['metrics']['latent_action_distill_updates']=0
  state['metrics']['aux_updates']=0
  return state
 def weights(self,state):
  super().weights(state)
  self.b.vlm.load_state_dict(state['vlm'],strict=True)
  restore_auxiliary_state(self.policy,state['aux'])
 def _enable(self,phase):
  from starVLA.model.framework.latent_world.runtime.freeze_policy import parse_policy_freeze_config,apply_policy_freeze
  for name,parameter in self.policy.named_parameters():
   parameter.requires_grad_(name in self.initial_trainable)
  apply_policy_freeze(self.b,parse_policy_freeze_config(self.official.trainer.freeze))
  self.b.flow.requires_grad_(True)
  if self.adapter:
   self.b.lam.decoder.requires_grad_(False)
   for parameter in adapter_parameters(self.b.lam.decoder):parameter.requires_grad_(phase!='action')
  self.policy.train()
  world=[p for p in (adapter_parameters(self.b.lam.decoder) if self.adapter else self.b.lam.decoder.parameters()) if p.requires_grad]
  action=[p for p in self.b.flow.parameters() if p.requires_grad]
  vlm=[p for p in self.b.vlm.parameters() if p.requires_grad]
  auxiliary=list(auxiliary_parameters(self.policy).values())
  if not all((world,action,vlm,auxiliary)):
   raise ValueError('Native world/action/VLM/auxiliary must all be trainable')
  return world,action,vlm,auxiliary
 def native_batch(self,sample):
  raw=make_native_sample(sample,self.stats)
  return {k:v.to(self.device) if isinstance(v,torch.Tensor) else v for k,v in self.collator([raw]).items()}
 def batch(self,sample):
  # Prediction packets/calibration must reflect this client's latest private VLM.
  native=self.native_batch(sample)
  with torch.no_grad():shared=self.b._run_shared_encoding_train(prepared_batch=native,
       source='fedwam_native_public',lam_features_with_no_grad=True)
  return dict(h_t=shared.h_t.detach(),intent=shared.pred_action_emb.detach(),
      h_vlm=shared.h_vlm.detach(),future_target=shared.h_t1_gt.detach(),
      actions=native['actions'],actions_mask=native['actions_mask'],state=native['state'],
      state_mask=native['state_mask'],action_hz=native['action_hz'],embodiment_id=native['embodiment_id'],
      attention_mask=native['attention_mask'])
 def _native_forward(self,batch):
  captured=[];original=self.b._decode_future_tokens_strict_single_query
  def tap(*args,**kwargs):
   value=original(*args,**kwargs)
   if 'h_t' in kwargs and 'pred_action_emb' in kwargs:captured.append((kwargs['h_t'],kwargs['pred_action_emb'],value))
   return value
  self.b._decode_future_tokens_strict_single_query=tap
  try:losses=self.b.forward(batch=batch)
  finally:self.b._decode_future_tokens_strict_single_query=original
  if len(captured)!=1:raise ValueError('Expected one deployed future query in native forward')
  return losses,captured[0]
 def world_prediction_only(self,z,intent):
  return self.b._decode_future_tokens_strict_single_query(
      h_t=z.detach(),pred_action_emb=intent.detach(),source='fedwam_native_world_only')
 def fixed_query_loss(self,row):
  # Public packets can be fp16, while the trainable decoder stays fp32.
  # Use the same autocast-enabled prediction interface as public uploads.
  qz=row['z'][None].to(device=self.device,dtype=torch.float32)
  qi=row['intent'][None].to(device=self.device,dtype=torch.float32)
  target=self._future(row['prediction'][None].to(device=self.device,dtype=torch.float32),qz)
  prediction=self.predict({'h_t':qz,'intent':qi})
  return F.mse_loss(prediction.float(),target.float())
 def train(self,client,state,phase,steps,context,start,save):
  self.weights(state);world,action,vlm,auxiliary=self._enable(phase)
  cfg=self.cfg['training'];betas=tuple(float(v) for v in self.official.trainer.optimizer.betas)
  common=dict(lr=cfg['lr'],betas=betas,eps=float(self.official.trainer.optimizer.eps),weight_decay=cfg['weight_decay'])
  wo=torch.optim.AdamW(world,**common);ao=torch.optim.AdamW(action,**common);vo=torch.optim.AdamW(vlm,**common);uo=torch.optim.AdamW(auxiliary,**common)
  for optimizer,key in ((wo,'world_optimizer'),(ao,'action_optimizer'),(vo,'vlm_optimizer'),(uo,'aux_optimizer')):
   if state[key] is not None:optimizer.load_state_dict(state[key])
  if phase=='post' and start==0:
   if context['kind']=='world':self.b.lam.decoder.load_state_dict(context['world'],strict=True)
   if context['kind']=='adapter':load_adapter_updates(self.b.lam.decoder,context['updates'])
  restore_rng(state['rng'])
  active=self._teacher_context(client,context,state,start) if phase=='post' else {'kind':'none'}
  if active.get('reception') is not None:
   state['reception']=active['reception']
   if start==0:state['metrics']['calibration_seconds']=state['metrics'].get('calibration_seconds',0.)+active['reception']['seconds']
  restore_rng(state['rng']);started=time.perf_counter();last_saved=started
  effective=cfg['effective_batch'];factor=len(self.cfg['clients']) if client=='pooled' else 1
  total=local_contract()['steps']*factor
  state.setdefault('reception_counts',{'queries':0,'positive':0,'weight_sum':0.})
  def snapshot():
   state.update(world=cpu_tree(self.b.lam.decoder.state_dict()),action=cpu_tree(self.b.flow.state_dict()),
                vlm=cpu_tree(self.b.vlm.state_dict()),aux=auxiliary_state(self.policy),world_optimizer=cpu_tree(wo.state_dict()),
                action_optimizer=cpu_tree(ao.state_dict()),vlm_optimizer=cpu_tree(vo.state_dict()),
                aux_optimizer=cpu_tree(uo.state_dict()),rng=rng_state())
   return state
  for step in range(start,steps):
   index=state['total_updates'];lr=native_lr(index,total=total,warmup=1500*factor) if self.cfg['mode']=='formal' else cfg['lr']
   for optimizer in (wo,ao,vo,uo):
    for group in optimizer.param_groups:group['lr']=lr
    optimizer.zero_grad(set_to_none=True)
   measures={k:0. for k in ('action','world','distill','fed')}
   for micro in range(effective):
    sample=self.sample(client,state['draw']);batch=self.native_batch(sample)
    native,(z,intent,pred)=self._native_forward(batch)
    fed=pred.float().new_zeros(())
    if active['kind']=='teacher':
     with torch.no_grad():
      output=active['model'](z.detach().float(),intent.detach().float())
      target=self._future(select_prediction(output),z.detach()).detach()
      if active['reception'] is not None:
       gate=reception_weights(active['reception']['calibration'],[sample['task_id']],z.detach(),intent.detach(),active['reception']['support'],output['logits'])
      else:gate=torch.ones(1,device=self.device)
     student=self.world_prediction_only(z,intent)
     fed=((student.float()-target.float()).square().mean((-2,-1))*gate.detach()).mean()
     counts=state['reception_counts'];counts['queries']+=1;counts['positive']+=int(gate.item()>0);counts['weight_sum']+=float(gate.item())
    elif active['kind']=='self':
     with torch.no_grad():target=active['model'](z.detach(),intent.detach())
     if isinstance(target,tuple):target=target[0]
     if target.ndim==4:target=target[:,-1]
     fed=F.mse_loss(self.world_prediction_only(z,intent).float(),target.float().detach())
    elif active['kind']=='fixed':
     row=active['queries'][state['draw']%len(active['queries'])]
     fed=self.fixed_query_loss(row)
    value=native['loss_total']+cfg['federated_weight']*fed
    if phase=='action':value=native['loss_flow']
    if not torch.isfinite(value):raise FloatingPointError('Nonfinite native federated loss')
    (value/effective).backward()
    for key,source in (('action','loss_flow'),('world','loss_perceptual'),('distill','loss_distill')):
     measures[key]+=float(native[source].detach())/effective
    measures['fed']+=float(fed.detach())/effective
    state['draw']+=1;state['metrics']['samples']+=1
    exposure=state['exposure'].setdefault(sample['source_group'],{'count':0,'records':{}});exposure['count']+=1
    exposure['records'][sample['record_id']]=exposure['records'].get(sample['record_id'],0)+1
    del batch,native,value,fed,sample
   torch.nn.utils.clip_grad_norm_([p for p in world+action+vlm+auxiliary if p.requires_grad],cfg['clip_grad_norm'],error_if_nonfinite=True)
   if phase!='action':
    wo.step();vo.step();uo.step();state['metrics']['world_updates']+=1
    state['metrics']['latent_action_distill_updates']+=1;state['metrics']['aux_updates']+=1
   ao.step();state['total_updates']+=1;state['metrics']['action_updates']+=1
   state['last_losses']=measures
   if (step+1)%self.cfg.get('checkpoint_every',50)==0:
    now=time.perf_counter();state['metrics']['train_seconds']+=now-last_saved;last_saved=now;save(step+1,snapshot())
  state['metrics']['train_seconds']+=time.perf_counter()-last_saved
  state['metrics']['peak_gpu_bytes']=torch.cuda.max_memory_allocated() if self.device.type=='cuda' else 0
  result=snapshot()
  if phase!='post':result.pop('self_teacher_world',None)
  return result
