"""Conservative ancestry and split contracts; never infer full state from proprioception."""
from collections import defaultdict
import hashlib
import numpy as np

def ordered_action_match(query,original,atol=2e-6):
    query=np.asarray(query);original=np.asarray(original)
    if query.ndim!=2 or original.ndim!=2 or query.shape[1:]!=(7,) or original.shape[1:]!=(7,):
        raise ValueError('Expected N x 7 actions')
    if not len(query) or not np.isfinite(query).all() or not np.isfinite(original).all():return None
    if len(query)>len(original):return None
    if len(query)==len(original):
        return list(range(len(query))) if np.allclose(query,original,atol=atol,rtol=0) else None
    indices=[];start=0
    for action in query:
        hits=np.flatnonzero(np.max(np.abs(original[start:]-action),axis=1)<=atol)
        if not len(hits):return None
        start+=int(hits[0]);indices.append(start);start+=1
    return indices

def continuous_starts(indices,horizon):
    indices=np.asarray(indices,dtype=np.int64)
    if horizon<1:raise ValueError('Positive horizon required')
    return [i for i in range(len(indices)-horizon) if np.all(np.diff(indices[i:i+horizon+1])==1)]

def allocate_groups(groups,seed):
    if len({g['group'] for g in groups})!=len(groups):raise ValueError('Duplicate source group')
    strata=defaultdict(list)
    for g in groups:strata[g['stratum']].append(g)
    result={};names=['train','calibration','development','prediction_test'];ratios=np.array([.7,.1,.1,.1])
    for stratum,items in sorted(strata.items()):
        n=len(items);counts=np.floor(n*ratios).astype(int)
        order=sorted(range(4),key=lambda k:(-(n*ratios-counts)[k],k))
        for k in order[:n-int(counts.sum())]:counts[k]+=1
        exposed=[g for g in items if g.get('exposed')]
        if len(exposed)>counts[0]:raise ValueError('Exposure exceeds training quota')
        for g in exposed:result[g['group']]='train'
        counts[0]-=len(exposed)
        remaining=sorted((g for g in items if not g.get('exposed')),
                         key=lambda g:hashlib.sha256(f'{seed}:{stratum}:{g["group"]}'.encode()).hexdigest())
        offset=0
        for name,count in zip(names,counts):
            for g in remaining[offset:offset+count]:result[g['group']]=name
            offset+=count
    return result

def state_matches(state,candidates,atol=1e-6):
    state=np.asarray(state);candidates=np.asarray(candidates)
    if state.ndim!=1 or candidates.ndim!=2 or candidates.shape[1]!=len(state):return []
    if not np.isfinite(state).all():raise ValueError('Nonfinite simulator state')
    # Flattened MuJoCo state starts with simulation clock. All physical components remain.
    return np.flatnonzero(np.max(np.abs(candidates[:,1:]-state[None,1:]),axis=1)<=atol).tolist()
