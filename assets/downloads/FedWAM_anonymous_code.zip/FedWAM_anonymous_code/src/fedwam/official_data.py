"""Official-release four-client split and directly indexed chunk access.

An accepted record is not evidence that its unpublished replay environment is
independent of the benchmark. All indices refer to retained RLDS observations;
continuity additionally requires consecutive original demonstration steps.
"""
from collections import defaultdict, OrderedDict
import hashlib
import io
import random
import struct
import numpy as np
from .provenance import continuous_starts
from .rlds import feature_payloads, feature_values, parse_episode

CLIENT_BUCKETS={'lighting':'light','camera_pose':'camera_view','sensor_noise':'noise','background':'env'}
SPLITS=('train','calibration','development','prediction_test')

def validate_groups(rows):
    seen={};ids=set()
    for row in rows:
        if row['record_id'] in ids:raise ValueError('Duplicate record identity')
        ids.add(row['record_id'])
        if row['split'] not in SPLITS:raise ValueError('Unknown split')
        previous=seen.setdefault(row['source_group'],row['split'])
        if previous!=row['split']:raise ValueError('cross-split source group')
    return seen

def valid_starts(indices,length,horizon=8):
    if len(indices)!=length or length<1 or any(b<=a for a,b in zip(indices,indices[1:])):
        raise ValueError('Invalid source step alignment')
    return continuous_starts(indices,horizon)

def repair_calibration(rows,exposed,seed,minimum=5):
    if minimum<1:raise ValueError('Positive calibration minimum required')
    assignments=validate_groups(rows)
    if any(assignments.get(g)!='train' for g in exposed):raise ValueError('Engineering group outside train')
    tasks=defaultdict(list)
    for row in rows:tasks[(row['suite'],row['source_file'])].append(row)
    promotions=[]
    for task,items in sorted(tasks.items()):
        coverage=defaultdict(set)
        for r in items:
            if r['continuous_chunk_starts']:coverage[r['source_group']].add(r['client'])
        counts={c:len({r['source_group'] for r in items if r['client']==c and r['split']=='calibration' and r['continuous_chunk_starts']}) for c in CLIENT_BUCKETS}
        candidates=sorted((g for g in coverage if assignments[g]=='train' and g not in exposed),
            key=lambda g:hashlib.sha256(f'{seed}:{task}:{g}'.encode()).hexdigest())
        while min(counts.values())<minimum:
            deficits={c for c,n in counts.items() if n<minimum}
            best=next(iter(sorted(candidates,key=lambda g:-len(coverage[g]&deficits))),None)
            if best is None or not coverage[best]&deficits:raise ValueError(f'Insufficient calibration source groups: {task}, {counts}')
            assignments[best]='calibration';candidates.remove(best);promotions.append(best)
            for c in coverage[best]:counts[c]+=1
        # Never silently remove a client's last train source group.
        for c in CLIENT_BUCKETS:
            if not any(assignments[g]=='train' and c in covered for g,covered in coverage.items()):
                raise ValueError(f'No train groups after calibration repair: {task}, {c}')
    result=[dict(r,split=assignments[r['source_group']]) for r in rows]
    validate_groups(result)
    return result,promotions

class ChunkSampler:
    """Task -> ancestry group -> rendering -> continuous start, all uniform.

    Draw index and seed fully specify a draw independently of call order/resume.
    Use separate seeded samplers per client/split; duplicate renderings do not
    increase the source group's sampling weight.
    """
    def __init__(self,rows,client,split,seed):
        if client not in CLIENT_BUCKETS or split not in SPLITS:raise ValueError('Invalid client/split')
        validate_groups(rows)
        self.seed=f'{int(seed)}:{client}:{split}';tree=defaultdict(lambda:defaultdict(list))
        for r in sorted(rows,key=lambda x:x['record_id']):
            if r['client']==client and r['split']==split and r['continuous_chunk_starts']:
                tree[(r['suite'],r['source_file'])][r['source_group']].append(r)
        if not tree:raise ValueError('No eligible chunks')
        self.tree=dict(tree);self.tasks=sorted(tree)
        self.groups={t:sorted(tree[t]) for t in self.tasks}
    def draw(self,index):
        if index<0:raise ValueError('Nonnegative draw index required')
        rng=random.Random(int.from_bytes(hashlib.sha256(f'{self.seed}:{int(index)}'.encode()).digest(),'big'))
        task=rng.choice(self.tasks);group=rng.choice(self.groups[task]);row=rng.choice(self.tree[task][group])
        return row,rng.choice(row['continuous_chunk_starts'])

class RawChunkReader:
    """Small LRU of compressed episode features, CRC verified on each load."""
    def __init__(self,max_cached_episodes=4):
        if max_cached_episodes<1:raise ValueError('Positive cache size required')
        self.limit=max_cached_episodes;self.cache=OrderedDict()
    def _episode(self,row):
        fields=('action_sha256','state_sha256','source_bucket','suite','source_file','length','task')
        metadata=tuple(row[field] for field in fields)
        key=(row['shard'],row['offset'],row['record_id'],row['payload_sha256'])
        if key in self.cache:
            cached=self.cache[key]
            if cached['metadata']!=metadata:raise ValueError('Cached record identity mismatch')
            self.cache.move_to_end(key);return cached
        import google_crc32c
        def masked(data):
            v=google_crc32c.value(data);return (((v>>15)|(v<<17))+0xa282ead8)&0xffffffff
        with open(row['shard'],'rb') as f:
            f.seek(row['offset']);header=f.read(12)
            if len(header)!=12:raise ValueError('Truncated indexed TFRecord header')
            size,crc=struct.unpack('<QI',header)
            if size>512*1024**2 or masked(header[:8])!=crc:raise ValueError('Invalid indexed TFRecord header CRC/size')
            payload=f.read(size);tail=f.read(4)
            if len(payload)!=size or len(tail)!=4 or masked(payload)!=struct.unpack('<I',tail)[0]:raise ValueError('Indexed TFRecord payload CRC mismatch')
        if hashlib.sha256(payload).hexdigest()!=row['payload_sha256']:raise ValueError('Indexed record payload SHA mismatch')
        observed=parse_episode(payload)
        for field in fields:
            if observed[field]!=row[field]:raise ValueError(f'Indexed record identity mismatch: {field}')
        f=feature_payloads(payload)
        value={'metadata':metadata,'action':feature_values(f['steps/action'],2).reshape(-1,7).copy(),
            'primary':feature_values(f['steps/observation/image'],1),
            'wrist':feature_values(f['steps/observation/wrist_image'],1)}
        if len(value['primary'])!=row['length'] or len(value['wrist'])!=row['length']:raise ValueError('Missing observations')
        self.cache[key]=value
        while len(self.cache)>self.limit:self.cache.popitem(last=False)
        return value
    def read(self,row,t):
        if t not in row['continuous_chunk_starts'] or t<0 or t+8>=row['length']:
            raise ValueError('Chunk is not a verified continuous t->t+8 interval')
        value=self._episode(row)
        from PIL import Image
        def image(data):
            with Image.open(io.BytesIO(data)) as im:
                if im.mode!='RGB':raise ValueError('Expected RGB frame')
                return np.asarray(im).copy()
        return {'primary':image(value['primary'][t]),'wrist':image(value['wrist'][t]),
            'future':image(value['primary'][t+8]),'actions':value['action'][t:t+8].copy(),
            'lang':row['task'],'t':t,'future_t':t+8,'record_id':row['record_id'],
            'source_group':row['source_group'],'client':row['client'],'split':row['split']}
