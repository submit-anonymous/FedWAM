"""Real LaWAM backend: private control, deployable queries and public-only aggregation."""
from collections import OrderedDict,Counter,defaultdict
from pathlib import Path
import copy,hashlib,io,json,random,time
import numpy as np
import torch
import torch.nn.functional as F
from .io import ROOT,load,digest
from .round_runtime import cpu_tree,rng_state,restore_rng,atomic_torch,atomic_json,sha
from .official_dataset import OfficialDataset
from .training import configure,encode,losses,amp
from .parameter_methods import (install_adapters,adapter_parameters,adapter_export,aggregate_adapters,
 load_adapter_updates,world_export,validate_world_artifact,average_world)
from .packets import pack,unpack
from .server_teacher import train_teacher,load_teacher,select_prediction
from .reception import calibrate_reception,calibrate_support,reception_weights
from .function_controls import average_fixed_queries,future_from_prediction

def serialized_bytes(value):
 stream=io.BytesIO();torch.save(value,stream);return stream.getvalue()
def teacher_public(artifact):
 return {k:artifact[k] for k in ('schema','config','model','support','interface_version')}

class LaWAMFederation:
 def __init__(self,policy,config,run_root,interface_version):
  self.policy=policy;self.b=configure(policy);self.cfg=config;self.method=config['method'];self.root=Path(run_root)
  self.device=next(policy.parameters()).device;self.interface_version=interface_version
  self.adapter=self.method in ('M3','Local-adapter')
  if self.adapter:install_adapters(self.b.lam.decoder,config.get('adapter_rank',8),seed=0)
  self.base_world=cpu_tree(self.b.lam.decoder.state_dict());self.base_action=cpu_tree(self.b.flow.state_dict())
  self.stats=load(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json')['franka']['action']
  self.datasets={c:OfficialDataset(ROOT,c,'train',config['seed'],max_cached_episodes=1) for c in config['clients']}
  self.cache=OrderedDict();self.cache_limit=config.get('feature_cache_entries',8)
  self.representation=config.get('representation','transition')
  if self.representation not in ('future','transition'):raise ValueError('Unsupported representation')
 def initialize(self,client):
  random.seed(self.cfg['seed']);np.random.seed(self.cfg['seed']);torch.manual_seed(self.cfg['seed'])
  return {'world':cpu_tree(self.base_world),'action':cpu_tree(self.base_action),'world_optimizer':None,'action_optimizer':None,
   'rng':rng_state(),'draw':0,'total_updates':0,'exposure':{},'metrics':{'samples':0,'world_updates':0,'action_updates':0,'train_seconds':0.}}
 def weights(self,state):
  self.b.lam.decoder.load_state_dict(state['world'],strict=True);self.b.flow.load_state_dict(state['action'],strict=True)
 def _enable(self,phase):
  configure(self.policy,world=phase!='action',action=True)
  if self.adapter:
   self.b.lam.decoder.requires_grad_(False)
   for p in adapter_parameters(self.b.lam.decoder):p.requires_grad_(phase!='action')
  world=list(adapter_parameters(self.b.lam.decoder)) if self.adapter else list(self.b.lam.decoder.parameters())
  return world,list(self.b.flow.parameters())
 def batch(self,sample):
  key=(sample['record_id'],sample['t'])
  if key in self.cache:
   self.cache.move_to_end(key);cached=self.cache[key]
  else:
   encoded,_=encode(self.policy,sample,self.stats);cached=cpu_tree(encoded);self.cache[key]=cached
   while len(self.cache)>self.cache_limit:self.cache.popitem(last=False)
  return {k:v.to(self.device) for k,v in cached.items()}
 def sample(self,client,draw):
  origin=client if client!='pooled' else self.cfg['clients'][draw%len(self.cfg['clients'])]
  index=draw if client!='pooled' else draw//len(self.cfg['clients'])
  dataset=self.datasets[origin];row,t=dataset.sampler.draw(index);sample=dataset.reader.read(row,t)
  sample['task_id']=row['suite']+'/'+row['source_file'];return sample
 def predict(self,batch):
  with amp(self.device):return self.b._decode_future_tokens_strict_single_query(h_t=batch['h_t'].float(),pred_action_emb=batch['intent'].float(),source='fedwam_federation')
 def _future(self,pred,z):return future_from_prediction(pred,z,self.representation)
 def _teacher_context(self,client,context,state,start):
  result=dict(context)
  if context['kind']=='teacher':
   result['model']=load_teacher(context['teacher'],self.device)
   if self.method in ('M6','M8') and self.cfg.get('reception_gate',True):
    # Stored calibration is reusable only within the same resumed post phase.
    if start and state.get('reception') is not None:result['reception']=state['reception']
    else:result['reception']=self.calibrate(client,result['model'],context['teacher']['support'])
   else:result['reception']=None
  elif self.method=='M7':
   result={'kind':'self','model':copy.deepcopy(self.b.lam.decoder).eval().requires_grad_(False)}
   # On interrupted post training, use the original send-phase snapshot.
   snapshot=state.get('self_teacher_world') if start else state['world']
   if snapshot is None:raise ValueError('SelfKD snapshot missing on resume')
   result['model'].load_state_dict(snapshot);state['self_teacher_world']=cpu_tree(snapshot)
  return result
 def train(self,client,state,phase,steps,context,start,save):
  self.weights(state);world,action=self._enable(phase)
  wo=torch.optim.AdamW(world,lr=self.cfg['training']['lr'],weight_decay=self.cfg['training']['weight_decay'])
  ao=torch.optim.AdamW(action,lr=self.cfg['training']['lr'],weight_decay=self.cfg['training']['weight_decay'])
  if state['world_optimizer'] is not None and not(phase=='post' and start==0):wo.load_state_dict(state['world_optimizer'])
  if state['action_optimizer'] is not None:ao.load_state_dict(state['action_optimizer'])
  if phase=='post' and start==0:
   if context['kind']=='world':self.b.lam.decoder.load_state_dict(context['world'],strict=True)
   if context['kind']=='adapter':load_adapter_updates(self.b.lam.decoder,context['updates'])
  restore_rng(state['rng'])
  active=self._teacher_context(client,context,state,start) if phase=='post' else {'kind':'none'}
  if active.get('reception') is not None:
   state['reception']=active['reception']
   if start==0:state['metrics']['calibration_seconds']=state['metrics'].get('calibration_seconds',0.)+active['reception']['seconds']
  restore_rng(state['rng']);settings=self.cfg['training'];effective=settings['effective_batch'];started=time.perf_counter()
  state.setdefault('reception_counts',{'queries':0,'positive':0,'weight_sum':0.})
  def snapshot():
   state['world']=cpu_tree(self.b.lam.decoder.state_dict());state['action']=cpu_tree(self.b.flow.state_dict())
   state['world_optimizer']=cpu_tree(wo.state_dict());state['action_optimizer']=cpu_tree(ao.state_dict());state['rng']=rng_state()
   return state
  last_saved=time.perf_counter()
  for step in range(start,steps):
   wo.zero_grad(set_to_none=True);ao.zero_grad(set_to_none=True);measures=Counter()
   for micro in range(effective):
    sample=self.sample(client,state['draw']);batch=self.batch(sample)
    target=None;gate=None;extra=batch['h_t'].new_zeros((),dtype=torch.float32)
    if active['kind']=='teacher':
     with torch.no_grad():
      output=active['model'](batch['h_t'].float(),batch['intent'].float());target=self._future(select_prediction(output),batch['h_t']).detach()
      if active['reception'] is not None:
       gate=reception_weights(active['reception']['calibration'],[sample['task_id']],batch['h_t'],batch['intent'],active['reception']['support'],output['logits'])
      else:gate=torch.ones(1,device=self.device)
     counts=state['reception_counts'];counts['queries']+=1;counts['positive']+=int(gate.item()>0);counts['weight_sum']+=float(gate.item())
    elif active['kind']=='self':
     # The native decoder is called through the same backend routine with a temporary module swap.
     native=self.b.lam.decoder
     try:
      self.b.lam.decoder=active['model']
      with torch.no_grad():target=self.predict(batch).detach()
     finally:self.b.lam.decoder=native
    elif active['kind']=='fixed':
     row=active['queries'][state['draw']%len(active['queries'])]
     q={'h_t':row['z'][None].to(self.device),'intent':row['intent'][None].to(self.device)}
     target_q=self._future(row['prediction'][None].to(self.device),q['h_t'])
     extra=F.mse_loss(self.predict(q).float(),target_q.float())
    value=losses(self.policy,batch,detach_feedback=not self.cfg.get('action_feedback',True),teacher_target=target,gate=gate)
    total=value['action']+settings['world_weight']*value['world']+settings['federated_weight']*(value['fed']+extra)
    if phase=='action':total=value['action']
    if not torch.isfinite(total):raise FloatingPointError('Nonfinite local loss')
    (total/effective).backward()
    for k in ('action','world','fed'):measures[k]+=float(value[k].detach())/effective
    state['draw']+=1;state['metrics']['samples']+=1
    exposure=state['exposure'].setdefault(sample['source_group'],{'count':0,'records':{}});exposure['count']+=1
    exposure['records'][sample['record_id']]=exposure['records'].get(sample['record_id'],0)+1
    del batch,value,total,target,sample
   norm=torch.nn.utils.clip_grad_norm_([p for p in world+action if p.requires_grad],settings['clip_grad_norm'],error_if_nonfinite=True)
   if phase!='action':wo.step();state['metrics']['world_updates']+=1
   ao.step();state['total_updates']+=1;state['metrics']['action_updates']+=1
   state['last_losses']=dict(measures,pre_clip_norm=float(norm))
   if (step+1)%self.cfg.get('checkpoint_every',50)==0:
    now=time.perf_counter();state['metrics']['train_seconds']+=now-last_saved;last_saved=now
    save(step+1,snapshot())
  state['metrics']['train_seconds']+=time.perf_counter()-last_saved
  state['metrics']['peak_gpu_bytes']=torch.cuda.max_memory_allocated() if self.device.type=='cuda' else 0
  result=snapshot()
  if phase!='post':result.pop('self_teacher_world',None)
  del wo,ao,active
  return result
 def calibrate(self,client,model,support):
  dataset=OfficialDataset(ROOT,client,'calibration',self.cfg['seed'],max_cached_episodes=1)
  calibration_started=time.perf_counter()
  grouped=defaultdict(list)
  for row in dataset.rows:grouped[(row['suite']+'/'+row['source_file'],row['source_group'])].append(row)
  tasks=sorted({key[0] for key in grouped})
  if self.cfg.get('mode')=='engineering':tasks=tasks[:1]
  rows=[];zs=[];intents=[]
  for (task,group),items in sorted(grouped.items()):
   if task not in tasks:continue
   row=min(items,key=lambda x:x['record_id']);t=row['continuous_chunk_starts'][0];sample=dataset.reader.read(row,t);batch=self.batch(sample)
   with torch.no_grad():
    local=self.predict(batch).float();output=model(batch['h_t'].float(),batch['intent'].float())
    pred=self._future(select_prediction(output),batch['h_t']);target=batch['future_target'].float()
    all_future=self._future(output['means'],batch['h_t'][:,None])
    selected=output['logits'].argmax(-1);best=(all_future-target[:,None]).square().mean((-1,-2)).argmin(-1)
    rows.append(dict(task=task,source_group=group,local_error=float((local-target).square().mean()),teacher_error=float((pred-target).square().mean()),selected_branch_correct=bool((selected==best).all())))
    zs.append(batch['h_t'].cpu());intents.append(batch['intent'].cpu())
  calibration=calibrate_reception(rows,margin=self.cfg['server']['gain_margin'],min_groups=self.cfg['server']['calibration_min_groups'])
  local_support=calibrate_support(support,torch.cat(zs),torch.cat(intents))
  return {'calibration':calibration,'support':local_support,'samples':rows,'seconds':time.perf_counter()-calibration_started,'scope':'engineering one task' if self.cfg.get('mode')=='engineering' else 'all calibration source groups'}
 def _records(self,client,state,round,public=False):
  self.weights(state);records=[];seen=set();group_counts=Counter();accepted_mass=Counter();excluded_mass=0.;limit=self.cfg['server']['max_queries']
  # Each full spatial query costs at least two FP16 token arrays on the wire.
  per_query=2*self.cfg['server']['spatial_tokens']*self.cfg['server']['feature_dim']*2+4096
  limit=min(limit,max(1,self.cfg['server']['packet_budget_bytes']//per_query))
  version=hashlib.sha256(serialized_bytes(state['world'])).hexdigest()
  if public:
   candidates=self.public_queries()
   iterator=range(len(candidates))
  else:iterator=range(limit*30)
  for index in iterator:
   if public:
    item=candidates[index];batch={'h_t':item['z'][None].to(self.device),'intent':item['intent'][None].to(self.device)}
    group=item['source_group'];task=item['task'];qid=item['query_id'];prob=1/len(candidates)
   else:
    draw=100000000+round*100000+index;dataset=self.datasets[client];row,t=dataset.sampler.draw(draw)
    group=row['source_group'];qid=digest([row['record_id'],t]);task=row['suite']+'/'+row['source_file']
    if qid in seen or group_counts[group]>=self.cfg.get('packet_per_group',4):continue
    sample=dataset.reader.read(row,t);batch=self.batch(sample)
    tree=dataset.sampler.tree;task_key=(row['suite'],row['source_file'])
    proposal=1/(len(tree)*len(tree[task_key])*len(tree[task_key][group])*len(row['continuous_chunk_starts']))
    prob=min(1.,proposal/max(1-excluded_mass,1e-12))
   with torch.no_grad():
    prediction=self.predict(batch).float()
    if self.representation=='transition':prediction=prediction-batch['h_t'].float()
   records.append(dict(z=batch['h_t'][0].detach().cpu().half(),intent=batch['intent'][0].detach().cpu().half(),
    prediction=prediction[0].cpu().half(),horizon=8,hz=20,client=client,round=round,task=task,source_group=group,
    query_id=qid,model_version=version,interface_version=self.interface_version,sampling_probability=prob,reliability=1.))
   seen.add(qid);group_counts[group]+=1
   if not public:
    if group_counts[group]==self.cfg.get('packet_per_group',4):excluded_mass+=1/(len(tree)*len(tree[task_key]))-accepted_mass[group]
    else:excluded_mass+=proposal;accepted_mass[group]+=proposal
   if len(records)>=limit:break
  if not records:raise ValueError('No eligible public prediction queries')
  return records
 def public_queries(self):
  path=self.root/'public_queries.pt'
  if path.exists():
   saved=torch.load(path,map_location='cpu',weights_only=False)
   if saved['interface_version']!=self.interface_version:raise ValueError('Stale public query bank')
   atomic_json(self.root/'events/public_queries_initialization.json',{'upload_bytes':{'public_query_construction':path.stat().st_size},
    'download_bytes':{c:path.stat().st_size for c in self.cfg['clients']},'scope':'M4 additional train-query union access; no future labels','seconds_this_attempt':0})
   return saved['queries']
  # Fixed train-only union; bank contains no raw observations, targets or actions.
  queries=[];seen=set();limit=min(self.cfg['server']['max_queries'],max(1,(self.cfg['server']['packet_budget_bytes']//(2*self.cfg['server']['spatial_tokens']*self.cfg['server']['feature_dim']*2+4096))))
  for index in range(limit*20):
   client=self.cfg['clients'][index%len(self.cfg['clients'])];dataset=self.datasets[client]
   row,t=dataset.sampler.draw(200000000+index//len(self.cfg['clients']));qid=digest([row['record_id'],t])
   if qid in seen:continue
   batch=self.batch(dataset.reader.read(row,t));group=row['source_group'];task=(row['suite'],row['source_file']);tree=dataset.sampler.tree
   queries.append(dict(query_id=qid,z=batch['h_t'][0].detach().cpu().half(),intent=batch['intent'][0].detach().cpu().half(),
     task='/'.join(task),source_group=group,sampling_probability=1/(len(self.cfg['clients'])*len(tree)*len(tree[task])*len(tree[task][group])*len(row['continuous_chunk_starts']))))
   seen.add(qid)
   if len(queries)>=limit:break
  atomic_torch(path,{'interface_version':self.interface_version,'queries':queries})
  atomic_json(self.root/'events/public_queries_initialization.json',{'upload_bytes':{'public_query_construction':path.stat().st_size},
   'download_bytes':{c:path.stat().st_size for c in self.cfg['clients']},'scope':'M4 additional train-query union access; no future labels','seconds_this_attempt':0})
  return queries
 def publish(self,client,state,round):
  publish_started=time.perf_counter();self.weights(state)
  if self.method=='M2':return {'kind':'world','artifact':world_export(self.b.lam.decoder),'client':client,'round':round}
  if self.method=='M3':
   self._enable('pre')
   return {'kind':'adapter','artifact':adapter_export(self.b.lam.decoder),'client':client,'round':round}
  if self.method in ('M4','M5','M6','M8'):
   records=self._records(client,state,round,public=self.method=='M4')
   payload,n=pack(records,self.cfg['server']['packet_budget_bytes'],self.cfg['server']['max_queries'])
   if not n:raise ValueError('Packet budget cannot hold one prediction')
   if self.method=='M4' and n!=len(records):raise ValueError('M4 public bank does not fit common budget')
   return {'kind':'packet','payload':payload,'client':client,'round':round,'count':n,'bytes':len(payload),'packet_seconds':time.perf_counter()-publish_started}
  return {'kind':'none'}
 def upload_bytes(self,export):
  if export['kind']=='none':return 0
  if export['kind']=='packet':return len(export['payload'])
  return len(serialized_bytes(export['artifact']))
 def aggregate(self,exports,previous,round,workdir):
  if self.method in ('M1','M7','M9','Local-adapter'):return {'kind':'none'}
  if set(exports)!=set(self.cfg['clients']):raise ValueError('Server missing current-round clients')
  for client,export in exports.items():
   if export.get('client')!=client or export.get('round')!=round:raise ValueError('Mixed client/round contribution')
  if self.method=='M2':return {'kind':'world','world':average_world([validate_world_artifact(v['artifact']) for v in exports.values()])}
  if self.method=='M3':
   updates,metrics=aggregate_adapters([v['artifact'] for v in exports.values()],self.cfg.get('adapter_rank',8))
   return {'kind':'adapter','updates':updates,'metrics':metrics}
  records={}
  for client,export in exports.items():
   records[client]=unpack(export['payload'])
   if not records[client] or any(r['client']!=client or r['round']!=round or r['interface_version']!=self.interface_version for r in records[client]):raise ValueError('Stale prediction packet')
  if self.method=='M4':return {'kind':'fixed','queries':average_fixed_queries(list(records.values()))}
  s=self.cfg['server'];config={'tokens':s['spatial_tokens'],'dim':s['feature_dim'],'intent_dim':s['intent_dim'],
   'width':s['teacher_width'],'depth':s['teacher_depth'],'heads':s['teacher_heads'],'branches':1 if self.method=='M5' else self.cfg.get('branches',1),
   'steps':s['steps_per_round'],'batch_size':s['batch'],'lr':s['lr'],'device':str(self.device),
   'checkpoint_every':self.cfg.get('server_checkpoint_every',50),'replay_rounds':s['replay_rounds'],
   'validation_fraction':.2,'reliability_weighting':False}
  workdir=Path(workdir);workdir.mkdir(parents=True,exist_ok=True)
  def run_teacher(name,incoming,old):
   path=workdir/f'{name}.pt'
   if path.exists():old=torch.load(path,map_location='cpu',weights_only=False)
   result=train_teacher(incoming,config,self.cfg['seed'],previous=old,checkpoint_callback=lambda x:atomic_torch(path,x))
   atomic_torch(path,result);return result
  if self.method=='M8':
   if config['steps']%len(self.cfg['clients']):raise ValueError('M8 total server step budget must divide across clients')
   config['steps']//=len(self.cfg['clients'])
   teachers={}
   for client in self.cfg['clients']:
    old=previous.get('teachers',{}).get(client) if previous else None
    teachers[client]=run_teacher(client,[exports[client]['payload']],old)
   return {'kind':'self_teachers','teachers':teachers,'control':'total server steps split equally across private teachers; same batch/replay and own-source packets; total sample draws matched'}
  old=previous.get('teacher') if previous else None
  teacher=run_teacher('global',[v['payload'] for v in exports.values()],old)
  return {'kind':'teacher','teacher':teacher}
 def broadcast(self,server,client):
  if server['kind']=='self_teachers':return {'kind':'teacher','teacher':teacher_public(server['teachers'][client])}
  if server['kind']=='teacher':return {'kind':'teacher','teacher':teacher_public(server['teacher'])}
  return server
