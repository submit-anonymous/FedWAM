"""Strict predicted-query wire format. Real targets and private state are forbidden."""
from __future__ import annotations
import io
import math
import torch

SCHEMA = 'fedwam.predicted-packets.v1'
FIELDS = frozenset(('z', 'intent', 'prediction', 'horizon', 'hz', 'client', 'round',
                    'task', 'source_group', 'query_id', 'model_version',
                    'interface_version', 'sampling_probability', 'reliability'))
IDENTITY = ('client', 'round', 'model_version', 'interface_version', 'horizon', 'hz')


def validate_record(record):
    if not isinstance(record, dict) or set(record) != FIELDS:
        raise ValueError('Packet fields must exactly match public predicted-query schema')
    result = dict(record)
    for key in ('z', 'intent', 'prediction'):
        value = record[key]
        if not isinstance(value, torch.Tensor) or not value.is_floating_point() or value.layout != torch.strided:
            raise ValueError(f'{key} must be a dense floating tensor')
        if not torch.isfinite(value).all():
            raise ValueError(f'{key} contains nonfinite values')
        result[key] = value.detach().to('cpu').contiguous().clone()
    if result['z'].ndim != 2 or min(result['z'].shape) < 1 or result['prediction'].shape != result['z'].shape:
        raise ValueError('z and prediction must have matching nonempty [tokens,dim] shapes')
    if result['intent'].shape != (1, 32):
        raise ValueError('intent must have shape [1,32]')
    for key in ('client', 'task', 'source_group', 'query_id', 'model_version', 'interface_version'):
        if not isinstance(record[key], str) or not record[key].strip():
            raise ValueError(f'{key} must be a nonempty identity string')
    if type(record['round']) is not int or record['round'] < 0:
        raise ValueError('round must be a nonnegative integer')
    if record['horizon'] != 8 or record['hz'] != 20:
        raise ValueError('Only the frozen H=8,20Hz interface is supported')
    for key in ('sampling_probability', 'reliability'):
        if type(record[key]) not in (int, float) or not math.isfinite(record[key]):
            raise ValueError(f'{key} must be finite numeric data')
    if not 0 < record['sampling_probability'] <= 1 or record['reliability'] < 0:
        raise ValueError('Invalid probability or reliability')
    return result


def _validate_records(records):
    result = [validate_record(r) for r in records]
    seen = set()
    for record in result:
        if any(record[k] != result[0][k] for k in IDENTITY):
            raise ValueError('Mixed source/version/round identities in one packet')
        if record['z'].shape != result[0]['z'].shape:
            raise ValueError('Mixed query tensor shapes')
        if record['query_id'] in seen:
            raise ValueError('Duplicate query identity')
        seen.add(record['query_id'])
    return result


def _serialize(records):
    stream = io.BytesIO()
    torch.save({'schema': SCHEMA, 'records': records}, stream)
    return stream.getvalue()


def pack(records, max_bytes=256 * 1024**2, max_queries=1024):
    """Fit the longest input prefix, including all envelope/tensor bytes."""
    if type(max_bytes) is not int or max_bytes < 1 or type(max_queries) is not int or max_queries < 0:
        raise ValueError('Invalid packet budget')
    records = _validate_records(list(records))[:max_queries]
    empty = _serialize([])
    if len(empty) > max_bytes:
        raise ValueError('Byte budget cannot hold an empty packet envelope')
    # Binary search avoids quadratic tensor serialization at production packet sizes.
    lo, hi, payload = 0, len(records), empty
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate = _serialize(records[:mid])
        if len(candidate) <= max_bytes:
            lo, payload = mid, candidate
        else:
            hi = mid - 1
    return payload, lo


def unpack(payload):
    if not isinstance(payload, bytes):
        raise ValueError('Expected serialized packet bytes')
    try:
        envelope = torch.load(io.BytesIO(payload), map_location='cpu', weights_only=True)
    except Exception as exc:
        raise ValueError('Malformed packet serialization') from exc
    if not isinstance(envelope, dict) or set(envelope) != {'schema', 'records'} or envelope['schema'] != SCHEMA:
        raise ValueError('Unknown packet envelope')
    if not isinstance(envelope['records'], list):
        raise ValueError('Packet records must be a list')
    return _validate_records(envelope['records'])
