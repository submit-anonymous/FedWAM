"""Synchronous federation with private client phases and idempotent round commits."""
import json,io,time,shutil
import torch
from .round_runtime import RoundStore,PhaseRunner,atomic_json

class FederationEngine:
 def __init__(self,root,identity,config,backend,fault_hook=None):
  self.store=RoundStore(root,identity);self.phases=PhaseRunner(self.store);self.config=config;self.backend=backend
  self.clients=['pooled'] if config['method']=='M9' else config['clients'];self.hook=fault_hook or (lambda stage:None)
 def phase(self,client,state,round,phase,steps,context):
  key=f'r{round:04d}/{client}/{phase}'
  metadata={'method':self.config['method'],'seed':self.config['seed'],'client':client,'round':round,'phase':phase}
  atomic_json(self.store.path('status.json'),{'state':'running','round':round,'phase':phase,'client':client,'steps':steps})
  result=self.phases.run(key,state,steps,lambda state,start,save:self.backend.train(client,state,phase,steps,context,start,save),metadata)
  self.hook(f'round{round}:{phase}:{client}')
  return result,self.phases.ref(key)
 def artifact(self,key,compute):
  receipt=self.store.path(f'{key}.json')
  if receipt.exists():
   ref=json.loads(receipt.read_text());return self.store.read_ref(ref),ref
  value=compute();ref=self.store.write(f'{key}.pt',value);atomic_json(receipt,ref);return value,ref
 def run(self):
  cfg=self.config;budget=cfg['training'];factor=len(cfg['clients']) if cfg['method']=='M9' else 1
  latest=self.store.latest();states={};refs={}
  if latest is None:
   for client in self.clients:
    states[client],refs[client]=self.phase(client,self.backend.initialize(client),-1,'warmup',budget['warmup']*factor,{'kind':'none'})
   latest=self.store.commit(-1,refs,self.clients)
  else:
   states={c:self.store.read_ref(ref)['state'] for c,ref in latest['clients'].items()}
  previous=self.store.read_ref(latest['server']) if latest.get('server') else None
  for round in range(latest['round']+1,budget['rounds']):
   begin=time.perf_counter();exports={};upload={};pre={}
   for client in self.clients:
    pre[client],_=self.phase(client,states[client],round,'pre',budget['pre_receive_joint']*factor,{'kind':'none'})
    exports[client],ref=self.artifact(f'public/r{round:04d}/{client}',lambda c=client:self.backend.publish(c,pre[c],round))
    upload[client]=self.backend.upload_bytes(exports[client]) if hasattr(self.backend,'upload_bytes') else (ref['bytes'] if exports[client]['kind']!='none' else 0)
   self.hook(f'round{round}:all_pre_committed')
   server,server_ref=self.artifact(f'server/r{round:04d}',lambda:self.backend.aggregate(exports,previous,round,self.store.path(f'server/progress/r{round:04d}')))
   self.hook(f'round{round}:server_committed');download={};refs={}
   for client in self.clients:
    context=self.backend.broadcast(server,client)
    buffer=io.BytesIO();torch.save(context,buffer);download[client]=len(buffer.getvalue()) if context['kind']!='none' else 0
    state,_=self.phase(client,pre[client],round,'post',budget['post_receive_joint']*factor,context)
    state,refs[client]=self.phase(client,state,round,'action',budget['final_world_action_only']*factor,{'kind':'none'})
    states[client]=state
   server_seconds=(sum(t['metrics']['training_seconds'] for t in server['teachers'].values()) if server['kind']=='self_teachers' else server['teacher']['metrics']['training_seconds'] if server['kind']=='teacher' else 0.)
   ledger={'server_seconds':server_seconds,'packet_seconds':sum(x.get('packet_seconds',0.) for x in exports.values()),'client_cumulative_metrics':{c:states[c].get('metrics',{}) for c in self.clients},'upload_bytes':upload,'download_bytes':download,'seconds_this_attempt':time.perf_counter()-begin,'transport':'serialized same-host simulation, not network throughput'}
   self.store.event(f'round_{round:04d}',ledger)
   latest=self.store.commit(round,refs,self.clients,server_ref,ledger);previous=server
   self.hook(f'round{round}:committed')
   # Retain current and previous private states plus bounded server packet replay.
   if cfg.get('prune',True):
    old=round-2
    for prefix in ['phases','server/progress']:
     p=self.store.path(f'{prefix}/r{old:04d}')
     if p.exists():shutil.rmtree(p)
    old_server=self.store.path(f'server/r{old:04d}.pt')
    if old_server.exists():old_server.unlink()
    old_packet=round-int(cfg.get('server',{}).get('replay_rounds',4))
    p=self.store.path(f'public/r{old_packet:04d}')
    if p.exists():shutil.rmtree(p)
  final={'identity':self.store.identity,'method':cfg['method'],'seed':cfg['seed'],'clients':latest['clients'],
      'adapter_rank':cfg.get('adapter_rank',8) if cfg['method'] in ('M3','Local-adapter') else None,
      'rounds':budget['rounds'],'scope':self.store.identity.get('mode','unspecified')}
  atomic_json(self.store.path('final.json'),final)
  atomic_json(self.store.path('status.json'),{'state':'completed','phase':'all_rounds_committed','rounds':budget['rounds'],'clients':self.clients})
  return final
