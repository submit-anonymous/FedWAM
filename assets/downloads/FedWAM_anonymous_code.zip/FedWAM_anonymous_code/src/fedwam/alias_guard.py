"""Accept only verified shared references to actually loaded checkpoint tensors."""
from collections import Counter


def validate_loaded_keys(module, checkpoint, result):
    import torch
    live = module.state_dict(keep_vars=True)
    missing, unexpected = list(result.missing_keys), list(result.unexpected_keys)
    groups, invalid, value_failures = Counter(), [], []
    mappings = (('policy_vlm_adapter.model.', 'policy_backend.vlm.'),
                ('policy_action_head.', 'policy_backend.flow.'))
    for key in missing:
        canonical = None
        for alias_prefix, canonical_prefix in mappings:
            if key.startswith(alias_prefix):
                canonical = canonical_prefix + key[len(alias_prefix):]
                break
        if (canonical is None or canonical not in checkpoint or canonical in missing
                or key not in live or canonical not in live
                or live[key] is not live[canonical]):
            invalid.append(key)
            continue
        tensor, source = live[canonical], checkpoint[canonical]
        if (tensor.is_meta or source.is_meta or tensor.shape != source.shape
                or not torch.equal(tensor.detach(), source.detach().to(device=tensor.device, dtype=tensor.dtype))):
            value_failures.append(key)
            continue
        groups[key.split('.')[0]] += 1
    if invalid or unexpected or value_failures:
        examples = [k[:100] for k in (invalid + unexpected + value_failures)[:3]]
        raise RuntimeError(
            f'Checkpoint verification failed: missing={len(invalid)}, '
            f'unexpected={len(unexpected)}, alias_value_mismatch={len(value_failures)}; '
            f'examples={examples}')
    return {'missing': [], 'unexpected': [], 'reported_missing_count': len(missing),
            'verified_alias_count': sum(groups.values()), 'verified_alias_groups': dict(groups),
            'verification': 'same Parameter/buffer object and loaded checkpoint value'}
