"""Architecture-independent federation; separate from the frozen LaWAM campaign."""
