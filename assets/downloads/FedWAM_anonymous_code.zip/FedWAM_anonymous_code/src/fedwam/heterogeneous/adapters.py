"""Actual model boundaries, kept separate from the frozen main LaWAM campaign."""
import gc
import json
from pathlib import Path
import torch
from .interface import FutureReadout,pool_spatial
from .reference import REFERENCE_ID


class LaWAMAdapter:
    architecture='lawam'
    subset='A'
    def __init__(self,root,readout=None):
        from unittest.mock import patch
        from starVLA.model.framework.base_framework import baseframework
        from fedwam.alias_guard import validate_loaded_keys
        root=Path(root)
        original=torch.nn.Module.load_state_dict;captures=[]
        def checked(module,weights,*args,**kwargs):
            result=original(module,weights,*args,**kwargs)
            if any(k.startswith('policy_backend.') for k in weights):
                captures.append(validate_loaded_keys(module,weights,result))
            return result
        with patch.object(torch.nn.Module,'load_state_dict',checked):
            self.model=baseframework.from_pretrained(str(root/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'))
        if len(captures)!=1:raise ValueError('Missing full checkpoint compatibility receipt')
        self.model=self.model.cuda().eval().requires_grad_(False)
        self.stats=json.loads((root/'runtime/lawam_libero_sft/dataset_statistics.json').read_text())['franka']['action']
        self.world=self.model.policy_backend.lam.decoder
        self.action=self.model.policy_backend.flow
        self.version='lawam-libero-sft-base-reference-v3'

    def prepare(self,sample):
        from fedwam.training import encode
        return encode(self.model,sample,self.stats)[0]

    def predict(self,native):
        from fedwam.training import amp
        with amp('cuda'):
            y=self.model.policy_backend._decode_future_tokens_strict_single_query(
                h_t=native['h_t'],pred_action_emb=native['intent'],source='heterogeneous_adapter')
        return pool_spatial(y.float())

    def state(self,sample):
        # The current LaWAM checkpoint does not consume proprioception.
        return torch.zeros(1,8),torch.zeros(1,8,dtype=torch.bool)

    def action_output(self,sample,native):
        import numpy as np
        torch.manual_seed(42)
        result=self.model.predict_action(examples=[dict(lang=sample['lang'],primary_image=[sample['primary']],
            wrist_image=[sample['wrist']],action_hz=20.,embodiment_id=25)])
        return torch.from_numpy(np.asarray(result['normalized_actions']).copy()).float()


class ImageWAMAdapter:
    architecture='imagewam'
    subset='B'
    def __init__(self,root,readout):
        from hydra.utils import instantiate
        from omegaconf import OmegaConf
        from imagewam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
        import hashlib
        root=Path(root)
        cfg=OmegaConf.load(root/'reports/imagewam_preparation/native_eval_config.yaml')
        self.model=instantiate(cfg.model,model_dtype=torch.bfloat16,device='cuda')
        def checked(module,keys):
            if keys.missing_keys or keys.unexpected_keys:raise ValueError('ImageWAM checkpoint key mismatch')
        hook=self.model.mot.register_load_state_dict_post_hook(checked)
        try:
            payload=self.model.load_checkpoint(str(cfg.ckpt))
            if 'proprio_encoder' not in payload:raise ValueError('Missing proprio weights')
            del payload
        finally:hook.remove()
        gc.collect()
        self.model.eval().requires_grad_(False)
        self.processor=instantiate(cfg.data.train.processor).eval()
        self.processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(cfg.EVALUATION.dataset_stats_path)))
        payload=torch.load(readout,map_location='cpu',weights_only=True)
        if payload['reference_id']!=REFERENCE_ID or payload['horizon_original_steps']!=8:
            raise ValueError('Readout common reference mismatch')
        adaptation=payload.get('native_adaptation')
        if adaptation is not None:
            from fedwam.round_runtime import sha
            if sha(adaptation['path'])!=adaptation['sha256']:
                raise ValueError('Native checkpoint no longer matches calibrated readout')
            saved=torch.load(adaptation['path'],map_location='cpu',weights_only=False)
            if saved['identity']!=adaptation['identity'] or saved['step']!=adaptation['step']:
                raise ValueError('Native checkpoint/readout identity mismatch')
            for name,expected in saved['identity']['assets'].items():
                if sha(name)!=expected:raise ValueError('Frozen native asset differs from calibrated model')
            config_key='reports/imagewam_preparation/native_eval_config.yaml'
            if sha(root/config_key)!=saved['identity']['code'][config_key]:raise ValueError('Native configuration changed')
            self.model.mot.load_state_dict(saved['modules']['mot'],strict=True)
            self.model.proprio_encoder.load_state_dict(saved['modules']['proprio_encoder'],strict=True)
            del saved;gc.collect()
        kind=payload.get('readout_kind','learned_query')
        if kind=='spatial':
            from .spatial_readout import SpatialFutureReadout
            head_class=SpatialFutureReadout
        elif kind=='learned_query':head_class=FutureReadout
        else:raise ValueError('Unknown calibrated readout architecture')
        self.head=head_class(3072).cuda().eval().requires_grad_(False)
        self.head.load_state_dict(payload['head'],strict=True)
        self.domain=payload['domain']
        self.version='imagewam-base-readout-'+hashlib.sha256(Path(readout).read_bytes()).hexdigest()
        self.world=self.model.video_expert;self.action=self.model.action_expert
        self.text_cache={}

    @torch.no_grad()
    def text(self,instruction):
        if instruction not in self.text_cache:
            if next(self.model.text_encoder.model.parameters()).device.type!='cuda':
                self.model.text_encoder.model.to('cuda')
            hidden,mask=self.model._encode_flux2_prompts([instruction])
            self.text_cache[instruction]=(hidden.cpu(),mask.cpu())
        return tuple(t.cuda() for t in self.text_cache[instruction])

    def prepare(self,sample):
        from .imagewam import make_native_sample
        native=make_native_sample(sample,self.processor)
        native['text_hidden_states'],native['text_attention_mask']=self.text(native['instruction'])
        return native

    def predict(self,native):
        from .imagewam import prefix_cache,control_features_from_cache
        with torch.autocast('cuda',dtype=torch.bfloat16):
            h=control_features_from_cache(prefix_cache(self.model,native['current_frame'],native['text_hidden_states'],
                native['text_attention_mask'],native['proprio']))
            return self.head(h).float()

    def state(self,sample):
        # Physical current state8 is common across clients; normalization is local.
        return torch.as_tensor(sample['state'],dtype=torch.float32)[None],torch.ones(1,8,dtype=torch.bool)

    def action_output(self,sample,native):
        return self.model.infer_action_flux2(prompt=None,input_image=native['current_frame'],proprio=native['proprio'],
            context=native['text_hidden_states'],context_mask=native['text_attention_mask'],
            action_horizon=8,num_inference_steps=10,seed=42)['action'].float().cpu()

    def offload_text(self):
        self.model.text_encoder.model.to('cpu');gc.collect();torch.cuda.empty_cache()
