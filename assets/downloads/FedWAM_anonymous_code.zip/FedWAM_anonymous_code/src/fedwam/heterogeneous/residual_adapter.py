"""Explicit development adapter for a fixed reference skip and world-only delta."""
from pathlib import Path
import torch
from .adapters import ImageWAMAdapter
from .residual_readout import ResidualFutureReadout
from .reference import ReferenceEncoder
from fedwam.round_runtime import sha


class ResidualImageWAMAdapter(ImageWAMAdapter):
    def __init__(self,root,readout):
        root=Path(root);readout=Path(readout)
        payload=torch.load(readout,map_location='cpu',weights_only=True)
        if payload['schema']!='imagewam-residual-development-v1' or payload['arm']!='residual':
            raise ValueError('Expected validated residual development artifact')
        identity=payload['identity'];domain=identity['domain']
        if identity['seed']!=42 or identity['steps']!=4000:raise ValueError('Residual development budget/seed changed')
        import json
        receipt=json.loads((readout.parent/'residual-result.json').read_text())
        if receipt['head_sha256']!=sha(readout):raise ValueError('Residual head checkpoint changed')
        base=root/f'reports/heterogeneous/adapted-readout-spatial-{domain}-10456/readout.pt'
        base_payload=torch.load(base,map_location='cpu',weights_only=True)
        if base_payload['native_adaptation']!=identity['native_adaptation']:
            raise ValueError('Residual world initialization differs from base adapter')
        super().__init__(root,base)
        self.head=ResidualFutureReadout(3072).cuda().eval().requires_grad_(False)
        self.head.load_state_dict(payload['head'],strict=True)
        self.reference=ReferenceEncoder(root/'assets/dinov3-vitb16-pretrain-lvd1689m')
        self.version='imagewam-native1000-residual-'+sha(readout)

    def prepare(self,sample):
        native=super().prepare(sample)
        # Only the current observation enters the fixed skip; future is never used.
        with torch.no_grad(),torch.backends.cudnn.flags(enabled=True,benchmark=False,deterministic=True,allow_tf32=True):
            native['reference_current']=self.reference([sample['primary']]).detach()
        return native

    def predict(self,native):
        from .imagewam import prefix_cache,control_features_from_cache
        with torch.autocast('cuda',dtype=torch.bfloat16):
            h=control_features_from_cache(prefix_cache(self.model,native['current_frame'],native['text_hidden_states'],
                native['text_attention_mask'],native['proprio']))
            return self.head(h,native['reference_current']).float()
