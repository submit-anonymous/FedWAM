"""Development alternative: initialize spatial queries from the actual world grid."""
import torch
from torch.nn import functional as F
from .interface import FutureReadout


def external_camera_grid(memory):
    if memory.ndim!=3 or memory.shape[1]!=392:
        raise ValueError('Expected FLUX224x448 row-major14x28 two-camera patch layout')
    grid=memory.reshape(len(memory),14,28,memory.shape[-1])[:,:,:14]
    return F.adaptive_avg_pool2d(grid.permute(0,3,1,2),(7,7)).flatten(2).transpose(1,2)


class SpatialFutureReadout(FutureReadout):
    """Reads only control-path world values, with a fixed camera/grid correspondence.

    No external DINO current feature, true future or raw observation bypass is
    added. Cross-attention still accesses both cameras' world features.
    """
    def forward(self,control_features):
        if control_features.ndim!=3 or control_features.shape[-1]!=self.input_dim:
            raise ValueError('Invalid world features')
        memory=self.memory(control_features.float())
        queries=self.queries+external_camera_grid(memory)
        memory=memory+self.memory_position
        return self.output(self.decoder(queries,memory))
