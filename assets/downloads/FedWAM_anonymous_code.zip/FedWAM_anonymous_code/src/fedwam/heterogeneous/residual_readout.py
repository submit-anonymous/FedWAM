"""Development candidate: fixed current reference plus a learned world-only change."""
import torch
from .readout_diagnostics import DeterministicSpatialReadout


class ResidualFutureReadout(DeterministicSpatialReadout):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        torch.nn.init.zeros_(self.output.weight)
        torch.nn.init.zeros_(self.output.bias)

    def delta(self,control_features):
        return super().forward(control_features)

    def forward(self,control_features,current):
        delta=self.delta(control_features).float()
        if delta.shape!=current.shape or not torch.isfinite(current).all():
            raise ValueError('Residual reference must match the common spatial shape')
        return current.detach().float()+delta
