"""Fail-closed selection of a common head on matched development experiments."""
import hashlib
import json
import math

DOMAINS=('lighting','camera_pose','sensor_noise','background')
KINDS=('learned_query','spatial')


def select_adapted_readout(results,*,reference_id):
    if set(results)-set(KINDS):raise ValueError('Undeclared readout candidate')
    candidates={};identities={};copy_baselines={}
    for kind in KINDS:
        clients=results.get(kind,{})
        if set(clients)-set(DOMAINS):raise ValueError('Unexpected client domain')
        rows=[]
        for domain in DOMAINS:
            r=clients.get(domain)
            if r is None:
                rows.append(dict(domain=domain,completed=False));continue
            if (r.get('completed') is not True or r['seed']!=42 or r['domain']!=domain
                    or r['readout_kind']!=kind or r['steps']!=4000 or r['reference_id']!=reference_id):
                raise ValueError('Readout identity/budget mismatch')
            native=r.get('native_adaptation')
            if not native or native['step']!=1000:
                raise ValueError('Readout lacks complete native initial adaptation')
            expected=dict(seed=42,domain=domain,subset='B',horizon=8)
            if any(native['identity'].get(k)!=v for k,v in expected.items()):
                raise ValueError('Native source/horizon identity mismatch')
            for digest in (native['sha256'],r['head_sha256']):
                if len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
                    raise ValueError('Invalid checkpoint digest')
            samples=r['samples']
            if set(samples)!={'train','development'} or len(samples['train'])!=4096 or len(samples['development'])!=256:
                raise ValueError('Unequal readout sample budget')
            groups={}
            for split,items in samples.items():
                if len({(x['record_id'],x['t']) for x in items})!=len(items):
                    raise ValueError('Duplicate readout temporal query')
                groups[split]={x['source_group'] for x in items}
            if groups['train']&groups['development']:raise ValueError('Readout train/development source overlap')
            sample_digest=hashlib.sha256(json.dumps(samples,sort_keys=True).encode()).hexdigest()
            identity=(sample_digest,native['sha256'])
            if domain in identities and identities[domain]!=identity:
                raise ValueError('Candidates use different samples or native checkpoints')
            identities[domain]=identity
            final=r['curves'][-1]
            if final['step']!=4000:raise ValueError('Missing final prescribed readout update')
            mse,copy=final['mse'],final['copy_mse']
            if not math.isfinite(mse) or not math.isfinite(copy) or mse<0 or copy<=0:
                raise ValueError('Invalid development MSE/copy denominator')
            if domain in copy_baselines and not math.isclose(copy,copy_baselines[domain],rel_tol=1e-6,abs_tol=1e-9):
                raise ValueError('Candidates report different copy baselines for identical samples')
            copy=copy_baselines.setdefault(domain,copy)
            rows.append(dict(domain=domain,completed=True,mse=mse,copy_mse=copy,
                ratio=mse/copy,beats_copy=mse<copy,head_sha256=r['head_sha256']))
        complete=all(row['completed'] for row in rows)
        candidates[kind]=dict(clients=rows,complete=complete,
            all_domains_beat_copy=complete and all(row['beats_copy'] for row in rows),
            mean_relative_mse=sum(row['ratio'] for row in rows)/4 if complete else None)
    complete=all(v['complete'] for v in candidates.values())
    eligible=[k for k,v in candidates.items() if v['all_domains_beat_copy']] if complete else []
    selected=min(eligible,key=lambda k:(candidates[k]['mean_relative_mse'],k)) if eligible else None
    return dict(development_complete=complete,candidates=candidates,selected_readout=selected,
        matched_inputs={d:dict(samples_sha256=v[0],native_checkpoint_sha256=v[1]) for d,v in identities.items()},
        selection_rule='Wait for both candidates; one architecture must beat copy in all four domains; minimize mean relative MSE',
        formal_admission=False,note='Passing readout development alone does not admit formal federation or establish control improvement')
