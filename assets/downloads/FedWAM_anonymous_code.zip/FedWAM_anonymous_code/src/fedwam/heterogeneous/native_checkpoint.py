"""Private native checkpoints retain exact optimizer, scheduler and RNG progress."""
from pathlib import Path
import torch
from fedwam.round_runtime import atomic_torch,cpu_tree,rng_state,restore_rng


def save_training(path,modules,optimizer,scheduler,*,step,identity):
    atomic_torch(path,dict(schema='heterogeneous-private-native-v1',identity=identity,step=step,
        modules={k:cpu_tree(v.state_dict()) for k,v in modules.items()},
        optimizer=cpu_tree(optimizer.state_dict()),scheduler=scheduler.state_dict(),rng=rng_state()))


def restore_training(path,modules,optimizer,scheduler,*,identity):
    # Only the account-owned checkpoints written above; never arbitrary downloaded input.
    payload=torch.load(Path(path),map_location='cpu',weights_only=False)
    if payload['schema']!='heterogeneous-private-native-v1' or payload['identity']!=identity:
        raise ValueError('Native checkpoint data/code/training identity changed')
    if set(payload['modules'])!=set(modules) or payload['step']<0:raise ValueError('Invalid native checkpoint modules/progress')
    for name,module in modules.items():module.load_state_dict(payload['modules'][name],strict=True)
    optimizer.load_state_dict(payload['optimizer']);scheduler.load_state_dict(payload['scheduler'])
    restore_rng(payload['rng'])
    return int(payload['step'])
