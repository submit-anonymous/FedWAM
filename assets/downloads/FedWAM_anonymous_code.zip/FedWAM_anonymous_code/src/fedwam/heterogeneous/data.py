"""Source-preserving eight-client allocation of accepted official records."""
from collections import defaultdict
import hashlib


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def allocate_sources(records, seed=42, public_fraction=0.05):
    if seed != 42 or not 0 < public_fraction < 1:
        raise ValueError('This experiment is restricted to seed42 with a nonempty public fraction')
    sources = {}
    for row in records:
        key = row['source_group']
        definition = (row['suite'], row['task'], row['split'])
        if key in sources and sources[key] != definition:
            raise ValueError('One source spans tasks or held-out splits')
        sources[key] = definition
    tasks = defaultdict(list)
    for group, (suite, task, split) in sources.items():
        if split == 'train':
            tasks[(suite, task)].append(group)
    allocation = {}
    for task, groups in sorted(tasks.items()):
        groups.sort(key=lambda g: digest(f'{seed}:heterogeneous-v1:{g}'))
        n_public = max(1, int(len(groups) * public_fraction + 0.5))
        if len(groups) - n_public < 2:
            raise ValueError(f'Insufficient sources for public/A/B split: {task}')
        offset = int(digest(repr(task))[:8], 16) % 2
        for i, group in enumerate(groups):
            allocation[group] = ('public' if i < n_public else
                                 ('A', 'B')[(i - n_public + offset) % 2])
    return allocation


def partition_records(records, seed=42, public_fraction=0.05):
    records = list(records)
    allocation = allocate_sources(records, seed, public_fraction)
    result = {key: [] for key in ('A', 'B', 'public', 'heldout')}
    for row in records:
        key = allocation[row['source_group']] if row['split'] == 'train' else 'heldout'
        result[key].append(row)
    return result


class HeterogeneousDataset:
    """Resolve allocation indexes through their checksum-bound parent manifests."""
    def __init__(self, root, subset, domain, split='train'):
        import json
        from pathlib import Path
        from fedwam.official_data import ChunkSampler, RawChunkReader
        self.root = Path(root).resolve()
        base = self.root / 'manifests/heterogeneous_seed42_v1'
        receipt = json.loads((base / 'acceptance.json').read_text())
        def checked(path, expected):
            if not path.resolve().is_relative_to(self.root):
                raise ValueError('Data path escapes project')
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            if actual != expected:
                raise ValueError('Data index checksum mismatch: ' + str(path))
            return json.loads(path.read_text())
        parent_receipt = checked(self.root / 'manifests/official_four_clients/acceptance.json',
                                 receipt['parent_receipt_sha256'])
        for relative, expected in parent_receipt['code'].items():
            path = (self.root / relative).resolve()
            if not path.is_relative_to(self.root):
                raise ValueError('Parent code escapes project')
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
                raise ValueError('Accepted data decoder changed')
        if split == 'train':
            if subset not in ('A', 'B', 'public'):
                raise ValueError('Unknown training subset')
            name = f'{subset}/{domain}.json'
        elif split in ('calibration', 'development', 'prediction_test'):
            name = 'heldout/all.json'
        else:
            raise ValueError('Unknown held-out split')
        index = checked(base / name, receipt['files'][name])
        parents = {}
        rows = []
        for ref in index['rows']:
            if ref['client'] != domain or ref['split'] != split:
                continue
            name = ref['parent_manifest']
            if name not in parents:
                parents[name] = checked(self.root / name, receipt['parents'][name])
            row = parents[name]['rows'][ref['parent_row']]
            if any(row[key] != ref[key] for key in ('record_id', 'source_group', 'client', 'split')):
                raise ValueError('Index does not match accepted parent row')
            if split == 'train' and receipt['assignments'][row['source_group']] != subset:
                raise ValueError('Training row escapes source allocation')
            rows.append(row)
        self.rows = rows
        self.sampler = ChunkSampler(rows, domain, split, 42)
        self.reader = RawChunkReader(2)

    def sample(self, draw):
        import io
        import numpy as np
        from PIL import Image
        from fedwam.rlds import fingerprint
        row, t = self.sampler.draw(draw)
        result = self.reader.read(row, t)
        with np.load(row['numeric_path'], allow_pickle=False) as arrays:
            state = arrays['state']
            if fingerprint(state, 8) != row['state_sha256']:
                raise ValueError('Numeric proprioception differs from audited RLDS')
            result['state'] = state[t].copy()
        encoded = self.reader._episode(row)['wrist'][t + 8]
        with Image.open(io.BytesIO(encoded)) as image:
            if image.mode != 'RGB':
                raise ValueError('Future wrist must be RGB')
            result['future_wrist'] = np.asarray(image).copy()
        return result
