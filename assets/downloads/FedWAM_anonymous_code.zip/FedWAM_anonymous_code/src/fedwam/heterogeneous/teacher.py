"""Resumable balanced fitting of different queries to a shared conditional model."""
import copy
import hashlib
import json
import torch
from .interface import CommonTeacher, SCHEMA
from .packets import validate_packet, balanced_weights


def _cpu(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:_cpu(v) for k,v in value.items()}
    if isinstance(value,list):return [_cpu(v) for v in value]
    if isinstance(value,tuple):return tuple(_cpu(v) for v in value)
    return copy.deepcopy(value)


def packet_digest(packets):
    h=hashlib.sha256()
    for p in packets:
        h.update(json.dumps({k:v for k,v in p.items() if k not in ('query','prediction')},sort_keys=True).encode())
        for key,tensor in sorted(dict(p['query'],prediction=p['prediction']).items()):
            value=tensor.detach().cpu().contiguous()
            h.update(str((key,str(value.dtype),tuple(value.shape))).encode())
            h.update(value.view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def fit_teacher(packets, *, round_id, steps=1000, config=None, batch_size=64,
                lr=1e-4, device='cpu', previous=None, resume=None, checkpoint=None):
    """steps is total updates this round, so resuming does not add hidden budget.

    `previous` initializes the next round with last round's weights, while
    `resume` restores model, Adam state and sampling RNG within this round.
    Held-out packet sources are for server fitting diagnostics only, not client
    calibration and not held-out scientific evaluation data.
    """
    config=dict(config or {})
    if min(steps,batch_size)<1 or previous is not None and resume is not None:
        raise ValueError('Invalid teacher budget/resume')
    packets=sorted(packets,key=lambda p:p['client'])
    if not packets or len({p['client'] for p in packets})!=len(packets):
        raise ValueError('Exactly one nonempty current-round packet per sender required')
    shapes={k:config[k] for k in ('dim','language_dim','state_dim','tokens') if k in config}
    for packet in packets:
        validate_packet(packet,round_id=round_id,shapes=shapes)
    signature=packet_digest(packets)
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(42)
        model=CommonTeacher(**config).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=.01)
    generator=torch.Generator().manual_seed(42+round_id)
    metadata=[]
    query={k:torch.cat([p['query'][k].cpu() for p in packets]) for k in packets[0]['query']}
    target=torch.cat([(p['prediction'] if p['representation']=='future' else p['prediction']+p['query']['z']).cpu() for p in packets])
    for p in packets:
        for task,group in zip(p['tasks'],p['source_groups']):
            metadata.append(dict(client=p['client'],task=task,source_group=group))
    # Same group always has the same server partition across senders and rounds.
    is_validation=[int(hashlib.sha256(('server-v1:'+r['source_group']).encode()).hexdigest()[:8],16)%5==0 for r in metadata]
    train=[i for i,v in enumerate(is_validation) if not v]
    validation=[i for i,v in enumerate(is_validation) if v]
    if not train or not validation:
        raise ValueError('Insufficient source diversity for server fit/validation separation')
    for client in {p['client'] for p in packets}:
        if not any(metadata[i]['client']==client for i in train):
            raise ValueError('Sender lacks server-training source groups')
    weights=balanced_weights([metadata[i] for i in train])
    start=0
    state=resume if resume is not None else previous
    if state is not None:
        if state['schema']!=SCHEMA or state['config']!=config:
            raise ValueError('Teacher state interface/configuration mismatch')
        if resume is not None:
            if state['round']!=round_id or state['packet_digest']!=signature:
                raise ValueError('Cannot resume a different round or changed packet pool')
            if state['batch_size']!=batch_size or state['lr']!=lr:
                raise ValueError('Resume training settings changed')
            start=state['updates']
            if start>steps:
                raise ValueError('Resume already exceeds requested update budget')
        elif state['round']!=round_id-1:
            raise ValueError('Teacher must inherit immediately preceding round')
        model.load_state_dict(state['model'],strict=True)
        if resume is not None:
            optimizer.load_state_dict(state['optimizer'])
            generator.set_state(state['rng'])
    def snapshot(updates):
        return dict(schema=SCHEMA,config=config,round=round_id,updates=updates,packet_digest=signature,
                    model=_cpu(model.state_dict()),optimizer=_cpu(optimizer.state_dict()),rng=generator.get_state(),
                    batch_size=batch_size,lr=lr,
                    training_groups=sorted({metadata[i]['source_group'] for i in train}),
                    validation_groups=sorted({metadata[i]['source_group'] for i in validation}))
    model.train()
    for step in range(start,steps):
        choices=torch.multinomial(weights,batch_size,replacement=True,generator=generator).tolist()
        indices=[train[i] for i in choices]
        q={k:v[indices].to(device) for k,v in query.items()}
        optimizer.zero_grad(set_to_none=True)
        loss=(model(q)-target[indices].to(device).float()).square().mean()
        if not torch.isfinite(loss):raise ValueError('Nonfinite teacher fit')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
        optimizer.step()
        if checkpoint is not None and (step+1)%100==0:
            checkpoint(snapshot(step+1))
    model.eval()
    errors=[]
    with torch.no_grad():
        for offset in range(0,len(validation),batch_size):
            indices=validation[offset:offset+batch_size]
            q={k:v[indices].to(device) for k,v in query.items()}
            errors.extend((model(q)-target[indices].to(device).float()).square().mean((-2,-1)).cpu().tolist())
    validation_weights=balanced_weights([metadata[i] for i in validation])
    result=snapshot(steps)
    result['validation_mse']=sum(e*float(w) for e,w in zip(errors,validation_weights))
    result['sender_clients']=[p['client'] for p in packets]
    result['target_kind']='source model predictions; no true future labels'
    return result
