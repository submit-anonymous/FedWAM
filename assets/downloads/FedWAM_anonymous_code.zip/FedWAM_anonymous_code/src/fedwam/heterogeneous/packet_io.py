"""Measured prediction upload sizes, integrity receipts and fixed public text pooling."""
import hashlib
import io
import json
from pathlib import Path
import torch
from .packets import validate_packet


def masked_language(hidden, mask):
    if hidden.ndim!=3 or mask.shape!=hidden.shape[:2] or mask.dtype!=torch.bool:
        raise ValueError('Invalid public text hidden states/mask')
    count=mask.sum(1,keepdim=True)
    if (count==0).any():raise ValueError('Empty public instruction encoding')
    result=(hidden.float()*mask[...,None]).sum(1)/count
    if not torch.isfinite(result).all():raise ValueError('Nonfinite language encoding')
    return result.detach()


def save_packet(path,packet,*,round_id,max_bytes,shapes=None):
    validate_packet(packet,round_id=round_id,shapes=shapes)
    buffer=io.BytesIO()
    torch.save(packet,buffer)
    content=buffer.getvalue()
    if len(content)>max_bytes:raise ValueError('Serialized packet exceeds upload budget')
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    receipt=dict(bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),
                 round=round_id,client=packet['client'],schema=packet['schema'])
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_bytes(content);temp.replace(path)
    receipt_path=path.with_suffix(path.suffix+'.json')
    temp=receipt_path.with_suffix('.tmp');temp.write_text(json.dumps(receipt,sort_keys=True)+'\n');temp.replace(receipt_path)
    return receipt


def load_packet(path,*,round_id,shapes=None,max_bytes=256*1024**2):
    path=Path(path)
    if path.stat().st_size>max_bytes:raise ValueError('Packet exceeds receiver budget')
    receipt=json.loads(path.with_suffix(path.suffix+'.json').read_text())
    content=path.read_bytes()
    if len(content)!=receipt['bytes'] or hashlib.sha256(content).hexdigest()!=receipt['sha256']:
        raise ValueError('Upload receipt/content mismatch')
    packet=torch.load(io.BytesIO(content),map_location='cpu',weights_only=True)
    validate_packet(packet,round_id=round_id,shapes=shapes)
    if any(receipt[k]!=packet[k] for k in ('round','client','schema')):
        raise ValueError('Upload identity mismatch')
    return packet
