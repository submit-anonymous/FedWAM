"""Prediction diagnostics; change masks are evaluation proxies, not segmentation."""
import math
import hashlib
from pathlib import Path
import torch
from .packets import balanced_weights
from .spatial_readout import SpatialFutureReadout


class DeterministicSpatialReadout(SpatialFutureReadout):
    """Exact nonoverlapping 14-to-7 pooling, avoiding nondeterministic CUDA backward."""
    def forward(self,control_features):
        if control_features.ndim!=3 or control_features.shape[1:]!=(392,self.input_dim):
            raise ValueError('Invalid fixed two-camera world grid')
        memory=self.memory(control_features.float())
        b,_,d=memory.shape
        external=memory.reshape(b,14,28,d)[:,:,:14]
        pooled=external.reshape(b,7,2,7,2,d).mean((2,4)).reshape(b,49,d)
        queries=self.queries+pooled
        return self.output(self.decoder(queries,memory+self.memory_position))


def verified_readout(path,receipt):
    checksum=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024**2),b''):checksum.update(block)
    if checksum.hexdigest()!=receipt['head_sha256']:
        raise ValueError('Readout checkpoint digest differs from receipt')
    payload=torch.load(path,map_location='cpu',weights_only=True)
    if payload.get('horizon_original_steps')!=8 or any(payload.get(k)!=receipt[k] for k in ('seed','domain','reference_id','native_adaptation')):
        raise ValueError('Readout metadata/native identity differs from receipt')
    return payload


def error_row(prediction,current,future,pixel_change):
    if (prediction.ndim!=2 or prediction.shape!=current.shape or current.shape!=future.shape
            or pixel_change.shape!=(len(current),) or len(current)<2):
        raise ValueError('Diagnostic tensor shapes disagree')
    if not all(torch.isfinite(x).all() for x in (prediction,current,future,pixel_change)):
        raise ValueError('Nonfinite diagnostic input')
    prediction,current,future=(x.detach().float().cpu() for x in (prediction,current,future))
    pixel_change=pixel_change.detach().float().cpu()
    error=(prediction-future).square().mean(-1)
    delta=future-current;estimated=prediction-current
    copy=delta.square().mean(-1)
    norm=float(estimated.norm()*delta.norm())
    row=dict(mse=float(error.mean()),copy_mse=float(copy.mean()),
        current_mse=float(estimated.square().mean()),
        delta_cosine=float((estimated*delta).sum())/norm if norm>1e-12 else 0.)
    n=max(1,math.ceil(len(current)/4))
    for name,score in (('feature',copy),('pixel',pixel_change)):
        order=torch.argsort(score,descending=True,stable=True)
        for band,idx in (('high',order[:n]),('low',order[n:])):
            row[f'{band}_{name}_change_mse']=float(error[idx].mean())
            row[f'{band}_{name}_change_copy_mse']=float(copy[idx].mean())
    return row


def summarize(rows):
    if not rows:raise ValueError('Empty diagnostic sample')
    weights=balanced_weights([dict(client='one',task=r['task'],source_group=r['source_group']) for r in rows])
    keys=set(rows[0])-{'task','source_group','record_id','t'}
    if any((set(r)-{'task','source_group','record_id','t'})!=keys for r in rows):
        raise ValueError('Unequal diagnostic fields')
    if any(not math.isfinite(r[k]) for r in rows for k in keys):raise ValueError('Nonfinite diagnostic metric')
    return dict(n=len(rows),tasks=len({r['task'] for r in rows}),sources=len({r['source_group'] for r in rows}),
                **{k:sum(float(w)*r[k] for w,r in zip(weights,rows)) for k in sorted(keys)})
