"""Shared target definition matching the frozen native LaWAM visual interface."""
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from .interface import pool_spatial

REFERENCE_ID = 'dinov3-vitb16-lvd1689m-256-hidden-minus2-ln-eps1e-5-fp32-single-pool7-v3'


class ReferenceEncoder(nn.Module):
    def __init__(self, path, device='cuda'):
        super().__init__()
        from transformers import AutoModel
        self.model = AutoModel.from_pretrained(path, local_files_only=True).to(device).eval().requires_grad_(False)
        if self.model.config.hidden_size != 768 or self.model.config.num_register_tokens != 4:
            raise ValueError('Unexpected shared DINO configuration')
        self.register_buffer('mean',torch.tensor([.485,.456,.406],device=device).view(1,3,1,1))
        self.register_buffer('std',torch.tensor([.229,.224,.225],device=device).view(1,3,1,1))

    @torch.no_grad()
    def forward(self, images):
        array=np.stack(images)
        if array.dtype!=np.uint8 or array.shape[1:]!=(256,256,3):
            raise ValueError('Shared reference expects oriented uint8 RGB256 images')
        x=torch.from_numpy(array.copy()).permute(0,3,1,2).to(self.mean.device,dtype=torch.float32)/255.
        x=(x-self.mean)/self.std
        all_tokens=[]
        with torch.autocast(self.mean.device.type,enabled=False):
            # The federation encoder has its own FP32 precision contract.
            # It must not inherit either architecture's mixed-precision context.
            for frame in x.split(1):
                output=self.model(pixel_values=frame,output_hidden_states=True)
                tokens=output.hidden_states[-2][:,5:]
                all_tokens.append(F.layer_norm(tokens,(768,),eps=1e-5))
        tokens=torch.cat(all_tokens)
        if tuple(tokens.shape[1:])!=(256,768):
            raise ValueError('Shared DINO patch layout mismatch')
        return pool_spatial(tokens.float())
