"""Common-condition prediction interface; never consumes private latent intent."""
import math
import torch
from torch import nn
from torch.nn import functional as F

SCHEMA = 'fedwam-common-dinov3-256-layer-minus2-ln-fp32-pool7-h8-v3'
QUERY_FIELDS = frozenset(('z', 'language', 'state', 'state_mask', 'horizon'))


def pool_spatial(tokens, side=7):
    if tokens.ndim != 3:
        raise ValueError('Expected patch tokens [batch, spatial_tokens, feature]')
    n = math.isqrt(tokens.shape[1])
    if n * n != tokens.shape[1] or side < 1:
        raise ValueError('Patch tokens must form a square grid without CLS/register tokens')
    spatial = tokens.transpose(1, 2).reshape(len(tokens), tokens.shape[-1], n, n)
    return F.adaptive_avg_pool2d(spatial, (side, side)).flatten(2).transpose(1, 2)


def validate_query(query, *, tokens=49, dim=768, language_dim=7680, state_dim=8):
    if set(query) != QUERY_FIELDS:
        raise ValueError('Common query must contain only current features, public language, available state/mask and horizon')
    z = query['z']
    if z.ndim != 3 or z.shape[1:] != (tokens, dim):
        raise ValueError('Common visual token shape mismatch')
    b = len(z)
    expected = {'language': (b, language_dim), 'state': (b, state_dim),
                'state_mask': (b, state_dim), 'horizon': (b, 1)}
    for key, shape in expected.items():
        if tuple(query[key].shape) != shape:
            raise ValueError('Common query shape mismatch: ' + key)
    if query['state_mask'].dtype != torch.bool:
        raise ValueError('State availability must be a boolean mask')
    for key in QUERY_FIELDS - {'state_mask'}:
        if not torch.isfinite(query[key]).all():
            raise ValueError('Nonfinite common query: ' + key)
    if (query['horizon'] <= 0).any():
        raise ValueError('Horizon must be positive original-action steps')


class FutureReadout(nn.Module):
    """Spatial queries read actual world/control features, with no observation bypass."""
    def __init__(self, input_dim, output_dim=768, tokens=49, width=512, heads=8, depth=2, max_memory_tokens=392):
        super().__init__()
        self.input_dim = input_dim
        self.memory = nn.Sequential(nn.LayerNorm(input_dim), nn.Linear(input_dim, width))
        # FLUX values are pre-RoPE values. Without addresses, cross-attention is
        # invariant to shuffling memory tokens and cannot guarantee spatial readout.
        self.memory_position = nn.Parameter(torch.randn(1, max_memory_tokens, width) * .02)
        self.queries = nn.Parameter(torch.randn(1, tokens, width) * .02)
        layer = nn.TransformerDecoderLayer(width, heads, 4 * width, dropout=0.,
                                           activation='gelu', batch_first=True, norm_first=True)
        self.decoder = nn.TransformerDecoder(layer, depth, norm=nn.LayerNorm(width))
        self.output = nn.Linear(width, output_dim)

    def forward(self, control_features):
        if control_features.ndim != 3 or control_features.shape[-1] != self.input_dim:
            raise ValueError('Invalid world/control feature shape')
        if control_features.shape[1] > self.memory_position.shape[1]:
            raise ValueError('World feature layout exceeds frozen positional interface')
        memory = self.memory(control_features.float()) + self.memory_position[:, :control_features.shape[1]]
        return self.output(self.decoder(self.queries.expand(len(memory), -1, -1), memory))


class CommonTeacher(nn.Module):
    def __init__(self, dim=768, language_dim=7680, state_dim=8, tokens=49, width=512, heads=8, depth=4):
        super().__init__()
        self.shapes = dict(dim=dim, language_dim=language_dim, state_dim=state_dim, tokens=tokens)
        self.visual = nn.Linear(dim, width)
        self.language = nn.Linear(language_dim, width)
        self.state = nn.Linear(state_dim * 2, width)
        self.horizon = nn.Linear(1, width)
        self.position = nn.Parameter(torch.randn(1, tokens + 3, width) * .02)
        layer = nn.TransformerEncoderLayer(width, heads, 4 * width, dropout=0.,
                                           activation='gelu', batch_first=True, norm_first=True)
        self.encoder = nn.TransformerEncoder(layer, depth, norm=nn.LayerNorm(width), enable_nested_tensor=False)
        self.output = nn.Linear(width, dim)

    def forward(self, query):
        validate_query(query, **self.shapes)
        mask = query['state_mask'].float()
        available = torch.cat((query['state'].float() * mask, mask), dim=-1)
        condition = torch.stack((self.language(query['language'].float()), self.state(available),
                                 self.horizon(query['horizon'].float() / 8.)), dim=1)
        tokens = torch.cat((condition, self.visual(query['z'].float())), dim=1)
        return self.output(self.encoder(tokens + self.position)[:, 3:])


def reliability(local_error, teacher_error, epsilon=1e-8):
    if not all(math.isfinite(v) and v >= 0 for v in (local_error, teacher_error)) or epsilon <= 0:
        raise ValueError('Calibration errors must be finite and nonnegative')
    return max(0., min(1., (local_error - teacher_error) / (local_error + epsilon)))
