"""ImageWAM adapters without modifying the pinned upstream implementation."""
import numpy as np
import torch


def physical_to_dataset_actions(actions):
    actions = np.asarray(actions, dtype=np.float32)
    if actions.shape != (8, 7) or not np.isfinite(actions).all():
        raise ValueError('Expected eight finite physical LIBERO actions')
    if not np.isin(actions[:, -1], [-1., 1.]).all():
        raise ValueError('Unverified gripper convention; expected physical -1/+1')
    converted = actions.copy()
    # Inverse of official _predict_action_chunk: invert(2 * gripper - 1).
    converted[:, -1] = (1. - converted[:, -1]) / 2.
    return converted


def control_features_from_cache(cache):
    # The final post-block video output is not consumed by action attention.
    # Use the last single-block values actually concatenated into action K/V.
    values = cache['single'][-1]['v']
    start, count = int(cache['txt_len']), int(cache['img_len'])
    if values.ndim != 3 or values.shape[1] != start + count or count <= 0:
        raise ValueError('Unexpected FLUX control-cache layout')
    return values[:, start:start + count]


def prefix_cache(model, image, text, text_mask, proprio):
    """Differentiable equivalent of the deployment current-only prefix path.

    Signature excludes action labels and future images. Frozen encoders run
    without gradients upstream; pre_dit/prefill retain gradients to world.
    """
    image = image.to(device=model.device, dtype=model.torch_dtype)
    text = text.to(device=model.device, dtype=model.torch_dtype)
    text_mask = text_mask.to(device=model.device, dtype=torch.bool)
    text, text_mask = model._append_proprio_to_context_if_enabled(
        context=text, context_mask=text_mask, proprio=proprio, source='FedWAM deployed prefix')
    refs, ids = model._encode_flux2_image_tokens(image, time_value=10.)
    b = len(refs)
    pre = model.video_expert.pre_dit(
        x=refs.new_zeros(b, 0, refs.shape[-1]),
        timestep=refs.new_zeros(b), context=text, context_mask=text_mask,
        ref_image_hidden_states=refs, target_img_ids=ids.new_zeros(b, 0, ids.shape[-1]), ref_img_ids=ids)
    if int(pre['target_len']) != 0:
        raise ValueError('Unexpected target tokens in deployment-only prefix')
    mask = model._build_mot_attention_mask_flux2(
        batch_size=b, txt_len=int(pre['txt_len']), target_len=0,
        cond_len=int(pre['cond_len']), action_len=0, device=image.device,
        text_attention_mask=pre['text_mask'])
    return model.mot.prefill_flux2_video_cache(
        video_tokens=pre['tokens'], video_freqs=pre['freqs'],
        video_t_mod=pre['t_mod'], attention_mask=mask)


def paired_image(primary, wrist):
    from PIL import Image
    images = []
    for value in (primary, wrist):
        value = np.asarray(value)
        if value.shape != (256, 256, 3) or value.dtype != np.uint8:
            raise ValueError('Expected official RLDS uint8 RGB256 images')
        # Stored RLDS images are already oriented; do not apply simulator flip.
        images.append(np.asarray(Image.fromarray(value).resize((224, 224), Image.Resampling.BILINEAR)).copy())
    pixels = torch.from_numpy(np.concatenate(images, axis=1)).permute(2, 0, 1)[None]
    return pixels.float() * (2. / 255.) - 1.


def make_native_sample(sample, processor):
    if sample['future_t'] != sample['t'] + 8:
        raise ValueError('Future must correspond to eight consecutive original action steps')
    physical = physical_to_dataset_actions(sample['actions'])
    state = torch.as_tensor(sample['state'], dtype=torch.float32).reshape(1, 8)
    normal = processor.normalizer.forward(processor.action_state_transform({
        'action': {'default': torch.from_numpy(physical)[None]},
        'state': {'default': state}}))
    from imagewam.datasets.lerobot.robot_video_dataset import DEFAULT_PROMPT
    return {'current_frame': paired_image(sample['primary'], sample['wrist']),
            'next_frame': paired_image(sample['future'], sample['future_wrist']),
            'action': normal['action']['default'], 'proprio': normal['state']['default'],
            'instruction': DEFAULT_PROMPT.format(task=sample['lang']),
            'action_is_pad': torch.zeros(1, 8, dtype=torch.bool)}


def training_frames(sample,augmentation=None):
    """Official Tensor ToTensor/Resize -> per-camera video augmentation -> concat.

    Kept distinct from PIL resizing in the official deployment path. Both real
    endpoints receive the same temporal augmentation per camera, exactly as
    RobotVideoDataset; future frames are used only by the native training loss.
    """
    from torchvision.transforms import functional as TF
    cameras=[]
    for keys in (('primary','future'),('wrist','future_wrist')):
        frames=[]
        for key in keys:
            image=np.asarray(sample[key])
            if image.shape!=(256,256,3) or image.dtype!=np.uint8:raise ValueError('Expected audited RGB256 endpoints')
            frame=torch.from_numpy(image.copy()).permute(2,0,1).float()/255.
            frames.append(TF.resize(frame,[224,224],antialias=True))
        cameras.append(torch.stack(frames))
    video=torch.stack(cameras)
    if augmentation is not None:video=augmentation(video)
    # Tensor bilinear antialias resize can overshoot by a few FP32 ulps.
    # Match upstream VideoAugmentation._validate_input_range (eps=1e-6),
    # preserving its values rather than introducing a new clipping transform.
    eps=1e-6
    if video.shape!=(2,2,3,224,224) or not torch.isfinite(video).all() or video.min() < -eps or video.max() > 1.+eps:
        raise ValueError('Invalid official native video augmentation output')
    video=torch.cat((video[0],video[1]),dim=-1)*2.-1.
    return video[0:1],video[1:2]


def make_training_sample(sample,processor,augmentation=None):
    native=make_native_sample(sample,processor)
    native['current_frame'],native['next_frame']=training_frames(sample,augmentation)
    return native
