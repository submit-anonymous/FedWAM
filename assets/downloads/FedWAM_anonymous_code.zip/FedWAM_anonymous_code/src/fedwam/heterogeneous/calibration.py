"""Local-only reliability estimates with explicit source/task coverage requirements."""
from collections import defaultdict
import math
from .interface import reliability


def calibrate_reception(rows,*,expected_tasks,min_sources_per_task=2):
    tasks=set(expected_tasks)
    if not tasks or min_sources_per_task<1:raise ValueError('Calibration coverage must be specified')
    groups=defaultdict(lambda:defaultdict(list));seen=set();source_tasks={}
    for row in rows:
        if row['split']!='calibration':raise ValueError('Reliability may only use the calibration split')
        if row['query_id'] in seen:raise ValueError('Repeated calibration query')
        seen.add(row['query_id'])
        if row['task'] not in tasks:raise ValueError('Unexpected calibration task')
        for k in ('local_mse','teacher_mse'):
            if not math.isfinite(row[k]) or row[k]<0:raise ValueError('Invalid calibration error')
        group=row['source_group']
        if group in source_tasks and source_tasks[group]!=row['task']:raise ValueError('One source spans tasks')
        source_tasks[group]=row['task']
        groups[row['task']][group].append(row)
    counts={task:len(groups[task]) for task in sorted(tasks)}
    adequate=all(n>=min_sources_per_task for n in counts.values())
    if not adequate:
        return dict(adequate=False,gate=0.,sources_by_task=counts,
                    reason='insufficient independent calibration sources/task coverage')
    errors={}
    for kind in ('local_mse','teacher_mse'):
        errors[kind]=sum(sum(sum(r[kind] for r in values)/len(values) for values in sources.values())/len(sources)
                         for sources in groups.values())/len(tasks)
    return dict(adequate=True,gate=reliability(errors['local_mse'],errors['teacher_mse']),
                sources_by_task=counts,**errors)
