"""Strict prediction-only uploads and explicit directional sender selection."""
from collections import defaultdict
import math
import torch
from .interface import SCHEMA, validate_query

FIELDS = frozenset(('schema', 'round', 'client', 'architecture', 'model_version',
                    'representation', 'query', 'prediction', 'source_groups', 'tasks', 'query_ids'))


def validate_packet(packet, *, round_id, shapes=None):
    if set(packet) != FIELDS or packet['schema'] != SCHEMA:
        raise ValueError('Unsupported packet fields/schema; raw observations and private parameters forbidden')
    if packet['round'] != round_id or packet['architecture'] not in ('lawam', 'imagewam'):
        raise ValueError('Stale round or unknown architecture')
    if packet['representation'] not in ('future', 'transition'):
        raise ValueError('Unsupported predictive representation')
    if any(not isinstance(packet[k], str) or not packet[k] for k in ('client', 'model_version')):
        raise ValueError('Missing sender/model identity')
    validate_query(packet['query'], **(shapes or {}))
    if not (packet['query']['horizon']==8).all():
        raise ValueError('This packet schema permits only H8 original-action steps')
    z, y = packet['query']['z'], packet['prediction']
    if y.shape != z.shape or not torch.isfinite(y).all() or y.requires_grad:
        raise ValueError('Prediction must be finite, detached and spatially aligned')
    for name in ('source_groups', 'tasks', 'query_ids'):
        if len(packet[name]) != len(z) or any(not isinstance(s, str) or not s for s in packet[name]):
            raise ValueError('Invalid packet metadata: ' + name)
    if len(set(packet['query_ids'])) != len(z):
        raise ValueError('Duplicate packet query identity')
    if any(v.requires_grad for v in packet['query'].values()):
        raise ValueError('Uploaded query must be detached')


def select_senders(packets, mode, receiver_client, receiver_architecture):
    if mode == 'all':
        return list(packets)
    if mode == 'self':
        return [p for p in packets if p['client'] == receiver_client]
    if mode == 'same_architecture':
        return [p for p in packets if p['architecture'] == receiver_architecture]
    for source, destination in (('lawam', 'imagewam'), ('imagewam', 'lawam')):
        if mode == f'{source}_to_{destination}':
            return [p for p in packets if p['architecture'] == source] if receiver_architecture == destination else []
    raise ValueError('Unknown teacher source selection')


def balanced_weights(records):
    tree = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for i, record in enumerate(records):
        tree[record['client']][record['task']][record['source_group']].append(i)
    if not tree:
        raise ValueError('Empty teacher packet pool')
    weights = torch.zeros(len(records), dtype=torch.float64)
    for tasks in tree.values():
        for groups in tasks.values():
            for indices in groups.values():
                weights[indices] = 1. / (len(tree) * len(tasks) * len(groups) * len(indices))
    return weights


def reception_loss(local_prediction, teacher_prediction, gate):
    if not math.isfinite(gate) or not 0 <= gate <= 1:
        raise ValueError('Client reliability must be a finite scalar in [0,1]')
    if local_prediction.shape != teacher_prediction.shape:
        raise ValueError('Reception target shape mismatch')
    return gate * (local_prediction.float() - teacher_prediction.detach().float()).square().mean()
