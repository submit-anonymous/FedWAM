"""Consume only checksum-bound, accepted official four-client sample manifests."""
from pathlib import Path
from .io import load,file_hash
from .official_data import CLIENT_BUCKETS,SPLITS,ChunkSampler,RawChunkReader

class OfficialDataset:
    def __init__(self,root,client,split,seed,max_cached_episodes=4):
        if client not in CLIENT_BUCKETS or split not in SPLITS:raise ValueError('Unsupported client/split')
        root=Path(root).resolve();base=root/'manifests/official_four_clients'
        receipt=load(base/'acceptance.json')
        if receipt.get('accepted_for_official_four_client_training') is not True:raise ValueError('Data acceptance gate not passed')
        def checked(relative):
            path=root/relative
            if not path.resolve().is_relative_to(root):raise ValueError('Manifest/code path escapes project')
            expected=receipt['files'].get(relative)
            if expected is None or file_hash(path)!=expected:raise ValueError(f'Accepted manifest checksum mismatch: {relative}')
            value=load(path)
            if value['identity']!=receipt['identity']:raise ValueError('Mixed acceptance identities')
            return value
        for relative,sha in receipt['code'].items():
            path=root/relative
            if not path.resolve().is_relative_to(root) or file_hash(path)!=sha:raise ValueError('Audited data code changed; rerun acceptance')
        selected=checked(f'manifests/official_four_clients/{client}/{split}.json')
        assignment=checked('manifests/official_four_clients/source_assignment.json')['assignments']
        if selected['client']!=client or selected['split']!=split:raise ValueError('Client/split header mismatch')
        self.rows=selected['rows']
        for row in self.rows:
            if row['client']!=client or row['split']!=split or assignment[row['source_group']]!=split:
                raise ValueError('Record escapes requested client/split')
        self.identity=receipt['identity'];self.sampler=ChunkSampler(self.rows,client,split,seed)
        self.reader=RawChunkReader(max_cached_episodes)
    def sample(self,index):
        row,t=self.sampler.draw(index)
        return self.reader.read(row,t)
