"""Independent conditional spatial teacher fitted only to source predictions.

Mixture scales and packet fitting error do not establish physical uncertainty.
All stochastic training draws use an owned generator persisted in checkpoints.
Default reliability_weighting=False is the uniform-weight control: a packet's
reliability=1 is neutral, not a claim of measured local calibration accuracy.
"""
from __future__ import annotations
from collections import defaultdict
import copy
import hashlib
import json
import math
import time
import torch
from torch import nn
from .packets import unpack, validate_record
from .reception import build_support

DEFAULTS = dict(tokens=256,dim=768,intent_dim=32,width=512,depth=4,heads=8,branches=1,
                steps=1000,batch_size=32,lr=1e-4,device='cpu',checkpoint_every=100,
                replay_rounds=4,validation_fraction=.2,reliability_weighting=False,
                logvar_min=-6.,logvar_max=2.,max_support_references=1024)
ARCHITECTURE = ('tokens','dim','intent_dim','width','depth','heads','branches','logvar_min','logvar_max')


class ConditionalTeacher(nn.Module):
    def __init__(self, config=None, **kwargs):
        super().__init__()
        self.config = dict(DEFAULTS, **(config or {}), **kwargs)
        c = self.config
        if c['branches'] not in (1,2,4) or c['width'] % c['heads'] or c['intent_dim'] != 32:
            raise ValueError('Invalid teacher branch/attention/intent configuration')
        if c['logvar_min'] >= c['logvar_max'] or min(c[k] for k in ('tokens','dim','width','depth','heads')) < 1:
            raise ValueError('Invalid teacher dimensions or scale bounds')
        self.input_projection = nn.Linear(c['dim'],c['width'])
        self.intent_projection = nn.Linear(c['intent_dim'],c['width'])
        self.position = nn.Parameter(torch.zeros(1,c['tokens']+1,c['width']))
        nn.init.normal_(self.position,std=.02)
        layer = nn.TransformerEncoderLayer(c['width'],c['heads'],dim_feedforward=4*c['width'],
                                           dropout=0.,activation='gelu',batch_first=True,norm_first=True)
        self.transformer = nn.TransformerEncoder(layer,c['depth'],enable_nested_tensor=False)
        self.norm = nn.LayerNorm(c['width'])
        self.output_projection = nn.Linear(c['width'],c['branches']*c['dim'])
        self.gate = nn.Linear(c['width'],c['branches'])
        self.scale_projection = nn.Linear(c['width'],c['branches']*c['dim']) if c['branches'] > 1 else None

    def forward(self,z,intent):
        c = self.config
        if z.ndim != 3 or z.shape[1:] != (c['tokens'],c['dim']) or intent.shape != (len(z),1,c['intent_dim']):
            raise ValueError('Query shape does not match the frozen teacher interface')
        hidden = torch.cat((self.intent_projection(intent.float()),self.input_projection(z.float())),dim=1)
        hidden = self.norm(self.transformer(hidden+self.position))
        spatial = hidden[:,1:]
        means = self.output_projection(spatial).view(len(z),c['tokens'],c['branches'],c['dim']).permute(0,2,1,3)
        logits = self.gate(hidden[:,0])
        if self.scale_projection is None:
            logvar = torch.zeros_like(means)
        else:
            raw = self.scale_projection(spatial).view(len(z),c['tokens'],c['branches'],c['dim']).permute(0,2,1,3)
            logvar = c['logvar_min']+(c['logvar_max']-c['logvar_min'])*raw.sigmoid()
        return dict(means=means,logits=logits,logvar=logvar)

    def predict(self,z,intent):
        return select_prediction(self(z,intent))


def select_prediction(output):
    """Choose a deployable gate branch; never average conflicting branches."""
    return output['means'][torch.arange(len(output['means']),device=output['means'].device),output['logits'].argmax(-1)]


def teacher_loss(output,target):
    error = (output['means']-target[:,None]).square()
    if error.shape[1] == 1:
        return error[:,0].flatten(1).mean(-1)
    component = -.5*(error*torch.exp(-output['logvar'])+output['logvar']+math.log(2*math.pi))
    log_likelihood = component.flatten(2).sum(-1)+output['logits'].log_softmax(-1)
    return -torch.logsumexp(log_likelihood,dim=1)/target[0].numel()


def balanced_weights(records,reliability_weighting=False):
    """Client -> task -> trajectory-group -> round -> query uniform mass."""
    hierarchy = defaultdict(lambda:defaultdict(lambda:defaultdict(lambda:defaultdict(list))))
    for i,r in enumerate(records):hierarchy[r['client']][r['task']][r['source_group']][r['round']].append(i)
    weights = torch.zeros(len(records),dtype=torch.float64)
    for tasks in hierarchy.values():
        for groups in tasks.values():
            for rounds in groups.values():
                for indices in rounds.values():
                    relative = torch.ones(len(indices),dtype=torch.float64)
                    if reliability_weighting:
                        relative = torch.tensor([records[i]['reliability'] for i in indices],dtype=torch.float64)
                        relative = (relative/relative.mean().clamp_min(1e-12)).clamp(.25,4.)
                    relative /= relative.sum()
                    weights[indices] = relative/(len(hierarchy)*len(tasks)*len(groups)*len(rounds))
    return weights


def _record_digest(record):
    digest = hashlib.sha256()
    digest.update(json.dumps({k:v for k,v in record.items() if not isinstance(v,torch.Tensor)},sort_keys=True).encode())
    for name in ('z','intent','prediction'):
        tensor = record[name].detach().cpu().contiguous()
        digest.update(str((name,tensor.dtype,tuple(tensor.shape))).encode())
        digest.update(tensor.view(torch.uint8).numpy().tobytes())
    return digest.hexdigest()


def _identity(record):
    return (record['client'],record['round'],record['model_version'],record['source_group'],record['query_id'])


def _cpu_copy(value):
    if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
    if isinstance(value,dict):return {k:_cpu_copy(v) for k,v in value.items()}
    if isinstance(value,list):return [_cpu_copy(v) for v in value]
    if isinstance(value,tuple):return tuple(_cpu_copy(v) for v in value)
    return copy.deepcopy(value)


def _split(records,fraction,assignments=None):
    """Partition original ancestry globally, including all client renderings.

    A source_group may occur in several clients. Client-specific assignments
    would leak the same demonstration into both server training and validation.
    """
    groups = {r['source_group'] for r in records}
    assignments = dict(assignments or {})
    known = bool(assignments)
    ordered = sorted(groups,key=lambda group:hashlib.sha256(group.encode()).hexdigest())
    count = min(len(ordered)-1,max(1,int(len(ordered)*fraction))) if len(ordered)>1 else 0
    for index,group in enumerate(ordered):
        if group not in assignments:
            assignments[group] = (int(hashlib.sha256(group.encode()).hexdigest()[:8],16)/2**32 < fraction) if known else index < count
    heldout = {key for key,value in assignments.items() if value}
    train=[r for r in records if r['source_group'] not in heldout]
    validation=[r for r in records if r['source_group'] in heldout]
    return train,validation,assignments


def _batch(records,indices,device):
    rows=[records[i] for i in indices]
    return tuple(torch.stack([r[field] for r in rows]).to(device=device,dtype=torch.float32) for field in ('z','intent','prediction'))


def train_teacher(packets,config,seed,previous=None,checkpoint_callback=None):
    config = dict(DEFAULTS,**config)
    if not 1 <= config['replay_rounds'] <= 4 or config['steps'] < 0 or config['batch_size'] < 1 or not 0 < config['validation_fraction'] < 1:
        raise ValueError('Invalid server budget or bounded replay configuration')
    incoming=[]
    if isinstance(packets,bytes):packets=[packets]
    for packet in packets:
        incoming.extend(unpack(packet) if isinstance(packet,bytes) else [validate_record(packet)])
    if not incoming:raise ValueError('Server needs public predicted-query records')
    source_versions = {}
    for r in incoming:
        key = (r['client'],r['round'])
        if key in source_versions and source_versions[key] != r['model_version']:
            raise ValueError('Mixed source model identities within a client round')
        source_versions[key] = r['model_version']
    versions={r['interface_version'] for r in incoming}
    shapes={tuple(r['z'].shape) for r in incoming}
    if len(versions)!=1 or shapes!={(config['tokens'],config['dim'])}:
        raise ValueError('Mixed or mismatched teacher interfaces')
    version=next(iter(versions))
    if previous:
        if previous.get('validation_partition') != 'global-source-group.v1':
            raise ValueError('Cannot resume a teacher trained with a different ancestry partition')
        if previous['interface_version'] != version or any(previous['config'][k] != config[k] for k in ARCHITECTURE):
            raise ValueError('Cannot mix stale interface or teacher architecture')
        if previous['seed'] != seed:raise ValueError('Server restart seed mismatch')
        assignments = previous.get('group_assignments')
        if not isinstance(assignments,dict) or any(not isinstance(k,str) or not k.strip() or type(v) is not bool for k,v in assignments.items()):
            raise ValueError('Invalid persistent source-group assignments')
        stored_replay = previous.get('replay')
        if not isinstance(stored_replay,list) or not stored_replay:
            raise ValueError('Missing server replay checkpoint')
        for r in stored_replay:
            # Validate individually so integrity checks do not duplicate the
            # complete multi-GiB replay in host memory.
            checked = validate_record(r)
            if checked['interface_version'] != version or tuple(checked['z'].shape) not in shapes:
                raise ValueError('Replay checkpoint contains a stale or mismatched interface')
            if checked['source_group'] not in assignments:
                raise ValueError('Replay group is missing its permanent partition assignment')
        if len({r['round'] for r in stored_replay}) > 4:
            raise ValueError('Replay checkpoint exceeds the four-round bound')
    input_fingerprint=hashlib.sha256(''.join(sorted(_record_digest(r) for r in incoming)).encode()).hexdigest()
    resuming=bool(previous and previous['input_fingerprint']==input_fingerprint)
    if resuming:
        mutable = {'device','checkpoint_every','steps'}
        if any(previous['config'].get(k) != v for k,v in config.items() if k not in mutable):
            raise ValueError('Cannot change optimization or sampling settings during restart')
    if resuming and previous['steps'] > config['steps']:raise ValueError('Cannot rewind server optimization')
    if previous and not resuming and previous['steps'] < previous['config']['steps']:
        raise ValueError('Cannot change packets while server round is incomplete')
    if previous and not resuming and min(r['round'] for r in incoming) <= previous['round']:
        raise ValueError('New server packets must advance the committed round')
    deduplicated={}
    for r in (previous.get('replay',[]) if previous else [])+incoming:
        key=_identity(r)
        if key in deduplicated and _record_digest(deduplicated[key]) != _record_digest(r):
            raise ValueError('Conflicting source-version query records')
        deduplicated[key]=r
    rounds=sorted({r['round'] for r in deduplicated.values()})[-config['replay_rounds']:]
    replay=sorted((r for r in deduplicated.values() if r['round'] in rounds),key=_identity)
    train,validation,assignments=_split(replay,config['validation_fraction'],previous.get('group_assignments') if previous else None)
    if not train:raise ValueError('Replay has no independently assigned training groups')
    device=torch.device(config['device'])
    # Initialization must not perturb the caller's private training RNG.
    with torch.random.fork_rng(devices=[]):
        torch.random.default_generator.manual_seed(seed)
        model=ConditionalTeacher(config).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=config['lr'])
    generator=torch.Generator(device='cpu').manual_seed(seed)
    steps=0
    total_start=0
    if previous:
        model.load_state_dict(previous['model'])
        optimizer.load_state_dict(previous['optimizer'])
        generator.set_state(previous['rng']['sampling'])
        steps=previous['steps'] if resuming else 0
        total_start=previous['total_steps']-steps
    weights=balanced_weights(train,config['reliability_weighting'])
    start=time.monotonic()
    prior_seconds=previous['metrics'].get('training_seconds',0.) if resuming else 0.
    metrics=dict(train_groups=sorted({(r['client'],r['source_group']) for r in train}),
                 validation_groups=sorted({(r['client'],r['source_group']) for r in validation}),
                 train_queries=len(train),validation_queries=len(validation),
                 validation_kind='heldout source-predictor fitting error',
                 reliability_weighting=config['reliability_weighting'])
    support=build_support(train,config['max_support_references'])

    def artifact():
        return dict(schema='fedwam.server-teacher.v1',config=dict(config),seed=seed,model=_cpu_copy(model.state_dict()),
                    optimizer=_cpu_copy(optimizer.state_dict()),rng={'sampling':generator.get_state().clone()},
                    steps=steps,total_steps=total_start+steps,round=max(rounds),support=_cpu_copy(support),
                    metrics=dict(metrics,training_seconds=prior_seconds+time.monotonic()-start),
                    interface_version=version,replay=_cpu_copy(replay),input_fingerprint=input_fingerprint,
                    group_assignments=dict(assignments),validation_partition='global-source-group.v1')

    model.train()
    while steps < config['steps']:
        indices=torch.multinomial(weights,config['batch_size'],replacement=True,generator=generator).tolist()
        z,intent,target=_batch(train,indices,device)
        optimizer.zero_grad(set_to_none=True)
        loss=teacher_loss(model(z,intent),target).mean()
        if not torch.isfinite(loss):raise FloatingPointError('Nonfinite server prediction-fitting loss')
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
        optimizer.step()
        steps+=1
        metrics['last_batch_loss']=float(loss.detach())
        if checkpoint_callback and config['checkpoint_every'] > 0 and steps%config['checkpoint_every']==0:
            checkpoint_callback(artifact())
    model.eval()
    with torch.no_grad():
        for name,rows in [('train',train),('validation',validation)]:
            if not rows:
                metrics[f'{name}_mse']=None
                metrics[f'{name}_loss']=None
                continue
            losses,errors=[],[]
            for offset in range(0,len(rows),config['batch_size']):
                z,intent,target=_batch(rows,list(range(offset,min(len(rows),offset+config['batch_size']))),device)
                output=model(z,intent)
                losses.extend(teacher_loss(output,target).cpu().tolist())
                errors.extend((select_prediction(output)-target).square().flatten(1).mean(1).cpu().tolist())
            metric_weights=balanced_weights(rows)
            metrics[f'{name}_loss']=float((torch.tensor(losses)*metric_weights).sum())
            metrics[f'{name}_mse']=float((torch.tensor(errors)*metric_weights).sum())
    return artifact()


def load_teacher(artifact,device='cpu'):
    with torch.random.fork_rng(devices=[]):
        model=ConditionalTeacher(artifact['config']).to(device)
    model.load_state_dict(artifact['model'])
    model.eval().requires_grad_(False)
    return model


def infer_teacher(artifact,z,intent,device='cpu'):
    model=load_teacher(artifact,device)
    with torch.no_grad():return model.predict(z.to(device),intent.to(device))
