"""Full-denominator evaluation accounting and dependence-aware paired statistics.

This module contains no simulator imports. Failed executions remain observations with
zero success; missing observations stay in the planned denominator and are identified.
"""
from collections import defaultdict
from pathlib import Path
import math
import random
import statistics

from .io import digest, file_hash, load

CLIENTS = ('lighting', 'camera_pose', 'sensor_noise', 'background')
CATEGORIES = CLIENTS + ('object_layout', 'robot_initial', 'language')


def reusable_result(record, identity):
    if record.get('identity') != identity:
        raise ValueError('Evaluation identity changed; refusing stale case')
    return record.get('completed') is True and not record.get('error') and isinstance(record.get('success'), bool)


def load_final_checkpoint(run, final, client):
    import torch
    run = Path(run).resolve()
    expected_clients = {'pooled'} if final['method'] == 'M9' else set(CLIENTS)
    if client not in expected_clients or client not in final['clients']:
        raise ValueError('Client is not part of this final model')
    entry = final['clients'][client]
    path = (run / entry['path']).resolve()
    if not path.is_relative_to(run):
        raise ValueError('Checkpoint path escapes run')
    if file_hash(path) != entry['sha256']:
        raise ValueError('Final checkpoint checksum mismatch')
    # Private checkpoints include Python/NumPy RNG state and are trusted local artifacts.
    checkpoint = torch.load(path, map_location='cpu', weights_only=False)
    if checkpoint.get('schema') != 'fedwam.client.v1':
        raise ValueError('Unsupported checkpoint schema')
    for key in ('identity', 'method', 'seed'):
        if checkpoint.get(key) != final.get(key):
            raise ValueError(f'Final checkpoint {key} mismatch')
    done = checkpoint.get('done')
    completed = done is True or (type(done) is int and type(checkpoint.get('steps')) is int
                                 and done >= 0 and done == checkpoint['steps'])
    if checkpoint.get('client') != client or not completed:
        raise ValueError('Checkpoint is not the completed requested client')
    if not {'world', 'action'} <= checkpoint.get('state', {}).keys():
        raise ValueError('Missing deployed world/action state')
    return checkpoint


def verify_run_identity(root, identity):
    root = Path(root).resolve()
    if identity.get('schema') != 'fedwam.run.v1':
        raise ValueError('Unsupported run identity')
    paths = {'data_acceptance_sha256': 'manifests/official_four_clients/acceptance.json',
             'checkpoint_sha256': 'runtime/lawam_libero_sft/final_model/pytorch_model.pt',
             'normalization_sha256': 'runtime/lawam_libero_sft/dataset_statistics.json',
             'protocol_sha256': 'configs/protocol.json',
             'model_config_sha256': 'runtime/lawam_libero_sft/config.yaml'}
    for key, relative in paths.items():
        if file_hash(root / relative) != identity[key]:
            raise ValueError(f'Run identity mismatch: {key}')
    receipt = load(root / paths['data_acceptance_sha256'])
    if receipt['identity'] != identity['data_identity'] or receipt.get('accepted_for_official_four_client_training') is not True:
        raise ValueError('Accepted data identity mismatch')
    if not identity.get('code'):
        raise ValueError('Missing training code identity')
    for relative, sha in identity['code'].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or file_hash(path) != sha:
            raise ValueError(f'Run code identity mismatch: {relative}')


def verify_manifest(manifest):
    if manifest.get('sha256') != digest({k: v for k, v in manifest.items() if k != 'sha256'}):
        raise ValueError('Case manifest checksum mismatch')
    ids = [r['variant_id'] for r in manifest['cases']]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate case identity')
    seen, confirm = set(manifest['E_seen']), set(manifest['E_confirm'])
    if seen & confirm or seen | confirm != set(ids):
        raise ValueError('Exposure partitions do not cover cases exactly')


def attach_base_tasks(rows, source_rows):
    """Match official original task stems; never treat each variant as a base task."""
    bases = defaultdict(set)
    for row in source_rows:
        stem = Path(row['source_file']).stem
        if stem.endswith('_demo'):
            stem = stem[:-5]
        bases[row['suite']].add(stem.lower())
    result = []
    for row in rows:
        name = row['name'].lower()
        candidates = [b for b in bases[row['suite']] if name == b or name.startswith(b + '_')]
        if not candidates:
            raise ValueError(f'Cannot identify original base task for {row["variant_id"]}: {name}')
        longest = max(map(len, candidates))
        matches = [b for b in candidates if len(b) == longest]
        if len(matches) != 1:
            raise ValueError('Ambiguous base task identity')
        result.append(dict(row, base_task=matches[0]))
    return result


def prediction_items(rows, scope):
    ordered = sorted(rows, key=lambda r: (r['source_group'], r['record_id']))
    if scope == 'representative-per-group':
        seen = set()
        for row in ordered:
            if row['source_group'] not in seen and row['continuous_chunk_starts']:
                seen.add(row['source_group'])
                yield row, min(row['continuous_chunk_starts'])
    elif scope == 'all-chunks':
        for row in ordered:
            for t in sorted(row['continuous_chunk_starts']):
                yield row, t
    else:
        raise ValueError('Unknown prediction scope')


def _key(record):
    return record['seed'], record['client'], record['case']['variant_id']


def _index(records):
    indexed = {}
    for record in records:
        key = _key(record)
        if key in indexed:
            raise ValueError(f'Duplicate result: {key}')
        if not isinstance(record.get('success'), bool):
            raise ValueError(f'Invalid success value: {key}')
        indexed[key] = record
    return indexed


def _success(record):
    return int(record is not None and record.get('completed') is True and not record.get('error') and record['success'])


def _summary(observations):
    count = len(observations)
    present = [r for r in observations if r is not None]
    successes = sum(_success(r) for r in present)
    errors = sum(bool(r.get('error')) or r.get('completed') is not True for r in present)
    return {'expected': count, 'recorded': len(present), 'missing': count-len(present),
            'errors': errors, 'completed': len(present)-errors, 'successes': successes,
            'policy_failures': len(present)-errors-successes,
            'success_rate': successes/count if count else None}


def build_report(manifest, records, clients=CLIENTS, categories=CATEGORIES, *, seeds=None):
    records = list(records)
    indexed = _index(records)
    seeds = list(seeds if seeds is not None else sorted({r['seed'] for r in records}) or [42])
    rows = manifest['cases']
    cases = {r['variant_id']: r for r in rows}
    if len(cases) != len(rows):
        raise ValueError('Duplicate manifest case')
    for (seed, client, variant), record in indexed.items():
        if seed not in seeds or client not in clients or variant not in cases:
            raise ValueError('Result outside expected evaluation universe')
        if record['case'] != cases[variant]:
            raise ValueError('Result case identity differs from manifest')
    grid = [(seed, client, row, indexed.get((seed, client, row['variant_id'])))
            for seed in seeds for client in clients for row in rows]
    report = _summary([r for _, _, _, r in grid])
    report['complete'] = report['missing'] == 0 and report['errors'] == 0
    report['clients'] = list(clients)
    report['seeds'] = seeds
    report['matrix'] = {c: {cat: _summary([r for _, client, row, r in grid if client == c and row['category'] == cat])
                            for cat in categories} for c in clients}
    report['by_client'] = {c: _summary([r for _, client, _, r in grid if client == c]) for c in clients}
    report['worst_client'] = min((v['success_rate'] for v in report['by_client'].values() if v['expected']), default=None)
    report['by_seed'] = {str(s): _summary([r for seed, _, _, r in grid if seed == s]) for s in seeds}
    scores = [r['success_rate'] for r in report['by_seed'].values() if r['expected']]
    report['seed_mean'] = statistics.mean(scores) if scores else None
    report['seed_sample_sd'] = statistics.stdev(scores) if len(scores) > 1 else None
    exposure_ids = {split:set(manifest[split]) for split in ('E_seen','E_confirm')}
    report['exposure'] = {split: _summary([r for _, _, row, r in grid if row['variant_id'] in ids])
                          for split, ids in exposure_ids.items()}
    for field, label in [('suite', 'suite'), ('base_task', 'task')]:
        grouped = defaultdict(list)
        for _, _, row, record in grid:
            key = row['suite'] if field == 'suite' else row['suite'] + '/' + row['base_task']
            grouped[key].append(record)
        report['by_' + label] = {k: _summary(v) for k, v in sorted(grouped.items())}
        report[label + '_macro'] = statistics.mean(v['success_rate'] for v in report['by_' + label].values()) if grouped else None
    report['micro'] = report['success_rate']
    report['failures'] = [{'seed':s, 'client':c, 'variant_id':row['variant_id'],
                           'failure_type':'missing' if r is None else ('execution_error' if r.get('error') or not r.get('completed') else 'policy_failure'),
                           'error':r.get('error') if r else None, 'video':r.get('video') if r else None}
                          for s,c,row,r in grid if not _success(r)]
    report['videos'] = [{'seed':s, 'client':c, 'variant_id':row['variant_id'], 'video':r['video'], 'success':bool(_success(r))}
                        for s,c,row,r in grid if r and r.get('video')]
    report['evaluation_seconds'] = sum(float(r.get('elapsed_seconds',0)) for r in records)
    return report


def _percentile(values, p):
    ordered = sorted(values)
    index = (len(ordered)-1)*p
    lo = math.floor(index)
    return ordered[lo] + (ordered[math.ceil(index)]-ordered[lo])*(index-lo)


def paired_comparison(left, right, *, replicates=2000, seed=20260922):
    """Pair seed/client/variant first; resample tasks and variants as intact blocks.

    Cross-client and cross-seed repeats are kept together in each variant block.
    This is task uncertainty conditional on the observed seeds; seed SD is separate.
    """
    if replicates < 1:
        raise ValueError('Positive bootstrap replicate count required')
    a, b = _index(left), _index(right)
    common = sorted(a.keys() & b.keys())
    seed_deltas = defaultdict(list)
    clusters = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for key in common:
        if a[key]['case'] != b[key]['case']:
            raise ValueError('Paired case identity mismatch')
        row = a[key]['case']
        delta = _success(a[key])-_success(b[key])
        seed_deltas[key[0]].append(delta)
        # Optional source ancestry groups share one resampling block.
        unit = row.get('source_group', row['variant_id'])
        clusters[row['suite']][row['base_task']][unit].append(delta)
    means = {str(k):statistics.mean(v) for k,v in sorted(seed_deltas.items())}
    rng = random.Random(seed)
    draws = []
    for _ in range(replicates if common else 0):
        total = count = 0
        for tasks in clusters.values():
            task_keys = sorted(tasks)
            for task in rng.choices(task_keys, k=len(task_keys)):
                variants = tasks[task]
                for variant in rng.choices(sorted(variants), k=len(variants)):
                    values = variants[variant]
                    total += sum(values)
                    count += len(values)
        draws.append(total/count)
    return {'paired_cases':len(common), 'left_unpaired':len(a)-len(common), 'right_unpaired':len(b)-len(common),
            'by_seed':means, 'seed_mean_difference':statistics.mean(means.values()) if means else None,
            'seed_sample_sd':statistics.stdev(means.values()) if len(means)>1 else None,
            'task_bootstrap_95_ci':[_percentile(draws,.025),_percentile(draws,.975)] if draws else None,
            'independent_tasks':sum(len(tasks) for tasks in clusters.values()),
            'variant_clusters':sum(len(v) for tasks in clusters.values() for v in tasks.values()),
            'bootstrap_replicates':replicates, 'bootstrap_seed':seed,
            'uncertainty':'suite-stratified paired task/variant bootstrap; client and seed repeats kept together; seed SD is not a confidence interval',
            'missing_policy':'only common recorded cases paired; execution errors count as failures; unpaired counts explicit'}


def evaluate_shard(output, rows, identity, client, seed, index, count, rollout):
    """Evaluate every assigned row. Callback receives (row, per-case output directory)."""
    import time
    import traceback
    from .evaluation import partition
    from .io import save, status
    output = Path(output).resolve()
    worker = output / 'workers' / client / f'{index:04d}-of-{count:04d}'
    assigned = partition(rows,index,count)
    worker_identity = dict(identity=identity, client=client, seed=seed, index=index, count=count)
    if (worker/'identity.json').exists() and load(worker/'identity.json') != worker_identity:
        raise ValueError('Worker evaluation identity changed')
    save(worker/'identity.json',worker_identity)
    # Two fixed candidates per suite/category, selected globally before sharding.
    # Recording never depends on policy success or failure.
    candidates = defaultdict(list)
    for row in rows:
        cell = (row['suite'], row['category'])
        candidate = (digest(row['variant_id']), row['variant_id'])
        candidates[cell] = sorted(candidates[cell] + [candidate])[:2]
    fixed = {value[1] for values in candidates.values() for value in values}
    identity_sha = digest(identity)
    done = errors = resumed = 0
    for row in assigned:
        directory = output/'cases'/client/digest(row['variant_id'])[:24]
        path = directory/'result.json'
        key = {'evaluation':identity_sha, 'case_sha256':digest(row)}
        if path.exists() and reusable_result(load(path),key):
            done += 1
            resumed += 1
            continue
        status(worker,state='running',assigned=len(assigned),done=done,errors=errors,current=row['variant_id'])
        started = time.perf_counter()
        try:
            record = rollout(dict(row,record_video=row['variant_id'] in fixed),directory)
            if not isinstance(record.get('success'),bool):
                raise ValueError('Rollout did not return boolean success')
            record.update(completed=True,error=None)
            done += 1
        except Exception as error:
            traceback.print_exc()
            video = directory/'rollout.mp4'
            record = {'completed':False,'success':False,'error':repr(error),
                      'video':str(video) if video.exists() else None,
                      'video_unavailable_reason':None if video.exists() else (
                          'Native simulator failed before video serialization' if row['variant_id'] in fixed
                          else 'Case not selected by fixed two-per-suite/category video policy')}
            errors += 1
        record.update(case=row,identity=key,client=client,seed=seed,elapsed_seconds=time.perf_counter()-started)
        save(path,record)
    summary = {'state':'completed' if errors==0 else 'failed', 'assigned':len(assigned),
               'done':done,'errors':errors,'resumed':resumed,'index':index,'count':count}
    status(worker,**summary)
    return summary


def cost_summary(run):
    run = Path(run)
    events = []
    upload = download = 0
    seconds = 0.
    phase_seconds = defaultdict(float)
    initialization = run/'events/public_queries_initialization.json'
    paths = ([initialization] if initialization.exists() else []) + sorted((run/'events').glob('round_*.json'))
    for path in paths:
        event = load(path)
        up = sum(event.get('upload_bytes',{}).values())
        down = sum(event.get('download_bytes',{}).values())
        if up < 0 or down < 0:
            raise ValueError('Negative communication accounting')
        upload += up
        download += down
        seconds += float(event.get('seconds_this_attempt',0))
        for key,value in event.items():
            if key.endswith('_seconds') and isinstance(value,(float,int)):
                if not math.isfinite(value) or value < 0:
                    raise ValueError('Invalid compute accounting')
                phase_seconds[key] += value
        events.append({'event':path.name,'upload_bytes_by_client':event.get('upload_bytes',{}),
                       'download_bytes_by_client':event.get('download_bytes',{}),
                       'cumulative_upload_bytes':upload,'cumulative_download_bytes':download,
                       'seconds_this_attempt':event.get('seconds_this_attempt'),
                       'transport':event.get('transport'),
                       'measurements':{k:v for k,v in event.items() if k not in ('upload_bytes','download_bytes','transport')}})
    return {'upload_bytes':upload,'download_bytes':download,'recorded_attempt_seconds':seconds,
            'events':events,'rounds':[event for event in events if event['event'].startswith('round_')],
            'recorded_phase_seconds':dict(phase_seconds),'communication_measure':'actual serialized payload bytes; same-host transport, not network throughput',
            'complete_compute_accounting':False,
            'unaccounted_or_not_separately_measured':['interrupted/retried attempts','initial encoder/teacher/anchor distribution if not in round events',
                'GPU versus CPU time by training/packet/server/calibration/action-adaptation phase',
                'cache preprocessing','peak host/device memory','hardware FLOPs'],
            'comparison_requirement':'at least three communication budget points required; this ledger describes only this run'}


def prediction_summary(records, expected):
    records = list(records)
    if len(records)>expected:
        raise ValueError('Prediction records exceed declared scope')
    valid = [r for r in records if r.get('completed') is True and not r.get('error')]
    groups = defaultdict(list)
    for row in valid:
        if not all(math.isfinite(row[k]) for k in ('future_mse','persistence_mse')):
            raise ValueError('Nonfinite prediction metric')
        groups[row['source_group']].append(row['future_mse'])
    return {'expected':expected,'recorded':len(records),'valid':len(valid),
            'errors':len(records)-len(valid),'missing':expected-len(records),
            'complete':len(valid)==expected,
            'future_mse_valid_only':statistics.mean(r['future_mse'] for r in valid) if valid else None,
            'persistence_mse_valid_only':statistics.mean(r['persistence_mse'] for r in valid) if valid else None,
            'future_mse_source_group_macro_valid_only':statistics.mean(statistics.mean(v) for v in groups.values()) if groups else None,
            'source_groups_with_valid_results':len(groups),
            'error_policy':'MSE undefined for failed/missing inputs; errors and missing counts explicit, never replaced with zero',
            'pose_contact_metrics':'unavailable in accepted image/action interface',
            'transition_mse':'equivalent to future MSE, not independent evidence'}


def run_settings(identity):
    """Compare seeds without discarding any scientific budget or method setting."""
    return dict({k:v for k,v in identity.items() if k not in ('seed','config')},
                config={k:v for k,v in identity['config'].items() if k!='seed'})
