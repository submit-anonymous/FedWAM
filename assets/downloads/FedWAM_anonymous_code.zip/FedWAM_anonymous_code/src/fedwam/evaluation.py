"""Evaluation resumability and exact shard coverage."""
def reusable(record,identity):
    if record.get('identity')!=identity:raise ValueError('Cannot resume across model/protocol identities')
    return record.get('completed') is True and not record.get('error') and isinstance(record.get('success'),bool)
def partition(rows,index,count):
    if not 0<=index<count:raise ValueError('Invalid evaluation shard')
    return rows[index::count]
