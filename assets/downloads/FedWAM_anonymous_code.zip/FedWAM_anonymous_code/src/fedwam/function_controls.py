"""Fixed-query control and future/transition conversion with matched coordinates."""
import torch

def future_from_prediction(prediction,z,representation):
 if representation=='transition':return prediction+z
 if representation=='future':return prediction
 raise ValueError('Unknown predictive representation')

def average_fixed_queries(client_records):
 if not client_records or not client_records[0]:raise ValueError('Empty public query contributions')
 expected=[r['query_id'] for r in client_records[0]]
 if len(set(expected))!=len(expected):raise ValueError('Duplicate public query')
 indexed=[]
 for records in client_records:
  mapping={r['query_id']:r for r in records}
  if len(mapping)!=len(records) or set(mapping)!=set(expected):raise ValueError('Clients must answer the exact same public queries')
  indexed.append(mapping)
 result=[]
 for q in expected:
  rows=[m[q] for m in indexed];base=rows[0]
  if any(not torch.equal(r['z'],base['z']) or not torch.equal(r['intent'],base['intent']) for r in rows):raise ValueError('Public query coordinates disagree')
  if any(r['prediction'].shape!=base['z'].shape or not torch.isfinite(r['prediction']).all() for r in rows):raise ValueError('Invalid public prediction')
  result.append(dict(base,prediction=torch.stack([r['prediction'].float() for r in rows]).mean(0)))
 return result
