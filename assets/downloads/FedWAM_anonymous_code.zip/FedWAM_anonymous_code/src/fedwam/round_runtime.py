"""Atomic private checkpoints, phase receipts and synchronous round commit points."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,random,time
import numpy as np
import torch

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 return h.hexdigest()
def atomic_json(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
 with tmp.open('w') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def atomic_torch(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
 with tmp.open('wb') as f:torch.save(value,f);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
def cpu_tree(value):
 if isinstance(value,torch.Tensor):return value.detach().cpu().clone()
 if isinstance(value,dict):return {k:cpu_tree(v) for k,v in value.items()}
 if isinstance(value,list):return [cpu_tree(v) for v in value]
 if isinstance(value,tuple):return tuple(cpu_tree(v) for v in value)
 return value
def rng_state():
 return dict(python=random.getstate(),numpy=np.random.get_state(),torch=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])
def restore_rng(state):
 random.setstate(state['python']);np.random.set_state(state['numpy']);torch.set_rng_state(state['torch'])
 if state['cuda']:
  if not torch.cuda.is_available():raise ValueError('CUDA RNG cannot resume on CPU')
  torch.cuda.set_rng_state_all(state['cuda'])

class RoundStore:
 def __init__(self,root,identity):
  self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True);self.identity=identity
  p=self.root/'identity.json'
  if p.exists() and json.loads(p.read_text())!=identity:raise ValueError('Run identity changed')
  if not p.exists():atomic_json(p,identity)
 def path(self,name):
  p=(self.root/name).resolve()
  if not p.is_relative_to(self.root):raise ValueError('Artifact path escapes run')
  return p
 def write(self,name,value):
  p=self.path(name);atomic_torch(p,value);return {'path':str(p.relative_to(self.root)),'sha256':sha(p),'bytes':p.stat().st_size}
 def read_ref(self,ref):
  p=self.path(ref['path'])
  if sha(p)!=ref['sha256']:raise ValueError('Artifact checksum mismatch')
  return torch.load(p,map_location='cpu',weights_only=False)
 def latest(self):
  p=self.path('committed.json')
  if not p.exists():return None
  value=json.loads(p.read_text())
  if value['identity']!=self.identity:raise ValueError('Committed identity mismatch')
  return value
 def commit(self,round,states,clients,server=None,ledger=None):
  if set(states)!=set(clients):raise ValueError('Cannot commit without all clients')
  for ref in states.values():self.read_ref(ref)
  if server:self.read_ref(server)
  value={'identity':self.identity,'round':round,'clients':states,'server':server,'ledger':ledger or {},'time':datetime.now(timezone.utc).isoformat()}
  atomic_json(self.path(f'commits/round_{round:04d}.json'),value)
  atomic_json(self.path('committed.json'),value)
  return value
 def event(self,key,value):
  # Unique semantic event key, overwritten on retry rather than double-counted.
  atomic_json(self.path(f'events/{key}.json'),value)

class PhaseRunner:
 def __init__(self,store):self.store=store
 def run(self,key,initial,steps,worker,metadata=None):
  checkpoint=self.store.path(f'phases/{key}.pt');receipt=self.store.path(f'phases/{key}.json')
  if receipt.exists():
   saved=json.loads(receipt.read_text())
   if saved['steps']!=steps:raise ValueError('Phase budget changed')
   return self.store.read_ref(saved['artifact'])['state']
  state=initial;done=0
  if checkpoint.exists():
   value=torch.load(checkpoint,map_location='cpu',weights_only=False)
   if value['identity']!=self.store.identity or value['key']!=key or value['steps']!=steps:raise ValueError('Partial phase identity changed')
   done=value['done'];state=value['state']
   if not 0<=done<=steps:raise ValueError('Invalid phase progress')
  started=time.perf_counter()
  def save(done,state):
   if not 0<=done<=steps:raise ValueError('Invalid phase progress')
   value={'schema':'fedwam.client.v1','identity':self.store.identity,'key':key,'steps':steps,'done':done,'state':state,**(metadata or {})}
   atomic_torch(checkpoint,value)
  state=worker(state,done,save)
  save(steps,state)
  ref={'path':str(checkpoint.relative_to(self.store.root)),'sha256':sha(checkpoint),'bytes':checkpoint.stat().st_size}
  atomic_json(receipt,{'steps':steps,'artifact':ref,'seconds_this_attempt':time.perf_counter()-started})
  return state
 def ref(self,key):return json.loads(self.store.path(f'phases/{key}.json').read_text())['artifact']
