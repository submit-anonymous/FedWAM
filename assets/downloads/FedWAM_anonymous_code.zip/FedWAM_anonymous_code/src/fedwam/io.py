"""Atomic per-job records, with no writes through external asset links."""
import hashlib,json,os
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
NATIVE_STORAGE_ROOT=ROOT/'runs/native'
NATIVE_LOCAL_STORAGE_ROOT=Path.home()/'FedWAM-native-runs/local-seed42-v3'
def save(path,value):
    path=Path(path)
    resolved=path.resolve()
    if not (resolved.is_relative_to(ROOT) or resolved.is_relative_to(NATIVE_LOCAL_STORAGE_ROOT.resolve())):
        raise ValueError(f'Output outside project/account native runs: {path}')
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
    tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n');tmp.replace(path)
def load(path):return json.loads(Path(path).read_text())
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,allow_nan=False).encode()).hexdigest()
def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def status(out,**value):
    save(Path(out)/'status.json',dict(value,updated=datetime.now(timezone.utc).isoformat(),job=os.environ.get('SLURM_JOB_ID')))
