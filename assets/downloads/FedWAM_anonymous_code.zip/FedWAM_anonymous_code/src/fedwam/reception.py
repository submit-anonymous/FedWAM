"""Local reception calibration; public support uses only deployable queries.

Support distance is a conservative heuristic, not a physical uncertainty estimate.
Errors passed here are computed privately against local calibration targets.
"""
from __future__ import annotations
from collections import defaultdict
import math
import torch


def calibrate_reception(samples, margin=.02, min_groups=5, epsilon=1e-8):
    if min_groups < 5 or epsilon <= 0 or not 0 <= margin < 1:
        raise ValueError('Reception requires at least five groups and a valid margin')
    grouped, coarse = defaultdict(lambda: defaultdict(list)), defaultdict(list)
    for sample in samples:
        task, group = sample['task'], sample['source_group']
        for field in ('local_error', 'teacher_error'):
            if not math.isfinite(float(sample[field])) or sample[field] < 0:
                raise ValueError('Calibration errors must be finite and nonnegative')
        grouped[task][group].append(sample)
        coarse[group].append(sample)

    def summarize(groups):
        if len(groups) < min_groups:
            return 0., False, None
        local, teacher, correct = [], [], []
        for rows in groups.values():
            local.append(sum(float(r['local_error']) for r in rows)/len(rows))
            teacher.append(sum(float(r['teacher_error']) for r in rows)/len(rows))
            # Missing branch evidence is explicitly not evidence of correctness.
            correct.append(sum(r.get('selected_branch_correct') is True for r in rows)/len(rows))
        e_local, e_teacher = sum(local)/len(local), sum(teacher)/len(teacher)
        gain = (e_local-e_teacher)/(e_local+epsilon)
        beta = max(0., min(1., gain-margin))
        return beta, min(correct) >= .8, dict(local_error=e_local, teacher_error=e_teacher, gain=gain)

    default, coarse_branch, coarse_metrics = summarize(coarse)
    betas, branches, counts, metrics = {}, {}, {}, {}
    for task, groups in grouped.items():
        beta, branch, values = summarize(groups)
        if len(groups) < min_groups:
            beta, branch, values = default, coarse_branch, coarse_metrics
        betas[task], branches[task], counts[task], metrics[task] = beta, branch, len(groups), values
    return dict(beta_by_task=betas, default_beta=default, branch_calibrated=branches,
                default_branch_calibrated=coarse_branch, counts=counts, metrics=metrics,
                coarse_groups=len(coarse), margin=margin, min_groups=min_groups)


def _features(z, intent):
    if z.ndim != 3 or intent.ndim != 3 or intent.shape[1:] != (1,32) or len(z) != len(intent):
        raise ValueError('Support requires z[B,S,D], intent[B,1,32]')
    features = torch.cat((z.detach().float().mean(1), intent.detach().float().flatten(1)), dim=1)
    if not torch.isfinite(features).all():
        raise ValueError('Nonfinite query features')
    return features


def build_support(records, max_references=1024):
    if not records or max_references < 1:
        raise ValueError('Support requires nonempty training queries')
    # Pool one query at a time rather than materializing the full spatial replay
    # as a temporary float32 batch (several GiB at the production byte budget).
    features = torch.cat([_features(r['z'][None],r['intent'][None]).cpu() for r in records],dim=0)
    center = features.mean(0)
    scale = features.std(0, unbiased=False).clamp_min(.001)
    normalized = (features-center)/scale
    indices = torch.linspace(0,len(features)-1,min(len(features),max_references)).long()
    return dict(references=normalized[indices], center=center, scale=scale, threshold=None,
                feature_version='mean-z-plus-intent.v1', training_queries=len(features))


def support_distances(support, z, intent):
    features = _features(z,intent)
    center, scale = support['center'].to(features.device), support['scale'].to(features.device)
    references = support['references'].to(features.device)
    normalized = (features-center)/scale
    return torch.cdist(normalized,references).amin(1)/math.sqrt(features.shape[1])


def calibrate_support(support, z, intent, quantile=.95):
    if not 0 < quantile <= 1 or len(z) == 0:
        raise ValueError('Support calibration requires queries and a valid quantile')
    distances = support_distances(support,z,intent)
    return dict(support, threshold=max(float(torch.quantile(distances,quantile)),1e-6),
                calibration_queries=len(z), quantile=quantile)


def support_mask(support, z, intent):
    if support.get('threshold') is None:
        return torch.zeros(len(z),dtype=torch.bool,device=z.device)
    return support_distances(support,z,intent) <= support['threshold']


def reception_weights(calibration, tasks, z, intent, support, logits=None, branch_confidence=.8):
    if len(tasks) != len(z) or not .5 < branch_confidence <= 1:
        raise ValueError('Invalid reception batch or branch confidence')
    weights = torch.tensor([calibration['beta_by_task'].get(t,calibration['default_beta']) for t in tasks],
                           device=z.device,dtype=torch.float32)
    weights *= support_mask(support,z,intent)
    if logits is not None:
        if logits.ndim != 2 or len(logits) != len(z) or not torch.isfinite(logits).all():
            raise ValueError('Invalid branch logits')
        if logits.shape[1] > 1:
            evidence = torch.tensor([calibration['branch_calibrated'].get(t,calibration['default_branch_calibrated']) for t in tasks],
                                    device=z.device,dtype=torch.bool)
            confidence = logits.detach().softmax(-1).amax(-1).to(z.device)
            weights *= evidence & (confidence >= branch_confidence)
    return weights.detach()
