"""Independent client jobs relinquish their GPU instead of waiting for peers."""
import json
from .parallel_engine import ParallelEngine

class DependencyPending(Exception):
 def __init__(self,name):
  self.name=name
  super().__init__(name)

class DetachedEngine(ParallelEngine):
 def wait(self,name,predicate=None):
  failures=list(self.store.path(f'attempts/{self.attempt}/errors').glob('*.json'))
  if failures:raise RuntimeError('Client failed: '+failures[0].read_text()[:500])
  # A new job starts at the last globally committed round. It need not wait
  # for the coordinator job to be allocated before its own warmup/pre work.
  if name==f'attempts/{self.attempt}/start.json':return {'latest':self.store.latest()}
  path=self.store.path(name)
  if path.exists():
   value=json.loads(path.read_text())
   if predicate is None or predicate(value):return value
  raise DependencyPending(name)
