"""Pinned LaWAM train-batch adapter for the accepted PLUS chunk-end data."""
from pathlib import Path
import numpy as np
import torch
import yaml
from .io import ROOT,file_hash
from .training import action_tensors
from .round_runtime import cpu_tree

OFFICIAL=ROOT/'third_party/LaWAM/starVLA/config/training/train_libero.yaml'
def local_contract():
 cfg=yaml.safe_load(OFFICIAL.read_text());t=cfg['trainer'];a=cfg['framework']['action_model']
 return dict(source_recipe=str(OFFICIAL.relative_to(ROOT)),source_sha256=file_hash(OFFICIAL),
             source_checkpoint_kind='LIBERO SFT',steps=int(t['max_train_steps']),lr_warmup=int(t['num_warmup_steps']),
             per_device_batch=int(cfg['datasets']['vla_data']['per_device_batch_size']),
             lr=float(t['learning_rate']['base']),optimizer_betas=[float(x) for x in t['optimizer']['betas']],
             weight_decay=float(t['optimizer']['weight_decay']),scheduler=t['lr_scheduler_type'],
             scheduler_min_lr=float(t['scheduler_specific_kwargs']['min_lr']),
             latent_action_distill=bool(a['enable_loss_distill']),
             latent_action_distill_weight=float(a['lam_encoder_distill_weight']),
             future_weight=float(a['perceptual_weight']),detach_future_feature=bool(a['detach_future_feature']),
             image_frames=int(cfg['datasets']['vla_data']['num_frames']),chunk_actions=int(a['num_action_queries']))
def make_native_sample(sample,stats):
 if sample.get('future_t',sample.get('t',0)+8)!=sample.get('t',0)+8:raise ValueError('Not chunk-end t+8')
 def frame(x):
  x=np.asarray(x)
  if x.shape!=(256,256,3) or x.dtype!=np.uint8:raise ValueError('Expected uint8 RGB256')
  return torch.from_numpy(x.copy()).permute(2,0,1).contiguous()
 actions=action_tensors(sample['actions'],stats)['actions'][0,:8,:7].contiguous()
 return dict(primary_videos=torch.stack([frame(sample['primary']),frame(sample['future'])])[None],
             wrist_images=frame(sample['wrist'])[None],lang=sample['lang'],state=torch.zeros(1,32),
             action=actions,embodiment_id=25,action_hz=20.)
def make_collator(policy,*,training=True):
 from starVLA.dataloader.latent_world_train_collator import LatentWorldTrainCollator
 from starVLA.model.framework.latent_world.processor_utils import build_latent_world_processor_spec
 cfg=policy.policy_backend.model_cfg
 spec=build_latent_world_processor_spec(policy_cfg=cfg,vlm_model_id=str(ROOT/'assets/qwen3-vl-2b'))
 result=LatentWorldTrainCollator(policy_cfg=cfg,processor_spec=spec,
         act_queries=int(cfg.num_action_queries),flow_queries=int(cfg.flow_action_num_queries),
         enable_primary_video_aug=False,enable_primary_random_resized_crop=False)
 return result.train() if training else result.eval()


def auxiliary_parameters(policy, *, trainable_only=True):
 excluded={id(p) for module in (policy.policy_backend.vlm,
           policy.policy_backend.lam.decoder,policy.policy_backend.flow)
           for p in module.parameters()}
 return {name:parameter for name,parameter in policy.named_parameters()
         if id(parameter) not in excluded and
         (not trainable_only or parameter.requires_grad)}


def auxiliary_state(policy):
 return {name:cpu_tree(parameter) for name,parameter in auxiliary_parameters(policy).items()}


def restore_auxiliary_state(policy,state):
 expected=auxiliary_parameters(policy,trainable_only=False)
 if not state or not set(state)<=set(expected):
  raise ValueError('Native auxiliary checkpoint has invalid parameter names')
 with torch.no_grad():
  for name,value in state.items():
   parameter=expected[name]
   if parameter.shape!=value.shape or parameter.dtype!=value.dtype:
    raise ValueError('Native auxiliary checkpoint shape/dtype mismatch: '+name)
   parameter.copy_(value.to(parameter.device))
