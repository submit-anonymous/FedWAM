"""Four persistent Slurm workers share a durable dependency queue, with stable leases."""
import json,fcntl,hashlib
from pathlib import Path
from collections import Counter
from .round_runtime import atomic_json
class WorkQueue:
 def __init__(self,root,tasks):
  self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True);self.tasks={t['id']:t for t in tasks}
  if len(self.tasks)!=len(tasks):raise ValueError('Duplicate task')
  if any(not set(t['depends'])<=set(self.tasks) for t in tasks):raise ValueError('Unknown dependency')
  self.hash=hashlib.sha256(json.dumps(tasks,sort_keys=True).encode()).hexdigest()
  with self._lock():
   if self.path.exists():self._load()
   else:atomic_json(self.path,{'identity':self.hash,'tasks':{k:{'state':'pending'} for k in self.tasks}})
 @property
 def path(self):return self.root/'queue.json'
 def _lock(self):
  class Lock:
   def __enter__(inner):inner.f=(self.root/'queue.lock').open('a');fcntl.flock(inner.f,fcntl.LOCK_EX);return inner
   def __exit__(inner,*args):inner.f.close()
  return Lock()
 def _load(self):
  data=json.loads(self.path.read_text())
  if data['identity']!=self.hash:raise ValueError('Queue plan changed')
  return data
 def claim(self,owner,prefer='train'):
  with self._lock():
   data=self._load();states=data['tasks']
   for key,s in states.items():
    if s.get('owner')==owner and s['state']=='running':return self.tasks[key]
   for key,s in states.items():
    if s['state']=='pending' and any(states[d]['state'] in ('failed','blocked') for d in self.tasks[key]['depends']):s['state']='blocked'
   ready=[key for key,s in states.items() if s['state']=='pending' and all(states[d]['state']=='completed' for d in self.tasks[key]['depends'])]
   ready.sort(key=lambda k:(self.tasks[k]['kind']!=prefer,list(self.tasks).index(k)))
   result=None
   if ready:
    key=ready[0];states[key].update(state='running',owner=owner);result=self.tasks[key]
   atomic_json(self.path,data);return result
 def finish(self,owner,key,returncode):
  with self._lock():
   data=self._load();s=data['tasks'][key]
   if s.get('owner')!=owner or s['state']!='running':raise ValueError('Task lease not owned')
   s.update(state='completed' if returncode==0 else 'failed',returncode=returncode);atomic_json(self.path,data)
 def retry(self,key):
  with self._lock():
   data=self._load()
   if key not in data['tasks'] or data['tasks'][key]['state']!='failed':raise ValueError('Only a failed task can be retried')
   old=data['tasks'][key];data['tasks'][key]={'state':'pending','previous_failure':old,'retry_count':old.get('retry_count',0)+1}
   for row in data['tasks'].values():
    if row['state']=='blocked':row['state']='pending'
   atomic_json(self.path,data)
 def summary(self):
  with self._lock():return dict(Counter(v['state'] for v in self._load()['tasks'].values()))
 def finished(self):return not any(k in self.summary() for k in ('pending','running'))
