"""Local joint world/action training with deployed intent and explicit feedback control."""
from contextlib import nullcontext
import numpy as np
import torch
import torch.nn.functional as F

def amp(device):return torch.autocast('cuda',dtype=torch.bfloat16) if torch.device(device).type=='cuda' else nullcontext()
def control_condition(pred,*,detach=False):return pred.detach() if detach else pred

def action_tensors(actions,stats,device='cpu',horizon=50):
    a=np.asarray(actions,dtype=np.float32)
    lo=np.asarray(stats.get('min',stats.get('q01')),dtype=np.float32)
    hi=np.asarray(stats.get('max',stats.get('q99')),dtype=np.float32)
    if a.shape!=(8,7) or not np.isfinite(a).all():raise ValueError('Expected finite [8,7] physical actions')
    if lo.shape!=(7,) or hi.shape!=(7,) or stats.get('mask')!=[True]*6+[False] or np.any(hi[:6]<=lo[:6]):raise ValueError('Invalid official LIBERO normalization semantics')
    norm=a.copy();norm[:,:6]=2*(a[:,:6]-lo[:6])/(hi[:6]-lo[:6])-1;norm[:,-1]=(a[:,-1]>.5)
    padded=torch.zeros(1,horizon,32,device=device);mask=torch.zeros_like(padded,dtype=torch.bool)
    padded[0,:8,:7]=torch.as_tensor(norm,device=device);mask[0,:8,:7]=True
    return {'actions':padded,'actions_mask':mask,'state':torch.zeros(1,32,device=device),'state_mask':torch.zeros(1,32,device=device,dtype=torch.bool)}

def configure(policy,*,world=True,action=True):
    policy.eval()
    for p in policy.parameters():p.requires_grad_(False);p.grad=None
    b=policy.policy_backend
    for module,enabled in [(b.lam.decoder,world),(b.flow,action)]:
        # Keep deterministic dropout behavior equal across methods; gradients remain enabled.
        for p in module.parameters():p.requires_grad_(enabled)
    return b

@torch.no_grad()
def encode(policy,sample,stats):
    from starVLA.model.framework.latent_world.batch_utils import prepare_frame_spatial_uint8,imagenet_normalize_image_batch_
    b=policy.policy_backend;builder=policy.policy_infer_batch_builder
    if sample['future_t']!=sample['t']+8:raise ValueError('Expected chunk-end t+8 observation')
    example={'lang':sample['lang'],'primary_image':[sample['primary']],'wrist_image':[sample['wrist']],'action_hz':20.,'embodiment_id':25}
    prepared=b._prepare_infer_batch(batch=builder.build_infer_batch([example]))
    shared=b._run_shared_encoding_infer(prepared_batch=prepared,source='fedwam_full_encode',lam_features_with_no_grad=True)
    frame=prepare_frame_spatial_uint8(sample['future'],target_hw=builder.infer_image_hw,apply_center_crop_90=builder.enable_primary_random_resized_crop)
    future=frame.to(device=shared.h_t.device,dtype=torch.float32).div(255).unsqueeze(0);imagenet_normalize_image_batch_(future)
    with amp(future.device):target=b.lam.extract_vision_features(future.unsqueeze(1))[:,0]
    result={'h_t':shared.h_t.detach(),'intent':shared.pred_action_emb.detach(),'h_vlm':shared.h_vlm.detach(),
        'future_target':target.detach(),'attention_mask':prepared['attention_mask'].bool(),
        'action_hz':prepared['action_hz'],'embodiment_id':prepared['embodiment_id']}
    result.update(action_tensors(sample['actions'],stats,device=shared.h_t.device,horizon=int(b.model_cfg.action_horizon)))
    # This parity check ensures cached deployed queries reproduce the online branch.
    with amp(future.device):pred=b._decode_future_tokens_strict_single_query(h_t=result['h_t'],pred_action_emb=result['intent'],source='cache_parity')
    if not torch.allclose(pred.float(),shared.h_t1_pred.float(),rtol=1e-4,atol=1e-4):raise RuntimeError('Cached/online world prediction mismatch')
    return result,{'world_max_abs':float((pred.float()-shared.h_t1_pred.float()).abs().max()),'tokens':list(shared.h_t.shape),
        'intent_shape':list(result['intent'].shape),'future_in_query':False}

def losses(policy,batch,*,detach_feedback=False,teacher_target=None,gate=None):
    b=policy.policy_backend
    if bool(b.flow.config.use_state):raise ValueError('Raw state8 requires a separate audited state adapter')
    with amp(batch['h_t'].device):
        pred=b._decode_future_tokens_strict_single_query(h_t=batch['h_t'],pred_action_emb=batch['intent'],source='fedwam_full_local')
    world=F.mse_loss(pred.float(),batch['future_target'].float())
    repeat=int(b.model_cfg.repeated_diffusion_steps)
    def rep(x):return x.repeat(repeat,*([1]*(x.ndim-1)))
    flow=b.flow(h_t=rep(batch['h_t']),h_t1_star=rep(control_condition(pred,detach=detach_feedback)),h_vlm=rep(batch['h_vlm']),
        state=rep(batch['state']),state_mask=rep(batch['state_mask']),actions=rep(batch['actions']),actions_mask=rep(batch['actions_mask']),
        action_hz=rep(batch['action_hz']),embodiment_id=rep(batch['embodiment_id']),attention_mask=rep(batch['attention_mask']))
    kd=world.new_zeros(())
    if teacher_target is not None:
        if teacher_target.requires_grad or teacher_target.shape!=pred.shape:raise ValueError('Teacher must be frozen and spatially aligned')
        per=(pred.float()-teacher_target.float()).square().mean(dim=(-2,-1))
        kd=(per*gate.detach()).mean() if gate is not None else per.mean()
    return dict(total=flow+.1*world+kd,action=flow,world=world,fed=kd,prediction=pred)
