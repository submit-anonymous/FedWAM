"""Checkpoint retention for native LaWAM's large private VLM state."""
import shutil

from .detached_engine import DetachedEngine


class NativeDetachedEngine(DetachedEngine):
    def phase(self, state, round, phase, steps, context):
        if phase == 'action' and steps == 0:
            return state, self.phases.ref(f'r{round:04d}/{self.client}/post')
        return super().phase(state, round, phase, steps, context)

    def _prune_client_phases(self, round, client):
        if not self.cfg.get('prune', True):
            return
        phases = self.store.path('phases')
        if not phases.exists():
            return
        current = f'r{round:04d}'
        for directory in phases.iterdir():
            if not directory.is_dir() or not directory.name.startswith('r'):
                continue
            target = directory / client
            if directory.name < current and target.exists():
                shutil.rmtree(target)
        current_dir = self.store.path(f'phases/{current}/{client}')
        for name in ('pre.pt', 'pre.json', 'action.pt', 'action.json'):
            (current_dir / name).unlink(missing_ok=True)

    def prune_private(self, round):
        self._prune_client_phases(round, self.client)

    def prune_shared(self, round):
        for client in self.clients:
            self._prune_client_phases(round, client)
        super().prune_shared(round)
