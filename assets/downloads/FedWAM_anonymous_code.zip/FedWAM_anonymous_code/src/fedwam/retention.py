"""Compact only verified complete runs; retain deployed weights and public teacher."""
import json
from .round_runtime import RoundStore, atomic_json
from .federated_reporting import load_final_checkpoint


def compact_completed_run(root, identity):
    store = RoundStore(root, identity)
    verification = json.loads(store.path('verification.json').read_text())
    if verification.get('passed') is not True or verification.get('identity') != identity:
        raise ValueError('Cannot prune an unverified training run')
    final = json.loads(store.path('final.json').read_text())
    if final.get('identity') != identity:
        raise ValueError('Final identity changed')
    if final.get('retention') != 'verified-final-weights.v1':
        refs = {}
        for client, ref in final['clients'].items():
            checkpoint = load_final_checkpoint(store.root, final, client)
            # Learning is finished; evaluation needs exactly the deployed weights.
            # Training diagnostics, exposure and RNG remain available for auditing.
            checkpoint['state']['world_optimizer'] = None
            checkpoint['state']['action_optimizer'] = None
            checkpoint['state'].pop('self_teacher_world', None)
            checkpoint['inference_only'] = True
            refs[client] = store.write(f'checkpoints/final/{client}.pt', checkpoint)
        latest = store.latest()
        server_ref = latest.get('server') if latest else None
        if server_ref:
            server = store.read_ref(server_ref)
            def public(teacher):
                return {k: teacher[k] for k in ('schema', 'config', 'model', 'support', 'interface_version', 'metrics') if k in teacher}
            if server['kind'] == 'teacher':
                server['teacher'] = public(server['teacher'])
            elif server['kind'] == 'self_teachers':
                server['teachers'] = {c: public(t) for c, t in server['teachers'].items()}
            final['server'] = store.write('checkpoints/final/server.pt', server)
        final['clients'] = refs
        final['retention'] = 'verified-final-weights.v1'
        atomic_json(store.path('final.json'), final)
    # Publication happens before removal, so interrupted cleanup is idempotent.
    for client in final['clients']:
        load_final_checkpoint(store.root, final, client)
    if final.get('server'):
        store.read_ref(final['server'])
    removed_bytes = 0
    for prefix in ('phases', 'server', 'public'):
        for path in store.path(prefix).rglob('*.pt'):
            if not path.resolve().is_relative_to(store.root):
                raise ValueError('Refusing cleanup outside run')
            removed_bytes += path.stat().st_size
            path.unlink()
    atomic_json(store.path('retention.json'), {
        'state': 'completed', 'policy': 'verified-final-weights.v1',
        'removed_bytes_this_attempt': removed_bytes,
        'preserved': ['final private world/action weights', 'final public server model',
                      'phase/round receipts', 'sample exposure', 'metrics', 'communication events'],
        'removed': ['completed intermediate weights/optimizers', 'server replay/progress', 'past prediction payloads'],
        'resume': 'completed training skips execution after identity verification; interrupted active runs retain full optimizer/RNG checkpoints'})
    atomic_json(store.path('status.json'), {'state': 'completed', 'phase': 'all_rounds_committed',
                                          'rounds': final.get('rounds'), 'clients': list(final['clients'])})
    return final
