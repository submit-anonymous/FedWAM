"""Integrity and leakage boundaries shared by acquisition and training."""
import hashlib
from pathlib import Path
import zlib

def checked_range(stream, header, offset, size, total):
    if header != f'bytes {offset}-{offset+size-1}/{total}':
        raise ValueError('Content-Range does not match request')
    data=stream.read(size+1)
    if len(data)!=size:raise ValueError('Truncated or oversized range response')
    return data

def source_category(bucket):
    mapping={'light':'lighting','noise':'sensor_noise','camera_view':'camera_pose','language':'language','env':None}
    if bucket not in mapping:raise ValueError(f'Unknown raw source bucket: {bucket}')
    return mapping[bucket]

def assert_group_disjoint(rows):
    roles={}
    for row in rows:
        key=row['source_group'];role=row['split']
        if key in roles and roles[key]!=role:raise ValueError(f'Source group crosses roles: {key}')
        roles[key]=role

def valid_times(length,horizon=8):
    return range(max(0,length-horizon))

def verify_file(path,size,crc):
    path=Path(path)
    if path.stat().st_size!=size:raise ValueError(f'Shard size mismatch: {path}')
    h=hashlib.sha256();observed=0
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024**2),b''):
            h.update(block);observed=zlib.crc32(block,observed)
    if observed!=crc:raise ValueError(f'Shard CRC mismatch: {path}')
    return {'bytes':size,'crc32':observed,'sha256':h.hexdigest()}

def cached_shard(directory,name):
    import re
    match=re.fullmatch(r'libero_mix-train\.tfrecord-(\d{5})-of-01024',name)
    if not match:raise ValueError('Invalid official shard name')
    for candidate in (Path(directory)/name,Path(directory)/(match[1]+'.tfrecord')):
        if candidate.is_file():return candidate
    return None

def publish_shard(raw,data,size,crc):
    import tempfile
    raw=Path(raw)
    # Keep the complete official basename and a unique worker suffix. with_suffix
    # would erase every shard identifier after the shared "libero_mix-train" stem.
    with tempfile.NamedTemporaryFile(dir=raw.parent,prefix=raw.name+'.',suffix='.partial',delete=False) as f:
        temp=Path(f.name)
        try:
            f.write(data);f.flush()
        except BaseException:
            temp.unlink(missing_ok=True)
            raise
    try:
        check=verify_file(temp,size,crc)
        temp.replace(raw)
        return check
    finally:
        temp.unlink(missing_ok=True)
