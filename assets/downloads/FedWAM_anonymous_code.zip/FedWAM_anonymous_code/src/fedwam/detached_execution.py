"""Identity and gates for independently scheduled client jobs."""
from .io import ROOT,load,file_hash
from .experiment_config import identity,formal_gate,METHODS
from .parallel_execution import parallel_identity

FILES=('src/fedwam/detached_engine.py','src/fedwam/detached_execution.py',
 'scripts/train_detached.py','scripts/detached_campaign.py',
 'scripts/detached_client.slurm','scripts/detached_pipeline.slurm','scripts/detached_eval.slurm')
def detached_code():return {p:file_hash(ROOT/p) for p in FILES}
def detached_identity(cfg):
 value=parallel_identity(cfg);value['code'].update(detached_code())
 value['execution']={'kind':'independent-slurm-client-jobs.v1','seed_offset_by_rank':False,'wait_holds_gpu':False}
 return value
def check_gate(cfg,receipt):
 formal_gate(identity(cfg),load(ROOT/'reports/federation_engineering/summary.json'))
 expected=detached_identity(cfg)
 if receipt.get('passed') is not True or receipt.get('mode')!='real_detached_client_engineering':raise ValueError('Detached engineering gate not passed')
 for key in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','execution'):
  if receipt.get(key)!=expected[key]:raise ValueError('Stale independent-client gate: '+key)
 if receipt.get('seed')!=43 or cfg['seed']!=43:raise ValueError('Only seed43 admitted')
 if set(receipt.get('methods_passed',[]))!=set(METHODS):raise ValueError('Incomplete method acceptance')
