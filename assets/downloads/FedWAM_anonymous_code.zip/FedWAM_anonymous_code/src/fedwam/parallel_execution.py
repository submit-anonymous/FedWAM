"""Additional execution provenance; the already-validated scientific backend is frozen."""
import copy
from .io import ROOT,load,file_hash
from .experiment_config import identity,formal_gate,METHODS

FILES=('src/fedwam/parallel_engine.py','src/fedwam/parallel_execution.py',
       'scripts/train_parallel.py','scripts/parallel_engineering.py','scripts/parallel_campaign.py',
       'scripts/parallel_engineering.slurm','scripts/parallel_campaign.slurm','scripts/parallel_eval.slurm',
       'scripts/report_seed43.py','scripts/finalize_seed43.py','scripts/parallel_finalize.slurm',
       'scripts/prepare_parallel_seed43.py','scripts/submit_parallel_seed43.py')
def execution_code():return {p:file_hash(ROOT/p) for p in FILES}
def parallel_identity(config):
 value=identity(config);value['code'].update(execution_code())
 value['execution']={'kind':'one-process-per-client.v1','independent_methods':['M1','M7','Local-adapter','M9'],'seed_offset_by_rank':False}
 return value
def check_gate(config,receipt):
 formal_gate(identity(config),load(ROOT/'reports/federation_engineering/summary.json'))
 expected=parallel_identity(config)
 if receipt.get('passed') is not True or receipt.get('mode')!='real_parallel_client_engineering':raise ValueError('Parallel engineering gate not passed')
 for key in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','execution'):
  if receipt.get(key)!=expected[key]:raise ValueError('Stale parallel receipt: '+key)
 if receipt.get('seed')!=43 or config['seed']!=43:raise ValueError('Only seed43 is admitted')
 if set(receipt.get('methods_passed',[]))!=set(METHODS):raise ValueError('Incomplete parallel method acceptance')

def claim_filtered(queue,owner,kinds,method=None):
 with queue._lock():
  data=queue._load();states=data['tasks']
  for key,s in states.items():
   if s.get('owner')==owner and s['state']=='running':return queue.tasks[key]
  for key,s in states.items():
   if s['state']=='pending' and any(states[d]['state'] in ('failed','blocked') for d in queue.tasks[key]['depends']):s['state']='blocked'
  result=None
  for key,s in states.items():
   task=queue.tasks[key]
   if s['state']!='pending' or task['kind'] not in kinds or (method and task.get('method')!=method):continue
   if all(states[d]['state']=='completed' for d in task['depends']):
    s.update(state='running',owner=owner);result=task;break
  from .round_runtime import atomic_json
  atomic_json(queue.path,data);return result

def remaining(queue,kinds,method=None):
 with queue._lock():
  states=queue._load()['tasks']
  return any(v['state'] in ('pending','running') and queue.tasks[k]['kind'] in kinds and (not method or queue.tasks[k].get('method')==method) for k,v in states.items())
