"""Frozen effective configurations and engineering-gated formal admission."""
import copy
from pathlib import Path
from .io import ROOT,load,file_hash,digest
METHODS=('M1','M2','M3','M4','M5','M6','M7','M8','M9','Local-adapter')
CODE_FILES=('src/fedwam/training.py','src/fedwam/official_dataset.py','src/fedwam/official_data.py',
 'src/fedwam/parameter_methods.py','src/fedwam/packets.py','src/fedwam/server_teacher.py','src/fedwam/reception.py',
 'src/fedwam/function_controls.py','src/fedwam/round_runtime.py','src/fedwam/federation_engine.py','src/fedwam/lawam_federation.py',
 'src/fedwam/experiment_config.py','src/fedwam/retention.py','src/fedwam/work_queue.py','scripts/federated_worker.py','scripts/plan_federated.py','scripts/train_federated.py','scripts/federation_engineering.py',
 'scripts/evaluate_federated.py','scripts/report_federated.py','scripts/acceptance.py','scripts/model_probe.py','scripts/common.env','src/fedwam/evaluation.py','src/fedwam/federated_reporting.py','scripts/submit_federated.py','scripts/federated_finalize.py','scripts/federation_engineering.slurm','scripts/federated_worker.slurm','scripts/federated_finalize.slurm','scripts/restore_baseline_slots.slurm')
def code_identity():return {p:file_hash(ROOT/p) for p in CODE_FILES}
def resolved_config(method,seed,mode,overrides=None):
 if method not in METHODS or seed not in (42,43,44) or mode not in ('formal','engineering'):raise ValueError('Unknown method/seed/mode')
 cfg=copy.deepcopy(load(ROOT/'configs/protocol.json'));cfg.update(method=method,seed=seed,mode=mode,adapter_rank=8,branches=1,
  action_feedback=True,reception_gate=True,representation='transition',checkpoint_every=50,server_checkpoint_every=50,prune=True)
 # Explicit algorithm switches, not an implicit smaller training budget.
 cfg['experiment_overrides']=copy.deepcopy(overrides or {})
 if overrides:
  allowed={'adapter_rank','branches','action_feedback','reception_gate','representation','packet_budget_bytes','final_action_adaptation'}
  if set(overrides)-allowed:raise ValueError('Unsupported experiment override')
  for k,v in overrides.items():
   if k=='packet_budget_bytes':cfg['server'][k]=v
   elif k=='final_action_adaptation':
    if not v:cfg['training']['final_world_action_only']=0
   else:cfg[k]=v
 if cfg['branches'] not in (1,2,4) or not 1<=cfg['adapter_rank']<=32 or cfg['representation'] not in ('future','transition'):
  raise ValueError('Invalid architecture/representation setting')
 if cfg['server']['packet_budget_bytes']<1024*1024:raise ValueError('Packet budget too small')
 if mode=='engineering':
  cfg['training'].update(warmup=1,rounds=2,pre_receive_joint=1,post_receive_joint=1,final_world_action_only=1,effective_batch=2)
  cfg['server'].update(steps_per_round=4,batch=2,max_queries=8,packet_budget_bytes=16*1024**2)
  cfg.update(checkpoint_every=1,server_checkpoint_every=1)
 return cfg

def identity(config):
 accepted=load(ROOT/'manifests/official_four_clients/acceptance.json')
 return {'schema':'fedwam.run.v1','method':config['method'],'seed':config['seed'],'config':config,
  'data_identity':accepted['identity'],'data_acceptance_sha256':file_hash(ROOT/'manifests/official_four_clients/acceptance.json'),
  'checkpoint_sha256':file_hash(ROOT/'runtime/lawam_libero_sft/final_model/pytorch_model.pt'),
  'normalization_sha256':file_hash(ROOT/'runtime/lawam_libero_sft/dataset_statistics.json'),
  'protocol_sha256':file_hash(ROOT/'configs/protocol.json'),
  'model_config_sha256':file_hash(ROOT/'runtime/lawam_libero_sft/config.yaml'),
  'code':code_identity(),'mode':config['mode']}

def formal_gate(run_identity,receipt):
 if not receipt.get('passed') or receipt.get('mode')!='real_model_two_round_engineering':raise ValueError('Real multi-round engineering gate not passed')
 for key in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256'):
  if receipt.get(key)!=run_identity[key]:raise ValueError(f'Stale engineering receipt: {key}')
 if receipt.get('experiment_overrides',{})!=run_identity['config'].get('experiment_overrides',{}):raise ValueError('Experiment overrides require their own real engineering receipt')
 if set(receipt.get('methods_passed',[]))!=set(METHODS):raise ValueError('Incomplete method engineering coverage')
