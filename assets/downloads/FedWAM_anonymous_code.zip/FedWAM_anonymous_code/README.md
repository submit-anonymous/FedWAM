# FedWAM — Anonymous Supplementary Code

This package accompanies **FedWAM: Federating Predictive World Knowledge for
Personalized Robot Control**. It provides the research implementation,
experiment configurations, source-group split references, algorithmic tests,
and recorded data for reproducing the qualitative figures.

## Contents

- **Federated learning:** conditional prediction packets, server teacher fitting,
  calibrated knowledge reception, and personalized local control.
- **LaWAM experiments:** native local objectives, world-parameter baselines,
  per-client execution, round synchronization, evaluation, and reporting.
- **Model heterogeneity:** common-space interfaces, LaWAM and ImageWAM adapters,
  readouts, packet I/O, and teacher components.
- **Qualitative reproduction:** five figure layouts with their recorded feature
  tensors, observations, and decoded predictions.
- **Verification:** algorithmic tests, numerical consistency checks, software
  versions, and file checksums.

The companion video package illustrates task execution and predictive
representations using the released LaWAM LIBERO-SFT and ImageWAM
FLUX.2-4B-LIBERO checkpoints. It includes complete task recordings, synchronized
latent visualizations, and six endpoint-image comparisons.

## Quick start

From the extracted directory:

```bash
python3 -m venv .review-venv
.review-venv/bin/python -m pip install -r requirements-review.txt
.review-venv/bin/python scripts/run_review_checks.py
.review-venv/bin/python scripts/verify_recorded_predictions.py
.review-venv/bin/python paper/scripts/render_native_predictions.py
```

After dependency installation, these CPU checks and figure-generation commands
run offline using the included records. Outputs appear in
`paper/figures/native_predictions/`; their descriptions are in `paper/captions/`.

The default test configuration has **94 passing tests and 2 optional upstream
integration tests skipped**. With the complete pinned LaWAM source and its
requirements installed, enable the integration tests using:

```bash
.review-venv/bin/python scripts/run_review_checks.py --with-upstream
```

## Code map

| Component | Files |
|---|---|
| Packet contracts and common teacher | `src/fedwam/packets.py`, `server_teacher.py` |
| Calibrated reception and controls | `src/fedwam/reception.py`, `function_controls.py` |
| World parameter/adapter baselines | `src/fedwam/parameter_methods.py` |
| Native LaWAM objectives and optimizer schedule | `src/fedwam/native_local.py`, `native_federation.py` |
| Per-client execution and round synchronization | `src/fedwam/native_engine.py`, `native_execution.py`, `round_runtime.py` |
| Source grouping and official data | `src/fedwam/official_data.py`, `official_dataset.py`, `data_contracts.py` |
| Evaluation and reporting | `scripts/evaluate_native_federated.py`, `src/fedwam/federated_reporting.py` |
| Heterogeneous query/readout/teacher | `src/fedwam/heterogeneous/` |
| Seed-42 campaign | `scripts/native_campaign.py` |
| Native video/feature capture | `scripts/lawam_paper_subgoals.py`, `imagewam_paper_future_rgb.py`, `imagewam_paper_rollout.py` |
| Figure rendering | `paper/scripts/render_native_predictions.py`, `scripts/subgoal_visual_math.py` |

## Experiment setup

The seed-42 native configuration is resolved by `native_config`, combining
`configs/protocol.json` with `configs/native_fedwam_protocol_v2.json`.
The latter specifies the native training schedule and optimization settings.
Use `scripts/native_campaign.py` for the seed-42 campaign; additional utilities
support other recorded configurations.

For GPU training and model inference, follow `docs/REPRODUCIBILITY.md` and
`docs/ASSETS.md`: obtain the pinned upstream sources and external assets,
configure separate model environments and local simulator paths, then generate
local data and model validation records. Adapt the Slurm templates to the
available cluster resources. The directly executable CPU workflow above covers
algorithmic verification and regeneration of the recorded visualizations.

## Assets and provenance

`third_party/upstreams.json` records exact upstream source revisions. The
package includes the LaWAM recipe used by CPU configuration tests and the
ImageWAM dependency patch. Install the complete upstream repositories for GPU
execution. Obtain checkpoints and datasets from their official distributions
under the applicable terms; asset locations are listed in `docs/ASSETS.md`.

`reference_manifests/` provides anonymized source-group split metadata. Regenerate
operational manifests and validation records for local paths and use the
references to check the resulting assignments. `environment/` records package
and Python versions for the model and visualization environments.

## Verification and attribution

`validation/` contains the recorded verification results, and `SHA256SUMS`
covers the distributed files. The recorded qualitative data includes all ten
LaWAM prediction chunks and all six ImageWAM prediction queries.

This material is supplied for anonymous scholarly review. Third-party attribution
and applicable upstream licenses are retained in `third_party/`.
