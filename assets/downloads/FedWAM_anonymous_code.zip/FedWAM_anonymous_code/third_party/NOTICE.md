# Upstream software

Upstream authorship is retained. The URLs identify third-party baselines, not
the submitting authors. Exact source commits are in upstreams.json. Full
upstream repositories, checkpoints, datasets, and native shared libraries are
not redistributed. Their original terms apply. The LaWAM training YAML is an
attributed configuration reference from the pinned LaWAM source. ImageWAM's
dependency-only local patch and upstream license are included.
