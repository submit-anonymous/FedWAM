# Anonymous Artifact Preparation

The package uses anonymous authorship and generic `/workspace/` path examples.
The project root is resolved from the source location. Configure local paths and
scheduler settings when preparing GPU experiments.

The distributed files contain research code, configurations, source-group
references, qualitative records, and verification reports. Authentication data,
Git history, and machine-account details are kept outside the package. Upstream
software attribution is retained.

Reference manifests preserve source-group assignments for comparison. Generate
operational manifests and validation records for the local installation.
