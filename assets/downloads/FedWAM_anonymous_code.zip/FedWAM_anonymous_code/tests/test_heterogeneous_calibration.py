import unittest
from fedwam.heterogeneous.calibration import calibrate_reception


def rows():
    return [dict(query_id=f'q{i}',task=t,source_group=f'g{i}',split='calibration',local_mse=2.,teacher_mse=1.)
            for i,t in enumerate(['a','a','b','b'])]


class CalibrationTest(unittest.TestCase):
    def test_task_source_balance_and_rejection(self):
        data=rows();data[0]['local_mse']=6.
        result=calibrate_reception(data,expected_tasks=['a','b'],min_sources_per_task=2)
        self.assertEqual(result['local_mse'],3.)
        self.assertAlmostEqual(result['gate'],2/3)
        data.extend([dict(data[0],query_id='extra'+str(i)) for i in range(9)])
        self.assertEqual(calibrate_reception(data,expected_tasks=['a','b'],min_sources_per_task=2),result)
        for row in data:row['teacher_mse']=10.
        self.assertEqual(calibrate_reception(data,expected_tasks=['a','b'],min_sources_per_task=2)['gate'],0.)

    def test_inadequate_coverage_closes_gate(self):
        result=calibrate_reception(rows()[:2],expected_tasks=['a','b'],min_sources_per_task=2)
        self.assertFalse(result['adequate']);self.assertEqual(result['gate'],0.)
        result=calibrate_reception(rows(),expected_tasks=['a','b'],min_sources_per_task=3)
        self.assertFalse(result['adequate']);self.assertEqual(result['gate'],0.)

    def test_rejects_other_splits_duplicate_queries_and_nonfinite(self):
        for change in ({'split':'prediction_test'},{'teacher_mse':float('nan')},{'local_mse':-1.}):
            data=rows();data[0].update(change)
            with self.assertRaises(ValueError):calibrate_reception(data,expected_tasks=['a','b'])
        data=rows();data[1]['query_id']=data[0]['query_id']
        with self.assertRaises(ValueError):calibrate_reception(data,expected_tasks=['a','b'])
