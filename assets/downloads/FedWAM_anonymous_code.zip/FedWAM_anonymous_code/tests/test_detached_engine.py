import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import torch
from fedwam.detached_engine import DetachedEngine, DependencyPending
from fedwam.federation_engine import FederationEngine
from fedwam.round_runtime import atomic_json
from test_parallel_engine import make_backend,STATS
from test_lawam_federation_integration import configuration,CLIENTS,FixtureData,encoded

class DetachedTests(unittest.TestCase):
 def setUp(self):
  for target,value in [('torch.cuda.is_available',False)]:
   p=patch(target,return_value=value);p.start();self.addCleanup(p.stop)
  for target,value in [('OfficialDataset',FixtureData),('encode',encoded)]:
   p=patch('fedwam.lawam_federation.'+target,value);p.start();self.addCleanup(p.stop)
  p=patch('fedwam.lawam_federation.load',return_value=STATS);p.start();self.addCleanup(p.stop)
 def equal_tree(self,x,y):
  import numpy as np
  if isinstance(x,torch.Tensor):torch.testing.assert_close(x,y,rtol=0,atol=0)
  elif isinstance(x,np.ndarray):np.testing.assert_array_equal(x,y)
  elif isinstance(x,dict):
   self.assertEqual(set(x),set(y))
   for k in x:self.equal_tree(x[k],y[k])
  elif isinstance(x,(list,tuple)):
   self.assertEqual(len(x),len(y))
   for a,b in zip(x,y):self.equal_tree(a,b)
  else:self.assertEqual(x,y)
 def execute(self,root,cfg,attempt='a',fail=None):
  ident={'method':cfg['method'],'seed':42,'mode':'engineering'}
  clients=['pooled'] if cfg['method']=='M9' else CLIENTS
  done=set()
  for sweep in range(100):
   for client in list(reversed(clients)):
    if client in done:continue
    def hook(stage):
     if stage==fail:raise RuntimeError('forced interruption')
    engine=DetachedEngine(root,ident,cfg,make_backend(root,cfg),client,attempt,fault_hook=hook)
    try:ref=engine.run_client()
    except DependencyPending:continue
    atomic_json(engine.store.path(f'client_verification/{client}.json'),dict(passed=True,identity=ident,attempt=attempt,ref=ref))
    done.add(client)
   if len(done)==len(clients):
    engine=DetachedEngine(root,ident,cfg,None,clients[0],attempt)
    return engine,engine.finalize()
  self.fail('independent jobs failed to progress')
 def test_all_methods_match_serial_even_when_only_one_job_runs_at_a_time(self):
  for method in ['M1','M2','M3','M4','M5','M6','M7','M8','M9','Local-adapter']:
   with self.subTest(method=method),tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
    cfg=configuration(method);ident={'method':method,'seed':42,'mode':'engineering'}
    original=FederationEngine(a,ident,cfg,make_backend(a,cfg));left=original.run()
    engine,right=self.execute(b,cfg)
    for c in left['clients']:
     x=original.store.read_ref(left['clients'][c])['state'];y=engine.store.read_ref(right['clients'][c])['state']
     for k in ('world','action','world_optimizer','action_optimizer','rng','draw','exposure'):self.equal_tree(x[k],y[k])
 def test_noncoordinator_can_train_first_and_yields_gpu_at_dependency(self):
  with tempfile.TemporaryDirectory() as root:
   cfg=configuration('M2');engine=DetachedEngine(root,{'method':'M2'},cfg,make_backend(root,cfg),'background','a')
   with self.assertRaises(DependencyPending) as result:engine.run_client()
   self.assertIn('broadcasts/',result.exception.name)
   self.assertTrue((Path(root)/'public/r0000/background.json').exists())
   self.assertFalse((Path(root)/'attempts/a/errors/background.json').exists())
 def test_post_server_restart_and_pruning(self):
  cfg=configuration('M6');cfg['training']['rounds']=5
  with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
   left,lf=self.execute(a,cfg)
   with self.assertRaisesRegex(RuntimeError,'forced interruption'):self.execute(b,cfg,fail='round0:server_published')
   right,rf=self.execute(b,cfg,attempt='retry')
   for c in CLIENTS:
    x=left.store.read_ref(lf['clients'][c])['state'];y=right.store.read_ref(rf['clients'][c])['state']
    for k in ('world','action','world_optimizer','action_optimizer','rng','draw','exposure'):self.equal_tree(x[k],y[k])
