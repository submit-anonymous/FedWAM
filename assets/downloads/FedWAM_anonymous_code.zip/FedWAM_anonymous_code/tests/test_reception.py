import unittest
import torch
from fedwam import reception
from test_packets import record


class ReceptionTests(unittest.TestCase):
    def test_trajectory_count_not_frame_count_controls_acceptance(self):
        one=dict(task='a',source_group='same',local_error=2.,teacher_error=1.)
        self.assertEqual(reception.calibrate_reception([one]*100)['beta_by_task']['a'],0.)
        samples=[dict(one,source_group=f'g{i}') for i in range(5)]
        result=reception.calibrate_reception(samples)
        self.assertAlmostEqual(result['beta_by_task']['a'],.48)
        samples[0]['teacher_error']=100
        self.assertEqual(reception.calibrate_reception(samples)['beta_by_task']['a'],0.)

    def test_group_means_prevent_long_trajectory_domination_and_coarse_fallback(self):
        samples=[dict(task='a',source_group=f'g{i}',local_error=2.,teacher_error=1.) for i in range(5)]
        samples += [dict(samples[0]) for _ in range(100)]
        samples += [dict(task='b',source_group='g0',local_error=2.,teacher_error=1.)]
        result=reception.calibrate_reception(samples)
        self.assertAlmostEqual(result['beta_by_task']['a'],.48)
        self.assertAlmostEqual(result['beta_by_task']['b'],.48)
        self.assertEqual(result['counts']['a'],5)

    def test_support_uses_only_query_and_requires_frozen_calibration(self):
        records=[]
        for i in range(8):
            r=record(str(i),str(i));r['z']+=i/8;records.append(r)
        support=reception.build_support(records)
        z=torch.stack([r['z'] for r in records]);intent=torch.stack([r['intent'] for r in records])
        self.assertFalse(reception.support_mask(support,z,intent).any())
        support=reception.calibrate_support(support,z+.01,intent)
        self.assertTrue(reception.support_mask(support,z,intent).all())
        self.assertFalse(reception.support_mask(support,z+100,intent).any())
        changed=[dict(r,prediction=r['prediction']*100) for r in records]
        torch.testing.assert_close(support['references'],reception.build_support(changed)['references'])

    def test_ambiguity_rejects_unvalidated_branches_and_never_averages(self):
        samples=[dict(task='a',source_group=f'g{i}',local_error=2.,teacher_error=1.) for i in range(5)]
        calibration=reception.calibrate_reception(samples)
        z=torch.zeros(1,3,4);intent=torch.zeros(1,1,32)
        support=reception.calibrate_support(reception.build_support([record()]),z,intent)
        args=(calibration,['a'],z,intent,support)
        self.assertAlmostEqual(reception.reception_weights(*args).item(),.48,places=6)
        self.assertEqual(reception.reception_weights(*args,logits=torch.tensor([[10.,0.]])).item(),0.)
        for s in samples:s['selected_branch_correct']=True
        calibration=reception.calibrate_reception(samples)
        args=(calibration,['a'],z,intent,support)
        self.assertGreater(reception.reception_weights(*args,logits=torch.tensor([[10.,0.]])).item(),0.)
        self.assertEqual(reception.reception_weights(*args,logits=torch.zeros(1,2)).item(),0.)
