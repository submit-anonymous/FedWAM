import tempfile
import unittest
from pathlib import Path

from scripts.train_native_federated import record_resource_retry


class NativeResourceRetryTests(unittest.TestCase):
    def test_unmanaged_gpu_occupancy_is_bounded_and_retryable(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            first = record_resource_retry(root, 'lighting', limit=2)
            self.assertTrue((root/first).exists())
            second = record_resource_retry(root, 'lighting', limit=2)
            self.assertNotEqual(first, second)
            with self.assertRaises(RuntimeError):
                record_resource_retry(root, 'lighting', limit=2)


if __name__ == '__main__':
    unittest.main()
