import unittest
import torch
from fedwam.heterogeneous.interface import FutureReadout, CommonTeacher, reliability, pool_spatial, validate_query


class InterfaceTest(unittest.TestCase):
    def test_readout_keeps_memory_spatial_addresses(self):
        torch.manual_seed(42)
        head = FutureReadout(input_dim=12, output_dim=8, tokens=4, width=16, heads=4)
        h = torch.randn(1, 9, 12)
        self.assertFalse(torch.allclose(head(h), head(h.flip(1)), rtol=1e-5, atol=1e-5))

    def test_frozen_readout_transmits_world_gradient(self):
        torch.manual_seed(42)
        world = torch.nn.Linear(5, 12)
        head = FutureReadout(input_dim=12, output_dim=8, tokens=4, width=16, heads=4)
        head.requires_grad_(False)
        h = world(torch.randn(2, 9, 5))
        loss = head(h).square().mean()
        loss.backward()
        self.assertGreater(world.weight.grad.abs().sum().item(), 0)
        self.assertTrue(all(p.grad is None for p in head.parameters()))

    def test_calibration_detach_updates_head_only(self):
        world = torch.nn.Linear(5, 12)
        head = FutureReadout(input_dim=12, output_dim=8, tokens=4, width=16, heads=4)
        head(world(torch.randn(2, 9, 5)).detach()).square().mean().backward()
        self.assertIsNone(world.weight.grad)
        self.assertTrue(any(p.grad is not None for p in head.parameters()))

    def test_teacher_mask_excludes_missing_state_and_no_private_query(self):
        teacher = CommonTeacher(dim=8, language_dim=6, state_dim=3, tokens=4, width=16, heads=4)
        q = dict(z=torch.randn(2, 4, 8), language=torch.randn(2, 6), state=torch.randn(2, 3),
                 state_mask=torch.zeros(2, 3, dtype=torch.bool), horizon=torch.full((2, 1), 8.))
        before = teacher(q)
        self.assertEqual(tuple(before.shape), (2, 4, 8))
        q['state'].fill_(999)
        torch.testing.assert_close(before, teacher(q))
        with self.assertRaises(ValueError):
            teacher(dict(q, intent=torch.zeros(2, 32)))
        with self.assertRaises(ValueError):
            teacher(dict(q, future=torch.zeros(2, 4, 8)))

    def test_reliability_boundaries_and_nonfinite(self):
        self.assertEqual(reliability(1., 2.), 0.)
        self.assertAlmostEqual(reliability(2., 1.), .5)
        with self.assertRaises(ValueError):
            reliability(float('nan'), 1.)

    def test_pool_preserves_spatial_structure_and_rejects_non_grid(self):
        x = torch.arange(16.).reshape(1, 16, 1)
        torch.testing.assert_close(pool_spatial(x, 2).flatten(), torch.tensor([2.5, 4.5, 10.5, 12.5]))
        with self.assertRaises(ValueError):
            pool_spatial(torch.zeros(1, 15, 1), 2)


if __name__ == '__main__':
    unittest.main()
