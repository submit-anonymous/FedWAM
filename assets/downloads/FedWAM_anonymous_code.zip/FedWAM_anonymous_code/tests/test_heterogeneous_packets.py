import unittest
import torch
from fedwam.heterogeneous.packets import validate_packet, select_senders, balanced_weights, reception_loss
from fedwam.heterogeneous.interface import SCHEMA


def packet(client='a', architecture='lawam', round_id=1, n=2):
    return dict(schema=SCHEMA, round=round_id, client=client, architecture=architecture,
                model_version='digest', representation='future',
                query=dict(z=torch.zeros(n, 4, 8), language=torch.zeros(n, 6),
                           state=torch.zeros(n, 3), state_mask=torch.zeros(n, 3, dtype=torch.bool),
                           horizon=torch.ones(n, 1)*8), prediction=torch.zeros(n, 4, 8),
                source_groups=['g1','g2'][:n], tasks=['t1','t1'][:n], query_ids=['q1','q2'][:n])


class PacketTest(unittest.TestCase):
    def test_packet_rejects_privileged_fields_and_wrong_round(self):
        shapes = dict(tokens=4, dim=8, language_dim=6, state_dim=3)
        validate_packet(packet(), round_id=1, shapes=shapes)
        for item in (dict(packet(), rgb=torch.zeros(1)), dict(packet(), round=2),
                     dict(packet(), prediction=torch.full((2,4,8),float('nan')))):
            with self.assertRaises(ValueError):
                validate_packet(item, round_id=1, shapes=shapes)

    def test_direction_and_self_control_do_not_leak_other_sources(self):
        packets = [packet('a','lawam'), packet('b','imagewam'), packet('c','lawam')]
        self.assertEqual([p['client'] for p in select_senders(packets,'self','a','lawam')], ['a'])
        self.assertEqual([p['client'] for p in select_senders(packets,'same_architecture','a','lawam')], ['a','c'])
        self.assertEqual([p['client'] for p in select_senders(packets,'lawam_to_imagewam','b','imagewam')], ['a','c'])
        self.assertEqual(select_senders(packets,'lawam_to_imagewam','a','lawam'), [])

    def test_balancing_keeps_clients_equal_despite_packet_size(self):
        records=[dict(client='a',task='t',source_group='g')]*4+[dict(client='b',task='t',source_group='h')]
        w=balanced_weights(records)
        self.assertAlmostEqual(w[:4].sum().item(), .5)
        self.assertAlmostEqual(w[4].item(), .5)

    def test_reception_only_backpropagates_to_local_world(self):
        local=torch.randn(2,4,8,requires_grad=True)
        teacher=torch.randn(2,4,8,requires_grad=True)
        reception_loss(local,teacher,.5).backward()
        self.assertIsNotNone(local.grad)
        self.assertIsNone(teacher.grad)


if __name__ == '__main__':
    unittest.main()
