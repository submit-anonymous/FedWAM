import unittest
import torch
from fedwam.heterogeneous.residual_readout import ResidualFutureReadout


class ResidualReadoutTest(unittest.TestCase):
    def test_zero_initialized_change_is_exact_current_copy(self):
        head=ResidualFutureReadout(8,output_dim=4,width=16,heads=4)
        x=torch.randn(2,392,8);z=torch.randn(2,49,4)
        torch.testing.assert_close(head(x,z),z,rtol=0,atol=0)

    def test_trained_frozen_head_passes_world_gradient_without_current_bypass_gradient(self):
        torch.manual_seed(42)
        world=torch.nn.Linear(4,8);head=ResidualFutureReadout(8,output_dim=4,width=16,heads=4)
        x=torch.randn(1,392,4);z=torch.randn(1,49,4,requires_grad=True);truth=torch.randn_like(z)
        optimizer=torch.optim.AdamW(head.parameters(),lr=.01)
        (head(world(x).detach(),z)-truth).square().mean().backward();optimizer.step();optimizer.zero_grad(set_to_none=True)
        self.assertIsNone(z.grad)
        head.requires_grad_(False)
        (head(world(x),z)-truth).square().mean().backward()
        self.assertGreater(world.weight.grad.abs().sum().item(),0)
        self.assertIsNone(z.grad)
        self.assertTrue(all(p.grad is None for p in head.parameters()))

    def test_future_and_delta_objectives_match(self):
        head=ResidualFutureReadout(8,output_dim=4,width=16,heads=4)
        torch.nn.init.normal_(head.output.weight,std=.02)
        x=torch.randn(1,392,8);z=torch.randn(1,49,4);future=torch.randn_like(z)
        a=(head(x,z)-future).square().mean()
        b=(head.delta(x)-(future-z)).square().mean()
        torch.testing.assert_close(a,b)


if __name__=='__main__':unittest.main()
