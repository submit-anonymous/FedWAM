import unittest
import numpy as np
from fedwam.collection import collection_plan, validate_episode, rewritten_instruction

class CollectionContracts(unittest.TestCase):
    def test_all_tasks_clients_and_split_quota(self):
        tasks=[{'suite':'suite','source_file':f'task{i}_demo.hdf5'} for i in range(40)]
        p=collection_plan(tasks)
        self.assertEqual(len(p),40*50*7)
        from collections import Counter
        self.assertEqual(Counter(x['client'] for x in p),dict.fromkeys(['lighting','camera_pose','sensor_noise','background','object_layout','robot_initial','language'],2000))
        bygroup={}
        for row in p:
            self.assertEqual(bygroup.setdefault(row['source_group'],row['split']),row['split'])
        self.assertEqual(Counter(bygroup.values()),dict(train=1400,calibration=200,development=200,prediction_test=200))
    def test_language_preserves_command_and_excludes_published_instruction(self):
        text=rewritten_instruction('put the bowl on the plate',0,set())
        self.assertIn('put the bowl on the plate',text)
        self.assertNotEqual(text,'put the bowl on the plate')
        self.assertNotEqual(rewritten_instruction('put the bowl on the plate',0,{text}),text)
    def test_future_observation_and_uniform_time_are_required(self):
        a=np.zeros((8,7));states=np.zeros((9,20));times=np.arange(9)*.05
        validate_episode(a,states,times,True)
        with self.assertRaises(ValueError):validate_episode(a,states[:-1],times[:-1],True)
        with self.assertRaises(ValueError):validate_episode(a,states,times*2,True)
        with self.assertRaises(ValueError):validate_episode(a,states,times,False)
