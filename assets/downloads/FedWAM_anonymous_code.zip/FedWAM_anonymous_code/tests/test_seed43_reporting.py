"""CPU-only regression coverage for the explicit single-seed study scope."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
sys.path.insert(0, str(ROOT / 'src'))
from fedwam.io import digest, file_hash
from fedwam.federated_reporting import CLIENTS, prediction_summary
import report_seed43 as report
import finalize_seed43 as finalize


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))


class Seed43ReportingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.rows = [dict(variant_id=str(i), suite='suite', base_task='task',
                          name='task', category='lighting') for i in range(2)]
        self.manifest = dict(cases=self.rows, E_seen=['0'], E_confirm=['1'], sha256='manifest')
        self.expected = {client: 3 for client in CLIENTS}

    def run_fixture(self, method='M1', seed=43, completed=()):
        run = self.root / method / f'seed{seed}'
        run.mkdir(parents=True)
        (run / 'client.pt').write_bytes(b'opaque checkpoint')
        identity = dict(method=method, seed=seed, mode='formal', data_identity='data',
                        data_acceptance_sha256='acceptance', checkpoint_sha256='foundation',
                        normalization_sha256='normalization', protocol_sha256='protocol',
                        model_config_sha256='model', code={'frozen': 'same'},
                        config=dict(method=method, seed=seed, rounds=20))
        clients = ['pooled'] if method == 'M9' else CLIENTS
        final = dict(method=method, seed=seed, identity=identity,
                     clients={c: dict(path='client.pt', sha256=file_hash(run / 'client.pt')) for c in clients})
        write(run / 'final.json', final)
        write(run / 'verification.json', dict(passed=True, identity=identity))
        for client in clients:
            evaluation = dict(training_identity=identity, method=method, seed=seed,
                              client=client, manifest_sha256='manifest',
                              final_sha256=file_hash(run / 'final.json'),
                              checkpoint_sha256=file_hash(run / 'client.pt'))
            write(run / 'evaluation/identities' / f'{client}.json', evaluation)
            for index in completed:
                row = self.rows[index]
                value = dict(case=row, client=client, seed=seed, completed=True,
                             error=None, success=True,
                             identity=dict(evaluation=digest(evaluation), case_sha256=digest(row)))
                write(run / 'evaluation/cases' / client / str(index) / 'result.json', value)
        return run

    def build(self, runs):
        return report.create_report(runs, self.manifest, self.expected, bootstrap_replicates=10)

    def test_no_runs_is_incomplete_and_all_methods_have_seed43_denominators(self):
        result = self.build([])
        self.assertEqual(len(result['methods']), 10)
        self.assertFalse(result['complete_requested_runs'])
        self.assertFalse(result['complete_study'])
        self.assertEqual(result['required_seeds'], [43])
        self.assertEqual(result['methods']['M1']['missing'], 8)
        self.assertEqual(result['methods']['M9']['missing'], 2)
        self.assertEqual(result['methods']['M1']['missing_seeds'], [43])
        self.assertEqual(result['methods']['M9']['prediction_test']['all-chunks/pooled']['missing'], 12)
        self.assertFalse(result['primary_contrasts']['M6-M1']['available'])
        self.assertNotIn('complete_three_seed_methods', result)

    def test_complete_rollouts_do_not_hide_absent_predictions_or_methods(self):
        result = self.build([self.run_fixture(completed=(0, 1))])
        method = result['methods']['M1']
        self.assertTrue(method['complete'])
        self.assertFalse(method['complete_with_prediction'])
        self.assertEqual(method['available_seeds'], [43])
        self.assertIsNone(method['seed_sample_sd'])
        self.assertFalse(result['complete_study'])
        self.assertFalse(result['complete_requested_runs'])

    def test_complete_study_requires_every_method_and_prediction_client(self):
        runs = [self.run_fixture(method, completed=(0, 1)) for method in report.METHODS]
        original = report.read_run
        def with_predictions(run, manifest):
            final, records, summary = original(run, manifest)
            for client in summary['clients']:
                count = 12 if client == 'pooled' else 3
                values = [dict(completed=True, error=None, future_mse=1., persistence_mse=2., source_group='g')] * count
                summary['prediction_test']['all-chunks/' + client] = prediction_summary(values, count)
            return final, records, summary
        with patch.object(report, 'read_run', side_effect=with_predictions):
            result = self.build(runs)
        self.assertTrue(result['complete_study'])
        self.assertTrue(result['primary_contrasts']['M6-M1']['complete'])
        self.assertEqual(result['primary_contrasts']['M6-M1']['scopes']['all']['missing_pairs'], 0)

    def test_partial_contrast_reports_missing_pairs_on_both_sides(self):
        runs = [self.run_fixture('M6', completed=(0,)), self.run_fixture('M1', completed=(0,))]
        contrast = self.build(runs)['primary_contrasts']['M6-M1']
        self.assertTrue(contrast['available'])
        self.assertFalse(contrast['complete'])
        self.assertEqual(contrast['scopes']['all']['missing_pairs'], 4)
        self.assertFalse(contrast['scopes']['E_confirm']['available'])

    def test_other_seed_and_duplicate_method_rejected(self):
        with self.assertRaisesRegex(ValueError, '43'):
            self.build([self.run_fixture(seed=42)])
        run = self.run_fixture()
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            self.build([run, run])

    def test_finalizer_uses_run_count_and_requires_matching_verified_final(self):
        good = self.run_fixture('M1')
        stale = self.run_fixture('M2')
        write(stale / 'verification.json', dict(passed=True, identity={}))
        absent = self.root / 'M9/seed43'
        plan = dict(runs=[str(good), str(stale), str(absent)], seeds=[43],
                    tasks=[dict(id=f'client-{i}', kind='train') for i in range(20)])
        summary = finalize.training_status(plan)
        self.assertEqual(summary['expected_training_runs'], 3)
        self.assertEqual(summary['runs_with_training_verification'], [str(good)])
        self.assertEqual(len(summary['unverified_runs']), 2)
        self.assertFalse(summary['complete_training'])


if __name__ == '__main__':
    unittest.main()
