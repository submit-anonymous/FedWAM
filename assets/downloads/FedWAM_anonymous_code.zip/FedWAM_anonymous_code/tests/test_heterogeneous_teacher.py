import unittest
import torch
from fedwam.heterogeneous.teacher import fit_teacher
from fedwam.heterogeneous.interface import SCHEMA


def packets():
    generator=torch.Generator().manual_seed(7)
    result=[]
    for client,arch in [('a','lawam'),('b','imagewam')]:
        n=40
        z=torch.randn(n,4,8,generator=generator)
        result.append(dict(schema=SCHEMA,round=0,client=client,architecture=arch,model_version='base',representation='future',
                           query=dict(z=z,language=torch.randn(n,6,generator=generator),state=torch.zeros(n,3),
                                      state_mask=torch.zeros(n,3,dtype=torch.bool),horizon=torch.ones(n,1)*8),
                           prediction=.7*z,source_groups=[f'{client}-{i}' for i in range(n)],
                           tasks=['task']*n,query_ids=[f'{i}' for i in range(n)]))
    return result


class TeacherTest(unittest.TestCase):
    config=dict(dim=8,language_dim=6,state_dim=3,tokens=4,width=16,heads=4,depth=1)

    def test_resume_matches_uninterrupted_and_holds_out_sources(self):
        data=packets()
        full=fit_teacher(data,round_id=0,steps=6,config=self.config,batch_size=4)
        short=fit_teacher(data,round_id=0,steps=3,config=self.config,batch_size=4)
        resumed=fit_teacher(data,round_id=0,steps=6,config=self.config,batch_size=4,resume=short)
        for key,value in full['model'].items():
            torch.testing.assert_close(value,resumed['model'][key],rtol=0,atol=0)
        self.assertFalse(set(full['training_groups']) & set(full['validation_groups']))
        self.assertEqual(full['updates'],6)

    def test_resume_rejects_changed_predictions(self):
        data=packets()
        short=fit_teacher(data,round_id=0,steps=1,config=self.config,batch_size=4)
        data[0]['prediction'][0,0,0]+=1
        with self.assertRaises(ValueError):
            fit_teacher(data,round_id=0,steps=2,config=self.config,batch_size=4,resume=short)


if __name__=='__main__':
    unittest.main()
