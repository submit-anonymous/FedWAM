"""Public packet boundary and actual serialized communication budget."""
import unittest
import torch
from fedwam import packets


def record(query='q0', group='g0', client='c0', round=0):
    return dict(z=torch.zeros(3, 4), intent=torch.zeros(1, 32), prediction=torch.ones(3, 4),
                horizon=8, hz=20, client=client, round=round, task='task', source_group=group,
                query_id=query, model_version=f'world-{round}', interface_version='test-v1',
                sampling_probability=0.5, reliability=1.)


class PacketTests(unittest.TestCase):
    def test_roundtrip_and_actual_budget(self):
        payload, count = packets.pack([record()], 100000, 10)
        self.assertEqual(count, 1)
        self.assertTrue(torch.equal(packets.unpack(payload)[0]['prediction'], torch.ones(3, 4)))
        payload2, count2 = packets.pack([record(), record('q1')], len(payload), 10)
        self.assertLessEqual(len(payload2), len(payload))
        self.assertEqual(count2, 1)
        self.assertEqual(packets.pack([record(),record('q1')],100000,1)[1],1)

    def test_private_unknown_and_nonfinite_values_rejected(self):
        for field in ['future', 'actions', 'optimizer', 'history', 'anything']:
            bad=record(); bad[field]=torch.ones(1)
            with self.assertRaises(ValueError): packets.pack([bad],100000,10)
        bad=record();bad['prediction'][0,0]=float('nan')
        with self.assertRaises(ValueError): packets.pack([bad],100000,10)
        bad=record();bad['sampling_probability']=0
        with self.assertRaises(ValueError): packets.pack([bad],100000,10)

    def test_mixed_packet_identity_rejected(self):
        for key,value in [('client','c1'),('round',1),('interface_version','other'),('model_version','old')]:
            bad=record('q1');bad[key]=value
            with self.assertRaises(ValueError):packets.pack([record(),bad],100000,10)

    def test_too_small_budget_rejected(self):
        with self.assertRaises(ValueError):packets.pack([record()],1,1)

class PacketInterfaceBoundaryTests(unittest.TestCase):
    @staticmethod
    def wire(records):
        import io
        stream=io.BytesIO();torch.save({'schema':packets.SCHEMA,'records':records},stream);return stream.getvalue()

    def test_empty_interface_ids_rejected_on_encoding_and_decoding(self):
        for identity in ['', '   ', '\t\n']:
            row=record();row['interface_version']=identity
            with self.assertRaises(ValueError):packets.pack([row],100000,10)
            with self.assertRaises(ValueError):packets.unpack(self.wire([row]))

    def test_future_and_transition_interfaces_cannot_share_packet(self):
        a=record();a['interface_version']='encoder:deployed-intent:H8:20Hz:future'
        b=record('q1');b['interface_version']='encoder:deployed-intent:H8:20Hz:transition'
        with self.assertRaises(ValueError):packets.pack([a,b],100000,10)
        with self.assertRaises(ValueError):packets.unpack(self.wire([a,b]))
