import unittest,copy
from fedwam.experiment_config import formal_gate,METHODS
class AdmissionTests(unittest.TestCase):
 def fixture(self):
  identity={k:'bound' for k in ['code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256']};identity['config']={'experiment_overrides':{}}
  receipt={k:v for k,v in identity.items() if k!='config'};receipt.update(passed=True,mode='real_model_two_round_engineering',methods_passed=list(METHODS),experiment_overrides={})
  return identity,receipt
 def test_gate_checks_all_inputs_and_complete_methods(self):
  ident,receipt=self.fixture();formal_gate(ident,receipt)
  for key in ['code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256']:
   changed=copy.deepcopy(ident);changed[key]='changed'
   with self.assertRaises(ValueError):formal_gate(changed,receipt)
  receipt['methods_passed']=['M1']
  with self.assertRaises(ValueError):formal_gate(ident,receipt)
 def test_untested_override_rejected(self):
  ident,receipt=self.fixture();ident['config']['experiment_overrides']={'branches':4}
  with self.assertRaises(ValueError):formal_gate(ident,receipt)
 def test_default_four_client_engineering_matches_self_packet_server_budget(self):
  from fedwam.experiment_config import resolved_config
  cfg=resolved_config('M8',42,'engineering')
  self.assertEqual(len(cfg['clients']),4)
  self.assertGreater(cfg['server']['steps_per_round'],0)
  self.assertEqual(cfg['server']['steps_per_round']%len(cfg['clients']),0)
