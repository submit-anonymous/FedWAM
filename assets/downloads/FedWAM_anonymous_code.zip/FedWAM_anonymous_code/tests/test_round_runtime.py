import tempfile,unittest
from pathlib import Path
import torch
from fedwam.round_runtime import RoundStore,PhaseRunner

class RuntimeTests(unittest.TestCase):
 def test_resume_partial_phase_and_reject_identity_change(self):
  with tempfile.TemporaryDirectory() as tmp:
   store=RoundStore(Path(tmp),{'method':'M1','seed':42})
   runner=PhaseRunner(store)
   def interrupted(state,start,save):
    state['v']+=2;save(2,state);raise RuntimeError('interrupted')
   with self.assertRaisesRegex(RuntimeError,'interrupted'):runner.run('warmup/a',{'v':0},4,interrupted)
   def resume(state,start,save):
    self.assertEqual(start,2);state['v']+=4-start;return state
   result=runner.run('warmup/a',{'v':0},4,resume)
   self.assertEqual(result['v'],4)
   self.assertEqual(runner.run('warmup/a',{},4,lambda *x:self.fail('repeated completed phase'))['v'],4)
   with self.assertRaisesRegex(ValueError,'identity'):RoundStore(Path(tmp),{'method':'M2','seed':42})
 def test_commit_requires_all_clients_and_sha_binding(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=RoundStore(Path(tmp),{'method':'M2'})
   p=s.write('x.pt',{'weight':torch.ones(2)})
   with self.assertRaisesRegex(ValueError,'clients'):s.commit(0,{'a':p},['a','b'])
   s.commit(0,{'a':p},['a']);self.assertEqual(s.latest()['round'],0)
   (Path(tmp)/'x.pt').write_bytes(b'broken')
   with self.assertRaisesRegex(ValueError,'checksum'):s.read_ref(p)
 def test_atomic_failed_round_does_not_replace_previous_commit(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=RoundStore(Path(tmp),{'method':'M2'});p=s.write('x.pt',{'v':1});s.commit(-1,{'a':p},['a'])
   with self.assertRaises(ValueError):s.commit(0,{},['a'])
   self.assertEqual(s.latest()['round'],-1)
