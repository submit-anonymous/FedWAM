import unittest
from fedwam.io import ROOT,load
from fedwam.native_local import local_contract
from fedwam.native_federation import native_config, native_lr
from fedwam.experiment_config import METHODS

class NativeProtocolTests(unittest.TestCase):
 def test_common_local_budget_matches_pinned_official_recipe(self):
  c=local_contract();p=load(ROOT/'configs/native_fedwam_protocol_v2.json');t=p['training']
  self.assertEqual(t['local_steps_per_client'],c['steps'])
  self.assertEqual(t['effective_batch_per_client'],c['per_device_batch'])
  self.assertEqual(t['warmup_local_updates']+t['federation_rounds']*(t['pre_receive_joint_updates']+t['post_receive_joint_updates']+t['action_only_updates']),c['steps'])
  self.assertEqual((t['lr'],t['lr_warmup_updates'],t['min_lr'],t['adamw_betas'],t['adamw_weight_decay']),
                   (c['lr'],c['lr_warmup'],c['scheduler_min_lr'],c['optimizer_betas'],c['weight_decay']))
  self.assertTrue(t['detach_future_feature_for_action'] and c['latent_action_distill'])
  self.assertEqual(p['aggregation']['query_horizon_actions'],8)

 def test_all_methods_have_equal_client_updates_and_official_detached_action_path(self):
  for method in METHODS:
   cfg=native_config(method,'formal')
   schedule=cfg['training']
   updates=schedule['warmup']+schedule['rounds']*(
       schedule['pre_receive_joint']+schedule['post_receive_joint']+
       schedule['final_world_action_only'])
   self.assertEqual(updates,25000,method)
   self.assertFalse(cfg['action_feedback'],method)
   self.assertEqual(schedule['effective_batch'],32,method)
   self.assertEqual(native_lr(1500),1e-4)

 def test_resolved_metadata_describes_actual_native_training(self):
  cfg=native_config('M1','formal')
  self.assertEqual(cfg['training']['intent'],'private native trainable prediction with latent-action distillation')
  self.assertFalse(cfg['training']['action_feedback_to_world'])
  self.assertEqual(cfg['training']['world_optimizer_receive'],'continuous private state')

 def test_scheduler_matches_official_transformers_schedule(self):
  import torch
  from transformers import get_scheduler
  p=torch.nn.Parameter(torch.zeros(1))
  optimizer=torch.optim.AdamW([p],lr=1e-4)
  scheduler=get_scheduler('cosine_with_min_lr',optimizer=optimizer,
       num_warmup_steps=1500,num_training_steps=25000,
       scheduler_specific_kwargs={'min_lr':5e-7})
  for step in (0,1,1499,1500,10000,24999,25000):
   official=optimizer.defaults['lr']*scheduler.lr_lambdas[0](step)
   self.assertAlmostEqual(native_lr(step),official,places=15)
