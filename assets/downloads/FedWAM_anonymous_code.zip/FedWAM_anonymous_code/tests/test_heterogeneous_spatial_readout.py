import unittest
import torch
from fedwam.heterogeneous.spatial_readout import external_camera_grid, SpatialFutureReadout


class SpatialReadoutTest(unittest.TestCase):
    def test_queries_use_left_external_camera_not_wrist(self):
        x=torch.zeros(1,14,28,2)
        x[:,:,:14]=3
        x[:,:,14:]=100
        grid=external_camera_grid(x.reshape(1,392,2))
        self.assertEqual(tuple(grid.shape),(1,49,2))
        torch.testing.assert_close(grid,torch.full_like(grid,3))

    def test_local_world_and_context_gradients_remain(self):
        head=SpatialFutureReadout(12,output_dim=8,width=16,heads=4)
        head.requires_grad_(False)
        h=torch.randn(1,392,12,requires_grad=True)
        head(h).square().mean().backward()
        grad=h.grad.reshape(1,14,28,12)
        self.assertGreater(grad[:,:,:14].abs().sum().item(),0)
        self.assertGreater(grad[:,:,14:].abs().sum().item(),0)


if __name__=='__main__':unittest.main()
