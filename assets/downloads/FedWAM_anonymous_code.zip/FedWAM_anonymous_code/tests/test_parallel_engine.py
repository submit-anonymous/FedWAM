import copy,json,multiprocessing,tempfile,time,unittest,contextlib
from pathlib import Path
from unittest.mock import patch
import torch
from fedwam.parallel_engine import ParallelEngine
from fedwam.federation_engine import FederationEngine
from fedwam.round_runtime import atomic_json
from test_lawam_federation_integration import Policy,FixtureData,encoded,configuration,CLIENTS
from fedwam.lawam_federation import LaWAMFederation

STATS={'franka':{'action':{'min':[-1]*7,'max':[1]*7,'mask':[True]*6+[False]}}}
def make_backend(root,cfg):
 torch.set_num_threads(1);torch.manual_seed(9)
 return LaWAMFederation(Policy(),cfg,Path(root),'interface')
def rank(root,cfg,client,attempt,fail=None,delay=0):
 with patch('torch.cuda.is_available',return_value=False),patch('fedwam.lawam_federation.OfficialDataset',FixtureData),patch('fedwam.lawam_federation.encode',encoded),patch('fedwam.lawam_federation.load',return_value=STATS):
  if delay:time.sleep(delay)
  ident={'method':cfg['method'],'seed':42,'mode':'engineering'}
  def hook(stage):
   if fail and stage==fail:raise RuntimeError('injected crash')
  engine=ParallelEngine(root,ident,cfg,make_backend(root,cfg),client,attempt,timeout=20,poll=.01,fault_hook=hook)
  try:
   from fedwam.round_runtime import atomic_torch as original_save
   def interrupted_save(path,value):
    original_save(path,value)
    if fail=='partial_post' and str(path).endswith('lighting/post.pt') and value.get('done')==1:raise RuntimeError('injected partial post')
   with patch('fedwam.round_runtime.atomic_torch',interrupted_save):ref=engine.run_client()
   atomic_json(engine.store.path(f'client_verification/{client}.json'),{'passed':True,'identity':ident,'attempt':attempt,'ref':ref})
   if engine.coordinator:engine.finalize()
  except Exception as e:
   engine.fail(e)
   raise

def execute(root,cfg,attempt='a',fail=None):
 context=multiprocessing.get_context('spawn');clients=['pooled'] if cfg['method']=='M9' else CLIENTS
 processes=[context.Process(target=rank,args=(root,cfg,c,attempt,fail if i==0 else None)) for i,c in enumerate(clients)]
 for p in processes:p.start()
 for p in processes:p.join(35)
 for p in processes:
  if p.is_alive():p.kill();p.join();raise AssertionError('parallel fixture deadlocked')
 return [p.exitcode for p in processes]

class ParallelTests(unittest.TestCase):
 def setUp(self):
  self.cuda=patch('torch.cuda.is_available',return_value=False);self.cuda.start();self.addCleanup(self.cuda.stop)
 def equal_tree(self,x,y):
  import numpy as np
  if isinstance(x,torch.Tensor):torch.testing.assert_close(x,y,rtol=0,atol=0)
  elif isinstance(x,np.ndarray):np.testing.assert_array_equal(x,y)
  elif isinstance(x,dict):
   self.assertEqual(set(x),set(y))
   for k in x:self.equal_tree(x[k],y[k])
  elif isinstance(x,(list,tuple)):
   self.assertEqual(len(x),len(y))
   for a,b in zip(x,y):self.equal_tree(a,b)
  else:self.assertEqual(x,y)
 def test_all_methods_match_serial_weights_and_exposure(self):
  torch.set_num_threads(1)
  for method in ['M1','M2','M3','M4','M5','M6','M7','M8','M9','Local-adapter']:
   with self.subTest(method=method),tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b,patch('fedwam.lawam_federation.OfficialDataset',FixtureData),patch('fedwam.lawam_federation.encode',encoded),patch('fedwam.lawam_federation.load',return_value=STATS):
    cfg=configuration(method);ident={'method':method,'seed':42,'mode':'engineering'}
    serial=FederationEngine(a,ident,cfg,make_backend(a,cfg));left=serial.run()
    self.assertEqual(execute(b,cfg),[0]*(1 if method=='M9' else 4))
    parallel=ParallelEngine(b,ident,cfg,None,('pooled' if method=='M9' else CLIENTS[0]),'inspect')
    right=json.loads((Path(b)/'final.json').read_text())
    for c in left['clients']:
     x=serial.store.read_ref(left['clients'][c])['state'];y=parallel.store.read_ref(right['clients'][c])['state']
     for key in ('draw','total_updates','exposure'):self.assertEqual(x[key],y[key])
     self.equal_tree(x['world_optimizer'],y['world_optimizer']);self.equal_tree(x['action_optimizer'],y['action_optimizer']);self.equal_tree(x['rng'],y['rng'])
     for module in ('world','action'):
      for key in x[module]:torch.testing.assert_close(x[module][key],y[module][key],rtol=0,atol=0)
 def test_server_interruption_and_five_round_pruning(self):
  cfg=configuration('M6');cfg['training']['rounds']=5
  with tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
   self.assertEqual(execute(a,cfg),[0]*4)
   self.assertTrue(any(execute(b,cfg,fail='round0:server_published')))
   self.assertEqual(execute(b,cfg,attempt='retry'),[0]*4)
   for c in CLIENTS:
    def read(root):
     f=json.loads((Path(root)/'final.json').read_text());return torch.load(Path(root)/f['clients'][c]['path'],weights_only=False)['state']
    x,y=read(a),read(b)
    for module in ('world','action'):
     for key in x[module]:torch.testing.assert_close(x[module][key],y[module][key],rtol=0,atol=0)
   self.assertFalse((Path(b)/'phases/r0000').exists())
 def test_independent_client_can_finish_before_others_start(self):
  cfg=configuration('M1')
  with tempfile.TemporaryDirectory() as tmp:
   context=multiprocessing.get_context('spawn');p=context.Process(target=rank,args=(tmp,cfg,CLIENTS[0],'solo'));p.start()
   deadline=time.monotonic()+10
   while time.monotonic()<deadline and not (Path(tmp)/f'client_verification/{CLIENTS[0]}.json').exists():time.sleep(.03)
   self.assertTrue((Path(tmp)/f'client_verification/{CLIENTS[0]}.json').exists())
   others=[context.Process(target=rank,args=(tmp,cfg,c,'solo')) for c in CLIENTS[1:]]
   for q in others:q.start()
   for q in [p]+others:q.join(20);self.assertEqual(q.exitcode,0)

 def test_partial_post_and_committed_round_resume(self):
  for method,failure in [('M6','partial_post'),('M7','partial_post'),('M8','partial_post'),('M2','round0:committed')]:
   with self.subTest(method=method),tempfile.TemporaryDirectory() as a,tempfile.TemporaryDirectory() as b:
    cfg=configuration(method);cfg['training']['post_receive_joint']=2
    self.assertEqual(execute(a,cfg),[0]*4)
    self.assertTrue(any(execute(b,cfg,fail=failure)))
    self.assertEqual(execute(b,cfg,attempt='retry'),[0]*4)
    for c in CLIENTS:
     def read(root):
      f=json.loads((Path(root)/'final.json').read_text());return torch.load(Path(root)/f['clients'][c]['path'],weights_only=False)['state']
     x,y=read(a),read(b)
     for key in ('world','action','world_optimizer','action_optimizer','rng','draw','exposure'):self.equal_tree(x[key],y[key])

 def test_old_client_proofs_do_not_allow_early_finalize_on_restart(self):
  cfg=configuration('M6')
  with tempfile.TemporaryDirectory() as tmp:
   self.assertEqual(execute(tmp,cfg,attempt='old'),[0]*4)
   final=Path(tmp)/'final.json';old_time=final.stat().st_mtime_ns
   context=multiprocessing.get_context('spawn');p=context.Process(target=rank,args=(tmp,cfg,CLIENTS[0],'new'));p.start()
   proof=Path(tmp)/f'client_verification/{CLIENTS[0]}.json';deadline=time.monotonic()+12
   while time.monotonic()<deadline and json.loads(proof.read_text()).get('attempt')!='new':time.sleep(.03)
   self.assertEqual(json.loads(proof.read_text())['attempt'],'new')
   self.assertTrue(p.is_alive());self.assertEqual(final.stat().st_mtime_ns,old_time)
   others=[context.Process(target=rank,args=(tmp,cfg,c,'new')) for c in CLIENTS[1:]]
   for q in others:q.start()
   for q in [p]+others:q.join(25);self.assertEqual(q.exitcode,0)
