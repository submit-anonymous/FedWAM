import json
import tempfile
import unittest
from pathlib import Path
import torch
from fedwam.round_runtime import RoundStore, atomic_json
from fedwam.retention import compact_completed_run
from fedwam.federated_reporting import load_final_checkpoint


class RetentionTests(unittest.TestCase):
    def fixture(self, root):
        identity = {'test': 1}
        store = RoundStore(root, identity)
        checkpoint = {'schema': 'fedwam.client.v1', 'identity': identity, 'method': 'M1', 'seed': 42,
                      'client': 'lighting', 'done': 2, 'steps': 2,
                      'state': {'world': {'w': torch.ones(2)}, 'action': {'w': torch.arange(2)},
                                'world_optimizer': {'m': torch.zeros(2)}, 'action_optimizer': {'m': torch.zeros(2)}}}
        ref = store.write('phases/r0001/lighting/action.pt', checkpoint)
        server = store.write('server/r0001.pt', {'kind': 'none'})
        store.commit(1, {'lighting': ref}, ['lighting'], server)
        final = {'identity': identity, 'method': 'M1', 'seed': 42, 'clients': {'lighting': ref}}
        atomic_json(store.path('final.json'), final)
        return store, identity

    def test_unverified_run_keeps_restart_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            store, identity = self.fixture(tmp)
            atomic_json(store.path('verification.json'), {'passed': False, 'identity': identity})
            with self.assertRaises(ValueError): compact_completed_run(tmp, identity)
            self.assertTrue(store.path('phases/r0001/lighting/action.pt').exists())

    def test_compacted_weights_pass_evaluator_and_cleanup_can_repeat(self):
        with tempfile.TemporaryDirectory() as tmp:
            store, identity = self.fixture(tmp)
            atomic_json(store.path('verification.json'), {'passed': True, 'identity': identity})
            final = compact_completed_run(tmp, identity)
            checkpoint = load_final_checkpoint(tmp, final, 'lighting')
            torch.testing.assert_close(checkpoint['state']['world']['w'], torch.ones(2))
            torch.testing.assert_close(checkpoint['state']['action']['w'], torch.arange(2))
            self.assertIsNone(checkpoint['state']['world_optimizer'])
            self.assertFalse(store.path('phases/r0001/lighting/action.pt').exists())
            self.assertEqual(compact_completed_run(tmp, identity), final)
            self.assertTrue(store.path('checkpoints/final/server.pt').exists())

    def test_malformed_or_wrong_identity_checkpoint_cannot_remove_originals(self):
        for corruption in ('identity', 'done'):
            with self.subTest(corruption=corruption), tempfile.TemporaryDirectory() as tmp:
                store, identity = self.fixture(tmp)
                final = json.loads(store.path('final.json').read_text())
                old_ref = final['clients']['lighting']
                checkpoint = store.read_ref(old_ref)
                if corruption == 'identity':
                    checkpoint['identity'] = {'other': True}
                else:
                    del checkpoint['done']
                    del checkpoint['steps']
                final['clients']['lighting'] = store.write(old_ref['path'], checkpoint)
                atomic_json(store.path('final.json'), final)
                atomic_json(store.path('verification.json'), {'passed': True, 'identity': identity})
                with self.assertRaises(ValueError): compact_completed_run(tmp, identity)
                self.assertTrue(store.path(old_ref['path']).exists())
                self.assertTrue(store.path('server/r0001.pt').exists())
                self.assertNotIn('retention', json.loads(store.path('final.json').read_text()))
