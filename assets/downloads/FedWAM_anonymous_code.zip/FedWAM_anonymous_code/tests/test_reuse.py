import tempfile,unittest
from pathlib import Path
from fedwam import data_contracts as d
class ReuseTests(unittest.TestCase):
    def test_short_cached_shard_names_are_discovered(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'00007.tfrecord').write_bytes(b'data')
            self.assertEqual(d.cached_shard(p,'libero_mix-train.tfrecord-00007-of-01024'),p/'00007.tfrecord')
    def test_unknown_shard_is_not_replaced_by_an_unrelated_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'00008.tfrecord').write_bytes(b'data')
            self.assertIsNone(d.cached_shard(p,'libero_mix-train.tfrecord-00007-of-01024'))
