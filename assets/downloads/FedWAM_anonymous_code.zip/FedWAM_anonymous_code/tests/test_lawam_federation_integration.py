"""Exercise actual federation backend on small differentiable policy/data fixtures."""
import tempfile,unittest,copy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import torch
from torch import nn
from fedwam.lawam_federation import LaWAMFederation
from fedwam.federation_engine import FederationEngine
from fedwam.official_data import ChunkSampler
from fedwam.training import action_tensors

CLIENTS=['lighting','camera_pose','sensor_noise','background']
class FixtureData:
 def __init__(self,root,client,split,seed,max_cached_episodes=1):
  self.rows=[dict(client=client,split=split,record_id=f'{client}-{split}-{i}',source_group=f'{split}-g{i}',
   suite='fixture',source_file='task_demo.hdf5',continuous_chunk_starts=[0,1]) for i in range(8)]
  self.sampler=ChunkSampler(self.rows,client,split,seed);self.reader=self
 def read(self,row,t):
  i=int(row['source_group'].split('g')[-1]);c=CLIENTS.index(row['client'])
  return dict(row,t=t,future_t=t+8,lang='move',z=torch.full((1,2,4),.1*i+.02*c+.01*t),target=torch.full((1,2,4),.1*i+.1),
   actions=torch.full((8,7),.05*i).numpy())
class Flow(nn.Module):
 def __init__(self):super().__init__();self.layer=nn.Linear(4,7);self.config=SimpleNamespace(use_state=False)
 def forward(self,**kw):return (self.layer(kw['h_t1_star'].mean(1))-kw['actions'][:,0,:7]).square().mean()
class Backend(nn.Module):
 def __init__(self):
  super().__init__();self.lam=nn.Module();self.lam.decoder=nn.Sequential(nn.Linear(4,4));self.flow=Flow();self.model_cfg=SimpleNamespace(repeated_diffusion_steps=1,action_horizon=50)
 def _decode_future_tokens_strict_single_query(self,h_t,pred_action_emb,source):return self.lam.decoder(h_t)
class Policy(nn.Module):
 def __init__(self):super().__init__();self.policy_backend=Backend();self.frozen=nn.Linear(4,4)
def encoded(policy,sample,stats):
 d={'h_t':sample['z'],'intent':torch.zeros(1,1,32),'future_target':sample['target'],'h_vlm':torch.zeros(1,2,4),
 'attention_mask':torch.ones(1,2,dtype=torch.bool),'action_hz':torch.tensor([20.]),'embodiment_id':torch.tensor([25])}
 d.update(action_tensors(sample['actions'],stats));return d,{}
def configuration(method):
 return dict(method=method,seed=42,clients=CLIENTS,mode='engineering',prune=True,adapter_rank=2,checkpoint_every=1,server_checkpoint_every=1,
  training=dict(warmup=1,rounds=2,pre_receive_joint=1,post_receive_joint=1,final_world_action_only=1,effective_batch=1,lr=.001,weight_decay=.01,world_weight=.1,federated_weight=1.,clip_grad_norm=1.),
  server=dict(spatial_tokens=2,feature_dim=4,intent_dim=32,teacher_width=8,teacher_depth=1,teacher_heads=2,steps_per_round=4,batch=2,lr=.001,
   packet_budget_bytes=2**20,max_queries=8,replay_rounds=4,gain_margin=.02,calibration_min_groups=5))
class IntegrationTests(unittest.TestCase):
 def test_all_methods_complete_two_actual_backend_rounds(self):
  for method in ['M1','M2','M3','M4','M5','M6','M7','M8','M9','Local-adapter']:
   with self.subTest(method=method),tempfile.TemporaryDirectory() as tmp,patch('fedwam.lawam_federation.OfficialDataset',FixtureData),patch('fedwam.lawam_federation.encode',encoded),patch('fedwam.lawam_federation.load',return_value={'franka':{'action':{'min':[-1]*7,'max':[1]*7,'mask':[True]*6+[False]}}}):
    torch.manual_seed(9);policy=Policy();frozen=copy.deepcopy(policy.frozen.state_dict());cfg=configuration(method)
    backend=LaWAMFederation(policy,cfg,Path(tmp),'interface')
    engine=FederationEngine(Path(tmp),{'method':method,'seed':42,'mode':'engineering'},cfg,backend)
    final=engine.run();self.assertEqual(final['rounds'],2)
    for c,ref in final['clients'].items():
     state=engine.store.read_ref(ref)['state'];self.assertEqual(state['total_updates'],28 if method=='M9' else 7)
     self.assertEqual(state['metrics']['world_updates'],20 if method=='M9' else 5)
     self.assertEqual(state['metrics']['action_updates'],28 if method=='M9' else 7)
    if method=='M8':
     server=engine.store.read_ref(engine.store.latest()['server'])
     self.assertEqual(sum(t['steps'] for t in server['teachers'].values()),cfg['server']['steps_per_round'])
    for k,v in policy.frozen.state_dict().items():self.assertTrue(torch.equal(v,frozen[k]))
 def test_actual_backend_partial_post_resume_matches_uninterrupted(self):
  from fedwam.round_runtime import atomic_torch as real_save
  for method in ['M2','M3','M6','M7','M8']:
   with self.subTest(method=method),tempfile.TemporaryDirectory() as left,tempfile.TemporaryDirectory() as right,patch('fedwam.lawam_federation.OfficialDataset',FixtureData),patch('fedwam.lawam_federation.encode',encoded),patch('fedwam.lawam_federation.load',return_value={'franka':{'action':{'min':[-1]*7,'max':[1]*7,'mask':[True]*6+[False]}}}):
    cfg=configuration(method);cfg['training']['rounds']=1;cfg['training']['post_receive_joint']=2
    def engine(path):
     torch.manual_seed(9);backend=LaWAMFederation(Policy(),cfg,Path(path),'interface')
     return FederationEngine(Path(path),{'method':method,'seed':42,'mode':'engineering'},cfg,backend)
    a=engine(left);a.run();b=engine(right)
    def crash(path,value):
     real_save(path,value)
     if str(path).endswith('lighting/post.pt') and value.get('done')==1:raise RuntimeError('forced partial post interruption')
    with patch('fedwam.round_runtime.atomic_torch',crash),self.assertRaisesRegex(RuntimeError,'forced partial'):b.run()
    b=engine(right);b.run()
    for client in CLIENTS:
     x=a.store.read_ref(a.store.latest()['clients'][client])['state'];y=b.store.read_ref(b.store.latest()['clients'][client])['state']
     self.assertEqual(x['draw'],y['draw'])
     for module in ['world','action']:
      for key in x[module]:self.assertTrue(torch.equal(x[module][key],y[module][key]),f'{method}/{client}/{module}/{key}')
