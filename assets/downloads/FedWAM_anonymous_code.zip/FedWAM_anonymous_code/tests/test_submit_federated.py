import importlib.util
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('submit_federated', Path(__file__).resolve().parents[1] / 'scripts/submit_federated.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class SubmissionTests(unittest.TestCase):
    def test_partial_dag_and_lost_job_receipt_resume_without_duplicate_or_early_release(self):
        jobs = {}
        released = []
        failed = False
        def command(args):
            nonlocal failed
            if args[0] == 'squeue':
                return '\n'.join(f'{job}|{marker}' for marker, job in jobs.items())
            if args[0] == 'sbatch':
                self.assertIn('--hold', args)
                marker = next(x.split('=', 1)[1] for x in args if x.startswith('--comment='))
                self.assertNotIn(marker, jobs)
                jobs[marker] = str(100 + len(jobs))
                if marker.endswith(':intern_workers') and not failed:
                    failed = True
                    # Scheduler accepted the job, but the client lost the reply.
                    raise subprocess.CalledProcessError(1, args)
                return jobs[marker]
            raise AssertionError(args)
        def run(args, **kwargs):
            if args[:3] == ['scontrol', 'show', 'job']:
                if args[-1] == '10':
                    return subprocess.CompletedProcess(args, 1, '', '')
                return subprocess.CompletedProcess(args, 0, 'Reason=JobHeldUser', '')
            if args[:2] == ['scontrol', 'release']:
                self.assertEqual(len(jobs), 5)
                released.append(args[-1])
                return subprocess.CompletedProcess(args, 0)
            raise AssertionError(args)
        with tempfile.TemporaryDirectory() as tmp, patch.object(module, 'command', command), patch.object(module.subprocess, 'run', run):
            path = Path(tmp) / 'jobs.json'
            state = dict(plan='plan.json', plan_sha256='a'*64, jobs={}, baseline_intern='10', baseline_staff='20', baseline_predecessor='10_1', state='submitting')
            with self.assertRaises(subprocess.CalledProcessError):
                module.submit_dag(state, path)
            self.assertEqual(len(jobs), 3)
            self.assertEqual(released, [])
            resumed = json.loads(path.read_text())
            module.submit_dag(resumed, path)
            self.assertEqual(len(jobs), 5)
            self.assertEqual(resumed['state'], 'submitted')
            self.assertEqual(released[-1], resumed['jobs']['engineering'])
            # Receipt-level replay does not submit or release anything twice.
            module.submit_dag(resumed, path)
            self.assertEqual(len(released), 5)
