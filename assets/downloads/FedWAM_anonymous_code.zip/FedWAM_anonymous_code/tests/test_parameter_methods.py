"""Real CPU contracts for absolute world averaging and effective LoRA exchange."""
import copy
import io
import unittest

import torch
from torch import nn

try:
    from fedwam import parameter_methods as m
except ImportError:
    m = None


class ParameterMethods(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(m, 'parameter_methods implementation is required')

    def decoder(self):
        return nn.Sequential(nn.Linear(3, 4), nn.Tanh(), nn.Linear(4, 2))

    def test_absolute_uniform_mean_preserves_inputs_and_dtype(self):
        a = {'weight': torch.tensor([[2., 4.]], dtype=torch.float64), 'count': torch.tensor(3)}
        b = {'weight': torch.tensor([[8., 10.]], dtype=torch.float64), 'count': torch.tensor(3)}
        result = m.average_world([a, b])
        torch.testing.assert_close(result['weight'], torch.tensor([[5., 7.]], dtype=torch.float64))
        result['weight'].zero_()
        self.assertEqual(a['weight'][0, 0], 2)
        self.assertEqual(b['weight'][0, 0], 8)

    def test_average_rejects_incompatible_or_private_states(self):
        good = {'weight': torch.ones(2, 3)}
        for bad in ({'bias': torch.ones(2)}, {'weight': torch.ones(3, 2)},
                    {'weight': torch.ones(2, 3, dtype=torch.float64)},
                    {'weight': torch.full((2, 3), float('nan'))},
                    {'weight': torch.ones(2, 3), 'action.weight': torch.ones(2)},
                    {'world_optimizer': {'state': {}}}):
            with self.subTest(bad=list(bad)), self.assertRaises(ValueError):
                m.average_world([good, bad])
        for bad in ({'action.weight': torch.ones(1)}, {'flow.weight': torch.ones(1)},
                    {'optimizer.momentum': torch.ones(1)}, {'policy_backend.lam.decoder.weight': torch.ones(1)}):
            with self.assertRaises(ValueError):
                m.average_world([bad, bad])
        with self.assertRaises(ValueError):
            m.average_world([])
        with self.assertRaises(ValueError):
            m.average_world([{'count': torch.tensor(1)}, {'count': torch.tensor(2)}])

    def test_public_world_envelope_rejects_checkpoint_and_extra_fields(self):
        model = self.decoder()
        exported = m.world_export(model)
        state = m.validate_world_artifact(exported)
        self.assertEqual(set(state), set(model.state_dict()))
        bad = dict(exported, action={'weight': torch.ones(1)})
        with self.assertRaises(ValueError):
            m.validate_world_artifact(bad)
        with self.assertRaises(ValueError):
            m.validate_world_artifact({'world': state, 'action': state, 'optimizer': {}})

    def test_install_preserves_output_rng_base_and_private_action(self):
        torch.manual_seed(19)
        world = self.decoder(); twin = copy.deepcopy(world); action = nn.Linear(2, 1)
        x = torch.tensor([[1., -2., .5]])
        expected = world(x).detach(); original = copy.deepcopy(world.state_dict())
        action_before = copy.deepcopy(action.state_dict()); rng = torch.get_rng_state().clone()
        metadata = m.install_adapters(world, rank=2, seed=17)
        self.assertTrue(torch.equal(rng, torch.get_rng_state()))
        torch.testing.assert_close(world(x), expected, rtol=0, atol=0)
        self.assertEqual(metadata['rank'], 2)
        self.assertEqual(metadata, m.install_adapters(twin, rank=2, seed=17))
        for p, q in zip(m.adapter_parameters(world), m.adapter_parameters(twin)):
            torch.testing.assert_close(p, q, rtol=0, atol=0)
        optimizer = torch.optim.SGD(m.adapter_parameters(world), lr=.1)
        action(world(x)).square().sum().backward(); optimizer.step()
        self.assertFalse(torch.equal(world(x), expected))
        for name, module in world.named_modules():
            if hasattr(module, 'lora_A'):
                torch.testing.assert_close(module.base.weight, original[name + '.weight'], rtol=0, atol=0)
                self.assertFalse(module.base.weight.requires_grad)
                self.assertIsNone(module.base.weight.grad)
        for key, tensor in action.state_dict().items():
            torch.testing.assert_close(tensor, action_before[key], rtol=0, atol=0)

    def test_attention_functional_projection_stays_frozen_and_unwrapped(self):
        class Decoder(nn.Module):
            def __init__(self):
                super().__init__(); self.attn = nn.MultiheadAttention(4, 2, batch_first=True)
                self.ff = nn.Linear(4, 4)
            def forward(self, x):
                return self.ff(self.attn(x, x, x, need_weights=False)[0])
        decoder = Decoder().eval()
        metadata = m.install_adapters(decoder, rank=2)
        self.assertEqual(set(metadata['modules']), {'ff'})
        self.assertIsInstance(decoder.attn.out_proj, nn.Linear)
        decoder(torch.ones(1, 3, 4)).sum().backward()
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in m.adapter_parameters(decoder)))
        self.assertTrue(all(p.grad is None for p in decoder.attn.parameters()))

    def test_effective_aggregation_is_factor_rotation_invariant(self):
        a = self.decoder(); b = copy.deepcopy(a)
        m.install_adapters(a, rank=2, seed=7); m.install_adapters(b, rank=2, seed=7)
        with torch.no_grad():
            for model in (a, b):
                for module in model.modules():
                    if hasattr(module, 'lora_A'):
                        module.lora_A.copy_(torch.arange(module.lora_A.numel()).reshape_as(module.lora_A) / 11)
                        module.lora_B.copy_(torch.arange(module.lora_B.numel()).reshape_as(module.lora_B) / 7)
            rotation = torch.tensor([[0., -1.], [1., 0.]])
            for module in b.modules():
                if hasattr(module, 'lora_A'):
                    module.lora_A.copy_(rotation @ module.lora_A)
                    module.lora_B.copy_(module.lora_B @ rotation.T)
        ea, eb = m.adapter_export(a), m.adapter_export(b)
        projected, metrics = m.aggregate_adapters([ea, eb], rank=2)
        for key in ea['updates']:
            torch.testing.assert_close(ea['updates'][key], eb['updates'][key])
            torch.testing.assert_close(projected['updates'][key], ea['updates'][key], atol=2e-6, rtol=2e-6)
        self.assertLess(metrics['relative_frobenius_error'], 1e-5)
        m.load_adapter_updates(b, projected)
        torch.testing.assert_close(a(torch.ones(2, 3)), b(torch.ones(2, 3)), atol=2e-6, rtol=2e-6)

    def test_rank_projection_reports_discarded_energy_and_is_deterministic(self):
        model = nn.Sequential(nn.Linear(2, 2, bias=False)); m.install_adapters(model, rank=1)
        a = m.adapter_export(model); b = copy.deepcopy(a)
        a['updates']['0'] = torch.tensor([[6., 0.], [0., 0.]])
        b['updates']['0'] = torch.tensor([[0., 0.], [0., 2.]])
        updates, metrics = m.aggregate_adapters([a, b], rank=1)
        torch.testing.assert_close(updates['updates']['0'], torch.tensor([[3., 0.], [0., 0.]]))
        self.assertAlmostEqual(metrics['frobenius_error'], 1.)
        self.assertAlmostEqual(metrics['relative_frobenius_error'], 1 / (10 ** .5))
        again, _ = m.aggregate_adapters([a, b], rank=1)
        torch.testing.assert_close(updates['updates']['0'], again['updates']['0'], rtol=0, atol=0)

    def test_adapter_rejects_base_rank_version_key_shape_and_private_leaks(self):
        model = self.decoder(); m.install_adapters(model, rank=2)
        good = m.adapter_export(model)
        bad_exports = []
        for key, value in [('base_sha256', '0' * 64), ('rank', 1), ('version', 999), ('action', {})]:
            bad_exports.append(dict(good, **{key: value}))
        bad = copy.deepcopy(good); bad['updates']['0'] = torch.ones(1, 3); bad_exports.append(bad)
        bad = copy.deepcopy(good); del bad['updates']['0']; bad_exports.append(bad)
        bad = copy.deepcopy(good); bad['updates']['0'].fill_(float('inf')); bad_exports.append(bad)
        before = copy.deepcopy(model.state_dict())
        for bad in bad_exports:
            with self.assertRaises(ValueError):
                m.load_adapter_updates(model, bad)
            with self.assertRaises(ValueError):
                m.aggregate_adapters([good, bad], rank=2)
        for key, value in model.state_dict().items():
            torch.testing.assert_close(value, before[key], rtol=0, atol=0)
        with torch.no_grad():
            model[0].base.weight.add_(1)
        with self.assertRaisesRegex(ValueError, 'base'):
            m.adapter_export(model)

    def test_wrapped_state_roundtrips_and_zero_update_remains_trainable(self):
        world = self.decoder(); twin = copy.deepcopy(world)
        m.install_adapters(world, rank=2, seed=3); m.install_adapters(twin, rank=2, seed=9)
        updates, _ = m.aggregate_adapters([m.adapter_export(world)], rank=2)
        m.load_adapter_updates(world, updates)
        world(torch.tensor([[1., 2., 3.]])).sum().backward()
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in m.adapter_parameters(world)))
        with torch.no_grad():
            for p in m.adapter_parameters(world):
                p.add_(.1)
        stream = io.BytesIO(); torch.save(world.state_dict(), stream); stream.seek(0)
        twin.load_state_dict(torch.load(stream, weights_only=True))
        torch.testing.assert_close(world(torch.ones(1, 3)), twin(torch.ones(1, 3)), rtol=0, atol=0)
        for key, value in m.adapter_export(world)['updates'].items():
            torch.testing.assert_close(value, m.adapter_export(twin)['updates'][key], rtol=0, atol=0)

    def test_actual_decoder_intent_projection_and_attention_forward(self):
        from pathlib import Path
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'third_party/LaWAM'))
        from latent_action_model.core.utils.lam_decoder import LAMDecoder_v2
        decoder = LAMDecoder_v2(context_dim=8, input_dim=8, num_layers=1,
                                num_heads=2, grid_hw=(2, 2), code_dim=4, dropout=0).eval()
        features = torch.randn(2, 4, 8); intent = torch.randn(2, 1, 4)
        expected = decoder(features, intent).detach()
        metadata = m.install_adapters(decoder, rank=2, seed=0)
        self.assertIn('action_in_proj', metadata['modules'])
        self.assertNotIn('dec_layers.0.attn.out_proj', metadata['modules'])
        torch.testing.assert_close(decoder(features, intent), expected, rtol=0, atol=0)
        (decoder(features, intent) - torch.randn_like(expected)).square().mean().backward()
        self.assertTrue(any(p.grad is not None and p.grad.abs().sum() > 0 for p in m.adapter_parameters(decoder)))
        m.adapter_export(decoder)

    def test_receiver_rejects_silent_extra_rank_projection_and_dtype_overflow(self):
        decoder = nn.Sequential(nn.Linear(2, 2, bias=False)); m.install_adapters(decoder, rank=1)
        artifact = m.adapter_export(decoder)
        artifact['updates']['0'] = torch.eye(2)
        with self.assertRaisesRegex(ValueError, 'rank'):
            m.load_adapter_updates(decoder, artifact)
        half = nn.Sequential(nn.Linear(2, 2, bias=False).half()); m.install_adapters(half, rank=1)
        artifact = m.adapter_export(half)
        artifact['updates']['0'] = torch.tensor([[1e10, 0.], [0., 0.]])
        with self.assertRaisesRegex(ValueError, 'represent'):
            m.load_adapter_updates(half, artifact)

    def test_private_supervision_and_noninteger_world_version_rejected(self):
        for key in ('actions', 'action_labels', 'future_target', 'optimizer_state', 'rng'):
            with self.subTest(key=key), self.assertRaises(ValueError):
                m.average_world([{key: torch.ones(8, 7)}])
        artifact = m.world_export(self.decoder()); artifact['version'] = True
        with self.assertRaises(ValueError):
            m.validate_world_artifact(artifact)

    def test_unfreezing_base_is_rejected_before_public_export(self):
        decoder = self.decoder(); m.install_adapters(decoder, rank=2)
        decoder[0].base.weight.requires_grad_(True)
        with self.assertRaisesRegex(ValueError, 'frozen'):
            m.adapter_export(decoder)

    def test_m2_path_rejects_lora_factor_averaging(self):
        decoder = self.decoder(); m.install_adapters(decoder, rank=2)
        with self.assertRaises(ValueError):
            m.world_export(decoder)
        with self.assertRaises(ValueError):
            m.average_world([decoder.state_dict(), decoder.state_dict()])


if __name__ == '__main__':
    unittest.main()
