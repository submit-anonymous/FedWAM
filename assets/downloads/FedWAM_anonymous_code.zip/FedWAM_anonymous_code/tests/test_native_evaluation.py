import sys
import types
import unittest
from unittest.mock import patch

import torch

from scripts import evaluate_native_federated as evaluation


class Backend(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.vlm = torch.nn.Linear(1, 1, bias=False)
        self.lam = torch.nn.Module()
        self.lam.decoder = torch.nn.Linear(1, 1, bias=False)
        self.flow = torch.nn.Linear(1, 1, bias=False)
        self.act_query = torch.nn.Parameter(torch.zeros(1))


class Policy(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.policy_backend = Backend()


class NativeEvaluationTests(unittest.TestCase):
    def test_deployment_loads_private_vlm_as_well_as_world_and_action(self):
        policy = Policy()
        checkpoint = {'state': {'vlm': {'weight': torch.tensor([[1.]])},
                                'world': {'weight': torch.tensor([[2.]])},
                                'action': {'weight': torch.tensor([[3.]])},
                                'aux': {'policy_backend.act_query': torch.tensor([4.])}}}
        with patch.object(evaluation, 'load_final_checkpoint', return_value=checkpoint), \
             patch.dict(sys.modules, {'acceptance': types.SimpleNamespace(
                 model=lambda: (policy, object(), object()), OUT=None)}):
            deployed, _, _ = evaluation.load_deployed_policy(
                '/unused', {'method': 'M1'}, 'lighting', '/unused')
        self.assertEqual(deployed.policy_backend.vlm.weight.item(), 1.)
        self.assertEqual(deployed.policy_backend.lam.decoder.weight.item(), 2.)
        self.assertEqual(deployed.policy_backend.flow.weight.item(), 3.)
        self.assertEqual(deployed.policy_backend.act_query.item(), 4.)
        self.assertFalse(any(parameter.requires_grad for parameter in deployed.parameters()))


if __name__ == '__main__':
    unittest.main()
