import tempfile,unittest
from pathlib import Path
import torch
from fedwam.federation_engine import FederationEngine

class ToyBackend:
 def initialize(self,client):return {'world':{'w':torch.tensor(float(ord(client[0])))},'action':{'a':torch.tensor(float(ord(client[0])*10))},'total_updates':0}
 def train(self,client,state,phase,steps,context,start,save):
  if phase=='post' and start==0 and context['kind']=='world':state['world']={k:v.clone() for k,v in context['world'].items()}
  for i in range(start,steps):
   if phase!='action':state['world']['w']+=1
   state['action']['a']+=state['world']['w']*.01;state['total_updates']+=1;save(i+1,state)
  return state
 def publish(self,client,state,round):return {'kind':'world','world':state['world']}
 def aggregate(self,exports,previous,round,workdir):return {'kind':'world','world':{'w':torch.stack([v['world']['w'] for v in exports.values()]).mean()}}
 def broadcast(self,server,client):return server

class EngineTests(unittest.TestCase):
 def config(self):return {'method':'M2','seed':42,'clients':['a','b'],'training':{'warmup':1,'rounds':2,'pre_receive_joint':2,'post_receive_joint':2,'final_world_action_only':1}}
 def test_complete_rounds_and_action_private(self):
  with tempfile.TemporaryDirectory() as tmp:
   e=FederationEngine(Path(tmp),{'method':'M2'},self.config(),ToyBackend());r=e.run()
   self.assertEqual(set(r['clients']),{'a','b'})
   a=e.store.read_ref(r['clients']['a'])['state'];b=e.store.read_ref(r['clients']['b'])['state']
   self.assertEqual(a['total_updates'],11);self.assertEqual(b['total_updates'],11)
   self.assertEqual(a['world']['w'],b['world']['w']);self.assertNotEqual(a['action']['a'],b['action']['a'])
 def test_interruption_after_server_restores_without_double_steps(self):
  with tempfile.TemporaryDirectory() as left,tempfile.TemporaryDirectory() as right:
   a=FederationEngine(Path(left),{'method':'M2'},self.config(),ToyBackend());a.run()
   def crash(stage):
    if stage=='round0:server_committed':raise RuntimeError('crash')
   b=FederationEngine(Path(right),{'method':'M2'},self.config(),ToyBackend(),fault_hook=crash)
   with self.assertRaisesRegex(RuntimeError,'crash'):b.run()
   b=FederationEngine(Path(right),{'method':'M2'},self.config(),ToyBackend());b.run()
   for client in ['a','b']:
    x=a.store.read_ref(a.store.latest()['clients'][client])['state'];y=b.store.read_ref(b.store.latest()['clients'][client])['state']
    self.assertTrue(torch.equal(x['world']['w'],y['world']['w']));self.assertTrue(torch.equal(x['action']['a'],y['action']['a']));self.assertEqual(x['total_updates'],y['total_updates'])
