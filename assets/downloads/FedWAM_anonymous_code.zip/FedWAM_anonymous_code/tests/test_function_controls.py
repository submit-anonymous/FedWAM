import unittest
import torch
from fedwam.function_controls import average_fixed_queries, future_from_prediction
class FunctionControlsTests(unittest.TestCase):
 def row(self,q,v):return {'query_id':q,'z':torch.ones(2,3),'intent':torch.zeros(1,32),'prediction':torch.full((2,3),float(v))}
 def test_same_queries_average_but_unrelated_queries_rejected(self):
  a=self.row('a',1);b=self.row('a',3)
  result=average_fixed_queries([[a],[b]])
  self.assertTrue(torch.equal(result[0]['prediction'],torch.full((2,3),2.)))
  with self.assertRaises(ValueError):average_fixed_queries([[a],[self.row('b',3)]])
  b['z']=torch.zeros(2,3)
  with self.assertRaises(ValueError):average_fixed_queries([[a],[b]])
 def test_future_delta_identity(self):
  z=torch.randn(2,3);future=torch.randn(2,3)
  torch.testing.assert_close(future_from_prediction(future-z,z,'transition'),future)
  torch.testing.assert_close(future_from_prediction(future,z,'future'),future)
