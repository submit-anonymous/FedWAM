import tempfile
import unittest
from pathlib import Path

from fedwam.io import load
from fedwam.round_runtime import atomic_json
from scripts.native_gpu_resource_watchdog import maybe_rollover


class NativeGpuResourceWatchdogTests(unittest.TestCase):
    def test_rolls_only_finished_resource_attempt_with_running_peer(self):
        with tempfile.TemporaryDirectory(prefix='engineering-v4-') as directory:
            run = Path(directory)/'M1'
            path = run/'resource_retries/camera_pose.json'
            atomic_json(path, {'client': 'camera_pose', 'count': 9, 'limit': 12})
            atomic_json(run/'client_job_state/camera_pose.json',
                        {'state': 'waiting_dependency', 'reason': 'allocated_gpu_occupied'})
            rows = [('fwfull-eng-M1-lighting', 'RUNNING')]
            self.assertTrue(maybe_rollover(path, rows))
            self.assertEqual(load(path)['count'], 0)
            audit = run/'resource_retries/camera_pose_operational_rollover_001.json'
            self.assertEqual(load(audit)['previous']['count'], 9)

    def test_never_resets_while_target_job_is_active(self):
        with tempfile.TemporaryDirectory(prefix='engineering-v4-') as directory:
            run = Path(directory)/'M1'
            path = run/'resource_retries/camera_pose.json'
            atomic_json(path, {'client': 'camera_pose', 'count': 9, 'limit': 12})
            atomic_json(run/'client_job_state/camera_pose.json',
                        {'state': 'waiting_dependency', 'reason': 'allocated_gpu_occupied'})
            rows = [('fwfull-eng-M1-lighting', 'RUNNING'),
                    ('fwfull-eng-M1-camera_pose', 'RUNNING')]
            self.assertFalse(maybe_rollover(path, rows))
            self.assertEqual(load(path)['count'], 9)


if __name__ == '__main__':
    unittest.main()
