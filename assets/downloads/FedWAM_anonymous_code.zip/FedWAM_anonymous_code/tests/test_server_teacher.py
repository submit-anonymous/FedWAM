"""Spatial conditional fitting, source separation, bounded replay, exact restart."""
import unittest
import torch
from fedwam import server_teacher as st
from test_packets import record


def records(round=0):
    result=[]
    for c in range(2):
        for g in range(6):
            r=record(f'q{g}',f'g{g}',f'c{c}',round)
            r['z']=torch.full((3,4),g/5.)
            r['intent'][0,c]=1
            r['prediction']=r['z']*.3 + c*.5
            result.append(r)
    return result


def config(steps=4):
    return dict(tokens=3,dim=4,width=8,depth=1,heads=2,branches=1,steps=steps,
                batch_size=4,lr=.01,device='cpu',checkpoint_every=1)


class TeacherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1)

    def test_spatial_outputs_and_conditional_branch_not_mean(self):
        for branches in [1,2,4]:
            model=st.ConditionalTeacher(dict(config(),branches=branches))
            z=torch.randn(2,3,4);intent=torch.randn(2,1,32)
            output=model(z,intent)
            self.assertEqual(output['means'].shape,(2,branches,3,4))
            self.assertTrue((output['logvar']>=-6).all() and (output['logvar']<=2).all())
            prediction=model.predict(z,intent)
            chosen=output['means'][torch.arange(2),output['logits'].argmax(-1)]
            torch.testing.assert_close(prediction,chosen)
            loss=st.teacher_loss(output,torch.zeros_like(z)).mean();loss.backward()
            self.assertGreater(model.intent_projection.weight.grad.abs().sum().item(),0)
        self.assertFalse(torch.equal(model(z,intent)['means'],model(z,intent+1)['means']))

    def test_loss_has_element_normalization(self):
        output=dict(means=torch.ones(2,1,3,4),logits=torch.zeros(2,1),logvar=torch.zeros(2,1,3,4))
        torch.testing.assert_close(st.teacher_loss(output,torch.zeros(2,3,4)),torch.ones(2))
        output={k: v.repeat_interleave(2,dim=1) for k,v in output.items()}
        wanted=torch.full((2,),.5+.5*torch.log(torch.tensor(2*torch.pi)))
        torch.testing.assert_close(st.teacher_loss(output,torch.zeros(2,3,4)),wanted)

    def test_server_resume_matches_uninterrupted_model_and_optimizer(self):
        checkpoints=[]
        expected=st.train_teacher(records(),config(),17)
        class Interrupted(Exception):pass
        def checkpoint(state):
            checkpoints.append(state)
            if state['steps']==2:raise Interrupted()
        with self.assertRaises(Interrupted):st.train_teacher(records(),config(),17,checkpoint_callback=checkpoint)
        resumed=st.train_teacher(records(),config(),17,previous=checkpoints[-1])
        for key,value in expected['model'].items():torch.testing.assert_close(value,resumed['model'][key],rtol=0,atol=0)
        self.assertEqual(resumed['steps'],4)
        self.assertTrue(set(map(tuple,resumed['metrics']['train_groups'])).isdisjoint(set(map(tuple,resumed['metrics']['validation_groups']))))
        self.assertGreater(resumed['metrics']['validation_queries'],0)
        self.assertTrue(torch.isfinite(st.infer_teacher(resumed,torch.zeros(2,3,4),torch.zeros(2,1,32))).all())

    def test_balancing_and_replay_drop_old_rounds(self):
        small=records()
        larger=small+[dict(small[0],query_id=f'extra{i}') for i in range(20)]
        weights=st.balanced_weights(larger)
        for client in ['c0','c1']:
            self.assertAlmostEqual(sum(float(w) for r,w in zip(larger,weights) if r['client']==client),.5,places=6)
        previous=None
        for r in range(5):previous=st.train_teacher(records(r),config(1),17,previous=previous)
        self.assertEqual(sorted(set(r['round'] for r in previous['replay'])),[1,2,3,4])
        self.assertEqual(previous['total_steps'],5)
        bad=records(5);bad[0]['interface_version']='wrong'
        with self.assertRaises(ValueError):st.train_teacher(bad,config(1),17,previous=previous)

    def test_fits_public_predictions(self):
        artifact=st.train_teacher(records(),config(80),9)
        self.assertLess(artifact['metrics']['train_mse'],.1)

class TeacherBoundaryTests(unittest.TestCase):
    def test_heldout_groups_never_move_to_training_across_rounds(self):
        previous=st.train_teacher(records(),config(1),17)
        old_train=set(map(tuple,previous['metrics']['train_groups']))
        old_validation=set(map(tuple,previous['metrics']['validation_groups']))
        new=records(1)
        for i in range(50):new.append(record(f'new{i}',f'newgroup{i}','c0',1))
        current=st.train_teacher(new,config(1),17,previous=previous)
        self.assertFalse(old_train & set(map(tuple,current['metrics']['validation_groups'])))
        self.assertFalse(old_validation & set(map(tuple,current['metrics']['train_groups'])))

    def test_interrupted_restart_rejects_changed_sampling_settings(self):
        checkpoints=[]
        class Interrupted(Exception):pass
        def callback(a):
            checkpoints.append(a)
            raise Interrupted()
        with self.assertRaises(Interrupted):st.train_teacher(records(),config(),17,checkpoint_callback=callback)
        with self.assertRaises(ValueError):st.train_teacher(records(),dict(config(),batch_size=8),17,previous=checkpoints[-1])

    def test_loading_teacher_preserves_private_rng(self):
        artifact=st.train_teacher(records(),config(1),17)
        before=torch.get_rng_state().clone()
        st.load_teacher(artifact)
        self.assertTrue(torch.equal(before,torch.get_rng_state()))

    def test_conflicting_source_version_predictions_are_rejected(self):
        inputs=records();inputs.append(dict(inputs[0],prediction=torch.full((3,4),99.)))
        with self.assertRaises(ValueError):st.train_teacher(inputs,config(1),17)

class ReplayBalanceTests(unittest.TestCase):
    def test_replay_rounds_are_balanced_within_source_group(self):
        rows=[record(f'q{i}','group','client',0) for i in range(9)]
        rows.append(record('q-last','group','client',1))
        weights=st.balanced_weights(rows)
        self.assertAlmostEqual(float(weights[-1]),.5)

    def test_same_source_round_cannot_claim_two_model_versions(self):
        rows=records();rows[0]['model_version']='different-world'
        with self.assertRaises(ValueError):st.train_teacher(rows,config(1),17)

class GlobalAncestryValidationTests(unittest.TestCase):
    def test_shared_ancestry_cannot_cross_server_train_validation_clients(self):
        artifact=st.train_teacher(records(),config(1),17)
        train={group for client,group in artifact['metrics']['train_groups']}
        validation={group for client,group in artifact['metrics']['validation_groups']}
        self.assertTrue(validation)
        self.assertFalse(train & validation)
        incoming=records(1)
        for i in range(20):incoming.append(record(f'new{i}',f'newgroup{i}','c0',1))
        next_artifact=st.train_teacher(incoming,config(1),17,previous=artifact)
        next_train={group for client,group in next_artifact['metrics']['train_groups']}
        next_validation={group for client,group in next_artifact['metrics']['validation_groups']}
        self.assertFalse(next_train & next_validation)
        self.assertFalse(train & next_validation)
        self.assertFalse(validation & next_train)

class TeacherCheckpointBoundaryTests(unittest.TestCase):
    def test_cross_representation_cannot_enter_via_packets_or_checkpoint_replay(self):
        inputs=records()
        for r in inputs:r['interface_version']='frozen:future'
        previous=st.train_teacher(inputs,config(1),17)
        changed=records(1)
        for r in changed:r['interface_version']='frozen:transition'
        with self.assertRaises(ValueError):st.train_teacher(changed,config(1),17,previous=previous)
        previous['replay'][0]['interface_version']='frozen:transition'
        for r in changed:r['interface_version']='frozen:future'
        with self.assertRaises(ValueError):st.train_teacher(changed,config(1),17,previous=previous)

    def test_missing_persistent_group_assignment_rejected(self):
        previous=st.train_teacher(records(),config(1),17)
        previous['group_assignments'].pop(next(iter(previous['group_assignments'])))
        with self.assertRaises(ValueError):st.train_teacher(records(1),config(1),17,previous=previous)

    def test_serialized_callback_preserves_global_partition_and_exact_resume(self):
        import io
        states=[]
        class Interrupted(Exception):pass
        def callback(state):
            stream=io.BytesIO();torch.save(state,stream);stream.seek(0)
            states.append(torch.load(stream,weights_only=True))
            raise Interrupted()
        with self.assertRaises(Interrupted):st.train_teacher(records(),config(3),17,checkpoint_callback=callback)
        saved=states[0]
        resumed=st.train_teacher(records(),config(3),17,previous=saved)
        expected=st.train_teacher(records(),config(3),17)
        self.assertEqual(saved['group_assignments'],resumed['group_assignments'])
        for name,value in expected['model'].items():torch.testing.assert_close(value,resumed['model'][name],rtol=0,atol=0)
        subsequent=st.train_teacher(records(1),config(1),17,previous=resumed)
        self.assertEqual(resumed['group_assignments'],subsequent['group_assignments'])
        for round in range(2,6):
            incoming=records(round)
            for row in incoming:row['source_group']=f"round{round}-{row['source_group']}"
            subsequent=st.train_teacher(incoming,config(1),17,previous=subsequent)
        self.assertFalse(any(row['source_group']=='g0' for row in subsequent['replay']))
        returned=st.train_teacher(records(6),config(1),17,previous=subsequent)
        for group,assignment in saved['group_assignments'].items():
            self.assertEqual(returned['group_assignments'][group],assignment)
