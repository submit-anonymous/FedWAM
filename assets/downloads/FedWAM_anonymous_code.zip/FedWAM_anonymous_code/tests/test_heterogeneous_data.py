import unittest
from fedwam.heterogeneous.data import allocate_sources, partition_records


def rows():
    return [dict(source_group=f'{task}-{i}', task=task, suite='suite', split='train',
                 client=client, record_id=f'{client}:{task}:{i}', chunk_count=10)
            for task in ('one', 'two') for i in range(20) for client in ('light', 'noise')]


class SourceSplitTest(unittest.TestCase):
    def test_reordering_does_not_change_source_allocations(self):
        self.assertEqual(allocate_sources(rows()), allocate_sources(rows()[::-1]))

    def test_task_balanced_private_disjoint_public_and_heldout_preserved(self):
        records = rows() + [dict(source_group='held', task='one', suite='suite',
                                split='development', client='light', record_id='dev', chunk_count=10)]
        result = partition_records(records)
        groups = {k: {r['source_group'] for r in result[k]} for k in ('A', 'B', 'public', 'heldout')}
        for a in groups:
            for b in groups:
                if a != b:
                    self.assertFalse(groups[a] & groups[b])
        self.assertEqual(len(result['heldout']), 1)
        self.assertEqual(len(groups['public']), 2)
        for task in ('one', 'two'):
            counts = [len({r['source_group'] for r in result[k] if r['task'] == task}) for k in ('A', 'B')]
            self.assertLessEqual(abs(counts[0] - counts[1]), 1)

    def test_source_leakage_and_ambiguous_task_rejected(self):
        for change in ({'split': 'prediction_test'}, {'task': 'different'}):
            original = rows()
            original.append(dict(original[0], **change))
            with self.assertRaises(ValueError):
                partition_records(original)


if __name__ == '__main__':
    unittest.main()
