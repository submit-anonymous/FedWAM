import unittest
from fedwam import manifest as m
class ManifestTests(unittest.TestCase):
    def test_duplicate_variant_is_rejected(self):
        rows=[{'variant_id':'s:1'},{'variant_id':'s:1'}]
        with self.assertRaises(ValueError):m.partition_exposure(rows,set())
    def test_previous_and_engineering_cases_are_not_confirmatory(self):
        a,b,c=m.partition_exposure([{'variant_id':'s:1'},{'variant_id':'s:2'},{'variant_id':'s:3'}],{'s:1','s:2'})
        self.assertEqual(len(a),3);self.assertEqual([x['variant_id'] for x in b],['s:1','s:2'])
        self.assertEqual([x['variant_id'] for x in c],['s:3'])
    def test_unknown_history_is_reported_not_silently_discarded(self):
        with self.assertRaises(ValueError):m.partition_exposure([{'variant_id':'s:1'}],{'s:4'})
if __name__=='__main__':unittest.main()
