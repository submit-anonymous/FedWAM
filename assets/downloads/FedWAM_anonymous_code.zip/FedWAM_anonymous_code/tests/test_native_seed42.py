import unittest
from unittest.mock import patch

from fedwam.native_federation import native_config
from fedwam.native_execution import native_gate
from fedwam.experiment_config import METHODS


class NativeSeed42Tests(unittest.TestCase):
    def test_active_seed_matches_user_scope_for_every_method(self):
        for method in METHODS:
            self.assertEqual(native_config(method, 'formal')['seed'], 42)
            self.assertEqual(native_config(method, 'engineering', seed=42)['seed'], 42)

    def test_inactive_seeds_cannot_be_started(self):
        for seed in (43, 44):
            with self.assertRaises(ValueError):
                native_config('M1', 'formal', seed=seed)

    def test_gate_rejects_other_seed_even_when_other_fields_match(self):
        keys = ('code', 'data_identity', 'checkpoint_sha256', 'normalization_sha256',
                'protocol_sha256', 'model_config_sha256', 'native_protocol_sha256', 'execution')
        identity = dict.fromkeys(keys, 'matching')
        receipt = dict(identity, passed=True, seed=42,
                       mode='real_detached_client_engineering', methods_passed=list(METHODS))
        with patch('fedwam.native_execution.native_identity', return_value=identity):
            native_gate({'seed': 42}, receipt)
            for old_seed in (None, 43, 44):
                with self.assertRaises(ValueError):
                    native_gate({'seed': 42}, dict(receipt, seed=old_seed))


if __name__ == '__main__':
    unittest.main()
