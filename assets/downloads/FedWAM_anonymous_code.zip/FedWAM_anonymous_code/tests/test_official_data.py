import unittest
from fedwam import official_data as d

class OfficialDataContracts(unittest.TestCase):
    def fixture(self):
        rows=[]
        for client,bucket in d.CLIENT_BUCKETS.items():
            for i,split in enumerate(['train']*7+['calibration']*2+['development','prediction_test']):
                rows.append(dict(record_id=f'{client}/{i}',source_group=f'g{i}',suite='suite',source_file='task',
                    source_bucket=bucket,client=client,split=split,continuous_chunk_starts=[0,1]))
        return rows

    def test_calibration_promotes_shared_groups_without_touching_test_or_exposure(self):
        rows=self.fixture();new,promotions=d.repair_calibration(rows,{'g0'},seed=42,minimum=5)
        self.assertEqual(len(promotions),3)
        for row in new:
            if row['source_group']=='g0':self.assertEqual(row['split'],'train')
            if row['source_group']=='g9':self.assertEqual(row['split'],'development')
            if row['source_group']=='g10':self.assertEqual(row['split'],'prediction_test')
        for client in d.CLIENT_BUCKETS:
            self.assertEqual(len({r['source_group'] for r in new if r['client']==client and r['split']=='calibration'}),5)
        self.assertEqual(d.repair_calibration(list(reversed(rows)),{'g0'},seed=42,minimum=5)[1],promotions)
        self.assertTrue(all(r['split']=='train' for r in rows if r['source_group']=='g1'))

    def test_calibration_does_not_duplicate_groups_to_fill_missing_clients(self):
        rows=[r for r in self.fixture() if r['client']!='sensor_noise' or r['split']!='train']
        with self.assertRaisesRegex(ValueError,'calibration'):d.repair_calibration(rows,{'g0'},42,5)

    def test_split_leakage_rejected(self):
        rows=self.fixture();rows[0]=dict(rows[0],split='prediction_test')
        with self.assertRaisesRegex(ValueError,'cross-split'):d.validate_groups(rows)

    def test_continuous_endpoint_needed_and_temporal_gaps_rejected(self):
        self.assertEqual(d.valid_starts(list(range(9)),9,8),[0])
        self.assertEqual(d.valid_starts(list(range(8)),8,8),[])
        self.assertEqual(d.valid_starts([0,1,2,3,4,6,7,8,9,10],10,8),[])
        with self.assertRaises(ValueError):d.valid_starts(list(range(10)),9,8)

    def test_draw_reproducible_task_group_and_start_legal(self):
        rows=self.fixture();a=d.ChunkSampler(rows,'background','train',42);b=d.ChunkSampler(list(reversed(rows)),'background','train',42)
        selected=[a.draw(i) for i in range(50)]
        self.assertEqual([(r['record_id'],t) for r,t in selected],[(r['record_id'],t) for r,t in [b.draw(i) for i in range(50)]])
        self.assertTrue(all(r['split']=='train' and r['client']=='background' and t in r['continuous_chunk_starts'] for r,t in selected))
        self.assertGreater(len({r['source_group'] for r,t in selected}),1)

if __name__=='__main__':unittest.main()

class IndexedChunkReaderContracts(unittest.TestCase):
    def make_episode(self,path,pixel_shift=0):
        import io,struct
        import numpy as np
        import google_crc32c
        from PIL import Image
        from fedwam.rlds import parse_episode
        def varint(n):
            out=bytearray()
            while n>127:out.append((n&127)|128);n>>=7
            out.append(n);return bytes(out)
        def field(n,payload):return varint((n<<3)|2)+varint(len(payload))+payload
        def bytes_feature(values):return field(1,b''.join(field(1,v) for v in values))
        def floats_feature(array):return field(2,field(1,np.asarray(array,dtype='<f4').tobytes()))
        frames=[]
        for i in range(10):
            out=io.BytesIO();Image.fromarray(np.full((4,4,3),i+pixel_shift,dtype=np.uint8)).save(out,format='PNG');frames.append(out.getvalue())
        features={'episode_metadata/file_path':bytes_feature([b'/pro_data/env/libero_10/task_demo.hdf5']),
            'steps/language_instruction':bytes_feature([b'put cup on plate']*10),
            'steps/action':floats_feature(np.arange(70).reshape(10,7)),
            'steps/observation/state':floats_feature(np.zeros((10,8))),
            'steps/observation/image':bytes_feature(frames),'steps/observation/wrist_image':bytes_feature(frames)}
        payload=field(1,b''.join(field(1,field(1,k.encode())+field(2,v)) for k,v in features.items()))
        def crc(b):
            v=google_crc32c.value(b);return struct.pack('<I',(((v>>15)|(v<<17))+0xa282ead8)&0xffffffff)
        header=struct.pack('<Q',len(payload));path.write_bytes(header+crc(header)+payload+crc(payload))
        return dict(parse_episode(payload),shard=str(path),offset=0,record_id='fixture',
            source_group='g',client='background',split='train',continuous_chunk_starts=[0,1],
            payload_sha256=__import__('hashlib').sha256(payload).hexdigest())

    def test_real_encoded_record_endpoint_action_alignment_and_crc(self):
        import tempfile
        from pathlib import Path
        import numpy as np
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'record';row=self.make_episode(path)
            reader=d.RawChunkReader();sample=reader.read(row,1)
            self.assertEqual(sample['primary'][0,0,0],1)
            self.assertEqual(sample['future'][0,0,0],9)
            np.testing.assert_array_equal(sample['actions'],np.arange(70).reshape(10,7)[1:9])
            with self.assertRaisesRegex(ValueError,'continuous'):reader.read(row,2)
            content=bytearray(path.read_bytes());content[-5]^=1;path.write_bytes(content)
            with self.assertRaisesRegex(ValueError,'CRC'):d.RawChunkReader().read(row,0)

    def test_record_identity_cannot_be_swapped(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            row=self.make_episode(Path(tmp)/'record');row['task']='wrong instruction'
            with self.assertRaisesRegex(ValueError,'identity'):d.RawChunkReader().read(row,0)

    def test_rgb_replacement_with_valid_crc_is_rejected(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'record';old=self.make_episode(path)
            self.make_episode(path,pixel_shift=100)
            with self.assertRaisesRegex(ValueError,'payload SHA'):d.RawChunkReader().read(old,0)

    def test_cached_record_identity_is_still_validated(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            row=self.make_episode(Path(tmp)/'record');reader=d.RawChunkReader()
            reader.read(row,0)
            changed=dict(row,task='wrong instruction')
            with self.assertRaisesRegex(ValueError,'identity'):reader.read(changed,0)
