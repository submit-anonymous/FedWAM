import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from residual_finalize import validate_domains,graph_matches


class ResidualFinalizeTest(unittest.TestCase):
    def test_requires_exact_four_distinct_domains(self):
        rows=[dict(domain=x) for x in ('lighting','camera_pose','sensor_noise','background')]
        validate_domains(rows)
        for invalid in (rows[:3],rows+[rows[0]],rows[:3]+[rows[0]]):
            with self.assertRaises(ValueError):validate_domains(invalid)

    def test_requires_finite_graph_and_exact_head_identity(self):
        row=dict(domain='lighting',sha256='abc')
        graph=dict(passed=True,seed=42,domain='lighting',artifact_sha256='imagewam-native1000-residual-abc',
            future_label_effect=0.,action_unchanged=True,head_frozen=True,world_gradient_norm=1.,prediction_change=.1,action_change=.01)
        self.assertTrue(graph_matches(row,graph))
        for key,value in [('domain','background'),('artifact_sha256','stale'),('world_gradient_norm',float('inf')),
                          ('action_change',float('nan')),('prediction_change',0.),('seed',43)]:
            self.assertFalse(graph_matches(row,dict(graph,**{key:value})))


if __name__=='__main__':unittest.main()
