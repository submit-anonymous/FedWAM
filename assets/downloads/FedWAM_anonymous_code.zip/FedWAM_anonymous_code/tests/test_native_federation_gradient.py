import unittest
from types import SimpleNamespace
from unittest.mock import patch
import sys

import torch

from fedwam.native_federation import NativeLaWAMFederation
from fedwam.io import ROOT

sys.path.insert(0, str(ROOT/'third_party/LaWAM'))


class FakeBackend:
    def __init__(self):
        self.decoder = torch.nn.Linear(2, 1, bias=False)

    def _decode_future_tokens_strict_single_query(self, *, h_t, pred_action_emb, source):
        return self.decoder(torch.cat((h_t, pred_action_emb), -1))


class NativeFederationGradientTests(unittest.TestCase):
    def test_fixed_public_query_accepts_half_precision_packet_and_updates_world(self):
        backend = FakeBackend()
        federation = object.__new__(NativeLaWAMFederation)
        federation.b = backend
        federation.device = torch.device('cpu')
        federation.representation = 'future'
        row = {'z': torch.tensor([1.], dtype=torch.float16),
               'intent': torch.tensor([2.], dtype=torch.float16),
               'prediction': torch.tensor([3.], dtype=torch.float16)}
        loss = federation.fixed_query_loss(row)
        self.assertTrue(torch.isfinite(loss))
        loss.backward()
        self.assertIsNotNone(backend.decoder.weight.grad)

    def test_federated_teacher_updates_world_only_not_private_intent(self):
        backend = FakeBackend()
        federation = object.__new__(NativeLaWAMFederation)
        federation.b = backend
        z = torch.tensor([[1.]], requires_grad=True)
        intent = torch.tensor([[2.]], requires_grad=True)
        prediction = federation.world_prediction_only(z, intent)
        prediction.square().sum().backward()
        self.assertIsNone(z.grad)
        self.assertIsNone(intent.grad)
        self.assertIsNotNone(backend.decoder.weight.grad)

    def test_adapter_method_keeps_base_world_frozen_under_official_freeze(self):
        class Backend(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.vlm = torch.nn.Linear(1, 1)
                self.lam = torch.nn.Module()
                self.lam.decoder = torch.nn.Sequential(
                    torch.nn.Linear(1, 1), torch.nn.Linear(1, 1))
                self.flow = torch.nn.Linear(1, 1)
                self.act_query = torch.nn.Parameter(torch.ones(1))
                self.vlm_to_lam = torch.nn.Linear(1, 1)

        class Policy(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.policy_backend = Backend()

        policy = Policy()
        backend = policy.policy_backend
        federation = object.__new__(NativeLaWAMFederation)
        federation.policy = policy
        federation.b = backend
        federation.adapter = True
        federation.official = SimpleNamespace(trainer=SimpleNamespace(freeze={}))
        federation.initial_trainable = {name for name, parameter in policy.named_parameters()
                                        if parameter.requires_grad}
        adapter = backend.lam.decoder[0].weight

        def configure(_, **kwargs):
            backend.lam.decoder.requires_grad_(kwargs['world'])
            backend.flow.requires_grad_(kwargs['action'])
            return backend

        def apply(_, __):
            backend.lam.decoder.requires_grad_(True)

        with patch('fedwam.lawam_federation.configure', side_effect=configure), \
             patch('fedwam.lawam_federation.adapter_parameters', return_value=[adapter]), \
             patch('fedwam.native_federation.adapter_parameters', return_value=[adapter]), \
             patch('starVLA.model.framework.latent_world.runtime.freeze_policy.apply_policy_freeze',
                   side_effect=apply):
            world, action, vlm, auxiliary = federation._enable('pre')
        self.assertEqual(world, [adapter])
        self.assertTrue(adapter.requires_grad)
        self.assertFalse(backend.lam.decoder[1].weight.requires_grad)
        self.assertTrue(action and vlm and auxiliary)
        self.assertTrue(backend.vlm.weight.requires_grad)
        self.assertTrue(backend.act_query.requires_grad)
        self.assertIn(backend.act_query, auxiliary)


if __name__ == '__main__':
    unittest.main()
