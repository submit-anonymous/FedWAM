import unittest
import torch
from fedwam import training as t
class TrainingContracts(unittest.TestCase):
    def test_only_physical_chunk_dimensions_are_supervised(self):
        stats={'min':[-1]*7,'max':[1]*7,'mask':[True]*6+[False]}
        a=torch.zeros(8,7);a[:,-1]=1
        result=t.action_tensors(a.numpy(),stats)
        self.assertEqual(tuple(result['actions'].shape),(1,50,32))
        self.assertEqual(result['actions_mask'].sum().item(),56)
        self.assertFalse(result['actions_mask'][:,8:].any())
        self.assertFalse(result['actions_mask'][:,:,7:].any())
        self.assertTrue((result['actions'][0,:8,-26]==1).all())
    def test_future_condition_action_gradient_toggle(self):
        w=torch.nn.Linear(2,2,bias=False);a=torch.nn.Linear(2,1,bias=False)
        x=torch.tensor([[1.,2.]])
        a(t.control_condition(w(x),detach=False)).square().sum().backward()
        self.assertGreater(w.weight.grad.norm().item(),0)
        w.zero_grad(set_to_none=True);a.zero_grad(set_to_none=True)
        a(t.control_condition(w(x),detach=True)).square().sum().backward()
        self.assertIsNone(w.weight.grad)
    def test_normalization_rejects_wrong_semantics(self):
        with self.assertRaises(ValueError):t.action_tensors(torch.zeros(8,7).numpy(),{'min':[-1]*7,'max':[1]*7,'mask':[True]*7})
if __name__=='__main__':unittest.main()
