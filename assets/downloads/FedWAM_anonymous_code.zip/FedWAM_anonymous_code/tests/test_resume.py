import unittest
from fedwam import evaluation as e
class EvaluationTests(unittest.TestCase):
    def test_changed_checkpoint_or_protocol_cannot_reuse_success(self):
        r={'identity':{'checkpoint':'a','protocol':'p'},'completed':True,'error':None,'success':False}
        self.assertTrue(e.reusable(r,{'checkpoint':'a','protocol':'p'}))
        with self.assertRaises(ValueError):e.reusable(r,{'checkpoint':'b','protocol':'p'})
    def test_error_is_never_counted_as_a_completed_rollout(self):
        self.assertFalse(e.reusable({'identity':{},'completed':True,'error':'simulation crash','success':False},{}))
    def test_parallel_shards_cover_all_cases_without_overlap(self):
        rows=list(range(23));parts=[e.partition(rows,i,4) for i in range(4)]
        self.assertEqual(sorted(x for part in parts for x in part),rows)
        self.assertEqual(parts[0],[0,4,8,12,16,20])
