import importlib.util
from pathlib import Path
import unittest
import numpy as np
import tempfile
import torch

PATH = Path(__file__).resolve().parents[1] / 'scripts/imagewam_model_acceptance.py'
spec = importlib.util.spec_from_file_location('imagewam_acceptance', PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class AcceptanceTest(unittest.TestCase):
    def test_actions_require_exact_horizon_and_finite_values(self):
        self.assertEqual(module.action_summary(np.zeros((16, 7)), 16)['shape'], [16, 7])
        for value in (np.zeros((8, 7)), np.full((16, 7), np.nan), np.zeros((16, 8))):
            with self.assertRaises(ValueError):
                module.action_summary(value, 16)

    def test_partial_policy_load_fails_closed(self):
        module.check_keys([], [])
        for missing, unexpected in ((['action.weight'], []), ([], ['obsolete'])):
            with self.assertRaises(ValueError):
                module.check_keys(missing, unexpected)

    def test_numpy_initial_state_compatibility_is_scoped(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'states.pt'
            torch.save(np.zeros((2, 8), dtype=np.float64), path)
            before = list(torch.serialization.get_safe_globals())
            result = module.load_initial_states(lambda: torch.load(path))
            self.assertEqual(result.shape, (2, 8))
            self.assertCountEqual(before, torch.serialization.get_safe_globals())

    def test_numpy_loader_preserves_existing_allowlist(self):
        with torch.serialization.safe_globals([np.ndarray]):
            module.load_initial_states(lambda: None)
            self.assertIn(np.ndarray, torch.serialization.get_safe_globals())

    def test_benchmark_path_is_string_for_plus_wrapper(self):
        from types import SimpleNamespace
        observed = {}
        class Env:
            def __init__(self, **kwargs):
                observed.update(kwargs)
            def seed(self, seed):
                observed['seed'] = seed
        task = SimpleNamespace(problem_folder='libero_spatial', bddl_file='x.bddl', language='x')
        module.make_env(task, 256, 42, env_class=Env, bddl_root=Path('/tmp/bddl'))
        self.assertIsInstance(observed['bddl_file_name'], str)
        self.assertEqual(observed['seed'], 42)


if __name__ == '__main__':
    unittest.main()
