import tempfile,unittest
from pathlib import Path
from fedwam.work_queue import WorkQueue
class QueueTests(unittest.TestCase):
 def test_dependency_exclusivity_resume_and_failed_descendants(self):
  with tempfile.TemporaryDirectory() as tmp:
   tasks=[{'id':'train','kind':'train','depends':[],'argv':['true']},{'id':'eval','kind':'rollout','depends':['train'],'argv':['true']}]
   q=WorkQueue(Path(tmp),tasks)
   self.assertEqual(q.claim('one')['id'],'train');self.assertIsNone(q.claim('two'))
   self.assertEqual(q.claim('one')['id'],'train');q.finish('one','train',0)
   self.assertEqual(q.claim('two')['id'],'eval');q.finish('two','eval',1)
   self.assertTrue(q.finished());self.assertEqual(q.summary()['failed'],1)
 def test_changed_task_plan_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   WorkQueue(Path(tmp),[{'id':'a','kind':'train','depends':[],'argv':['true']}])
   with self.assertRaises(ValueError):WorkQueue(Path(tmp),[{'id':'a','kind':'train','depends':[],'argv':['false']}])
 def test_explicit_retry_preserves_completed_dependencies(self):
  with tempfile.TemporaryDirectory() as tmp:
   q=WorkQueue(Path(tmp),[{'id':'train','kind':'train','depends':[],'argv':['true']},{'id':'eval','kind':'rollout','depends':['train'],'argv':['true']}])
   q.claim('one');q.finish('one','train',1);self.assertIsNone(q.claim('two'))
   self.assertEqual(q.summary()['blocked'],1)
   q.retry('train');self.assertEqual(q.claim('three')['id'],'train');q.finish('three','train',0)
   self.assertEqual(q.claim('three')['id'],'eval')
