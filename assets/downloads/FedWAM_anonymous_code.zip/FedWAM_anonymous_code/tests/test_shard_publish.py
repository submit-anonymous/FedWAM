import concurrent.futures
from pathlib import Path
import tempfile,threading,unittest,zlib
from unittest.mock import patch
from fedwam import data_contracts as d

class PublishTests(unittest.TestCase):
    def test_concurrent_official_filenames_keep_distinct_verified_contents(self):
        with tempfile.TemporaryDirectory() as directory:
            files=[Path(directory)/f'libero_mix-train.tfrecord-{i:05d}-of-01024' for i in range(4)]
            payloads=[bytes([i])*4096 for i in range(4)]
            barrier=threading.Barrier(4);original=d.verify_file
            def checked(*args):
                barrier.wait(timeout=10)
                return original(*args)
            with patch.object(d,'verify_file',checked):
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    futures=[pool.submit(d.publish_shard,p,b,len(b),zlib.crc32(b)) for p,b in zip(files,payloads)]
                    for future in futures:future.result()
            for p,b in zip(files,payloads):self.assertEqual(p.read_bytes(),b)
            self.assertEqual(set(Path(directory).iterdir()),set(files))
    def test_invalid_new_payload_cannot_replace_existing_good_shard(self):
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'libero_mix-train.tfrecord-00001-of-01024';p.write_bytes(b'good')
            with self.assertRaises(ValueError):d.publish_shard(p,b'bad!',4,zlib.crc32(b'good'))
            self.assertEqual(p.read_bytes(),b'good')
            self.assertEqual(list(Path(directory).iterdir()),[p])
