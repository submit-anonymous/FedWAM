import unittest
import numpy as np
from fedwam.provenance import ordered_action_match, continuous_starts, allocate_groups, state_matches

class ProvenanceTests(unittest.TestCase):
    def test_subsequence_preserves_dropped_steps(self):
        original=np.arange(84,dtype=float).reshape(12,7)/100
        indices=ordered_action_match(original[[0,1,3,4,5,6,7,8,9,10,11]],original)
        self.assertEqual(indices,list([0,1,3,4,5,6,7,8,9,10,11]))
        self.assertEqual(continuous_starts(indices,8),[2])
    def test_wrong_order_or_different_actions_fail(self):
        a=np.arange(70,dtype=float).reshape(10,7)
        self.assertIsNone(ordered_action_match(a[::-1],a))
        self.assertIsNone(ordered_action_match(a+0.01,a))
    def test_terminal_observation_is_required(self):
        self.assertEqual(continuous_starts(list(range(8)),8),[])
        self.assertEqual(continuous_starts(list(range(9)),8),[0])
    def test_split_is_order_invariant_and_keeps_exposure_out_of_test(self):
        groups=[{'group':str(i),'stratum':'task','exposed':i==3} for i in range(50)]
        a=allocate_groups(groups,42);b=allocate_groups(groups[::-1],42)
        self.assertEqual(a,b);self.assertEqual(a['3'],'train')
        from collections import Counter
        self.assertEqual(Counter(a.values()),dict(train=35,calibration=5,development=5,prediction_test=5))
    def test_duplicate_group_fails_instead_of_overwriting(self):
        g={'group':'same','stratum':'t','exposed':False}
        with self.assertRaises(ValueError):allocate_groups([g,g],42)
    def test_state_comparison_ignores_clock_not_physics(self):
        a=np.array([0.,1.,2.,3.]);b=np.stack([a,a,a]);b[0,0]=10;b[1,2]+=.01
        self.assertEqual(state_matches(a,b),[0,2])
        self.assertEqual(state_matches(a,np.ones((2,5))),[])

if __name__=='__main__':unittest.main()
