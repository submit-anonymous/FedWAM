import json
import tempfile
import unittest

import torch

from fedwam.native_retention import compact_native_run
from fedwam.round_runtime import RoundStore, atomic_json


class NativeRetentionTests(unittest.TestCase):
    def test_compaction_keeps_all_private_deployed_modules_and_drops_optimizers(self):
        with tempfile.TemporaryDirectory() as directory:
            ident = {'schema': 'fedwam.run.v1', 'method': 'M1', 'seed': 43}
            store = RoundStore(directory, ident)
            private = {'vlm': {'w': torch.tensor([1.])},
                       'world': {'w': torch.tensor([2.])},
                       'action': {'w': torch.tensor([3.])},
                       'aux': {'policy_backend.act_query': torch.tensor([4.])},
                       'vlm_optimizer': {'large': torch.ones(3)},
                       'world_optimizer': {'large': torch.ones(3)},
                       'action_optimizer': {'large': torch.ones(3)},
                       'aux_optimizer': {'large': torch.ones(3)}}
            ref = store.write('phases/r0000/lighting/post.pt',
                              {'schema': 'fedwam.client.v1', 'identity': ident,
                               'method': 'M1', 'seed': 43, 'client': 'lighting',
                               'done': 2, 'steps': 2, 'state': private})
            atomic_json(store.path('verification.json'), {'passed': True, 'identity': ident})
            atomic_json(store.path('final.json'),
                        {'identity': ident, 'method': 'M1', 'seed': 43,
                         'clients': {'lighting': ref}, 'rounds': 1})
            final = compact_native_run(directory, ident)
            checkpoint = store.read_ref(final['clients']['lighting'])
            self.assertEqual(checkpoint['state']['vlm']['w'].item(), 1.)
            self.assertEqual(checkpoint['state']['world']['w'].item(), 2.)
            self.assertEqual(checkpoint['state']['action']['w'].item(), 3.)
            self.assertEqual(checkpoint['state']['aux']['policy_backend.act_query'].item(), 4.)
            for key in ('vlm_optimizer', 'world_optimizer', 'action_optimizer', 'aux_optimizer'):
                self.assertIsNone(checkpoint['state'][key])
            self.assertFalse(store.path('phases/r0000/lighting/post.pt').exists())
            retention = json.loads(store.path('retention.json').read_text())
            self.assertGreater(retention['largest_resume_checkpoint_bytes'], 0)
            self.assertGreater(retention['largest_final_checkpoint_bytes'], 0)
            self.assertEqual(json.loads(store.path('status.json').read_text())['state'], 'completed')


if __name__ == '__main__':
    unittest.main()
