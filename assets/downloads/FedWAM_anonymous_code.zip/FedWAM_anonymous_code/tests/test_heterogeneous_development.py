import copy
import unittest
from fedwam.heterogeneous.development import select_adapted_readout, DOMAINS, KINDS


def results():
    output={}
    for kind in KINDS:
        output[kind]={}
        for domain in DOMAINS:
            output[kind][domain]=dict(completed=True,seed=42,domain=domain,steps=4000,
                readout_kind=kind,reference_id='reference',head_sha256='a'*64,
                native_adaptation=dict(step=1000,sha256='b'*64,identity=dict(seed=42,domain=domain,subset='B',horizon=8)),
                samples=dict(train=[dict(record_id=f't{i}',source_group='train',t=i) for i in range(4096)],
                             development=[dict(record_id=f'd{i}',source_group='dev',t=i) for i in range(256)]),
                curves=[dict(step=4000,mse=.8 if kind=='learned_query' else .7,copy_mse=1.)])
    return output


class DevelopmentSelectionTest(unittest.TestCase):
    def test_chooses_one_architecture_by_equal_domain_ratios(self):
        value=select_adapted_readout(results(),reference_id='reference')
        self.assertEqual(value['selected_readout'],'spatial')
        self.assertFalse(value['formal_admission'])

    def test_any_domain_failure_disqualifies_that_candidate(self):
        r=results()
        for kind in KINDS:r[kind]['background']['curves'][-1]['mse']=1.
        self.assertIsNone(select_adapted_readout(r,reference_id='reference')['selected_readout'])

    def test_waits_for_all_predeclared_candidates(self):
        r=results();del r['spatial']['background']
        value=select_adapted_readout(r,reference_id='reference')
        self.assertFalse(value['development_complete'])
        self.assertIsNone(value['selected_readout'])

    def test_rejects_different_copy_baselines_for_identical_samples(self):
        r=results()
        r['spatial']['lighting']['curves'][-1].update(mse=1.2,copy_mse=2.)
        with self.assertRaisesRegex(ValueError,'copy baseline'):
            select_adapted_readout(r,reference_id='reference')

    def test_rejects_incomparable_budgets_samples_native_models_and_metrics(self):
        r=results()
        changes=[('steps',3999),('seed',43),('reference_id','stale')]
        for field,value in changes:
            changed=copy.deepcopy(r);changed['spatial']['lighting'][field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):
                select_adapted_readout(changed,reference_id='reference')
        for mode in ('samples','native','nan','future_leak'):
            changed=copy.deepcopy(r);row=changed['spatial']['lighting']
            if mode=='samples':row['samples']['train'][0]['t']=9000
            elif mode=='native':row['native_adaptation']['sha256']='c'*64
            elif mode=='nan':row['curves'][-1]['mse']=float('nan')
            else:row['samples']['development'][0]['source_group']='train'
            with self.subTest(mode=mode),self.assertRaises(ValueError):
                select_adapted_readout(changed,reference_id='reference')


if __name__=='__main__':unittest.main()
