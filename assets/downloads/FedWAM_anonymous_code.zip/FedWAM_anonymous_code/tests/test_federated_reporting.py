import tempfile
import unittest
from pathlib import Path
import torch
from fedwam import federated_reporting as reporting


def case(i, task='a', category='lighting'):
    return {'variant_id':str(i),'suite':'suite','base_task':task,'name':task,'category':category}


def manifest(rows):
    return {'cases':rows,'E_seen':[rows[0]['variant_id']],'E_confirm':[r['variant_id'] for r in rows[1:]]}


def result(row, client='lighting', seed=42, success=True, error=None):
    return {'case':row,'client':client,'seed':seed,'success':success,'completed':error is None,'error':error}


class ReportingTests(unittest.TestCase):
    def test_missing_and_errors_remain_in_full_denominator(self):
        rows=[case(0),case(1),case(2,'b')]
        values=[result(rows[0]),result(rows[1],success=False,error='simulator failed')]
        report=reporting.build_report(manifest(rows),values,['lighting'],categories=['lighting'])
        cell=report['matrix']['lighting']['lighting']
        self.assertEqual((cell['expected'],cell['successes'],cell['errors'],cell['missing']),(3,1,1,1))
        self.assertAlmostEqual(cell['success_rate'],1/3)
        self.assertFalse(report['complete'])
        self.assertEqual(report['exposure']['E_seen']['success_rate'],1)
        self.assertEqual(report['exposure']['E_confirm']['success_rate'],0)
        self.assertEqual(report['task_macro'],.25)

    def test_duplicate_records_are_rejected(self):
        row=case(0)
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            reporting.build_report(manifest([row]),[result(row),result(row)],['lighting'])

    def test_errors_retry_but_unsuccessful_valid_rollouts_resume(self):
        identity={'checkpoint':'x'}
        self.assertFalse(reporting.reusable_result({'identity':identity,'completed':False,'error':'bad','success':False},identity))
        self.assertTrue(reporting.reusable_result({'identity':identity,'completed':True,'error':None,'success':False},identity))
        with self.assertRaisesRegex(ValueError,'identity'):
            reporting.reusable_result({'identity':{}},identity)

    def test_paired_task_bootstrap_preserves_repeated_clients(self):
        rows=[case(0),case(1,'b')]
        a=[result(r,c,s,True) for r in rows for c in ['lighting','background'] for s in [42,43,44]]
        b=[result(r,c,s,False) for r in rows for c in ['lighting','background'] for s in [42,43,44]]
        comparison=reporting.paired_comparison(a,b,replicates=100)
        self.assertEqual(comparison['paired_cases'],12)
        self.assertEqual(comparison['seed_mean_difference'],1)
        self.assertEqual(comparison['seed_sample_sd'],0)
        self.assertEqual(comparison['task_bootstrap_95_ci'],[1,1])
        self.assertEqual(comparison['independent_tasks'],2)
        self.assertEqual(comparison['variant_clusters'],2)

    def test_prediction_selection_has_declared_complete_scope(self):
        rows=[{'source_group':'g','record_id':'b','continuous_chunk_starts':[0,8]},
              {'source_group':'g','record_id':'a','continuous_chunk_starts':[2]},
              {'source_group':'h','record_id':'c','continuous_chunk_starts':[0,1]}]
        selected=list(reporting.prediction_items(rows,'representative-per-group'))
        self.assertEqual([(r['record_id'],t) for r,t in selected],[('a',2),('c',0)])
        self.assertEqual(len(list(reporting.prediction_items(rows,'all-chunks'))),5)

    def test_final_checkpoint_checks_hash_and_metadata(self):
        from fedwam.io import file_hash
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            checkpoint={'schema':'fedwam.client.v1','identity':{'data':'receipt'},'method':'M1','seed':42,'client':'lighting','done':True,'state':{'world':{},'action':{}}}
            torch.save(checkpoint,root/'client.pt')
            final={'identity':checkpoint['identity'],'method':'M1','seed':42,'clients':{'lighting':{'path':'client.pt','sha256':file_hash(root/'client.pt')}}}
            loaded=reporting.load_final_checkpoint(root,final,'lighting')
            self.assertEqual(loaded['client'],'lighting')
            final['seed']=43
            with self.assertRaisesRegex(ValueError,'seed'):
                reporting.load_final_checkpoint(root,final,'lighting')
            final['seed']=42
            with open(root/'client.pt','ab') as f:f.write(b'changed')
            with self.assertRaisesRegex(ValueError,'checksum'):
                reporting.load_final_checkpoint(root,final,'lighting')

    def test_evaluator_resumes_failures_and_retries_execution_errors(self):
        from fedwam.io import ROOT
        rows=[case(0),case(1),case(2,'b')]
        calls=[]
        def rollout(row, directory):
            calls.append(row['variant_id'])
            directory.mkdir(parents=True,exist_ok=True)
            (directory/'rollout.mp4').write_bytes(b'video')
            if row['variant_id']=='1' and calls.count('1')==1:raise RuntimeError('retry me')
            return {'success':row['variant_id']=='2','video':str(directory/'rollout.mp4')}
        with tempfile.TemporaryDirectory(dir=ROOT/'runs') as tmp:
            from contextlib import redirect_stderr
            import io
            with redirect_stderr(io.StringIO()):
                first=reporting.evaluate_shard(Path(tmp),rows,{'checkpoint':'a'},'lighting',42,0,1,rollout)
            self.assertEqual(first['errors'],1)
            second=reporting.evaluate_shard(Path(tmp),rows,{'checkpoint':'a'},'lighting',42,0,1,rollout)
            self.assertEqual(second['errors'],0)
            self.assertEqual(calls,['0','1','2','1'])
            self.assertEqual(second['assigned'],3)
            with self.assertRaisesRegex(ValueError,'identity'):
                reporting.evaluate_shard(Path(tmp),rows,{'checkpoint':'b'},'lighting',42,0,1,rollout)

    def test_base_task_matching_does_not_split_variants(self):
        rows=[dict(case(0),name='pick_bowl_table_1'),dict(case(1),name='pick_bowl_light_12')]
        sources=[{'suite':'suite','source_file':'pick_bowl_demo.hdf5'}]
        self.assertEqual({r['base_task'] for r in reporting.attach_base_tasks(rows,sources)},{'pick_bowl'})

    def test_cost_ledger_counts_committed_events_once(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'events').mkdir();(root/'commits').mkdir()
            event={'upload_bytes':{'lighting':10,'background':30},'download_bytes':{'lighting':5},'seconds_this_attempt':3.5,'transport':'serialized same-host simulation, not network throughput'}
            (root/'events/round_0000.json').write_text(json.dumps(event))
            (root/'commits/round_0000.json').write_text(json.dumps(event))
            costs=reporting.cost_summary(root)
            self.assertEqual(costs['upload_bytes'],40)
            self.assertEqual(costs['download_bytes'],5)
            self.assertEqual(costs['recorded_attempt_seconds'],3.5)
            self.assertFalse(costs['complete_compute_accounting'])

    def test_prediction_summary_discloses_missing_and_errors(self):
        values=[{'completed':True,'error':None,'future_mse':2.,'persistence_mse':4.,'source_group':'g'},
                {'completed':False,'error':'bad','source_group':'h'}]
        value=reporting.prediction_summary(values,expected=3)
        self.assertEqual((value['valid'],value['errors'],value['missing']),(1,1,1))
        self.assertEqual(value['future_mse_valid_only'],2)
        self.assertFalse(value['complete'])

    def test_bootstrap_does_not_treat_clients_as_independent(self):
        rows=[case(0),case(1,'b')]
        a=[result(r,c,success=c=='lighting') for r in rows for c in ['lighting','background']]
        b=[result(r,c,success=c=='background') for r in rows for c in ['lighting','background']]
        self.assertEqual(reporting.paired_comparison(a,b,replicates=100)['task_bootstrap_95_ci'],[0,0])

    def test_cpu_report_rejects_forged_per_case_identity(self):
        import importlib.util
        import json
        from fedwam.io import ROOT, file_hash, digest
        spec=importlib.util.spec_from_file_location('report_federated',ROOT/'scripts/report_federated.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        row=case(0);m=manifest([row]);m['sha256']='frozen'
        with tempfile.TemporaryDirectory() as tmp:
            run=Path(tmp)
            checkpoint=run/'client.pt';checkpoint.write_bytes(b'opaque-local-checkpoint')
            identity={'method':'M1','seed':42,'mode':'engineering'}
            final={'identity':identity,'method':'M1','seed':42,'clients':{c:{'path':'client.pt','sha256':file_hash(checkpoint)} for c in reporting.CLIENTS}}
            (run/'final.json').write_text(json.dumps(final))
            _,records,report=module.read_run(run,m)
            self.assertEqual(report['expected'],4)
            self.assertEqual(report['missing'],4)
            evaluation={'training_identity':identity,'method':'M1','seed':42,'client':'lighting','manifest_sha256':'frozen',
                        'final_sha256':file_hash(run/'final.json'),'checkpoint_sha256':file_hash(checkpoint)}
            p=run/'evaluation/identities/lighting.json';p.parent.mkdir(parents=True);p.write_text(json.dumps(evaluation))
            r=result(row);r['identity']={'evaluation':'forged','case_sha256':digest(row)}
            p=run/'evaluation/cases/lighting/case/result.json';p.parent.mkdir(parents=True);p.write_text(json.dumps(r))
            with self.assertRaisesRegex(ValueError,'identity'):
                module.read_run(run,m)

    def test_seed_comparison_preserves_budget_and_ignores_config_seed(self):
        a={'method':'M1','seed':42,'config':{'method':'M1','seed':42,'training':{'rounds':20}}}
        b={'method':'M1','seed':43,'config':{'method':'M1','seed':43,'training':{'rounds':20}}}
        self.assertEqual(reporting.run_settings(a),reporting.run_settings(b))
        b['config']['training']['rounds']=2
        self.assertNotEqual(reporting.run_settings(a),reporting.run_settings(b))

    def test_final_checkpoint_accepts_completed_integer_phase_counter(self):
        from fedwam.io import file_hash
        with tempfile.TemporaryDirectory() as tmp:
            run=Path(tmp)
            checkpoint={'schema':'fedwam.client.v1','identity':{},'method':'M1','seed':42,'client':'lighting','phase':'action','done':100,'steps':100,'state':{'world':{},'action':{}}}
            torch.save(checkpoint,run/'client.pt')
            final={'identity':{},'method':'M1','seed':42,'clients':{'lighting':{'path':'client.pt','sha256':file_hash(run/'client.pt')}}}
            self.assertEqual(reporting.load_final_checkpoint(run,final,'lighting')['done'],100)
            checkpoint['done']=99;torch.save(checkpoint,run/'client.pt');final['clients']['lighting']['sha256']=file_hash(run/'client.pt')
            with self.assertRaisesRegex(ValueError,'completed'):
                reporting.load_final_checkpoint(run,final,'lighting')

    def test_cost_ledger_includes_initial_public_queries_once(self):
        import json
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'events').mkdir()
            (root/'events/public_queries_initialization.json').write_text(json.dumps({
                'upload_bytes':{'lighting':100},'download_bytes':{'server':200},'packet_seconds':2.5}))
            (root/'events/round_0000.json').write_text(json.dumps({
                'upload_bytes':{'lighting':10},'download_bytes':{'lighting':20},'server_seconds':1.25,'seconds_this_attempt':3.}))
            value=reporting.cost_summary(root)
            self.assertEqual((value['upload_bytes'],value['download_bytes']),(110,220))
            self.assertEqual(len(value['events']),2)
            self.assertEqual(len(value['rounds']),1)
            self.assertEqual(value['recorded_phase_seconds'],{'packet_seconds':2.5,'server_seconds':1.25})

    def test_video_candidates_are_two_per_cell_independent_of_shards_and_outcomes(self):
        from fedwam.io import ROOT, digest, load
        rows=[case(i, category='lighting' if i<6 else 'background') for i in range(9)]
        expected=set()
        for category in ('lighting','background'):
            selected=sorted([r for r in rows if r['category']==category],
                            key=lambda r:(digest(r['variant_id']),r['variant_id']))[:2]
            expected.update(r['variant_id'] for r in selected)
        for count,success in ((1,True),(3,False)):
            observed={}
            def rollout(row,directory):
                observed[row['variant_id']]=row['record_video']
                directory.mkdir(parents=True,exist_ok=True)
                video=directory/'rollout.mp4'
                if row['record_video']:video.write_bytes(b'video')
                (directory/'actions.npy').write_bytes(b'full trajectory')
                return {'success':success,'actions':12,'video':str(video) if row['record_video'] else None}
            with tempfile.TemporaryDirectory(dir=ROOT/'runs') as tmp:
                out=Path(tmp)
                for index in range(count):
                    reporting.evaluate_shard(out,rows,{'checkpoint':'a'},'lighting',42,index,count,rollout)
                self.assertEqual(set(observed),{r['variant_id'] for r in rows})
                self.assertEqual({key for key,value in observed.items() if value},expected)
                self.assertEqual(len(list(out.glob('cases/lighting/*/rollout.mp4'))),4)
                self.assertEqual(len(list(out.glob('cases/lighting/*/actions.npy'))),len(rows))
                records=[load(path) for path in out.glob('cases/lighting/*/result.json')]
                self.assertEqual(len(records),len(rows))
                self.assertEqual({r['case']['variant_id'] for r in records if r.get('video')},expected)
                self.assertTrue(all(r['completed'] and r['success']==success and r['actions']==12 for r in records))

    def test_run_identity_rejects_changed_protocol_or_model_config(self):
        import json
        from fedwam.io import file_hash
        paths={'data_acceptance_sha256':'manifests/official_four_clients/acceptance.json',
               'checkpoint_sha256':'runtime/lawam_libero_sft/final_model/pytorch_model.pt',
               'normalization_sha256':'runtime/lawam_libero_sft/dataset_statistics.json',
               'protocol_sha256':'configs/protocol.json',
               'model_config_sha256':'runtime/lawam_libero_sft/config.yaml'}
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            for relative in paths.values():
                path=root/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_text('original')
            (root/paths['data_acceptance_sha256']).write_text(json.dumps({
                'identity':'accepted-data','accepted_for_official_four_client_training':True}))
            (root/'training.py').write_text('audited code')
            identity={'schema':'fedwam.run.v1','data_identity':'accepted-data',
                      'code':{'training.py':file_hash(root/'training.py')},
                      **{key:file_hash(root/relative) for key,relative in paths.items()}}
            reporting.verify_run_identity(root,identity)
            for key in ('protocol_sha256','model_config_sha256'):
                with self.subTest(key=key):
                    path=root/paths[key];path.write_text('changed')
                    with self.assertRaisesRegex(ValueError,key):
                        reporting.verify_run_identity(root,identity)
                    path.write_text('original')
