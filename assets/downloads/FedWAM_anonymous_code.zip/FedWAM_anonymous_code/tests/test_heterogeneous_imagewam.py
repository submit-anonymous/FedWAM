import unittest
import numpy as np
import torch
from fedwam.heterogeneous.imagewam import physical_to_dataset_actions, control_features_from_cache, training_frames


class ImageAdapterTest(unittest.TestCase):
    def test_native_resize_accepts_official_float_tolerance(self):
        sample={k:np.full((256,256,3),255,dtype=np.uint8) for k in ('primary','future','wrist','future_wrist')}
        current,future=training_frames(sample)
        torch.testing.assert_close(current,torch.ones_like(current),atol=2e-6,rtol=0)
        torch.testing.assert_close(future,torch.ones_like(future),atol=2e-6,rtol=0)

    def test_native_range_still_rejects_real_invalid_values(self):
        sample={k:np.zeros((256,256,3),dtype=np.uint8) for k in ('primary','future','wrist','future_wrist')}
        for bad in (-1e-4,1.0001,float('nan')):
            with self.subTest(bad=bad),self.assertRaises(ValueError):
                training_frames(sample,lambda video:torch.full_like(video,bad))

    def test_native_augmentation_preserves_camera_and_endpoint_axes(self):
        sample={k:np.full((256,256,3),i*40,dtype=np.uint8) for i,k in enumerate(('primary','future','wrist','future_wrist'))}
        observed=[]
        def augmentation(video):
            observed.append(video.clone())
            return video*.5
        current,future=training_frames(sample,augmentation)
        self.assertEqual(tuple(observed[0].shape),(2,2,3,224,224))
        self.assertEqual(tuple(current.shape),(1,3,224,448))
        self.assertEqual(tuple(future.shape),(1,3,224,448))
        for index,(image,left,right) in enumerate(((current,0,80),(future,40,120))):
            torch.testing.assert_close(image[:,:,:,:224],torch.full((1,3,224,224),left/255.-1.))
            torch.testing.assert_close(image[:,:,:,224:],torch.full((1,3,224,224),right/255.-1.))

    def test_gripper_inverse_matches_official_execution(self):
        physical = np.zeros((8, 7), dtype=np.float32)
        physical[:, -1] = [-1, 1] * 4
        data = physical_to_dataset_actions(physical)
        np.testing.assert_array_equal(-(2 * data[:, -1] - 1), physical[:, -1])
        np.testing.assert_array_equal(data[:, :6], physical[:, :6])
        with self.assertRaises(ValueError):
            physical_to_dataset_actions(np.zeros((16, 7)))

    def test_reads_consumed_values_not_unused_final_video(self):
        v = torch.randn(1, 10, 12, requires_grad=True)
        cache = {'single': [{'v': v}], 'txt_len': 4, 'img_len': 6,
                 'final_video': {'img': torch.full((1, 6, 12), float('nan'))}}
        result = control_features_from_cache(cache)
        torch.testing.assert_close(result, v[:, 4:])
        result.square().sum().backward()
        self.assertEqual(v.grad[:, :4].abs().sum().item(), 0)
        self.assertGreater(v.grad[:, 4:].abs().sum().item(), 0)


if __name__ == '__main__':
    unittest.main()
