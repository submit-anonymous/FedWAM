import tempfile
import unittest
from pathlib import Path

from fedwam.io import ROOT, NATIVE_STORAGE_ROOT, load, save
from scripts.evaluate_native_federated import validate_native_run_path


class NativeStorageTests(unittest.TestCase):
    def test_native_account_run_root_is_allowed_but_other_home_paths_are_not(self):
        root = ROOT/'runs/native'
        root.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=root) as directory:
            path = Path(directory)/'record.json'
            save(path, {'native': True})
            self.assertEqual(load(path), {'native': True})
        with self.assertRaises(ValueError):
            save(Path.home()/'some-other-output'/'record.json', {'native': True})

    def test_new_campaign_uses_data_filesystem(self):
        self.assertEqual(NATIVE_STORAGE_ROOT, ROOT/'runs/native')

    def test_evaluator_requires_native_account_run_root(self):
        root = ROOT/'runs/native'
        self.assertEqual(validate_native_run_path(root/'seed42-native-v6'/'M1'/'seed42'),
                         (root/'seed42-native-v6'/'M1'/'seed42').resolve())
        with self.assertRaises(ValueError):
            validate_native_run_path(Path.home()/'other-experiment')


if __name__ == '__main__':
    unittest.main()
