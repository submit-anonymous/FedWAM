import importlib.util
import tempfile
import unittest
from pathlib import Path
from fedwam.io import file_hash
from fedwam.work_queue import WorkQueue

spec=importlib.util.spec_from_file_location('extra_worker',Path(__file__).resolve().parents[1]/'scripts/federated_extra_worker.py')
extra=importlib.util.module_from_spec(spec)
spec.loader.exec_module(extra)

class ExtraWorkerTests(unittest.TestCase):
 def test_extension_requires_unchanged_plan_and_extra_worker(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);plan=root/'plan.json';plan.write_text('{}')
   code=root/'worker.py';code.write_text('original')
   extension={'base_plan_sha256':file_hash(plan),'max_total_gpus':6,'extra_worker_ids':[4,5],'code':{'worker.py':file_hash(code)}}
   extra.validate_extension(root,plan,extension,4)
   with self.assertRaises(ValueError):extra.validate_extension(root,plan,extension,0)
   code.write_text('changed')
   with self.assertRaises(ValueError):extra.validate_extension(root,plan,extension,4)
   code.write_text('original');plan.write_text('{"changed":true}')
   with self.assertRaises(ValueError):extra.validate_extension(root,plan,extension,5)
 def test_six_workers_claim_distinct_tasks_and_resume_same_lease(self):
  with tempfile.TemporaryDirectory() as tmp:
   tasks=[{'id':str(i),'kind':'train','depends':[],'argv':['true']} for i in range(8)]
   queue=WorkQueue(Path(tmp),tasks)
   claimed=[queue.claim(f'worker-{i}')['id'] for i in range(6)]
   self.assertEqual(len(set(claimed)),6)
   self.assertEqual(queue.claim('worker-4')['id'],claimed[4])
   queue.finish('worker-4',claimed[4],0)
   self.assertNotIn(queue.claim('worker-4')['id'],claimed)
