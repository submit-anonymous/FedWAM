import io
import unittest
from fedwam import data_contracts as d

class DataContracts(unittest.TestCase):
    def test_range_response_rejects_whole_file_or_wrong_offset(self):
        self.assertEqual(d.checked_range(io.BytesIO(b'ab'),'bytes 4-5/10',4,2,10),b'ab')
        for header,body in [('bytes 0-1/10',b'ab'),('bytes 4-5/10',b'a'),('bytes 4-5/10',b'abc')]:
            with self.assertRaises(ValueError):d.checked_range(io.BytesIO(body),header,4,2,10)
    def test_raw_environment_bucket_is_not_an_invented_client(self):
        self.assertEqual(d.source_category('light'),'lighting')
        self.assertEqual(d.source_category('camera_view'),'camera_pose')
        self.assertIsNone(d.source_category('env'))
        with self.assertRaises(ValueError):d.source_category('unknown')
    def test_shared_sources_cannot_cross_split_roles(self):
        rows=[{'source_group':'a','split':'train'},{'source_group':'a','split':'pred_test'}]
        with self.assertRaises(ValueError):d.assert_group_disjoint(rows)
        d.assert_group_disjoint([{'source_group':'a','split':'train'},{'source_group':'a','split':'train'}])
    def test_chunk_endpoint_requires_future_observation(self):
        self.assertEqual(list(d.valid_times(9)),[0])
        self.assertEqual(list(d.valid_times(8)),[])
        self.assertEqual(list(d.valid_times(12)),[0,1,2,3])
    def test_crc_and_size_reject_corrupt_existing_shard(self):
        import tempfile,zlib
        from pathlib import Path
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'shard';p.write_bytes(b'abcdef')
            self.assertEqual(d.verify_file(p,6,zlib.crc32(b'abcdef'))['bytes'],6)
            with self.assertRaises(ValueError):d.verify_file(p,6,0)
            with self.assertRaises(ValueError):d.verify_file(p,7,zlib.crc32(b'abcdef'))
if __name__=='__main__':unittest.main()
