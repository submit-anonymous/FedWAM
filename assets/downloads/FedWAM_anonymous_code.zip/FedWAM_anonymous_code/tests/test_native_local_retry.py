import unittest
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch
from scripts import native_local_retry as retry

from scripts.native_local_retry import retry_candidates


class RelocatedNativeRetryTests(unittest.TestCase):
    def test_reads_relocated_receipts_and_retries_only_failed_client(self):
        class EndIteration(Exception):
            pass
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            local = root/'relocated-local'
            output = root/'retry'
            identity = {'seed': 42}
            for client in retry.CLIENTS:
                path = local/'engineering'/client
                path.mkdir(parents=True)
                if client == 'background':
                    state = {'state': 'failed', 'error': 'Allocated GPU already occupied or insufficient memory'}
                else:
                    state = {'state': 'completed'}
                    (path/'verification.json').write_text(json.dumps({'passed': True, 'identity': identity}))
                (path/'status.json').write_text(json.dumps(state))
            with patch.dict(os.environ, SLURM_JOB_ID='test'), \
                 patch.object(retry, 'ROOT', root), \
                 patch.object(retry, 'NATIVE_LOCAL_STORAGE_ROOT', local), \
                 patch.object(retry, 'OUT', output), \
                 patch.object(retry, 'run_identity', return_value=identity), \
                 patch.object(retry, 'queue_rows', return_value=[]), \
                 patch.object(retry.subprocess, 'check_output', return_value='12345\n'), \
                 patch.object(retry.time, 'sleep', side_effect=EndIteration):
                with self.assertRaises(EndIteration):
                    retry.main()
            status = json.loads((output/'status.json').read_text())
            self.assertEqual(status['done'], ['camera_pose', 'lighting', 'sensor_noise'])
            self.assertEqual(status['pending_retries'], ['background'])
            self.assertEqual(status['attempts'], {'background': 1})


class NativeLocalRetryTests(unittest.TestCase):
    def test_only_retries_known_gpu_occupancy_after_slots_open(self):
        states = {'lighting': {'state': 'running'},
                  'camera_pose': {'state': 'failed', 'error':
                      "RuntimeError('Allocated GPU already occupied or insufficient memory')"},
                  'sensor_noise': {'state': 'completed'},
                  'background': {'state': 'failed', 'error':
                      "RuntimeError('Allocated GPU already occupied or insufficient memory')"}}
        self.assertEqual(retry_candidates(states, active=1, done={'sensor_noise'},
                                          attempts={}, limit=3, max_active=2),
                         ['camera_pose'])
        states['background']['error'] = "ValueError('Malformed batch')"
        with self.assertRaises(ValueError):
            retry_candidates(states, active=0, done={'sensor_noise'},
                             attempts={}, limit=3, max_active=2)


if __name__ == '__main__':
    unittest.main()
