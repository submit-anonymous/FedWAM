import json
import tempfile
import unittest
from pathlib import Path

from scripts.native_campaign import capacity_requirement, prune_engineering_weights, storage_admission


class NativeDiskAuditTests(unittest.TestCase):
    def test_projection_includes_all_final_models_and_active_resume_checkpoints(self):
        gib = 1024**3
        required = capacity_requirement(largest_resume=10*gib,
                                        largest_final=4*gib,
                                        final_models=37)
        # Four previous post states, four current pre states, four current
        # post states, and four concurrent atomic temporary checkpoints.
        self.assertEqual(required, (16*10+37*4+80)*gib)

    def test_engineering_weights_prune_only_after_complete_gate(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            method = root/'M1'
            method.mkdir()
            (method/'final.json').write_text('{}')
            (method/'weights.pt').write_bytes(b'weights')
            with self.assertRaises(ValueError):
                prune_engineering_weights(root, ['M1'], {'passed': False})
            self.assertTrue((method/'weights.pt').exists())
            result = prune_engineering_weights(root, ['M1'],
                     {'passed': True, 'methods_passed': ['M1']})
            self.assertEqual(result['removed_bytes'], 7)
            self.assertFalse((method/'weights.pt').exists())
            self.assertTrue((method/'final.json').exists())
            self.assertEqual(json.loads((root/'weights_pruned_after_gate.json').read_text())
                             ['state'], 'completed')

    def test_low_storage_stays_waiting_without_admitting_gpu_work(self):
        gib=1024**3
        report=storage_admission(180*gib,14*gib,5*gib)
        self.assertFalse(report['passed'])
        self.assertEqual(report['state'],'waiting_for_storage')
        self.assertEqual(report['required_free_bytes'],(16*14+37*5+80)*gib)
        self.assertEqual(report['missing_bytes'],report['required_free_bytes']-180*gib)
        self.assertTrue(storage_admission(500*gib,14*gib,5*gib)['passed'])

    def test_resume_does_not_reserve_all_final_models_a_second_time(self):
        gib=1024**3
        report=storage_admission(180*gib,14*gib,5*gib,previously_admitted=True)
        self.assertTrue(report['passed'])
        self.assertEqual(report['required_free_bytes'],80*gib)
        self.assertFalse(storage_admission(79*gib,14*gib,5*gib,previously_admitted=True)['passed'])


if __name__ == '__main__':
    unittest.main()
