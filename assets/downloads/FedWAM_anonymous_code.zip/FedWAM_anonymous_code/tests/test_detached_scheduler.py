import importlib.util,json,tempfile,unittest,sys
from pathlib import Path
from unittest.mock import patch
from fedwam.round_runtime import atomic_json
from fedwam.detached_engine import DetachedEngine,DependencyPending
from test_parallel_engine import make_backend,STATS
from test_lawam_federation_integration import configuration,FixtureData,encoded,CLIENTS

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import detached_campaign as campaign

class SchedulerTests(unittest.TestCase):
 def test_independent_jobs_complete_federation_without_simultaneous_allocation(self):
  with tempfile.TemporaryDirectory() as tmp,patch('torch.cuda.is_available',return_value=False),patch('fedwam.lawam_federation.OfficialDataset',FixtureData),patch('fedwam.lawam_federation.encode',encoded),patch('fedwam.lawam_federation.load',return_value=STATS):
   root=Path(tmp);cfg=configuration('M2');ident={'method':'M2','seed':42,'mode':'engineering'};launched=[]
   def submit(state,key,args,path,marker):
    client=args[args.index('--client')+1];entry=state['jobs'][key];job=str(len(launched)+1)
    entry['job']=job;atomic_json(path,state);launched.append((client,job))
    engine=DetachedEngine(root,ident,cfg,make_backend(root,cfg),client,state['attempt'])
    result=dict(token=entry['token'],attempt=state['attempt'])
    try:ref=engine.run_client()
    except DependencyPending as error:result.update(state='waiting_dependency',wait=error.name)
    else:
     result.update(state='training_completed')
     atomic_json(root/f'client_verification/{client}.json',dict(passed=True,identity=ident,attempt=state['attempt'],ref=ref,module_updates={'world':True,'action':True},frozen_sha256='fixture'))
    atomic_json(root/f'client_job_state/{client}.json',result)
    return job
   with patch.object(campaign,'detached_identity',return_value=ident),patch.object(campaign,'queue_jobs',return_value={}),patch.object(campaign,'ensure_job',side_effect=submit),patch.object(campaign.time,'sleep'),patch.object(campaign,'compact_completed_run'):
    final=campaign.run_method(cfg,root)
   self.assertEqual(set(final['clients']),set(CLIENTS));self.assertGreater(len(launched),4)
   self.assertTrue(json.loads((root/'verification.json').read_text())['passed'])
 def test_lost_submission_reply_reuses_held_job(self):
  with tempfile.TemporaryDirectory() as tmp:
   state={'jobs':{'client-1':{'job':None,'token':'fixed'}}};rows={'123':dict(comment='marker',reason='JobHeldUser')}
   with patch.object(campaign,'queue_jobs',return_value=rows),patch.object(campaign,'command') as command,patch.object(campaign.subprocess,'run') as run:
    job=campaign.ensure_job(state,'client-1',['ignored'],Path(tmp)/'state.json','marker')
   self.assertEqual(job,'123');command.assert_not_called();run.assert_called_once_with(['scontrol','release','123'],check=True)
