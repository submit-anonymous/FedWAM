import tempfile
import unittest
from pathlib import Path

from fedwam.native_engine import NativeDetachedEngine


class NativeDetachedEngineTests(unittest.TestCase):
    def engine(self, root, method='M1'):
        cfg = {'method': method, 'seed': 43, 'clients': ['a', 'b'],
               'training': {'final_world_action_only': 0}, 'prune': True,
               'server': {'replay_rounds': 4}}
        return NativeDetachedEngine(root, {'id': 'native'}, cfg, None, 'a', 'attempt')

    def test_zero_action_phase_reuses_post_without_checkpoint(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = self.engine(directory)
            ref = engine.store.write('phases/r0000/a/post.pt', {'state': {'updates': 2}})
            from fedwam.round_runtime import atomic_json
            atomic_json(engine.store.path('phases/r0000/a/post.json'),
                        {'steps': 1, 'artifact': ref})
            state, actual = engine.phase({'updates': 2}, 0, 'action', 0, {'kind': 'none'})
            self.assertEqual(state, {'updates': 2})
            self.assertEqual(actual, ref)
            self.assertFalse(engine.store.path('phases/r0000/a/action.pt').exists())

    def test_after_private_commit_only_latest_post_is_kept(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = self.engine(directory)
            for round in (-1, 0, 1):
                for phase in ('warmup',) if round == -1 else ('pre', 'post'):
                    p = engine.store.path(f'phases/r{round:04d}/a/{phase}.pt')
                    p.parent.mkdir(parents=True, exist_ok=True)
                    p.write_bytes(b'x')
            engine.prune_private(1)
            self.assertFalse(engine.store.path('phases/r-001/a').exists())
            self.assertFalse(engine.store.path('phases/r0000/a').exists())
            self.assertFalse(engine.store.path('phases/r0001/a/pre.pt').exists())
            self.assertTrue(engine.store.path('phases/r0001/a/post.pt').exists())


if __name__ == '__main__':
    unittest.main()
