import hashlib,json,tempfile,unittest
from pathlib import Path
from fedwam.official_dataset import OfficialDataset

class AcceptedDatasetTests(unittest.TestCase):
    def fixture(self,root):
        def write(rel,value):
            p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value));return hashlib.sha256(p.read_bytes()).hexdigest()
        identity='receipt'
        row={'record_id':'one','source_group':'g','client':'background','split':'train','suite':'s','source_file':'task','continuous_chunk_starts':[0]}
        file='manifests/official_four_clients/background/train.json'
        sha=write(file,{'identity':identity,'client':'background','split':'train','rows':[row]})
        assignment='manifests/official_four_clients/source_assignment.json'
        ash=write(assignment,{'identity':identity,'assignments':{'g':'train'}})
        write('manifests/official_four_clients/acceptance.json',{'identity':identity,'accepted_for_official_four_client_training':True,'files':{file:sha,assignment:ash},'code':{}})
        return root/file
    def test_requires_acceptance_receipt(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(FileNotFoundError):OfficialDataset(Path(tmp),'background','train',42)
    def test_manifest_integrity_checked_before_sampling(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);p=self.fixture(root)
            data=OfficialDataset(root,'background','train',42)
            self.assertEqual(data.sampler.draw(0)[0]['record_id'],'one')
            p.write_text(p.read_text()+' ')
            with self.assertRaisesRegex(ValueError,'checksum'):OfficialDataset(root,'background','train',42)
    def test_unsupported_language_client_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):OfficialDataset(Path(tmp),'language','train',42)
