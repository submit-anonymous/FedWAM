import unittest
import tempfile
import hashlib
from pathlib import Path
import torch
from fedwam.heterogeneous.readout_diagnostics import error_row, summarize, verified_readout, DeterministicSpatialReadout
from fedwam.heterogeneous.spatial_readout import SpatialFutureReadout


class DiagnosticMetricsTest(unittest.TestCase):
    def test_deterministic_spatial_implementation_preserves_values_and_gradients(self):
        torch.manual_seed(42)
        original=SpatialFutureReadout(8,output_dim=4,width=16,heads=4)
        alternate=DeterministicSpatialReadout(8,output_dim=4,width=16,heads=4)
        alternate.load_state_dict(original.state_dict())
        x=torch.randn(2,392,8,requires_grad=True);y=x.detach().clone().requires_grad_()
        a=original(x);b=alternate(y)
        torch.testing.assert_close(a,b,atol=1e-6,rtol=1e-5)
        a.square().sum().backward();b.square().sum().backward()
        torch.testing.assert_close(x.grad,y.grad,atol=1e-6,rtol=1e-4)

    def test_saved_head_must_match_digest_and_native_identity(self):
        value=dict(seed=42,domain='background',reference_id='ref',native_adaptation={'step':1000},horizon_original_steps=8)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'head.pt';torch.save(value,path)
            receipt=dict(value,head_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
            self.assertEqual(verified_readout(path,receipt),value)
            with self.assertRaises(ValueError):verified_readout(path,dict(receipt,head_sha256='0'*64))
            with self.assertRaises(ValueError):verified_readout(path,dict(receipt,native_adaptation={'step':999}))

    def test_copy_is_zero_predicted_change_and_has_correct_token_errors(self):
        current=torch.zeros(4,2);future=current.clone();future[0]=2
        row=error_row(current,current,future,torch.tensor([4.,0.,0.,0.]))
        self.assertEqual(row['mse'],1.)
        self.assertEqual(row['copy_mse'],1.)
        self.assertEqual(row['current_mse'],0.)
        self.assertEqual(row['delta_cosine'],0.)
        self.assertEqual(row['high_feature_change_mse'],4.)
        self.assertEqual(row['low_feature_change_mse'],0.)
        self.assertEqual(row['high_pixel_change_mse'],4.)

    def test_exact_future_and_weighted_token_partition(self):
        current=torch.zeros(4,2);future=torch.arange(8.).reshape(4,2)
        row=error_row(future,current,future,torch.arange(4.))
        self.assertEqual(row['mse'],0.)
        self.assertAlmostEqual(row['delta_cosine'],1.,places=6)
        self.assertAlmostEqual(row['copy_mse'],.25*row['high_feature_change_copy_mse']+.75*row['low_feature_change_copy_mse'],places=6)

    def test_task_source_balancing_and_future_errors_are_not_averaged_by_count(self):
        row=error_row(torch.zeros(4,2),torch.zeros(4,2),torch.ones(4,2),torch.zeros(4))
        rows=[dict(row,task='a',source_group='a',mse=1.) for _ in range(3)]
        rows.append(dict(row,task='b',source_group='b',mse=3.))
        self.assertAlmostEqual(summarize(rows)['mse'],2.)

    def test_nonfinite_and_wrong_shapes_fail(self):
        for value in (torch.full((4,2),float('nan')),torch.ones(3,2)):
            with self.assertRaises(ValueError):error_row(value,torch.zeros(4,2),torch.ones(4,2),torch.ones(4))


if __name__=='__main__':unittest.main()
