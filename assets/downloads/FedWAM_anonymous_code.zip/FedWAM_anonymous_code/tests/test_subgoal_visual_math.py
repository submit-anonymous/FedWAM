import sys
from pathlib import Path
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from subgoal_visual_math import cosine_map,fit_pca,project_pca

class VisualMathTests(unittest.TestCase):
    def test_cosine_is_patch_correspondence_not_norm(self):
        q=np.array([1.,0.,0.]);x=np.array([[0,2,0],[3,0,0],[-1,0,0]])
        np.testing.assert_allclose(cosine_map(q,x),[0,1,-1])
    def test_pca_is_fixed_across_frames(self):
        x=np.random.default_rng(42).normal(size=(32,8))
        p=fit_pca(x)
        one=project_pca(x[:1],p)[0];sequence=project_pca(x[[4,0,9]],p)[1]
        np.testing.assert_allclose(one,sequence,atol=1e-12)
        np.testing.assert_allclose(p['basis']@p['basis'].T,np.eye(3),atol=1e-10)
    def test_invalid_values_rejected(self):
        with self.assertRaises(ValueError):cosine_map(np.zeros(3),np.eye(3))
        with self.assertRaises(ValueError):fit_pca(np.full((8,4),np.nan))

if __name__=='__main__':unittest.main()
