import unittest
import tempfile
import os
from pathlib import Path
from unittest.mock import patch

from fedwam.io import ROOT, NATIVE_STORAGE_ROOT
from fedwam.native_federation import native_config
from fedwam.native_execution import native_identity

from scripts.native_campaign import (make_native_plan, native_local_dependency,
                                     prune_verified_engineering_method)
from fedwam.round_runtime import atomic_json
from scripts import native_campaign


class NativeCampaignTests(unittest.TestCase):
    def test_evaluation_dispatch_uses_the_seed_from_the_validated_plan(self):
        class StopAfterGate(Exception):
            pass
        observed = []
        def config(method, seed, mode):
            observed.append((method, seed, mode))
            return {'seed': seed}
        with patch.dict(os.environ, SLURM_JOB_ID='test'), \
             patch.object(native_campaign.base, 'validated_plan', return_value={'seeds': [42]}), \
             patch.object(native_campaign.base, 'resolved_config', side_effect=config), \
             patch.object(native_campaign.base, 'load', return_value={}), \
             patch.object(native_campaign.base, 'check_gate', side_effect=StopAfterGate):
            with self.assertRaises(StopAfterGate):
                native_campaign.base.evaluate(0)
        self.assertEqual(observed, [('M1', 42, 'formal')])

    def test_evaluation_binding_preserves_seed_mode_argument_order(self):
        with patch.dict(native_campaign.base.__dict__):
            native_campaign._bind_existing_controller()
            cfg = native_campaign.base.resolved_config('M1', 42, 'formal')
            self.assertEqual(cfg, native_config('M1', 'formal', seed=42))

    def test_prunes_only_verified_engineering_weights(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            weight = root/'checkpoints/final/client.pt'
            weight.parent.mkdir(parents=True)
            weight.write_bytes(b'weights')
            identity = {'code': 'v4'}
            atomic_json(root/'verification.json', {'passed': True, 'identity': identity})
            atomic_json(root/'final.json', {'identity': identity})
            atomic_json(root/'retention.json', {'state': 'completed'})
            with self.assertRaises(ValueError):
                prune_verified_engineering_method(root, {'code': 'wrong'})
            self.assertTrue(weight.exists())
            receipt = prune_verified_engineering_method(root, identity)
            self.assertEqual(receipt['removed_bytes'], 7)
            self.assertFalse(weight.exists())

    def test_seed42_plan_uses_native_evaluation_and_training_budget(self):
        plan = make_native_plan(shards=2)
        self.assertEqual(plan['seeds'], [42])
        self.assertEqual(plan['training_jobs'], 10)
        self.assertEqual(plan['rollout_cases'], 37*10030)
        self.assertEqual(plan['expected_prediction_inputs'], 1584830)
        self.assertEqual(plan['max_gpu_workers'], 4)
        self.assertEqual(plan['root'], str(NATIVE_STORAGE_ROOT/'seed42-native-v6'))
        self.assertTrue(all(run.startswith(plan['root']+'/') for run in plan['runs']))
        self.assertEqual(len([t for t in plan['tasks'] if t['kind'] == 'detached_train']), 10)
        eval_tasks = [t for t in plan['tasks'] if t['kind'] in ('rollout', 'prediction')]
        self.assertTrue(eval_tasks)
        self.assertTrue(all(str(ROOT/'scripts/evaluate_native_federated.py') in t['argv']
                            for t in eval_tasks))
        self.assertTrue(all(t['argv'][t['argv'].index('--run')+1].startswith(plan['root']+'/')
                            for t in eval_tasks))
        self.assertEqual(plan['execution_code'], native_identity(native_config('M1', 'engineering'))['code'])

    def test_new_campaign_waits_for_queued_native_local_acceptance(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch('scripts.native_campaign.base.command',
                       return_value='9320|fwfull-native-summary\n9319|fwfull-native-local'):
                self.assertEqual(native_local_dependency(Path(directory)/'summary.json'), '9320')

    def test_new_campaign_waits_for_bounded_local_retry_controller(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch('scripts.native_campaign.base.command',
                       return_value='9346|fwfull-native-local-retry'):
                self.assertEqual(native_local_dependency(Path(directory)/'summary.json'), '9346')


if __name__ == '__main__':
    unittest.main()
