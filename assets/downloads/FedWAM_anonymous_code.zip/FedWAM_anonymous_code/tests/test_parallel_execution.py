import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fedwam.work_queue import WorkQueue
from fedwam.parallel_execution import claim_filtered,remaining,check_gate
class ExecutionTests(unittest.TestCase):
 def test_evaluation_worker_cannot_steal_parallel_training(self):
  with tempfile.TemporaryDirectory() as tmp:
   q=WorkQueue(Path(tmp),[{'id':'t','kind':'parallel_train','method':'M1','depends':[],'argv':[]},{'id':'e','kind':'rollout','depends':['t'],'argv':[]}])
   self.assertIsNone(claim_filtered(q,'eval',['rollout']))
   self.assertEqual(claim_filtered(q,'train',['parallel_train'],'M1')['id'],'t')
   q.finish('train','t',0)
   self.assertFalse(remaining(q,['parallel_train'],'M1'))
   self.assertEqual(claim_filtered(q,'eval',['rollout'])['id'],'e')
 def test_other_seed_and_stale_execution_receipt_cannot_pass(self):
  from fedwam.experiment_config import METHODS
  cfg={'seed':43};expected={k:'bound' for k in ('code','data_identity','checkpoint_sha256','normalization_sha256','protocol_sha256','model_config_sha256','execution')}
  receipt=dict(expected,passed=True,mode='real_parallel_client_engineering',seed=43,methods_passed=list(METHODS))
  with patch('fedwam.parallel_execution.formal_gate'),patch('fedwam.parallel_execution.identity'),patch('fedwam.parallel_execution.load'),patch('fedwam.parallel_execution.parallel_identity',return_value=expected):
   check_gate(cfg,receipt)
   with self.assertRaises(ValueError):check_gate({'seed':42},receipt)
   receipt['execution']='changed'
   with self.assertRaises(ValueError):check_gate(cfg,receipt)
