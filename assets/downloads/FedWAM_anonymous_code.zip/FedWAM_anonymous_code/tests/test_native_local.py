import tempfile,unittest
from pathlib import Path
import numpy as np
import torch
from fedwam.native_local import (local_contract,make_native_sample,
                                 auxiliary_parameters,auxiliary_state,restore_auxiliary_state)

class NativeLocalTests(unittest.TestCase):
 def test_contract_tracks_pinned_official_recipe_and_post_sft_scope(self):
  x=local_contract()
  self.assertEqual((x['steps'],x['lr_warmup'],x['per_device_batch'],x['lr']),
                   (25000,1500,32,1e-4))
  self.assertEqual((x['optimizer_betas'],x['weight_decay']),([.9,.95],1e-8))
  self.assertTrue(x['latent_action_distill'])
  self.assertTrue(x['detach_future_feature'])
  self.assertEqual(x['source_checkpoint_kind'],'LIBERO SFT')
 def test_native_sample_is_exactly_current_and_chunk_end_frame(self):
  current=np.zeros((256,256,3),dtype=np.uint8);future=np.full_like(current,19)
  sample={'primary':current,'future':future,'wrist':current,'actions':np.zeros((8,7),dtype=np.float32),
          'lang':'move','future_t':18,'t':10}
  stats={'min':[-1]*7,'max':[1]*7,'mask':[True]*6+[False]}
  out=make_native_sample(sample,stats)
  self.assertEqual(tuple(out['primary_videos'].shape),(1,2,3,256,256))
  self.assertEqual(int(out['primary_videos'][0,0,0,0,0]),0)
  self.assertEqual(int(out['primary_videos'][0,1,0,0,0]),19)
  self.assertEqual(tuple(out['action'].shape),(8,7))
  self.assertEqual(out['lang'],'move')
 def test_official_trainable_auxiliary_queries_are_checkpointed(self):
  class Backend(torch.nn.Module):
   def __init__(self):
    super().__init__();self.vlm=torch.nn.Linear(1,1);self.flow=torch.nn.Linear(1,1)
    self.lam=torch.nn.Module();self.lam.decoder=torch.nn.Linear(1,1)
    self.lam.encoder=torch.nn.Linear(1,1);self.lam.encoder.requires_grad_(False)
    self.act_query=torch.nn.Parameter(torch.ones(1));self.vlm_to_lam=torch.nn.Linear(1,1)
  class Policy(torch.nn.Module):
   def __init__(self):
    super().__init__();self.policy_backend=Backend()
  policy=Policy();aux=auxiliary_parameters(policy)
  self.assertIn('policy_backend.act_query',aux)
  self.assertIn('policy_backend.vlm_to_lam.weight',aux)
  self.assertNotIn('policy_backend.lam.encoder.weight',aux)
  saved=auxiliary_state(policy)
  with torch.no_grad():policy.policy_backend.act_query.zero_()
  restore_auxiliary_state(policy,saved)
  self.assertEqual(policy.policy_backend.act_query.item(),1.)
