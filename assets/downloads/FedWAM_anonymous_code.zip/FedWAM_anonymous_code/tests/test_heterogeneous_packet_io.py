import tempfile
from pathlib import Path
import unittest
import torch
from fedwam.heterogeneous.packet_io import save_packet, load_packet, masked_language
from test_heterogeneous_packets import packet


class PacketIOTest(unittest.TestCase):
    def test_bytes_budget_and_corruption(self):
        shapes=dict(tokens=4,dim=8,language_dim=6,state_dim=3)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'packet.pt'
            with self.assertRaises(ValueError):
                save_packet(path,packet(),round_id=1,max_bytes=1,shapes=shapes)
            self.assertFalse(path.exists())
            receipt=save_packet(path,packet(),round_id=1,max_bytes=100000,shapes=shapes)
            self.assertEqual(receipt['bytes'],path.stat().st_size)
            self.assertEqual(load_packet(path,round_id=1,shapes=shapes)['client'],'a')
            with path.open('ab') as out:out.write(b'changed')
            with self.assertRaises(ValueError):load_packet(path,round_id=1,shapes=shapes)

    def test_masked_language_excludes_padding(self):
        x=torch.tensor([[[1.,2.],[3.,4.],[999.,999.]]])
        mask=torch.tensor([[True,True,False]])
        torch.testing.assert_close(masked_language(x,mask),torch.tensor([[2.,3.]]))
        with self.assertRaises(ValueError):masked_language(x,torch.zeros_like(mask))

    def test_h8_packet_rejects_other_horizon(self):
        from fedwam.heterogeneous.packets import validate_packet
        p=packet();p['query']['horizon'].fill_(16)
        with self.assertRaises(ValueError):
            validate_packet(p,round_id=1,shapes=dict(tokens=4,dim=8,language_dim=6,state_dim=3))
