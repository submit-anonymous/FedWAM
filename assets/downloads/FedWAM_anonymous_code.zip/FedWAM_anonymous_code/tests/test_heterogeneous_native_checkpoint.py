import random
import tempfile
from pathlib import Path
import unittest
import numpy as np
import torch
from fedwam.heterogeneous.native_checkpoint import save_training,restore_training


class NativeCheckpointTest(unittest.TestCase):
    def test_resume_keeps_optimizer_scheduler_and_all_random_streams(self):
        def setup():
            torch.manual_seed(42);np.random.seed(42);random.seed(42)
            model=torch.nn.Linear(3,2)
            optim=torch.optim.AdamW(model.parameters(),lr=.01)
            scheduler=torch.optim.lr_scheduler.LinearLR(optim,start_factor=.1,total_iters=10)
            return model,optim,scheduler
        def step(model,optim,scheduler):
            x=torch.randn(4,3)+np.random.random()+random.random()
            optim.zero_grad();model(x).square().mean().backward();optim.step();scheduler.step()
        model,optim,scheduler=setup()
        for _ in range(4):step(model,optim,scheduler)
        reference={k:v.detach().clone() for k,v in model.state_dict().items()}
        model,optim,scheduler=setup()
        for _ in range(2):step(model,optim,scheduler)
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'latest.pt';identity={'batch':32,'seed':42}
            save_training(path,{'mot':model},optim,scheduler,step=2,identity=identity)
            model,optim,scheduler=setup()
            restored=restore_training(path,{'mot':model},optim,scheduler,identity=identity)
            self.assertEqual(restored,2)
            for _ in range(2):step(model,optim,scheduler)
            for k,v in model.state_dict().items():torch.testing.assert_close(v,reference[k],rtol=0,atol=0)
            with self.assertRaises(ValueError):restore_training(path,{'mot':model},optim,scheduler,identity={'batch':16})
