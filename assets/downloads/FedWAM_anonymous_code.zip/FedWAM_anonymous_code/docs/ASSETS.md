# External Assets

Use the official instructions from the source commits in
`third_party/upstreams.json` for model access and licensing. Keep access credentials in the local authentication environment.

| Asset | Expected project location / purpose |
|---|---|
| LaWAM LIBERO SFT | `assets/lawam_libero_sft`; released checkpoint, config, normalization statistics |
| LaWAM LAM | `assets/lawam_lam`; native world-model config/checkpoint |
| DINOv3 ViT-B/16 | `assets/dinov3-vitb16-pretrain-lvd1689m`; shared visual features |
| Qwen3-VL-2B | `assets/qwen3-vl-2b`; LaWAM conditioning |
| ImageWAM FLUX.2-4B LIBERO | `assets/imagewam/imagewam_flux2_4b_libero`; native action/world checkpoint |
| FLUX.2 Klein base 4B, FLUX.2-dev VAE, Qwen3-4B | ImageWAM native dependencies; configure using its pinned source and local evaluation config |
| LIBERO-Plus official RLDS | `data/libero_plus_rlds/libero_mix/1.0.0`; 1,024 shards in the observed release |
| LIBERO-Plus simulator assets | Locally configured benchmark asset, BDDL, and initial-state paths |
| Original LIBERO data/benchmark | Separate clean evaluation protocol; not interchangeable with PLUS domain slices |

Install weights, datasets, and native libraries from their official distributions.
Verify model shapes, normalization, hashes, and simulator behavior during local
setup before inference or training.
